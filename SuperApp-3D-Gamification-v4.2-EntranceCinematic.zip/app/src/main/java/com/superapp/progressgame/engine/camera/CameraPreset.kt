package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position

data class CameraPreset(
    val id: String,
    val eye: Position,
    val target: Position,
    val minRadius: Float,
    val maxRadius: Float,
)

object CameraPresets {
    // V4.2 authored entrance sequence. The first frame is deliberately outside the gate,
    // centered on Gate -> Fountain -> Mansion so the user enters the world instead of
    // spawning in the middle of the plaza.
    val EntranceFront = CameraPreset(
        id = "entrance_front",
        eye = Position(x = 0f, y = 2.20f, z = 19.4f),
        target = Position(x = 0f, y = 1.18f, z = -1.8f),
        minRadius = 14.0f,
        maxRadius = 23.0f,
    )

    val EntranceApproach = CameraPreset(
        id = "entrance_approach",
        eye = Position(x = 0f, y = 2.26f, z = 14.1f),
        target = Position(x = 0f, y = 1.14f, z = -1.7f),
        minRadius = 10.5f,
        maxRadius = 18.5f,
    )

    val EntrancePass = CameraPreset(
        id = "entrance_pass",
        eye = Position(x = 0f, y = 2.55f, z = 9.0f),
        target = Position(x = 0f, y = 1.10f, z = -1.8f),
        minRadius = 7.8f,
        maxRadius = 15.2f,
    )

    // Main playable hero shot after the entrance reveal.
    val Hero = CameraPreset(
        id = "hero",
        eye = Position(x = 4.8f, y = 3.25f, z = 6.6f),
        target = Position(x = 0f, y = 1.12f, z = -2.0f),
        minRadius = 7.8f,
        maxRadius = 15.0f,
    )

    val Overview = CameraPreset(
        id = "overview",
        eye = Position(x = 7.6f, y = 5.10f, z = 8.8f),
        target = Position(x = 0f, y = 1.10f, z = -2.0f),
        minRadius = 10.0f,
        maxRadius = 20.0f,
    )

    val Fountain = CameraPreset(
        id = "fountain_main",
        eye = Position(x = 4.65f, y = 3.05f, z = 3.85f),
        target = Position(x = 0f, y = 0.98f, z = -1.2f),
        minRadius = 4.7f,
        maxRadius = 9.2f,
    )

    val Mansion = CameraPreset(
        id = "mansion_main",
        eye = Position(x = 5.2f, y = 3.35f, z = -2.35f),
        target = Position(x = 0f, y = 1.72f, z = -9.0f),
        minRadius = 7.0f,
        maxRadius = 14.0f,
    )

    val Entrance = CameraPreset(
        id = "entrance_gate",
        eye = Position(x = 0f, y = 2.25f, z = 17.7f),
        target = Position(x = 0f, y = 1.28f, z = 11.0f),
        minRadius = 5.8f,
        maxRadius = 11.0f,
    )

    val GardenWest = CameraPreset(
        id = "garden_west",
        eye = Position(x = -8.7f, y = 3.55f, z = 3.9f),
        target = Position(x = -5.7f, y = 1.0f, z = -0.8f),
        minRadius = 5.0f,
        maxRadius = 11.0f,
    )

    val GardenEast = CameraPreset(
        id = "garden_east",
        eye = Position(x = 8.7f, y = 3.55f, z = 3.9f),
        target = Position(x = 5.7f, y = 1.0f, z = -0.8f),
        minRadius = 5.0f,
        maxRadius = 11.0f,
    )

    fun forObject(objectId: String?): CameraPreset = when {
        objectId == null -> Hero
        objectId.startsWith("fountain") -> Fountain
        objectId.startsWith("mansion") -> Mansion
        objectId.startsWith("entrance") -> Entrance
        objectId.startsWith("tree_w") || objectId.startsWith("bench_w") || objectId.startsWith("plant_0") -> GardenWest
        objectId.startsWith("tree_e") || objectId.startsWith("bench_e") -> GardenEast
        objectId.startsWith("lamp_") -> Hero
        else -> Hero
    }

    fun byId(id: String?): CameraPreset = when (id) {
        EntranceFront.id -> EntranceFront
        EntranceApproach.id -> EntranceApproach
        EntrancePass.id -> EntrancePass
        Hero.id -> Hero
        Overview.id -> Overview
        Fountain.id -> Fountain
        Mansion.id -> Mansion
        Entrance.id -> Entrance
        GardenWest.id -> GardenWest
        GardenEast.id -> GardenEast
        else -> Hero
    }
}
