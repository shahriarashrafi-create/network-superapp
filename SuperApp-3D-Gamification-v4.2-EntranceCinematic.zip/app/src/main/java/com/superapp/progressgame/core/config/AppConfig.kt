package com.superapp.progressgame.core.config

object AppConfig {
    const val APP_ID = "com.superapp.progressgame"
    const val FOUNDATION_VERSION = "4.0.0-asset-system"
    const val SAVE_SCHEMA_VERSION = 2
    const val WORLD_SCHEMA_VERSION = 3
    const val ASSET_SCHEMA_VERSION = 1
    const val DEFAULT_REGION_ID = "starter_estate"
    const val DEFAULT_CAMERA_PROFILE = "overview"
    const val RENDERER_NAME = "SceneView 4.32 + Google Filament"
}
