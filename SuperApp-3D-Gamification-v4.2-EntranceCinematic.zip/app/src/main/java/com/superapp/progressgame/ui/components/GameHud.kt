package com.superapp.progressgame.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.ui.theme.ElevatedSurface
import com.superapp.progressgame.ui.theme.SuccessGreen

@Composable
fun GameHud(
    progress: PlayerProgress,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Row(
            modifier = Modifier
                .background(ElevatedSurface.copy(alpha = 0.62f), RoundedCornerShape(13.dp))
                .padding(start = 2.dp, end = 7.dp, top = 1.dp, bottom = 1.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onSettings, modifier = Modifier.size(38.dp)) {
                Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات", tint = Color.White)
            }
            Box(
                modifier = Modifier
                    .background(SuccessGreen.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
            ) {
                Text("◉ ${progress.coins}", color = SuccessGreen, fontSize = 10.sp)
            }
        }

        Row(
            modifier = Modifier
                .background(ElevatedSurface.copy(alpha = 0.62f), RoundedCornerShape(13.dp))
                .padding(horizontal = 9.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("XP ${progress.xp}", color = Color.White.copy(alpha = 0.92f), fontSize = 10.sp)
            Spacer(Modifier.width(8.dp))
            LinearProgressIndicator(
                progress = { (progress.xp % 100) / 100f },
                modifier = Modifier.width(88.dp).height(4.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.12f),
            )
            Spacer(Modifier.width(8.dp))
            Text("LV ${progress.level}", color = Color.White, fontSize = 12.sp)
        }
    }
}
