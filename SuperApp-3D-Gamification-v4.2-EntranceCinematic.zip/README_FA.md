# Progress World — V4

این ZIP نسخهٔ V4 پروژهٔ گیمیفیکیشن سه‌بعدی است و شامل دو بسته تغییر اصلی می‌شود:

1. **V3.2 Interaction + Visual Foundation Fix**
   - اصلاح Selection و قابل لمس شدن اجزای اصلی Mansion/Fountain/Gate/Tree/Bench/Plant/Lamp
   - شناسهٔ پایدار برای هر آبجکت قابل تعامل
   - Selection Ring به‌جای تعویض متریال آبجکت
   - محدودیت واقعی‌تر Camera برای Pitch/Distance و ناحیهٔ بازی
   - Camera Safety برای جلوگیری از ورود دوربین به Footprint آبجکت‌های بزرگ
   - Terrain یکپارچه‌تر، حذف حلقهٔ قهوه‌ای و حذف moundهای بزرگ
   - Path پیوسته با جزئیات سنگی روی آن
   - نور و پالت کم‌نورتر و طبیعی‌تر
   - بازطراحی اولیه Mansion، Gate، Fountain، Tree، Plant، Bench و Lamp

2. **V4 Asset System**
   - AssetDefinition و AssetInstance
   - AssetCatalog مرکزی
   - Asset State metadata
   - Collision metadata
   - LOD metadata
   - StarterEstateLayout دیتا-محور
   - Asset manifest JSON
   - Style Guide واحد: Stylized Premium 3D
   - 85 تعریف Asset پایه برای توسعه Regionهای بعدی

Package ثابت است:
`com.superapp.progressgame`

Version Code:
`9`

Version Name:
`4.0.0-asset-system`

APKهای بعدی باید همین Package و Keystore را حفظ کنند تا روی نسخه قبلی Update شوند.
