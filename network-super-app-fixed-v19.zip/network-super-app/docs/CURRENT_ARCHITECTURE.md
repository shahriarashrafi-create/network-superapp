# Current Architecture — v19

این فایل Source of Truth معماری جاری پروژه است. تاریخچه‌ی تصمیم‌های بصری Home در `HOME_SPEC_FA.md` نگه داشته می‌شود.

## لایه‌ها

### App shell
`MainActivity` فقط state محلی لازم را قبل از Composition initialize می‌کند و Theme + `AppRoot` را بالا می‌آورد.

`AppRoot` مالک Bottom Navigation و انتخاب مقصد است. Home دیگر نباید درباره‌ی تب‌های دیگر یا Progress screen routing تصمیم بگیرد.

### Home
Home یک screen renderer است. Mockهای فعلی در `HomeUiState` و `HomeDefaults` متمرکز هستند تا جایگزینی آنها با ViewModel/API نیاز به دستکاری layout نداشته باشد.

### Progress Path
- `ProgressStage.kt`: model
- `ProgressPathRules.kt`: business rules خالص و قابل تست
- `ProgressPathStore.kt`: Compose state + persistence/migration
- `ProgressPathScreen/Header/World/Dialogs`: UI

Persistence فعلی برای prototype عمداً SharedPreferences است، اما payload اصلی JSON نسخه‌دار و backup دارد. کلید legacy v18 فقط برای migration خوانده می‌شود و بعد از migration حذف می‌شود.

### Shared UI
المان‌هایی که واقعاً یک visual contract مشترک دارند در `ui/components` قرار می‌گیرند. از ساختن component عمومی برای هر dp یا Color خودداری شود؛ فقط duplication معنادار استخراج شود.

## Invariants مسیر پیشرفت

1. `id` و `number` باید مثبت و یکتا باشند.
2. شماره‌ها بعد از mutation به‌صورت contiguous از 1 بازسازی می‌شوند.
3. در حالت active حداکثر یک `CURRENT` وجود دارد.
4. اگر `CURRENT` وجود نداشته باشد ولی `UPCOMING` وجود داشته باشد، اولین upcoming به current ارتقا می‌یابد.
5. اگر هیچ `CURRENT/UPCOMING` وجود نداشته باشد، مسیر completed است و progress باید 100٪ باشد.
6. payload ناقص/corrupt به‌صورت silent بخشی از stages را حذف نمی‌کند؛ primary، سپس backup، سپس legacy و در نهایت defaults بررسی می‌شوند.

## Visual lock

برای Home و Progress Path این موارد بدون درخواست طراحی تغییر نکنند:

- اندازه/وزن سکشن‌ها
- padding و spacing اصلی
- Card radius و ابعاد CTAهای موجود
- Canvas geometry
- جهت RTL/LTR موضعی
- رنگ‌های فعلی

Refactor باید behavior-preserving و pixel-preserving باشد، مگر جایی که یک bug رفتاری مشخص اصلاح می‌شود.

## قدم‌های بعدی

مقصدهای Customers، Networking و More از قبل در App shell جدا شده‌اند و می‌توانند مستقل توسعه داده شوند. وقتی داده‌ی واقعی اضافه شد، `HomeDefaults` با ViewModel/Repository جایگزین شود؛ UI contract و `HomeUiState` می‌تواند باقی بماند.
