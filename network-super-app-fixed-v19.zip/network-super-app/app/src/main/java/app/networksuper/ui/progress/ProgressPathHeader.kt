package app.networksuper.ui.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.*

@Composable
internal fun ProgressPathHeader() {
    val stages = ProgressPathStore.stages
    val current = ProgressPathStore.currentStage()
    val ordinal = ProgressPathStore.currentOrdinal()
    val total = stages.size.coerceAtLeast(1)
    val progress = (ordinal.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val percent = (progress * 100).toInt()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                3.dp,
                RoundedCornerShape(22.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.06f),
                spotColor = PrimaryBlue.copy(alpha = 0.07f)
            ),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceOutline)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(15.dp),
                    color = SoftBlue,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.18f))
                ) {
                    Text(
                        text = when {
                            current != null -> stringResource(R.string.stage_of, current.number, stages.size)
                            ProgressPathStore.isComplete() -> stringResource(R.string.path_completed)
                            else -> stringResource(R.string.no_current_stage)
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        color = PrimaryBlueDark,
                        fontSize = NetworkTextSize.Label,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Text(
                        text = stringResource(R.string.progress_path),
                        color = Navy,
                        fontSize = NetworkTextSize.ScreenTitle,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .shadow(3.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color.White, Color(0xFFFFF2C8))))
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EmojiEvents,
                            contentDescription = null,
                            tint = RewardGold,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDDEAF9))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF29B8EF), Color(0xFF0E6FFF))
                                )
                            )
                    )
                }

                Text(
                    text = "$percent%",
                    color = PrimaryBlue,
                    fontSize = NetworkTextSize.ProgressPercent,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

