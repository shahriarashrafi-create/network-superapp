package app.networksuper.ui.progress

enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus
)
