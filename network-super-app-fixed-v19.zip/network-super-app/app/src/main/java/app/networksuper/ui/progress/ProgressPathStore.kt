package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Single source of truth for the progress path.
 *
 * The UI reads [stages] as Compose state. Persistence is versioned JSON with a backup and a
 * one-way migration from the legacy pipe/comma format used by v18.
 */
object ProgressPathStore {
    private const val PREFS_NAME = "progress_path_v1"
    private const val KEY_STAGES_JSON = "stages_json_v2"
    private const val KEY_STAGES_JSON_BACKUP = "stages_json_v2_backup"
    private const val KEY_STAGES_LEGACY = "stages"
    private const val SCHEMA_VERSION = 2

    private val defaultStages = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    )

    val stages = mutableStateListOf<ProgressStage>()

    private var prefs: SharedPreferences? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return

        val sharedPreferences = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sharedPreferences

        val restored = restore(sharedPreferences)
        replaceWithRenumbered(restored ?: defaultStages, persistAfter = false)
        persist()
        sharedPreferences.edit().remove(KEY_STAGES_LEGACY).apply()
        initialized = true
    }

    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    /**
     * 1-based stage position used by the header progress indicator.
     * A path with no current/upcoming stage is completed and therefore reports the final ordinal.
     */
    fun currentOrdinal(): Int = ProgressPathRules.currentOrdinal(stages)

    fun isComplete(): Boolean = stages.isNotEmpty() &&
        stages.none { it.status == StageStatus.CURRENT || it.status == StageStatus.UPCOMING }

    /** Number of selectable positions for the add/edit sheet. */
    fun positionCount(isNew: Boolean): Int = (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    /** Insert a new card at [position]. Existing cards are shifted and positions stay contiguous. */
    fun addStage(title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        val nextId = nextAvailableId(ordered)
        ordered.add(
            insertionIndex,
            ProgressStage(
                id = nextId,
                number = position,
                title = cleanTitle,
                status = StageStatus.UPCOMING
            )
        )
        replaceWithRenumbered(ordered)
    }

    /** Move the card to [position] instead of rejecting an occupied position. */
    fun editStage(id: Long, title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return

        val updated = ordered.removeAt(oldIndex).copy(title = cleanTitle)
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(insertionIndex, updated)
        replaceWithRenumbered(ordered)
    }

    /** Delete a card and close the numbering gap automatically. */
    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val target = ordered.removeAt(targetIndex)
        if (target.status == StageStatus.CURRENT) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex)
        }
        replaceWithRenumbered(ordered)
    }

    /** Make exactly [id] the current stage. */
    fun setCurrent(id: Long) {
        if (stages.none { it.id == id }) return

        val ordered = stages.sortedBy { it.number }.map { stage ->
            when {
                stage.id == id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        replaceWithRenumbered(ordered)
    }

    fun markCompleted(id: Long) = markResult(id, StageStatus.COMPLETED)

    fun markFailed(id: Long) = markResult(id, StageStatus.FAILED)

    private fun markResult(id: Long, result: StageStatus) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)

        if (wasCurrent) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex + 1)
        }
        replaceWithRenumbered(ordered)
    }

    private fun promoteNextUpcoming(
        ordered: MutableList<ProgressStage>,
        preferredStartIndex: Int
    ) {
        if (ordered.any { it.status == StageStatus.CURRENT }) return

        val safeStart = preferredStartIndex.coerceIn(0, ordered.size)
        val nextIndex = (safeStart until ordered.size)
            .firstOrNull { ordered[it].status == StageStatus.UPCOMING }
            ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING }.takeIf { it >= 0 }

        if (nextIndex != null) {
            ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
        }
    }

    private fun replaceWithRenumbered(
        ascendingItems: List<ProgressStage>,
        persistAfter: Boolean = true
    ) {
        val ordered = ProgressPathRules.normalize(ascendingItems)

        stages.clear()
        stages.addAll(ordered.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun nextAvailableId(items: List<ProgressStage>): Long {
        val used = items.asSequence().map { it.id }.toHashSet()
        var candidate = (used.maxOrNull() ?: 0L) + 1L
        while (candidate in used || candidate <= 0L) candidate++
        return candidate
    }

    private fun restore(sharedPreferences: SharedPreferences): List<ProgressStage>? {
        val primary = sharedPreferences.getString(KEY_STAGES_JSON, null)
        decodeJson(primary)?.let { return it }

        val backup = sharedPreferences.getString(KEY_STAGES_JSON_BACKUP, null)
        decodeJson(backup)?.let { return it }

        val legacy = sharedPreferences.getString(KEY_STAGES_LEGACY, null)
        decodeLegacy(legacy)?.let { return it }

        return null
    }

    private fun persist() {
        val sharedPreferences = prefs ?: return
        val payload = encodeJson(stages)
        val previous = sharedPreferences.getString(KEY_STAGES_JSON, null)

        sharedPreferences.edit().apply {
            // Never replace a known-good backup with a corrupted primary payload.
            if (!previous.isNullOrBlank() && previous != payload && decodeJson(previous) != null) {
                putString(KEY_STAGES_JSON_BACKUP, previous)
            }
            putString(KEY_STAGES_JSON, payload)
        }.apply()
    }

    private fun encodeJson(items: List<ProgressStage>): String {
        val array = JSONArray()
        items.sortedBy { it.number }.forEach { stage ->
            array.put(
                JSONObject()
                    .put("id", stage.id)
                    .put("number", stage.number)
                    .put("title", stage.title)
                    .put("status", stage.status.name)
            )
        }
        return JSONObject()
            .put("version", SCHEMA_VERSION)
            .put("stages", array)
            .toString()
    }

    private fun decodeJson(raw: String?): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != SCHEMA_VERSION) return@runCatching null
            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        ProgressStage(
                            id = item.getLong("id"),
                            number = item.getInt("number"),
                            title = item.getString("title"),
                            status = StageStatus.valueOf(item.getString("status"))
                        )
                    )
                }
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    /** Strict legacy decoder: one malformed record invalidates the payload instead of deleting it silently. */
    private fun decodeLegacy(raw: String?): List<ProgressStage>? {
        if (raw == null) return null
        if (raw.isBlank()) return emptyList()

        return runCatching {
            val tokens = raw.split('|')
            val parsed = tokens.map { token ->
                val parts = token.split(',', limit = 4)
                require(parts.size == 4)
                ProgressStage(
                    id = parts[0].toLong(),
                    number = parts[1].toInt(),
                    status = StageStatus.valueOf(parts[2]),
                    title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                )
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun validateParsed(items: List<ProgressStage>): List<ProgressStage>? {
        if (items.any { it.id <= 0L || it.number <= 0 || it.title.isBlank() }) return null
        if (items.map { it.id }.toSet().size != items.size) return null
        if (items.map { it.number }.toSet().size != items.size) return null
        return items
    }
}
