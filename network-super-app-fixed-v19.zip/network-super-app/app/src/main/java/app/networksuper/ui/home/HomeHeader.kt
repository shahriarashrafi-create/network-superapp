package app.networksuper.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.*

@Composable
internal fun HomeHeader(state: HomeUiState, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
    ) {
        HeaderWaveBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.offset(x = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ComboTile(count = state.comboCount)
                        RewardTile(showDot = state.hasRewardNotification)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            ProfileAvatar()
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = state.userName,
                                    color = Navy,
                                    style = MaterialTheme.typography.headlineSmall,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                                Spacer(Modifier.height(2.dp))
                                RankBadge(rankName = state.rankName)
                            }
                        }
                    }
                }
            }

            XpProgressRow(
                current = state.xpCurrent,
                target = state.xpTarget
            )
        }
    }
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val wave1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.32f)
            cubicTo(w * 0.74f, h * 0.12f, w * 0.60f, h * 0.42f, w * 0.38f, h * 0.28f)
            cubicTo(w * 0.20f, h * 0.16f, w * 0.10f, h * 0.34f, 0f, h * 0.20f)
            close()
        }
        drawPath(
            path = wave1,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = 0.34f),
                    Color(0xFF8CCBFF).copy(alpha = 0.18f),
                    Color.Transparent
                )
            )
        )

        val wave2 = Path().apply {
            moveTo(0f, h * 0.08f)
            cubicTo(w * 0.18f, h * 0.30f, w * 0.32f, h * 0.04f, w * 0.48f, h * 0.18f)
            cubicTo(w * 0.66f, h * 0.34f, w * 0.80f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.46f)
            cubicTo(w * 0.80f, h * 0.32f, w * 0.63f, h * 0.52f, w * 0.45f, h * 0.38f)
            cubicTo(w * 0.24f, h * 0.22f, w * 0.12f, h * 0.44f, 0f, h * 0.31f)
            close()
        }
        drawPath(
            path = wave2,
            color = Color.White.copy(alpha = 0.28f)
        )
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(56.dp)
            .shadow(8.dp, CircleShape, ambientColor = PrimaryBlue.copy(alpha = 0.18f), spotColor = PrimaryBlue.copy(alpha = 0.22f))
            .clip(CircleShape)
            .background(Color(0xFFE9F5FF))
            .border(2.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(49.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))
                    )
                )
                .border(2.5.dp, RewardGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Person,
                contentDescription = stringResource(R.string.profile),
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
private fun RankBadge(rankName: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF0A1E63), Color(0xFF17368B))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = rankName,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun ComboTile(count: Int) {
    Row(
        modifier = Modifier
            .height(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFBF4), Color(0xFFFFF0D8))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.95f), RoundedCornerShape(17.dp))
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = stringResource(R.string.combo),
                tint = Color(0xFFFF6A1A),
                modifier = Modifier.size(30.dp)
            )
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = null,
                tint = Color(0xFFFFC83D),
                modifier = Modifier.size(17.dp)
            )
            Icon(
                Icons.Rounded.AutoAwesome,
                contentDescription = null,
                tint = RewardGold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(8.dp)
            )
        }
        Text(
            text = count.toString(),
            color = Navy,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun RewardTile(showDot: Boolean) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFFFF), Color(0xFFFFF3E5))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.96f), RoundedCornerShape(17.dp)),
        contentAlignment = Alignment.Center
    ) {
        RewardGiftAsset(Modifier.size(34.dp))
        if (showDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(8.dp)
                    .background(Color(0xFFFF4057), CircleShape)
            )
        }
    }
}

@Composable
private fun RewardGiftAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFD348), Color(0xFFF09A16))
            ),
            topLeft = Offset(w * 0.15f, h * 0.38f),
            size = Size(w * 0.70f, h * 0.45f),
            cornerRadius = CornerRadius(w * 0.09f, w * 0.09f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFE676), Color(0xFFFFB51A))
            ),
            topLeft = Offset(w * 0.11f, h * 0.31f),
            size = Size(w * 0.78f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )
        drawRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.44f, h * 0.31f),
            size = Size(w * 0.12f, h * 0.52f)
        )
        drawRoundRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.30f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = Color(0xFFFF6671),
            topLeft = Offset(w * 0.50f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.70f),
            radius = w * 0.035f,
            center = Offset(w * 0.26f, h * 0.43f)
        )
        drawLine(
            color = Color.White.copy(alpha = 0.65f),
            start = Offset(w * 0.18f, h * 0.35f),
            end = Offset(w * 0.35f, h * 0.35f),
            strokeWidth = 2.2f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun XpProgressRow(current: Int, target: Int) {
    val progress = (current.toFloat() / target.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(3.dp, RoundedCornerShape(18.dp), ambientColor = PrimaryBlue.copy(alpha = 0.05f), spotColor = PrimaryBlue.copy(alpha = 0.07f)),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.82f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.92f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(
                    text = "$current XP",
                    color = PrimaryBlue,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(9.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCE8F7))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)
                                )
                            )
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .offset(x = 3.dp)
                            .size(3.dp)
                            .background(Color.White.copy(alpha = 0.72f), CircleShape)
                    )
                }

                Text(
                    text = target.toString(),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

