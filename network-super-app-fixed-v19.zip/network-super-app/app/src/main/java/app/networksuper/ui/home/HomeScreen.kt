package app.networksuper.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.progress.ProgressStageInteractionDialog

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    uiState: HomeUiState = HomeDefaults.state
) {
    var selectedProgressStageId by remember { mutableStateOf<Long?>(null) }
    val currentStage = ProgressPathStore.currentStage()
    val nextActionTitle = currentStage?.title ?: stringResource(R.string.next_step_missing)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HomeHeader(
            state = uiState,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.16f)
        )
        NextActionCard(
            nextActionTitle = nextActionTitle,
            onStart = { currentStage?.let { selectedProgressStageId = it.id } },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.24f)
        )
        TodaySection(
            title = uiState.todayTitle,
            dateLabel = uiState.todayDateLabel,
            scheduleItems = uiState.scheduleItems,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.30f)
        )
        ProgressSection(
            onStageClick = { selectedProgressStageId = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.30f)
        )
    }

    ProgressStageInteractionDialog(
        stageId = selectedProgressStageId,
        onDismiss = { selectedProgressStageId = null }
    )
}

