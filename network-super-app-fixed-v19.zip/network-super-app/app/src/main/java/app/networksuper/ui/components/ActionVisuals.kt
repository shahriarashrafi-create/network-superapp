package app.networksuper.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.ActionButtonBlue

/** Shared visual used by the blue action panels on Home and Progress. */
@Composable
fun GeometricBlueBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        for (i in -1..7) {
            val x = w * (0.02f + i * 0.16f)
            drawLine(
                color = Color.White.copy(alpha = 0.09f),
                start = Offset(x, 0f),
                end = Offset(x - h * 0.25f, h),
                strokeWidth = 2f
            )
        }

        for (row in 0..2) {
            for (col in 0..4) {
                val left = w * (0.06f + col * 0.20f) + if (row % 2 == 1) w * 0.06f else 0f
                val top = h * (0.13f + row * 0.27f)
                drawRoundRect(
                    color = Color.White.copy(alpha = if ((row + col) % 3 == 0) 0.12f else 0.07f),
                    topLeft = Offset(left, top),
                    size = Size(w * 0.14f, w * 0.14f),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 3f)
                )
            }
        }

        drawCircle(
            color = Color.White.copy(alpha = 0.07f),
            radius = w * 0.22f,
            center = Offset(w * 0.14f, h * 0.78f)
        )
        drawCircle(
            color = Color(0xFF9FDBFF).copy(alpha = 0.09f),
            radius = w * 0.18f,
            center = Offset(w * 0.82f, h * 0.18f)
        )
    }
}

/** Same CTA chrome everywhere; call sites keep their original dimensions and direction. */
@Composable
fun StartActionButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconSize: Dp = 22.dp,
    shadowElevation: Dp = 1.dp,
    forceLtr: Boolean = false
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = ActionButtonBlue,
        border = androidx.compose.foundation.BorderStroke(
            2.dp,
            Color.White.copy(alpha = 0.96f)
        ),
        shadowElevation = shadowElevation
    ) {
        val content: @Composable () -> Unit = {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(R.string.action_start),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Spacer(Modifier.width(7.dp))
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(iconSize)
                )
            }
        }

        if (forceLtr) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { content() }
        } else {
            content()
        }
    }
}
