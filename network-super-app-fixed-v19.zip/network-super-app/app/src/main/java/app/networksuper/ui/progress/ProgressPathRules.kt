package app.networksuper.ui.progress

/** Pure progress-path rules kept separate from Android persistence and Compose state. */
internal object ProgressPathRules {
    fun currentOrdinal(items: List<ProgressStage>): Int {
        val ordered = items.sortedBy { it.number }
        val currentIndex = ordered.indexOfFirst { it.status == StageStatus.CURRENT }
        if (currentIndex >= 0) return currentIndex + 1

        if (ordered.isNotEmpty() && ordered.none { it.status == StageStatus.UPCOMING }) {
            return ordered.size
        }
        return 0
    }

    fun normalize(items: List<ProgressStage>): List<ProgressStage> {
        val ordered = items
            .sortedWith(compareBy<ProgressStage> { it.number }.thenBy { it.id })
            .mapIndexed { index, stage ->
                stage.copy(number = index + 1, title = stage.title.trim())
            }
            .toMutableList()

        val currentIndices = ordered.indices.filter { ordered[it].status == StageStatus.CURRENT }
        if (currentIndices.size > 1) {
            currentIndices.drop(1).forEach { index ->
                ordered[index] = ordered[index].copy(status = StageStatus.UPCOMING)
            }
        }

        if (ordered.none { it.status == StageStatus.CURRENT }) {
            val firstUpcoming = ordered.indexOfFirst { it.status == StageStatus.UPCOMING }
            if (firstUpcoming >= 0) {
                ordered[firstUpcoming] = ordered[firstUpcoming].copy(status = StageStatus.CURRENT)
            }
        }
        return ordered
    }
}
