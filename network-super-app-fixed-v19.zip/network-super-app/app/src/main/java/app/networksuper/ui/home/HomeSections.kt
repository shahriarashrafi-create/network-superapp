package app.networksuper.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.components.EdgePreviewLazyRow
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.progress.ProgressStage
import app.networksuper.ui.progress.StageStatus
import app.networksuper.ui.progress.StageStatusBadge
import app.networksuper.ui.theme.*

@Composable
private fun SyncedHomeSection(
    modifier: Modifier = Modifier,
    title: String,
    titleIcon: ImageVector,
    titleIconTint: Color,
    badgeText: String,
    badgeIcon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    HomeSectionCard(modifier = modifier) {
        SectionHeader(
            title = title,
            rightIcon = titleIcon,
            rightIconTint = titleIconTint,
            leftContent = {
                SectionMetaPill(
                    text = badgeText,
                    icon = badgeIcon
                )
            }
        )
        Spacer(Modifier.height(5.dp))
        content()
    }
}

@Composable
private fun SectionMetaPill(
    text: String,
    icon: ImageVector? = null
) {
    Surface(
        modifier = Modifier.height(32.dp),
        shape = RoundedCornerShape(12.dp),
        color = SoftBlue
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = text,
                color = if (icon == null) PrimaryBlueDark else Navy,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SyncedItemCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    done: Boolean,
    meta: String? = null,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(19.dp),
            colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.062f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.165f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusMark(done = done)
                        if (meta != null) {
                            Text(
                                text = meta,
                                color = accent,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                maxLines = 1
                            )
                        } else {
                            Spacer(Modifier.width(1.dp))
                        }
                    }
                }

                PremiumIconBubble(
                    icon = icon,
                    accent = accent,
                    contentDescription = title,
                    modifier = Modifier.size(43.dp)
                )

                Text(
                    text = title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun SyncedItemRow(
    items: List<HomeCardItem>,
    modifier: Modifier = Modifier
) {
    EdgePreviewLazyRow(
        items = items,
        key = { "${it.title}|${it.meta.orEmpty()}" },
        modifier = modifier
    ) { item, itemModifier ->
        SyncedItemCard(
            title = item.title,
            icon = item.icon,
            accent = item.accent,
            done = item.done,
            meta = item.meta,
            modifier = itemModifier
        )
    }
}

@Composable
internal fun TodaySection(
    title: String,
    dateLabel: String,
    scheduleItems: List<HomeCardItem>,
    modifier: Modifier = Modifier
) {
    SyncedHomeSection(
        modifier = modifier,
        title = title,
        titleIcon = Icons.Rounded.CheckCircle,
        titleIconTint = SuccessGreen,
        badgeText = dateLabel,
        badgeIcon = Icons.Rounded.CalendarMonth
    ) {
        SyncedItemRow(
            items = scheduleItems,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
internal fun ProgressSection(
    onStageClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val stages = ProgressPathStore.stages.sortedBy { it.number }
    val current = ProgressPathStore.currentStage()
    val currentIndex = stages.indexOfFirst { it.status == StageStatus.CURRENT }
    val start = when {
        stages.size <= 4 -> 0
        currentIndex < 0 -> 0
        currentIndex <= 1 -> 0
        currentIndex >= stages.lastIndex - 1 -> (stages.size - 4).coerceAtLeast(0)
        else -> currentIndex - 1
    }
    val visibleStages = stages.drop(start).take(4)

    SyncedHomeSection(
        modifier = modifier,
        title = stringResource(R.string.progress_path),
        titleIcon = Icons.Rounded.EmojiEvents,
        titleIconTint = RewardGold,
        badgeText = when {
            current != null -> stringResource(R.string.stage_of, current.number, stages.size)
            ProgressPathStore.isComplete() -> stringResource(R.string.path_completed)
            else -> stringResource(R.string.no_current_stage)
        }
    ) {
        ProgressSyncedItemRow(
            items = visibleStages,
            onStageClick = onStageClick,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ProgressSyncedItemRow(
    items: List<ProgressStage>,
    onStageClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    EdgePreviewLazyRow(
        items = items,
        key = { it.id },
        modifier = modifier
    ) { item, itemModifier ->
        ProgressHomeCard(
            stage = item,
            onClick = { onStageClick(item.id) },
            modifier = itemModifier
        )
    }
}

@Composable
private fun ProgressHomeCard(
    stage: ProgressStage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.FAILED -> FailRed
        StageStatus.UPCOMING -> PrimaryBlue
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            onClick = onClick,
            modifier = modifier,
            shape = RoundedCornerShape(19.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (stage.status == StageStatus.CURRENT) SoftBlue.copy(alpha = 0.55f)
                else accent.copy(alpha = 0.055f)
            ),
            border = androidx.compose.foundation.BorderStroke(
                if (stage.status == StageStatus.CURRENT) 1.7.dp else 1.dp,
                accent.copy(alpha = if (stage.status == StageStatus.CURRENT) 0.52f else 0.17f)
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 9.dp, vertical = 8.dp)
            ) {
                StageStatusBadge(
                    stage = stage,
                    compact = true,
                    modifier = Modifier.align(Alignment.TopEnd)
                )
                Text(
                    text = stage.title,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(top = 20.dp, start = 4.dp, end = 4.dp),
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StatusMark(done: Boolean) {
    Icon(
        imageVector = if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
        contentDescription = if (done) stringResource(R.string.done) else stringResource(R.string.not_done),
        tint = if (done) SuccessGreen else Muted.copy(alpha = 0.50f),
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun PremiumIconBubble(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(2.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        Color.White.copy(alpha = 0.92f),
                        accent.copy(alpha = 0.18f)
                    )
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun PremiumSmallIcon(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?,
    containerSize: androidx.compose.ui.unit.Dp = 31.dp,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp
) {
    Box(
        modifier = Modifier
            .size(containerSize)
            .shadow(1.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.88f), accent.copy(alpha = 0.13f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.82f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
private fun HomeSectionCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            content = content
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    rightIcon: ImageVector,
    rightIconTint: Color,
    leftContent: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            leftContent()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PremiumSmallIcon(
                        icon = rightIcon,
                        accent = rightIconTint,
                        contentDescription = null
                    )
                    Text(
                        text = title,
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}
