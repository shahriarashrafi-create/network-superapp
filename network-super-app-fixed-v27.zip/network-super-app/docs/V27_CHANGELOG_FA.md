# V27 — Home / Header / Progress / Rewards Finalization

## قانون override مهم

در V27 هیچ کارت `UPCOMING` برای شروع قفل نیست. `CURRENT` فقط «پیشنهاد قدم فعلی» است و permission gate نیست.

## 19 تغییر اصلی

1. Home Header به Component ثابت مشترک تبدیل و ارتفاع آن کمتر شد.
2. Header assets حرفه‌ای‌تر و Chest badge اصلاح شد.
3. تمام Chestها فقط در Reward Chest page باز می‌شوند.
4. XP/Coin/Combo با difficulty واقعی و persistence یکپارچه شد.
5. ظاهر Home baseline حفظ شد و فقط refinement انجام گرفت.
6. Progress Path از road design به Home-like horizontal sections تغییر کرد.
7. پنج دسته با Surface سفید و accent اختصاصی استاندارد شدند.
8. وضعیت Done/Current/Next/Failed/Skipped روی کارت‌ها واضح ولی مینیمال است.
9. RTL + focus روی Current + scroll memory برای هر دسته اجرا شد.
10. `+` اختصاصی هر دسته جای FAB عمومی را گرفت؛ Add Task با مدل جدید ساخته شد.
11. Next Action algorithm: Pin → Due today → Active → Priority.
12. Today algorithm از همان Task source و زمان/تکرار واقعی استفاده می‌کند.
13. Home و Progress یک source of truth دارند.
14. hard-lock/unlock permission حذف شد؛ Current marker محاسباتی باقی ماند.
15. Done/Fail/Skip/Undo رفتار مستقل دارند.
16. Progress v5 + Gamification v2 migration و persistence اجرا شد.
17. Bottom Navigation کوتاه‌تر و active state کنترل‌شده‌تر شد.
18. UI/logic/persistence/gamification تفکیک و road legacy code حذف شد.
19. Validation و migration review برای جلوگیری از شکستن update انجام شد.

## 30 refinement تکمیلی

1. Empty state برای دسته‌های بدون Task.
2. Skeleton state برای Loading.
3. Error state + Retry.
4. Motion کوتاه 180–340ms در stateهای اصلی.
5. Haptic برای Start/Done/Fail/Skip/Chest claim.
6. Reward Snackbar با مقدار XP/Coin/Combo.
7. Undo action روی Snackbar.
8. Label «تسک مسیر» برای تفکیک مفهوم کارت.
9. Progress عددی هر دسته.
10. Overall progress درصدی بالای Progress.
11. Vertical scroll position صفحه Progress در رفت‌وبرگشت داخل session حفظ می‌شود.
12. Scroll memory مستقل برای Horizontal rows.
13. Long press روی کارت‌های Home و Progress: Edit/Pin/Move/Skip/Delete.
14. Tap در همه Progress cards → Mission Detail.
15. Swipe محدود فقط در Mission Detail؛ Horizontal rows عمداً gesture-conflict ندارند.
16. Cardها از ابتدا Disabled/Locked نیستند.
17. چون lock حذف شده، lock reason UI نیز حذف شده است.
18. Badge semantics استاندارد: action/done/info/reward/skipped.
19. SafeDrawing insets در AppRoot.
20. Adaptive user-name sizing.
21. Compact number formatting برای Coin/XP بزرگ.
22. اعداد اصلی Home/Progress/Rewards و Snackbar پاداش با digits فارسی نمایش داده می‌شوند.
23. Dark-theme token set آماده شد، بدون تغییر پیش‌فرض Light UI.
24. Design tokens مشترک برای radius/spacing/motion/header.
25. Icon/assetهای جدید Vector/Canvas و resolution-independent هستند.
26. Current card border/elevation با animation تغییر می‌کند.
27. Progress rows بار اول روی Current/recommended index متمرکز می‌شوند.
28. Chest badge تعداد Chest آماده را نمایش می‌دهد.
29. Header counters عرض ثابت دارند تا layout jump نکند.
30. Home/Header/Progress/Rewards به‌عنوان visual baseline پایدار V27 مستند شد.

## ایمنی Reward

- Chest milestone فقط با اولین Completion هر Task جلو می‌رود؛ Undo و re-complete همان Task صندوق اضافی تولید نمی‌کند.
- `rewardLedger` برای rollback دقیق Coin/XP استفاده می‌شود.
