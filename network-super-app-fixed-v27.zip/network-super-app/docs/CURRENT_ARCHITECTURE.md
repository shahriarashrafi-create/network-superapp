# Current Architecture — V27

V27 هویت Home را به Progress Path گسترش می‌دهد و Home/Progress/Rewards را روی یک state مشترک و persistent نگه می‌دارد.

## App shell

- `MainActivity`: ابتدا `ProgressPathStore` و سپس `GamificationStore` را قبل از Composition initialize می‌کند.
- `AppRoot`: مقصدها، Mission Detail، Rewards، Settings، Snackbar سراسری و Bottom Navigation را مدیریت می‌کند.
- `SharedFixedHeader`: هدر ثابت Home در Home، Progress، Mission Detail و صفحات اصلی.

## Header

- راست: Profile + ناحیه نام با عرض ثابت و فونت تطبیقی.
- زیر نام: Builder در راست + Chest کوچک در چپ، کاملاً داخل عرض ناحیه نام.
- چپ هدر، از چپ به راست: `Settings → Combo → Coin`.
- Coin و Combo عدد persistent دارند؛ Coin count در عرض ثابت فشرده می‌شود.
- Chest badge فقط هنگام وجود صندوق آماده نمایش داده می‌شود و تعداد را نشان می‌دهد.
- XP bar پایین هدر است و هدر از scroll صفحه مستقل می‌ماند.

## Home

- `HomeScreen` قدم بعدی را از `ProgressPathStore.nextAction()` می‌گیرد.
- Today از همان Progress task source تولید می‌شود، نه state جداگانه.
- Progress preview و صفحه کامل Progress هر دو از `ProgressTaskCard` مشترک استفاده می‌کنند.
- تمام Horizontal rows RTL هستند و scroll position را نگه می‌دارند.

## Progress domain

`ProgressStage` علاوه بر Mission state، اطلاعات زیر را نگه می‌دارد:

- category
- difficulty
- priority
- pinned next action
- today visibility
- progress visibility
- planned date/time
- repeat rule
- skipped state

`UPCOMING` به معنی «بعدی» است، نه «قفل». همه کارت‌ها از ابتدا قابل باز شدن و Start هستند.

## Progress UI

پنج بخش:

- کارهای شخصی
- کارهای فروش
- کارهای شبکه‌سازی
- کارهای حمایتی
- کارهای حامی

هر بخش دقیقاً با زبان بصری Home ساخته می‌شود: Surface سفید، accent اختصاصی، Horizontal RTL cards، بدون جاده/خیابان. هر Header یک `+` اختصاصی دارد و Add Task دسته را از همان بخش preselect می‌کند.

## Task interaction

- Tap: جزئیات Task.
- Long press: Edit / Pin next / Move category / Skip / Delete.
- Swipe محدود فقط در Mission Detail و خارج از Horizontal rows فعال است تا با scroll افقی تداخل نکند.
- Skip پاداش نمی‌دهد و Combo را نمی‌شکند.
- Fail پاداش نمی‌دهد و Combo را reset می‌کند.
- Done پاداش واقعی می‌دهد و Snackbar + Undo دارد.

## Gamification

Reward پایه بر اساس difficulty:

- Low: `10 XP / 2 Coin`
- Medium: `20 XP / 4 Coin`
- High: `35 XP / 7 Coin`

قوانین:

1. سومین موفقیت متوالی Combo را فعال می‌کند.
2. از موفقیت سوم، XP/Coin ×1.5 می‌شوند.
3. Fail، Combo را reset می‌کند.
4. Skip، Combo را حفظ می‌کند.
5. هر Task ID مستقیم فقط یک reward فعال دارد.
6. Undo از reward ledger مقدار واقعی همان Completion را برمی‌گرداند.
7. اگر Chest ناشی از Completion قبلاً Claim شده باشد، reward rollback محدود می‌شود تا exploit ایجاد نشود.
8. هر 5 اولین Completion یکتای Taskها، Task Chest می‌دهد؛ Undo/re-complete همان Task milestone تازه تولید نمی‌کند.
9. Three-hour Chest بعد از Claim دقیقاً 3 ساعت cooldown دارد.
10. Claim همه Chestها فقط در `RewardChestScreen` انجام می‌شود.

## Persistence

- Progress schema: v5 با migration از v4/v3/v2/legacy.
- Gamification prefs: v2 با migration از `gamification_v1`.
- اطلاعات نسخه‌های قبلی حفظ می‌شوند.
- Task state، XP، Coin، Combo، reward ledger، chest cooldown و scroll-relevant UI state از هم جدا شده‌اند.

## Visual system

- `DesignTokens.kt`: spacing/radius/header/motion/badge tokens.
- `UiFormatters.kt`: اعداد فارسی، compact number، time و percent.
- `ProgressTaskCard.kt`: کارت مشترک Home + Progress.
- Dark color token set آماده است ولی V27 همچنان Light-first است.
