# V27 Validation — 2026-10-16

این گزارش برای کنترل ریسک تغییرات Home / Header / Progress / Rewards تهیه شده است.

## کنترل‌های خودکار انجام‌شده

- تمام XMLهای `app/src/main/res` و `AndroidManifest.xml` با XML parser بررسی شدند: خطای ساختاری وجود ندارد.
- تمام `R.string.*`های Kotlin با `strings.xml` تطبیق داده شدند: reference گمشده وجود ندارد.
- اسکن `TODO(`، `FIXME` و `NotImplementedError` روی سورس اصلی: مورد رهاشده وجود ندارد.
- قواعد Pure Kotlin شامل `ProgressStage`، `MissionRules`، `ProgressPathRules` و `GamificationRules` با `kotlinc` با موفقیت compile شدند.
- Smoke test مستقل قواعد اجرا شد و پاس شد: Combo در سومین Done، ضریب ×1.5، جلوگیری از Chest تکراری در re-complete و انتخاب Upcoming باز به‌عنوان Next Action.
- parse/syntax smoke test روی تمام فایل‌های Kotlin اجرا شد؛ خطای parser از نوع `expecting` / `unexpected tokens` / `redeclaration` مشاهده نشد. خطاهای unresolved AndroidX در این تست طبیعی‌اند چون Android/Compose classpath در محیط محلی وجود ندارد.
- اجرای Full Android Gradle build در این محیط ممکن نبود چون `gradle-wrapper.jar` در پروژه مبنا وجود ندارد و اینترنت runtime برای bootstrap Gradle در دسترس نیست. Workflow پروژه همچنان wrapper را در GitHub Actions می‌سازد و `:app:testDebugUnitTest` + `:app:assembleDebug` را اجرا می‌کند.

## کنترل‌های رگرسیون V27

- هیچ Progress Task برای شروع hard-lock نیست؛ `UPCOMING` فقط وضعیت «بعدی» است و Start در Mission Detail همیشه enabled است.
- هیچ Road/Street composable قدیمی در Progress باقی نمانده است.
- Home و Progress برای Progress cards از `ProgressTaskCard` مشترک استفاده می‌کنند.
- هدر مشترک ثابت است و ترتیب سمت چپ از چپ به راست `Settings → Combo → Coin` است.
- Profile سمت راست است و `Builder + Chest` زیر نام داخل عرض ثابت نام قرار دارند.
- Chest فقط وضعیت readiness را در هدر نشان می‌دهد؛ Claim داخل `RewardChestScreen` انجام می‌شود.
- Three-hour chest cooldown persist می‌شود.
- Coin / XP / Combo و reward ledger persist می‌شوند.
- Reward مستقیم Task بر اساس ID دوباره پرداخت نمی‌شود تا وقتی Undo معتبر انجام نشده باشد.
- Chest milestone بر پایه اولین Completion هر Task محاسبه می‌شود؛ Undo و re-complete همان Task صندوق milestone تازه تولید نمی‌کند.
- Undo از ledger مقدار دقیق Coin/XP همان Completion را برمی‌گرداند.
- Fail تنها نتیجه‌ای است که Combo را reset می‌کند؛ Skip پاداش ندارد و Combo را نمی‌شکند.
- Progress v5 از schemaهای v4/v3/v2/legacy migrate می‌شود؛ Gamification v2 از `gamification_v1` migrate می‌شود.
- Scroll position عمودی Progress و Scroll position افقی هر دسته در رفت‌وبرگشت داخل session حفظ می‌شوند.
- SafeDrawing insets برای App shell فعال است.
- Version به `versionCode 8 / versionName 0.8.0` افزایش یافته و `applicationId = app.networksuper` تغییر نکرده است.

## نکته Signing

در ZIP مبنای V26 فایل keystore/signing config اختصاصی وجود نداشت؛ V27 این بخش را تغییر نداده است تا رفتار build مبنا عوض نشود. اگر APKهای تستی با signing ثابت بیرونی/CI ساخته می‌شوند، همان signing باید در build بعدی نیز استفاده شود تا Android آن را Update همان اپ تشخیص دهد.
