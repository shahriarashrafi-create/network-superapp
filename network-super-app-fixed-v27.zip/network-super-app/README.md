# Network Super App — V27

پروتوتایپ Android سوپر اپ نتورک مارکتینگ با Kotlin، Jetpack Compose و Material 3.

V27 پرونده Home/Header/Progress/Rewards را یکپارچه می‌کند: Progress دقیقاً زبان بصری Home را دارد، هیچ کارت UPCOMING از ابتدا قفل نیست، و XP/Coin/Combo/Chest روی یک state persistent مشترک کار می‌کنند.

## تکنولوژی

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Jetpack Compose / Material 3
- Min SDK 26 / Target SDK 35
- Java 17
- App version: `0.8.0` / versionCode `8`

## Build

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

GitHub Actions همین taskها را اجرا می‌کند و APK debug را به‌عنوان artifact تحویل می‌دهد.

## V27 highlights

- هدر ثابت کوتاه‌تر و responsive.
- ترتیب چپ هدر: Settings → Combo → Coin.
- Profile + adaptive name + Builder/Chest در راست.
- Assetهای Coin/Combo/Chest کدنویسی‌شده و مستقل از bitmap.
- Home Today و Next Action از Progress task source خوانده می‌شوند.
- Progress شامل 5 Horizontal RTL section و بدون road است.
- Add/Edit Task شامل category، difficulty، priority، schedule، repeat، Today و Progress flags.
- همه کارت‌های UPCOMING از ابتدا Start می‌شوند؛ Current فقط پیشنهاد قدم فعلی است.
- Reward difficulty-based + Combo ×1.5 از موفقیت سوم.
- Reward ledger برای Undo دقیق Completion.
- Three-hour Chest + Task Chests فقط داخل صفحه صندوق‌ها Claim می‌شوند.
- Empty/Loading/Error states، Snackbar Undo، haptic، scroll memory، long-press quick actions و limited safe swipe.
- Design tokens و dark-theme token set برای توسعه بعدی.

برای جزئیات کامل: `docs/V27_CHANGELOG_FA.md` و `docs/CURRENT_ARCHITECTURE.md`.
