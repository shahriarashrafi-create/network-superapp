package app.networksuper.ui.progress

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProgressPathRulesTest {
    @Test
    fun completedItemsProduceOverallProgress() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.COMPLETED),
            ProgressStage(2, 2, "B", StageStatus.FAILED),
            ProgressStage(3, 3, "C", StageStatus.COMPLETED)
        )
        assertEquals(2f / 3f, ProgressPathRules.overallProgress(items), 0.0001f)
    }

    @Test
    fun currentStageReportsItsOneBasedPosition() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.COMPLETED),
            ProgressStage(2, 2, "B", StageStatus.CURRENT),
            ProgressStage(3, 3, "C", StageStatus.UPCOMING)
        )
        assertEquals(2, ProgressPathRules.currentOrdinal(items))
    }

    @Test
    fun normalizeKeepsSingleCurrentAndContiguousNumbersWithoutLockingUpcoming() {
        val normalized = ProgressPathRules.normalize(
            listOf(
                ProgressStage(3, 30, " C ", StageStatus.CURRENT),
                ProgressStage(1, 10, " A ", StageStatus.CURRENT),
                ProgressStage(2, 20, " B ", StageStatus.UPCOMING)
            )
        )

        assertEquals(listOf(1, 2, 3), normalized.map { it.number })
        assertEquals(listOf("A", "B", "C"), normalized.map { it.title })
        assertEquals(1, normalized.count { it.status == StageStatus.CURRENT })
        assertTrue(normalized.any { it.status == StageStatus.UPCOMING })
    }

    @Test
    fun pinnedTaskWinsNextAction() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.CURRENT, pinnedNext = false),
            ProgressStage(2, 2, "B", StageStatus.UPCOMING, pinnedNext = true)
        )
        assertEquals(2L, ProgressPathRules.nextAction(items, 0L)?.id)
    }

    @Test
    fun skippedTaskIsNotSelectedAsNextAction() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.CURRENT, skipped = true),
            ProgressStage(2, 2, "B", StageStatus.UPCOMING)
        )
        assertEquals(2L, ProgressPathRules.nextAction(items, 0L)?.id)
        assertFalse(ProgressPathRules.nextAction(items, 0L)?.skipped ?: true)
    }
}
