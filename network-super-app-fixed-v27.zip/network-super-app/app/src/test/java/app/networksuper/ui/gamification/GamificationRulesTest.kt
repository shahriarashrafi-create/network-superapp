package app.networksuper.ui.gamification

import app.networksuper.ui.progress.TaskDifficulty
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GamificationRulesTest {
    @Test
    fun difficultyUsesExpectedBaseRewards() {
        assertEquals(2 to 10, GamificationRules.baseReward(TaskDifficulty.LOW))
        assertEquals(4 to 20, GamificationRules.baseReward(TaskDifficulty.MEDIUM))
        assertEquals(7 to 35, GamificationRules.baseReward(TaskDifficulty.HIGH))
    }

    @Test
    fun firstTwoSuccessesUseBaseReward() {
        val first = GamificationRules.taskReward(TaskDifficulty.MEDIUM, currentCombo = 0, currentSuccessCount = 0)
        val second = GamificationRules.taskReward(TaskDifficulty.MEDIUM, currentCombo = 1, currentSuccessCount = 1)

        assertEquals(4, first.coins)
        assertEquals(20, first.xp)
        assertEquals(1f, first.multiplier)
        assertEquals(4, second.coins)
        assertEquals(20, second.xp)
        assertEquals(1f, second.multiplier)
    }

    @Test
    fun thirdConsecutiveSuccessActivatesOnePointFiveMultiplier() {
        val reward = GamificationRules.taskReward(TaskDifficulty.MEDIUM, currentCombo = 2, currentSuccessCount = 2)
        assertEquals(3, reward.comboCount)
        assertEquals(6, reward.coins)
        assertEquals(30, reward.xp)
        assertEquals(1.5f, reward.multiplier)
    }

    @Test
    fun everyFifthNewSuccessEarnsOneTaskChest() {
        assertFalse(GamificationRules.taskReward(TaskDifficulty.LOW, 0, 3).chestEarned)
        assertTrue(GamificationRules.taskReward(TaskDifficulty.LOW, 0, 4).chestEarned)
    }

    @Test
    fun xpLevelTargetAdvancesInThreeThousandSteps() {
        assertEquals(3000, GamificationRules.xpTarget(2480))
        assertEquals(3000, GamificationRules.xpLevelStart(5999))
        assertEquals(6000, GamificationRules.xpTarget(3000))
    }
    @Test
    fun recompletionDoesNotAdvanceChestMilestone() {
        val reward = GamificationRules.taskReward(
            difficulty = TaskDifficulty.LOW,
            currentCombo = 1,
            currentSuccessCount = 4,
            countForChestMilestone = false
        )
        assertEquals(4, reward.successCount)
        assertFalse(reward.chestEarned)
    }

}
