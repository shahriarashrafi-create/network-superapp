package app.networksuper.ui.progress

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.R
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.FailRed
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.PrimaryBlueDark
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen
import app.networksuper.ui.theme.SurfaceOutline
import app.networksuper.ui.theme.WarningOrange
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
internal fun DetailToolbar(
    stage: ProgressStage,
    totalStages: Int,
    pathProgress: Float,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onNote: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 2.dp
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                SmallIconButton(
                    icon = Icons.Rounded.ArrowForward,
                    description = stringResource(R.string.action_back),
                    onClick = onBack
                )
                Text(
                    text = stringResource(R.string.stage_of, stage.number, totalStages),
                    modifier = Modifier.weight(1f),
                    color = Muted,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Box {
                    SmallIconButton(
                        icon = Icons.Rounded.Notes,
                        description = stringResource(R.string.mission_note),
                        onClick = onNote
                    )
                    if (stage.note.isNotBlank() || !stage.noteDraft.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(8.dp)
                                .background(SuccessGreen, CircleShape)
                                .border(1.dp, Color.White, CircleShape)
                        )
                    }
                }
                SmallIconButton(
                    icon = Icons.Rounded.Edit,
                    description = stringResource(R.string.action_edit),
                    onClick = onEdit
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = pathProgress.coerceIn(0f, 1f),
                    modifier = Modifier
                        .weight(1f)
                        .height(7.dp)
                        .clip(CircleShape),
                    color = PrimaryBlue,
                    trackColor = SoftBlue
                )
                Spacer(Modifier.width(9.dp))
                Text(
                    text = "${(pathProgress * 100).roundToInt()}٪",
                    color = PrimaryBlue,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun SmallIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.size(44.dp),
        shape = CircleShape,
        color = SoftBlue.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.12f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = description, tint = Navy, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
internal fun StageIdentityCard(stage: ProgressStage, totalStages: Int, modifier: Modifier = Modifier) {
    val statusText = when (stage.missionStatus) {
        MissionStatus.NOT_STARTED -> if (stage.skipped) "رد شده؛ آماده شروع دوباره" else stringResource(R.string.mission_status_ready)
        MissionStatus.ACTIVE -> stringResource(R.string.mission_active)
        MissionStatus.EXPIRED -> stringResource(R.string.mission_expired_badge)
        MissionStatus.COMPLETED -> stringResource(R.string.done)
        MissionStatus.FAILED -> stringResource(R.string.not_done)
    }
    val statusColor = when (stage.missionStatus) {
        MissionStatus.ACTIVE -> PrimaryBlue
        MissionStatus.EXPIRED -> WarningOrange
        MissionStatus.COMPLETED -> SuccessGreen
        MissionStatus.FAILED -> FailRed
        MissionStatus.NOT_STARTED -> if (stage.skipped) WarningOrange else PrimaryBlue
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stage.title,
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = stringResource(R.string.stage_of, stage.number, totalStages),
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Surface(
                shape = RoundedCornerShape(11.dp),
                color = statusColor.copy(alpha = 0.10f)
            ) {
                Text(
                    text = statusText,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                    color = statusColor,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
internal fun TimerCard(stage: ProgressStage, remainingMillis: Long) {
    val totalMillis = stage.durationMinutes.coerceAtLeast(1) * 60_000L
    val rawFraction = (remainingMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f)
    val fraction by animateFloatAsState(rawFraction, tween(350), label = "timerProgress")
    val timerColorTarget = when {
        stage.missionStatus == MissionStatus.EXPIRED -> FailRed
        stage.missionStatus != MissionStatus.ACTIVE -> PrimaryBlue
        fraction <= 0.05f -> FailRed
        fraction <= 0.20f -> WarningOrange
        else -> PrimaryBlue
    }
    val timerColor by animateColorAsState(timerColorTarget, label = "timerColor")
    val pulseTransition = rememberInfiniteTransition(label = "timerPulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "timerPulseScale"
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(23.dp),
        color = if (stage.missionStatus == MissionStatus.EXPIRED) {
            FailRed.copy(alpha = 0.06f)
        } else {
            Color.White
        },
        border = BorderStroke(1.2.dp, timerColor.copy(alpha = 0.18f)),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier
                    .size(46.dp)
                    .scale(if (stage.missionStatus == MissionStatus.ACTIVE) pulse else 1f),
                shape = CircleShape,
                color = timerColor.copy(alpha = 0.11f),
                border = BorderStroke(1.dp, timerColor.copy(alpha = 0.16f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (stage.missionStatus == MissionStatus.EXPIRED) Icons.Rounded.WarningAmber else Icons.Rounded.Timer,
                        contentDescription = null,
                        tint = timerColor,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                text = when (stage.missionStatus) {
                    MissionStatus.ACTIVE -> stringResource(R.string.mission_time_remaining)
                    MissionStatus.EXPIRED -> stringResource(R.string.mission_time_finished)
                    else -> stringResource(R.string.mission_duration)
                },
                color = Muted,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            AnimatedContent(targetState = remainingMillis, label = "countdown") { millis ->
                Text(
                    text = formatDuration(millis),
                    color = timerColor,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(CircleShape)
                    .background(timerColor.copy(alpha = 0.09f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(timerColor.copy(alpha = 0.70f), timerColor, PrimaryBlueDark)
                            )
                        )
                )
            }
            if (stage.missionStatus == MissionStatus.EXPIRED) {
                Spacer(Modifier.height(7.dp))
                Text(
                    text = stringResource(R.string.mission_expired_message),
                    color = FailRed,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
internal fun ChecklistCard(
    stage: ProgressStage,
    enabled: Boolean,
    onCheckedChange: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val completed = MissionRules.completedCount(stage.checklist)
    val fraction = MissionRules.completionFraction(stage.checklist)
    val animatedFraction by animateFloatAsState(fraction, label = "checklistProgress")

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(23.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 2.dp
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.mission_checklist),
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = stringResource(R.string.mission_checklist_progress, completed, stage.checklist.size),
                        color = Muted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Text(
                    text = "${(fraction * 100).roundToInt()}٪",
                    color = SuccessGreen,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(Modifier.height(7.dp))
            LinearProgressIndicator(
                progress = animatedFraction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(CircleShape),
                color = SuccessGreen,
                trackColor = SuccessGreen.copy(alpha = 0.10f)
            )
            Spacer(Modifier.height(7.dp))

            if (stage.checklist.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = stringResource(R.string.mission_no_checklist),
                        color = Muted,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(stage.checklist, key = { it.id }) { item ->
                        ChecklistRow(
                            item = item,
                            enabled = enabled,
                            onCheckedChange = { checked -> onCheckedChange(item.id, checked) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChecklistRow(
    item: MissionChecklistItem,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val scale by animateFloatAsState(if (item.checked) 1.04f else 1f, label = "checkScale")
    Surface(
        onClick = { if (enabled) onCheckedChange(!item.checked) },
        enabled = enabled,
        shape = RoundedCornerShape(15.dp),
        color = if (item.checked) SuccessGreen.copy(alpha = 0.07f) else AppBackground.copy(alpha = 0.62f),
        border = BorderStroke(1.dp, if (item.checked) SuccessGreen.copy(alpha = 0.22f) else SurfaceOutline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = item.checked,
                onCheckedChange = if (enabled) onCheckedChange else null,
                modifier = Modifier.scale(scale),
                colors = CheckboxDefaults.colors(
                    checkedColor = SuccessGreen,
                    uncheckedColor = Muted.copy(alpha = 0.55f)
                )
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = item.text,
                modifier = Modifier.weight(1f),
                color = if (enabled) Navy else Muted,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (item.required) FontWeight.Bold else FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.width(7.dp))
            Surface(
                shape = RoundedCornerShape(9.dp),
                color = if (item.required) FailRed.copy(alpha = 0.09f) else SoftBlue
            ) {
                Text(
                    text = if (item.required) stringResource(R.string.mission_required) else stringResource(R.string.mission_optional),
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                    color = if (item.required) FailRed else Muted,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
internal fun StartButton(
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "startPulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.018f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "startScale"
    )
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(58.dp)
            .scale(if (enabled) scale else 1f),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
    ) {
        Icon(Icons.Rounded.Timer, contentDescription = null, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.mission_start), fontWeight = FontWeight.Black)
    }
}

@Composable
internal fun ResultActions(
    stage: ProgressStage,
    onDone: () -> Unit,
    onFailed: () -> Unit,
    onSkip: () -> Unit,
    onRestore: () -> Unit
) {
    val remainingRequired = MissionRules.remainingRequired(stage.checklist)
    val canDone = remainingRequired == 0

    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        if (!canDone) {
            Text(
                text = stringResource(R.string.mission_required_remaining, remainingRequired),
                modifier = Modifier.fillMaxWidth(),
                color = FailRed,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Surface(
                onClick = onRestore,
                modifier = Modifier.size(50.dp),
                shape = RoundedCornerShape(16.dp),
                color = SoftBlue,
                border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.16f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.Restore,
                        contentDescription = stringResource(R.string.mission_restore),
                        tint = PrimaryBlue,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
            OutlinedButton(
                onClick = onFailed,
                modifier = Modifier
                    .weight(0.82f)
                    .height(50.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, FailRed.copy(alpha = 0.35f))
            ) {
                Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(5.dp))
                Text(stringResource(R.string.mark_failed), color = FailRed, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onDone,
                enabled = canDone,
                modifier = Modifier
                    .weight(1.55f)
                    .height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SuccessGreen,
                    disabledContainerColor = Muted.copy(alpha = 0.18f)
                )
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(29.dp))
                Spacer(Modifier.width(7.dp))
                Text(stringResource(R.string.mark_done), fontWeight = FontWeight.Black)
            }
        }
        TextButton(
            onClick = onSkip,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Rounded.SkipNext, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(5.dp))
            Text("رد کردن بدون شکستن کمبو", color = WarningOrange, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun FailedContent(
    stage: ProgressStage,
    onRetry: () -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            border = BorderStroke(1.dp, FailRed.copy(alpha = 0.16f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(modifier = Modifier.size(76.dp), shape = CircleShape, color = FailRed.copy(alpha = 0.10f)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(39.dp))
                    }
                }
                Spacer(Modifier.height(13.dp))
                Text(
                    text = stringResource(R.string.mission_failed_title),
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    text = stage.title,
                    color = Muted,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.mission_failed_message),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(stringResource(R.string.mission_retry), fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onRestore,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.mission_restore), fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    text = stringResource(R.string.mission_note_preserved),
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
internal fun SuccessContent(
    stage: ProgressStage,
    pathProgress: Float,
    onNextStage: () -> Unit,
    onBackToPath: () -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.18f)),
            shadowElevation = 3.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(modifier = Modifier.size(78.dp), shape = CircleShape, color = SuccessGreen) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(45.dp))
                    }
                }
                Spacer(Modifier.height(13.dp))
                Text(
                    text = stringResource(R.string.mission_success_title),
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stage.title,
                    color = Muted,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(14.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(17.dp),
                    color = SuccessGreen.copy(alpha = 0.06f)
                ) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row {
                            Text(stringResource(R.string.mission_path_progress), color = Muted, modifier = Modifier.weight(1f))
                            Text("${(pathProgress * 100).roundToInt()}٪", color = SuccessGreen, fontWeight = FontWeight.Black)
                        }
                        LinearProgressIndicator(
                            progress = pathProgress.coerceIn(0f, 1f),
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                            color = SuccessGreen,
                            trackColor = SuccessGreen.copy(alpha = 0.12f)
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onNextStage,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                ) {
                    Text(stringResource(R.string.mission_next_stage), fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
                Spacer(Modifier.height(7.dp))
                OutlinedButton(
                    onClick = onBackToPath,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Route, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.mission_back_to_path), fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onRestore) {
                    Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.mission_restore), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}


private fun formatDuration(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) + 999L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        "%02d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }
}
