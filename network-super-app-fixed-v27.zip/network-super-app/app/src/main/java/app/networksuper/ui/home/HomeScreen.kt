package app.networksuper.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.networksuper.ui.progress.ProgressCategory
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.progress.ProgressStage
import app.networksuper.ui.progress.TaskEditorDialog
import app.networksuper.ui.progress.TaskQuickActionsDialog
import app.networksuper.ui.theme.*
import java.time.LocalDate

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    uiState: HomeUiState = HomeDefaults.state,
    onOpenMission: (Long) -> Unit = {}
) {
    var quickStage by remember { mutableStateOf<ProgressStage?>(null) }
    var editStage by remember { mutableStateOf<ProgressStage?>(null) }

    val nextAction = ProgressPathStore.nextAction()
    val todayStages = ProgressPathStore.todayTasks(LocalDate.now().toEpochDay())
    val scheduleItems = todayStages.map { stage ->
        HomeCardItem(
            id = stage.id,
            title = stage.title,
            icon = when (stage.category) {
                ProgressCategory.PERSONAL -> Icons.Rounded.Person
                ProgressCategory.SALES -> Icons.Rounded.ShoppingBag
                ProgressCategory.NETWORKING -> Icons.Rounded.AccountTree
                ProgressCategory.SUPPORT -> Icons.Rounded.Groups
                ProgressCategory.SPONSOR -> Icons.Rounded.WorkspacePremium
            },
            accent = categoryAccent(stage.category.name),
            done = stage.status == app.networksuper.ui.progress.StageStatus.COMPLETED,
            meta = formatMinuteOfDayPersian(stage.dueMinuteOfDay)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = NetworkDimens.ScreenHorizontalPadding, vertical = NetworkDimens.ScreenVerticalPadding),
        verticalArrangement = Arrangement.spacedBy(NetworkDimens.SectionGap)
    ) {
        NextActionCard(
            nextActionTitle = nextAction?.title ?: "قدم بعدی تنظیم نشده",
            onStart = { nextAction?.let { onOpenMission(it.id) } },
            modifier = Modifier.fillMaxWidth().weight(0.29f)
        )
        TodaySection(
            title = uiState.todayTitle,
            dateLabel = uiState.todayDateLabel,
            scheduleItems = scheduleItems,
            onItemClick = { item -> item.id?.let(onOpenMission) },
            onItemLongClick = { item -> item.id?.let { id -> ProgressPathStore.stage(id)?.let { quickStage = it } } },
            modifier = Modifier.fillMaxWidth().weight(0.355f)
        )
        ProgressSection(
            onStageClick = onOpenMission,
            onStageLongClick = { quickStage = it },
            modifier = Modifier.fillMaxWidth().weight(0.355f)
        )
    }

    quickStage?.let { stage ->
        TaskQuickActionsDialog(
            stage = stage,
            onEdit = { quickStage = null; editStage = stage },
            onDismiss = { quickStage = null }
        )
    }

    editStage?.let { stage ->
        TaskEditorDialog(
            initialCategory = stage.category,
            editingStage = stage,
            onDismiss = { editStage = null },
            onSave = {
                ProgressPathStore.updateTask(stage.id, it)
                editStage = null
            }
        )
    }
}
