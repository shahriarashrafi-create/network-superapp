package app.networksuper.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Shared design tokens for the stable Home / Header / Progress visual system.
 * New screens should consume these tokens rather than introducing one-off sizes.
 */
object NetworkDimens {
    val ScreenHorizontalPadding = 14.dp
    val ScreenVerticalPadding = 6.dp
    val HeaderOuterHeight = 79.dp
    val HeaderCornerRadius = 20.dp
    val SectionRadius = 24.dp
    val CardRadius = 19.dp
    val CompactRadius = 12.dp
    val SectionGap = 8.dp
    val CardGap = 8.dp
    val Hairline = 1.dp
    val ActiveBorder = 1.7.dp
}

object NetworkMotion {
    const val QuickMillis = 180
    const val StandardMillis = 280
    const val RewardMillis = 340
}

/** Semantic badge colors. Keep badge meaning consistent across every screen. */
object NetworkBadgeColors {
    val Action = FailRed       // needs attention / action
    val Done = SuccessGreen    // completed
    val Info = PrimaryBlue     // informational / current
    val Reward = RewardGold    // reward available
    val Skipped = WarningOrange
}

/** Category accents; section surfaces remain white. */
fun categoryAccent(name: String): Color = when (name) {
    "PERSONAL" -> AccentPurple
    "SALES" -> SuccessGreen
    "NETWORKING" -> PrimaryBlue
    "SUPPORT" -> WarningOrange
    "SPONSOR" -> Color(0xFF7659E8)
    else -> PrimaryBlue
}
