package app.networksuper.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.networksuper.R
import app.networksuper.ui.gamification.GamificationStore
import app.networksuper.ui.theme.*
import kotlinx.coroutines.delay

/**
 * Shared compact header used by Home, Progress and the other main destinations.
 * It intentionally owns no scroll state so AppRoot can keep it fixed above page content.
 */
@Composable
internal fun HomeHeader(
    state: HomeUiState,
    modifier: Modifier = Modifier,
    onOpenRewards: () -> Unit = {},
    onOpenSettings: () -> Unit = {}
) {
    val game = GamificationStore.state
    val xpTarget = GamificationStore.xpTarget()
    val xpStart = GamificationStore.xpLevelStart()
    var nowMillis by remember(game.nextThreeHourChestAtMillis) {
        mutableLongStateOf(System.currentTimeMillis())
    }
    LaunchedEffect(game.nextThreeHourChestAtMillis) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(30_000L)
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(21.dp))
            .background(Color.White.copy(alpha = 0.78f))
    ) {
        HeaderWaveBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Fixed left cluster, visual order from left to right: Settings → Combo → Coin.
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        SettingsHeaderItem(onClick = onOpenSettings)
                        ComboHeaderItem(
                            count = game.comboCount,
                            active = GamificationStore.comboActive()
                        )
                        CoinHeaderItem(coins = game.coins)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ProfileArea(
                            userName = state.userName,
                            rankName = state.rankName,
                            chestCount = GamificationStore.availableChestCount(nowMillis),
                            onOpenRewards = onOpenRewards
                        )
                    }
                }
            }

            XpProgressRow(
                current = game.totalXp,
                levelStart = xpStart,
                target = xpTarget
            )
        }
    }
}

@Composable
private fun ProfileArea(
    userName: String,
    rankName: String,
    chestCount: Int,
    onOpenRewards: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ProfileAvatar()
        Column(
            modifier = Modifier.width(124.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AdaptiveNameText(
                userName = userName,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(3.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                RankBadge(
                    rankName = rankName,
                    modifier = Modifier.weight(1f)
                )
                MiniChestButton(
                    availableCount = chestCount,
                    onClick = onOpenRewards
                )
            }
        }
    }
}


@Composable
private fun AdaptiveNameText(userName: String, modifier: Modifier = Modifier) {
    val preferred = when {
        userName.length <= 9 -> 18f
        userName.length <= 14 -> 16f
        userName.length <= 20 -> 14f
        userName.length <= 26 -> 12f
        else -> 10f
    }
    var fittedSize by remember(userName) { mutableFloatStateOf(preferred) }

    Text(
        text = userName,
        modifier = modifier,
        color = Navy,
        fontSize = fittedSize.sp,
        lineHeight = fittedSize.sp,
        fontWeight = FontWeight.Black,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { result ->
            if (result.didOverflowWidth && fittedSize > 8f) {
                fittedSize = (fittedSize - 0.5f).coerceAtLeast(8f)
            }
        }
    )
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val wave1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.38f)
            cubicTo(w * 0.75f, h * 0.16f, w * 0.58f, h * 0.48f, w * 0.38f, h * 0.31f)
            cubicTo(w * 0.20f, h * 0.17f, w * 0.10f, h * 0.38f, 0f, h * 0.22f)
            close()
        }
        drawPath(
            path = wave1,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = 0.34f),
                    Color(0xFF8CCBFF).copy(alpha = 0.18f),
                    Color.Transparent
                )
            )
        )

        val wave2 = Path().apply {
            moveTo(0f, h * 0.08f)
            cubicTo(w * 0.18f, h * 0.30f, w * 0.32f, h * 0.04f, w * 0.48f, h * 0.18f)
            cubicTo(w * 0.66f, h * 0.34f, w * 0.80f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.52f)
            cubicTo(w * 0.80f, h * 0.35f, w * 0.63f, h * 0.56f, w * 0.45f, h * 0.40f)
            cubicTo(w * 0.24f, h * 0.24f, w * 0.12f, h * 0.47f, 0f, h * 0.33f)
            close()
        }
        drawPath(path = wave2, color = Color.White.copy(alpha = 0.28f))
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(43.dp)
            .shadow(5.dp, CircleShape, ambientColor = PrimaryBlue.copy(alpha = 0.14f), spotColor = PrimaryBlue.copy(alpha = 0.18f))
            .clip(CircleShape)
            .background(Color(0xFFE9F5FF))
            .border(1.5.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(37.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))))
                .border(2.dp, RewardGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Person,
                contentDescription = stringResource(R.string.profile),
                tint = Color.White,
                modifier = Modifier.size(23.dp)
            )
        }
    }
}

@Composable
private fun RankBadge(rankName: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(11.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1E63), Color(0xFF17368B))))
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(11.dp))
            .padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(13.dp)
        )
        Spacer(Modifier.width(3.dp))
        Text(
            text = rankName,
            color = Color.White,
            fontSize = 10.sp,
            lineHeight = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
    }
}

@Composable
private fun MiniChestButton(availableCount: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .shadow(2.dp, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.94f))
            .border(1.dp, RewardGold.copy(alpha = 0.26f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        RewardGiftAsset(Modifier.size(20.dp))
        if (availableCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 2.dp, y = (-2).dp)
                    .size(if (availableCount > 9) 14.dp else 12.dp)
                    .background(NetworkBadgeColors.Action, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (availableCount > 9) "۹+" else availableCount.toPersianNumber(),
                    color = Color.White,
                    fontSize = 7.sp,
                    lineHeight = 7.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun CoinHeaderItem(coins: Int) {
    CompactHeaderAction(
        icon = { PremiumCoinAsset(Modifier.size(27.dp)) },
        bottomText = formatCompactPersianNumber(coins)
    )
}

@Composable
private fun ComboHeaderItem(count: Int, active: Boolean) {
    CompactHeaderAction(
        icon = {
            Box(modifier = Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                PremiumComboAsset(active = active, modifier = Modifier.size(26.dp))
                if (active) {
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter).offset(y = 2.dp),
                        shape = RoundedCornerShape(5.dp),
                        color = Color.White.copy(alpha = 0.94f)
                    ) {
                        Text(
                            text = "×۱.۵",
                            modifier = Modifier.padding(horizontal = 2.dp),
                            color = Navy,
                            fontSize = 6.sp,
                            lineHeight = 7.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        },
        bottomText = count.toPersianNumber()
    )
}

@Composable
private fun SettingsHeaderItem(onClick: () -> Unit) {
    CompactHeaderAction(
        modifier = Modifier.clickable(onClick = onClick),
        icon = { PremiumSettingsAsset(Modifier.size(25.dp)) },
        bottomText = ""
    )
}

@Composable
private fun PremiumSettingsAsset(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0xFFEAF6FF), Color(0xFFB9DCFF))))
            .border(1.dp, Color.White.copy(alpha = 0.92f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.Settings,
            contentDescription = "تنظیمات",
            tint = PrimaryBlueDark,
            modifier = Modifier.size(17.dp)
        )
    }
}

@Composable
private fun CompactHeaderAction(
    icon: @Composable BoxScope.() -> Unit,
    bottomText: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.width(33.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Box(
            modifier = Modifier
                .size(29.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.78f))
                .border(1.dp, Color.White.copy(alpha = 0.92f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
            content = icon
        )
        if (bottomText.isNotEmpty()) {
            Text(
                text = bottomText,
                color = Navy,
                fontSize = 9.sp,
                lineHeight = 9.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PremiumCoinAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val r = size.minDimension / 2f
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color(0xFFFFF0A3), Color(0xFFFFC83D), Color(0xFFE89A08)),
                center = Offset(size.width * 0.36f, size.height * 0.30f),
                radius = r
            ),
            radius = r * 0.88f,
            center = center
        )
        drawCircle(
            color = Color(0xFFFFE783),
            radius = r * 0.66f,
            center = center,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = r * 0.12f)
        )
        val star = Path().apply {
            val cx = center.x
            val cy = center.y
            val outer = r * 0.42f
            val inner = r * 0.19f
            for (i in 0 until 10) {
                val angle = -Math.PI / 2 + i * Math.PI / 5
                val radius = if (i % 2 == 0) outer else inner
                val x = cx + kotlin.math.cos(angle).toFloat() * radius
                val y = cy + kotlin.math.sin(angle).toFloat() * radius
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        drawPath(star, Color(0xFFB87500))
        drawCircle(Color.White.copy(alpha = 0.42f), radius = r * 0.11f, center = Offset(size.width * 0.34f, size.height * 0.25f))
    }
}

@Composable
private fun PremiumComboAsset(active: Boolean, modifier: Modifier = Modifier) {
    val hot = if (active) Color(0xFFFF4D23) else Color(0xFFFF9B55)
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val flame = Path().apply {
            moveTo(w * 0.50f, h * 0.06f)
            cubicTo(w * 0.68f, h * 0.28f, w * 0.88f, h * 0.41f, w * 0.80f, h * 0.67f)
            cubicTo(w * 0.74f, h * 0.90f, w * 0.56f, h * 0.97f, w * 0.42f, h * 0.91f)
            cubicTo(w * 0.16f, h * 0.81f, w * 0.10f, h * 0.58f, w * 0.25f, h * 0.39f)
            cubicTo(w * 0.32f, h * 0.30f, w * 0.39f, h * 0.20f, w * 0.50f, h * 0.06f)
            close()
        }
        drawPath(flame, Brush.verticalGradient(listOf(Color(0xFFFFD059), hot, Color(0xFFE9381B))))
        val inner = Path().apply {
            moveTo(w * 0.50f, h * 0.40f)
            cubicTo(w * 0.63f, h * 0.55f, w * 0.65f, h * 0.72f, w * 0.53f, h * 0.82f)
            cubicTo(w * 0.40f, h * 0.78f, w * 0.36f, h * 0.64f, w * 0.42f, h * 0.54f)
            close()
        }
        drawPath(inner, Color(0xFFFFF1A8))
    }
}

@Composable
private fun RewardGiftAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFD348), Color(0xFFF09A16))),
            topLeft = Offset(w * 0.15f, h * 0.38f),
            size = Size(w * 0.70f, h * 0.45f),
            cornerRadius = CornerRadius(w * 0.09f, w * 0.09f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE676), Color(0xFFFFB51A))),
            topLeft = Offset(w * 0.11f, h * 0.31f),
            size = Size(w * 0.78f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )
        drawRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.44f, h * 0.31f),
            size = Size(w * 0.12f, h * 0.52f)
        )
        drawRoundRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.30f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = Color(0xFFFF6671),
            topLeft = Offset(w * 0.50f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawLine(
            color = Color.White.copy(alpha = 0.65f),
            start = Offset(w * 0.18f, h * 0.35f),
            end = Offset(w * 0.35f, h * 0.35f),
            strokeWidth = 1.4f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun XpProgressRow(current: Int, levelStart: Int, target: Int) {
    val denominator = (target - levelStart).coerceAtLeast(1)
    val progress = ((current - levelStart).toFloat() / denominator.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(17.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.White.copy(alpha = 0.72f))
                .padding(horizontal = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "${formatCompactPersianNumber(current)} XP",
                color = PrimaryBlue,
                fontSize = 8.sp,
                lineHeight = 8.sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDCE8F7))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)))
                )
            }
            Text(
                text = formatCompactPersianNumber(target),
                color = Muted,
                fontSize = 8.sp,
                lineHeight = 8.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
