package app.networksuper.ui.gamification

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.progress.StageStatus
import app.networksuper.ui.progress.TaskDifficulty
import org.json.JSONArray
import org.json.JSONObject

/** Persistent single source of truth for XP, Coin, Combo and all reward chests. */
object GamificationStore {
    private const val PREFS_NAME = "gamification_v2"
    private const val LEGACY_PREFS_NAME = "gamification_v1"
    private const val KEY_COINS = "coins"
    private const val KEY_XP = "xp"
    private const val KEY_COMBO = "combo"
    private const val KEY_REWARDED_STAGE_IDS = "rewarded_stage_ids"
    private const val KEY_UNCLAIMED_TASK_CHESTS = "unclaimed_task_chests"
    private const val KEY_NEXT_THREE_HOUR_CHEST_AT = "next_three_hour_chest_at"
    private const val KEY_CHEST_OPEN_COUNT = "chest_open_count"
    private const val KEY_SUCCESS_COUNT = "success_count"
    private const val KEY_EVENT_SEQUENCE = "event_sequence"
    private const val KEY_LAST_FAILURE_SEQUENCE = "last_failure_sequence"
    private const val KEY_REWARD_LEDGER = "reward_ledger"
    private const val KEY_EVER_COMPLETED_STAGE_IDS = "ever_completed_stage_ids"

    private const val DEFAULT_COINS = 86
    private const val DEFAULT_XP = 2480
    const val THREE_HOURS_MILLIS: Long = 3L * 60L * 60L * 1000L

    private var prefs: SharedPreferences? = null
    private var initialized = false

    var state by mutableStateOf(GamificationState())
        private set

    fun initialize(context: Context) {
        if (initialized) return
        val appContext = context.applicationContext
        val storage = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val legacy = appContext.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)
        prefs = storage

        val source = if (storage.contains(KEY_COINS) || storage.contains(KEY_XP)) storage else legacy
        val alreadyCompletedIds = ProgressPathStore.stages
            .filter { it.status == StageStatus.COMPLETED }
            .map { it.id }
            .toSet()

        val rewardedIds = if (source.contains(KEY_REWARDED_STAGE_IDS)) {
            source.getStringSet(KEY_REWARDED_STAGE_IDS, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
        } else alreadyCompletedIds

        val everCompletedIds = if (source.contains(KEY_EVER_COMPLETED_STAGE_IDS)) {
            source.getStringSet(KEY_EVER_COMPLETED_STAGE_IDS, emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()
        } else {
            rewardedIds + alreadyCompletedIds
        }
        val ledger = decodeLedger(source.getString(KEY_REWARD_LEDGER, null))
        state = GamificationState(
            coins = source.getInt(KEY_COINS, DEFAULT_COINS),
            totalXp = source.getInt(KEY_XP, DEFAULT_XP),
            comboCount = source.getInt(KEY_COMBO, 0).coerceAtLeast(0),
            rewardedStageIds = rewardedIds,
            unclaimedTaskChests = source.getInt(KEY_UNCLAIMED_TASK_CHESTS, 0).coerceAtLeast(0),
            nextThreeHourChestAtMillis = source.getLong(KEY_NEXT_THREE_HOUR_CHEST_AT, 0L).coerceAtLeast(0L),
            chestOpenCount = source.getInt(KEY_CHEST_OPEN_COUNT, 0).coerceAtLeast(0),
            successCount = maxOf(source.getInt(KEY_SUCCESS_COUNT, 0).coerceAtLeast(0), everCompletedIds.size),
            everCompletedStageIds = everCompletedIds,
            eventSequence = source.getLong(KEY_EVENT_SEQUENCE, 0L).coerceAtLeast(0L),
            lastFailureSequence = source.getLong(KEY_LAST_FAILURE_SEQUENCE, 0L).coerceAtLeast(0L),
            rewardLedger = ledger
        )
        persist()
        initialized = true
    }

    fun onTaskCompleted(stageId: Long, difficulty: TaskDifficulty): TaskRewardReceipt? {
        if (stageId in state.rewardedStageIds) return null

        val firstLifetimeCompletion = stageId !in state.everCompletedStageIds
        val reward = GamificationRules.taskReward(
            difficulty = difficulty,
            currentCombo = state.comboCount,
            currentSuccessCount = state.successCount,
            countForChestMilestone = firstLifetimeCompletion
        )
        val sequence = state.eventSequence + 1L
        val entry = RewardLedgerEntry(
            stageId = stageId,
            coins = reward.coins,
            xp = reward.xp,
            multiplier = reward.multiplier,
            chestEarned = reward.chestEarned,
            sequence = sequence
        )

        state = state.copy(
            coins = state.coins + reward.coins,
            totalXp = state.totalXp + reward.xp,
            comboCount = reward.comboCount,
            rewardedStageIds = state.rewardedStageIds + stageId,
            unclaimedTaskChests = state.unclaimedTaskChests + if (reward.chestEarned) 1 else 0,
            successCount = reward.successCount,
            everCompletedStageIds = state.everCompletedStageIds + stageId,
            eventSequence = sequence,
            rewardLedger = state.rewardLedger + entry
        )
        persist()

        return TaskRewardReceipt(reward.coins, reward.xp, reward.comboCount, reward.multiplier, reward.chestEarned)
    }

    /** Failure is the only result that breaks the current consecutive Combo. */
    fun onTaskFailed() {
        val sequence = state.eventSequence + 1L
        state = state.copy(comboCount = 0, eventSequence = sequence, lastFailureSequence = sequence)
        persist()
    }

    /** Skip gives no reward and intentionally does not break Combo. */
    fun onTaskSkipped() = Unit

    /**
     * Exact reward rollback. If the completion created a chest that has already been claimed,
     * undo is intentionally blocked to prevent reward duplication/exploitation.
     */
    fun undoTaskCompletion(stageId: Long): UndoRewardReceipt? {
        val entry = state.rewardLedger.lastOrNull { it.stageId == stageId } ?: return null
        if (entry.chestEarned && state.unclaimedTaskChests <= 0) return null

        val remainingLedger = state.rewardLedger.filterNot { it.stageId == stageId }
        val comboAfterLastFailure = remainingLedger.count { it.sequence > state.lastFailureSequence }
        state = state.copy(
            coins = (state.coins - entry.coins).coerceAtLeast(0),
            totalXp = (state.totalXp - entry.xp).coerceAtLeast(0),
            comboCount = comboAfterLastFailure,
            rewardedStageIds = state.rewardedStageIds - stageId,
            unclaimedTaskChests = (state.unclaimedTaskChests - if (entry.chestEarned) 1 else 0).coerceAtLeast(0),
            rewardLedger = remainingLedger
        )
        persist()
        return UndoRewardReceipt(entry.coins, entry.xp)
    }

    fun comboActive(): Boolean = state.comboCount >= GamificationRules.COMBO_START
    fun xpTarget(): Int = GamificationRules.xpTarget(state.totalXp)
    fun xpLevelStart(): Int = GamificationRules.xpLevelStart(state.totalXp)

    fun isThreeHourChestReady(nowMillis: Long = System.currentTimeMillis()): Boolean =
        state.nextThreeHourChestAtMillis == 0L || nowMillis >= state.nextThreeHourChestAtMillis

    fun availableChestCount(nowMillis: Long = System.currentTimeMillis()): Int =
        state.unclaimedTaskChests + if (isThreeHourChestReady(nowMillis)) 1 else 0

    fun threeHourChestRemainingMillis(nowMillis: Long = System.currentTimeMillis()): Long =
        (state.nextThreeHourChestAtMillis - nowMillis).coerceAtLeast(0L)

    fun claimTaskChest(): ChestReward? {
        if (state.unclaimedTaskChests <= 0) return null
        val reward = rewardForOpenIndex(state.chestOpenCount, earned = true)
        applyChestReward(reward, state.copy(unclaimedTaskChests = state.unclaimedTaskChests - 1, chestOpenCount = state.chestOpenCount + 1))
        return reward
    }

    fun claimThreeHourChest(nowMillis: Long = System.currentTimeMillis()): ChestReward? {
        if (!isThreeHourChestReady(nowMillis)) return null
        val reward = rewardForOpenIndex(state.chestOpenCount, earned = false)
        applyChestReward(reward, state.copy(nextThreeHourChestAtMillis = nowMillis + THREE_HOURS_MILLIS, chestOpenCount = state.chestOpenCount + 1))
        return reward
    }

    private fun applyChestReward(reward: ChestReward, nextState: GamificationState) {
        state = nextState.copy(coins = nextState.coins + reward.coins, totalXp = nextState.totalXp + reward.xp)
        persist()
    }

    private fun rewardForOpenIndex(openIndex: Int, earned: Boolean): ChestReward {
        val bucket = Math.floorMod(openIndex, 6)
        return if (earned) {
            when (bucket) {
                0 -> ChestReward(20, 60, "۲۰ سکه + ۶۰ XP")
                1 -> ChestReward(35, 0, "۳۵ سکه")
                2 -> ChestReward(12, 120, "۱۲ سکه + ۱۲۰ XP")
                3 -> ChestReward(50, 50, "۵۰ سکه + ۵۰ XP")
                4 -> ChestReward(18, 160, "۱۸ سکه + ۱۶۰ XP")
                else -> ChestReward(65, 80, "۶۵ سکه + ۸۰ XP")
            }
        } else {
            when (bucket) {
                0 -> ChestReward(8, 30, "۸ سکه + ۳۰ XP")
                1 -> ChestReward(12, 20, "۱۲ سکه + ۲۰ XP")
                2 -> ChestReward(6, 50, "۶ سکه + ۵۰ XP")
                3 -> ChestReward(15, 25, "۱۵ سکه + ۲۵ XP")
                4 -> ChestReward(10, 45, "۱۰ سکه + ۴۵ XP")
                else -> ChestReward(18, 30, "۱۸ سکه + ۳۰ XP")
            }
        }
    }

    private fun persist() {
        val storage = prefs ?: return
        storage.edit()
            .putInt(KEY_COINS, state.coins)
            .putInt(KEY_XP, state.totalXp)
            .putInt(KEY_COMBO, state.comboCount)
            .putStringSet(KEY_REWARDED_STAGE_IDS, state.rewardedStageIds.map(Long::toString).toMutableSet())
            .putInt(KEY_UNCLAIMED_TASK_CHESTS, state.unclaimedTaskChests)
            .putLong(KEY_NEXT_THREE_HOUR_CHEST_AT, state.nextThreeHourChestAtMillis)
            .putInt(KEY_CHEST_OPEN_COUNT, state.chestOpenCount)
            .putInt(KEY_SUCCESS_COUNT, state.successCount)
            .putStringSet(KEY_EVER_COMPLETED_STAGE_IDS, state.everCompletedStageIds.map(Long::toString).toMutableSet())
            .putLong(KEY_EVENT_SEQUENCE, state.eventSequence)
            .putLong(KEY_LAST_FAILURE_SEQUENCE, state.lastFailureSequence)
            .putString(KEY_REWARD_LEDGER, encodeLedger(state.rewardLedger))
            .apply()
    }

    private fun encodeLedger(entries: List<RewardLedgerEntry>): String = JSONArray().apply {
        entries.forEach { entry ->
            put(JSONObject().put("stageId", entry.stageId).put("coins", entry.coins).put("xp", entry.xp)
                .put("multiplier", entry.multiplier.toDouble()).put("chestEarned", entry.chestEarned).put("sequence", entry.sequence))
        }
    }.toString()

    private fun decodeLedger(raw: String?): List<RewardLedgerEntry> = runCatching {
        if (raw.isNullOrBlank()) return@runCatching emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(RewardLedgerEntry(item.getLong("stageId"), item.getInt("coins"), item.getInt("xp"), item.optDouble("multiplier", 1.0).toFloat(), item.optBoolean("chestEarned", false), item.optLong("sequence", i.toLong() + 1L)))
            }
        }
    }.getOrDefault(emptyList())
}

data class GamificationState(
    val coins: Int = 86,
    val totalXp: Int = 2480,
    val comboCount: Int = 0,
    val rewardedStageIds: Set<Long> = emptySet(),
    val unclaimedTaskChests: Int = 0,
    val nextThreeHourChestAtMillis: Long = 0L,
    val chestOpenCount: Int = 0,
    val successCount: Int = 0,
    val everCompletedStageIds: Set<Long> = emptySet(),
    val eventSequence: Long = 0L,
    val lastFailureSequence: Long = 0L,
    val rewardLedger: List<RewardLedgerEntry> = emptyList()
)

data class RewardLedgerEntry(val stageId: Long, val coins: Int, val xp: Int, val multiplier: Float, val chestEarned: Boolean, val sequence: Long)
data class TaskRewardReceipt(val coins: Int, val xp: Int, val comboCount: Int, val multiplier: Float, val chestEarned: Boolean)
data class UndoRewardReceipt(val coins: Int, val xp: Int)
data class ChestReward(val coins: Int, val xp: Int, val label: String)
