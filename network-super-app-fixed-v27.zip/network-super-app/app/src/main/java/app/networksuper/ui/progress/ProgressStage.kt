package app.networksuper.ui.progress

enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

enum class MissionStatus { NOT_STARTED, ACTIVE, EXPIRED, COMPLETED, FAILED }

enum class TaskDifficulty {
    LOW, MEDIUM, HIGH
}

enum class TaskPriority(val weight: Int) {
    LOW(0), NORMAL(1), HIGH(2), CRITICAL(3)
}

enum class RepeatRule {
    NONE, DAILY, WEEKLY
}

enum class ProgressCategory {
    PERSONAL,
    SALES,
    NETWORKING,
    SUPPORT,
    SPONSOR;

    companion object {
        fun fromLegacy(number: Int, title: String): ProgressCategory {
            val normalized = title.trim()
            return when {
                normalized.contains("مشتری") || normalized.contains("فروش") || normalized.contains("مالی") -> SALES
                normalized.contains("ارتباط") || normalized.contains("معرفی") || normalized.contains("شبکه") -> NETWORKING
                normalized.contains("یادگیری") || normalized.contains("مهارت") || normalized.contains("حمایت") -> SUPPORT
                normalized.contains("رهبری") || normalized.contains("حامی") || normalized.contains("تیم") -> SPONSOR
                else -> entries[Math.floorMod(number - 1, entries.size)]
            }
        }
    }
}

data class MissionChecklistItem(
    val id: Long,
    val text: String,
    val required: Boolean,
    val checked: Boolean = false
)

/**
 * One source of truth for the Home action cards and Progress Path cards.
 * UPCOMING means "not current yet", never "locked". Every task is openable from the start.
 */
data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus,
    val category: ProgressCategory = ProgressCategory.PERSONAL,
    val difficulty: TaskDifficulty = TaskDifficulty.MEDIUM,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val pinnedNext: Boolean = false,
    val showInToday: Boolean = false,
    val belongsToProgressPath: Boolean = true,
    val plannedEpochDay: Long? = null,
    /** Minutes after midnight in local time. Null means untimed. */
    val dueMinuteOfDay: Int? = null,
    val repeatRule: RepeatRule = RepeatRule.NONE,
    /** Used as the recurrence anchor for weekly tasks. */
    val repeatAnchorEpochDay: Long? = plannedEpochDay,
    /** Skip is a soft state. It never locks a card and it does not break Combo. */
    val skipped: Boolean = false,
    val createdAtMillis: Long = 0L,
    /** Legacy persisted field kept only so existing payloads remain fully compatible. */
    val description: String = "",
    val missionStatus: MissionStatus = status.defaultMissionStatus(),
    val durationMinutes: Int = DEFAULT_MISSION_DURATION_MINUTES,
    val startedAtMillis: Long? = null,
    val endAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val attemptCount: Int = 0,
    val note: String = "",
    /** Autosaved working copy. Null means there is no unsaved draft. */
    val noteDraft: String? = null,
    val checklist: List<MissionChecklistItem> = emptyList()
) {
    companion object {
        const val DEFAULT_MISSION_DURATION_MINUTES = 15
    }
}

data class TaskDraft(
    val title: String,
    val category: ProgressCategory,
    val difficulty: TaskDifficulty = TaskDifficulty.MEDIUM,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val showInToday: Boolean = false,
    val belongsToProgressPath: Boolean = true,
    val dueMinuteOfDay: Int? = null,
    val repeatRule: RepeatRule = RepeatRule.NONE,
    val plannedEpochDay: Long? = null,
    val pinnedNext: Boolean = false
)

private fun StageStatus.defaultMissionStatus(): MissionStatus = when (this) {
    StageStatus.COMPLETED -> MissionStatus.COMPLETED
    StageStatus.FAILED -> MissionStatus.FAILED
    StageStatus.CURRENT, StageStatus.UPCOMING -> MissionStatus.NOT_STARTED
}
