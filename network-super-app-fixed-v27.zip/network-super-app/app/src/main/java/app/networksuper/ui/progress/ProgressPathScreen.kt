package app.networksuper.ui.progress

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.ui.components.ProgressTaskCard
import app.networksuper.ui.theme.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private data class CategoryVisual(val category: ProgressCategory, val title: String, val icon: ImageVector, val accent: Color)

private val ProgressCategories = listOf(
    CategoryVisual(ProgressCategory.PERSONAL, "کارهای شخصی", Icons.Rounded.Person, AccentPurple),
    CategoryVisual(ProgressCategory.SALES, "کارهای فروش", Icons.Rounded.ShoppingBag, SuccessGreen),
    CategoryVisual(ProgressCategory.NETWORKING, "کارهای شبکه‌سازی", Icons.Rounded.AccountTree, PrimaryBlue),
    CategoryVisual(ProgressCategory.SUPPORT, "کارهای حمایتی", Icons.Rounded.Groups, WarningOrange),
    CategoryVisual(ProgressCategory.SPONSOR, "کارهای حامی", Icons.Rounded.WorkspacePremium, Color(0xFF7659E8))
)

private object ProgressScrollMemory {
    val positions = mutableMapOf<ProgressCategory, Pair<Int, Int>>()
    var verticalOffset: Int = 0
}

/** Full Progress page intentionally mirrors Home: white sections, RTL horizontal cards, no road. */
@Composable
fun ProgressPathContent(
    modifier: Modifier = Modifier,
    onOpenMission: (Long) -> Unit = {}
) {
    val context = LocalContext.current
    when (ProgressPathStore.loadState) {
        ProgressPathStore.LoadState.LOADING -> {
            ProgressSkeleton(modifier)
            return
        }
        ProgressPathStore.LoadState.ERROR -> {
            ProgressErrorState(modifier = modifier, onRetry = { ProgressPathStore.retryLoad(context) })
            return
        }
        else -> Unit
    }

    var addCategory by remember { mutableStateOf<ProgressCategory?>(null) }
    var editStage by remember { mutableStateOf<ProgressStage?>(null) }
    var quickStage by remember { mutableStateOf<ProgressStage?>(null) }

    val verticalState = rememberScrollState(initial = ProgressScrollMemory.verticalOffset)
    LaunchedEffect(verticalState) {
        snapshotFlow { verticalState.value }
            .distinctUntilChanged()
            .collectLatest { ProgressScrollMemory.verticalOffset = it }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .verticalScroll(verticalState)
            .padding(horizontal = NetworkDimens.ScreenHorizontalPadding, vertical = NetworkDimens.ScreenVerticalPadding),
        verticalArrangement = Arrangement.spacedBy(NetworkDimens.SectionGap)
    ) {
        ProgressSummaryCard()

        ProgressCategories.forEach { visual ->
            val items = ProgressPathStore.stages
                .filter { it.belongsToProgressPath && it.category == visual.category }
                .sortedBy { it.number }
            ProgressCategorySection(
                visual = visual,
                stages = items,
                onAdd = { addCategory = visual.category },
                onStageClick = onOpenMission,
                onStageLongClick = { quickStage = it }
            )
        }
        Spacer(Modifier.height(8.dp))
    }

    addCategory?.let { category ->
        TaskEditorDialog(
            initialCategory = category,
            editingStage = null,
            onDismiss = { addCategory = null },
            onSave = {
                ProgressPathStore.addTask(it)
                addCategory = null
            }
        )
    }

    editStage?.let { stage ->
        TaskEditorDialog(
            initialCategory = stage.category,
            editingStage = stage,
            onDismiss = { editStage = null },
            onSave = {
                ProgressPathStore.updateTask(stage.id, it)
                editStage = null
            }
        )
    }

    quickStage?.let { stage ->
        TaskQuickActionsDialog(
            stage = stage,
            onEdit = {
                quickStage = null
                editStage = stage
            },
            onDismiss = { quickStage = null }
        )
    }
}

@Composable
private fun ProgressSummaryCard() {
    val progress = ProgressPathStore.overallProgress()
    val completed = ProgressPathStore.stages.count { it.belongsToProgressPath && it.status == StageStatus.COMPLETED }
    val total = ProgressPathStore.stages.count { it.belongsToProgressPath }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(NetworkDimens.SectionRadius),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 1.dp
    ) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${completed.toPersianNumber()}/${total.toPersianNumber()}", color = PrimaryBlue, fontWeight = FontWeight.Black)
                Text("پیشرفت کلی ${formatPercentPersian(progress)}", color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
            }
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = PrimaryBlue,
                trackColor = SoftBlue,
                strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

@Composable
private fun ProgressCategorySection(
    visual: CategoryVisual,
    stages: List<ProgressStage>,
    onAdd: () -> Unit,
    onStageClick: (Long) -> Unit,
    onStageLongClick: (ProgressStage) -> Unit
) {
    val (completed, total) = ProgressPathStore.categoryProgress(visual.category)

    Surface(
        modifier = Modifier.fillMaxWidth().height(184.dp),
        shape = RoundedCornerShape(NetworkDimens.SectionRadius),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 1.5.dp
    ) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        onClick = onAdd,
                        modifier = Modifier.size(31.dp),
                        shape = CircleShape,
                        color = visual.accent.copy(alpha = 0.10f),
                        border = BorderStroke(1.dp, visual.accent.copy(alpha = 0.18f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Add, "افزودن", tint = visual.accent, modifier = Modifier.size(19.dp))
                        }
                    }
                    Surface(shape = RoundedCornerShape(11.dp), color = visual.accent.copy(alpha = 0.08f)) {
                        Text(
                            "${completed.toPersianNumber()}/${total.toPersianNumber()}",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            color = visual.accent,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(visual.title, color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
                    Box(
                        modifier = Modifier.size(32.dp).background(visual.accent.copy(alpha = 0.10f), RoundedCornerShape(11.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(visual.icon, null, tint = visual.accent, modifier = Modifier.size(19.dp))
                    }
                }
            }
            Spacer(Modifier.height(6.dp))

            if (stages.isEmpty()) {
                EmptyCategoryState(accent = visual.accent, onAdd = onAdd, modifier = Modifier.weight(1f))
            } else {
                HomeLikeProgressRow(
                    category = visual.category,
                    stages = stages,
                    accent = visual.accent,
                    onStageClick = onStageClick,
                    onStageLongClick = onStageLongClick,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun HomeLikeProgressRow(
    category: ProgressCategory,
    stages: List<ProgressStage>,
    accent: Color,
    onStageClick: (Long) -> Unit,
    onStageLongClick: (ProgressStage) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusIndex = stages.indexOfFirst { it.status == StageStatus.CURRENT }.takeIf { it >= 0 }
        ?: stages.indexOfFirst { !it.skipped && it.status == StageStatus.UPCOMING }.coerceAtLeast(0)
    val saved = ProgressScrollMemory.positions[category]
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = saved?.first?.coerceIn(0, stages.lastIndex) ?: focusIndex,
        initialFirstVisibleItemScrollOffset = saved?.second ?: 0
    )

    LaunchedEffect(category, listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .distinctUntilChanged()
            .collectLatest { ProgressScrollMemory.positions[category] = it }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        LazyRow(
            state = listState,
            modifier = modifier.fillMaxWidth(),
            reverseLayout = true,
            horizontalArrangement = Arrangement.spacedBy(NetworkDimens.CardGap),
            contentPadding = PaddingValues(horizontal = 1.dp)
        ) {
            itemsIndexed(stages, key = { _, item -> item.id }) { _, stage ->
                ProgressTaskCard(
                    stage = stage,
                    categoryAccent = accent,
                    onClick = { onStageClick(stage.id) },
                    onLongClick = { onStageLongClick(stage) },
                    modifier = Modifier.width(140.dp).fillMaxHeight()
                )
            }
        }
    }
}

@Composable
private fun EmptyCategoryState(accent: Color, onAdd: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Rounded.AddTask, null, tint = accent.copy(alpha = 0.65f), modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(4.dp))
        Text("هنوز کاری در این بخش ثبت نشده", color = Muted, style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = onAdd) { Text("افزودن تسک", color = accent, fontWeight = FontWeight.Bold) }
    }
}

@Composable
internal fun TaskEditorDialog(
    initialCategory: ProgressCategory,
    editingStage: ProgressStage?,
    onDismiss: () -> Unit,
    onSave: (TaskDraft) -> Unit
) {
    var title by remember(editingStage?.id) { mutableStateOf(editingStage?.title.orEmpty()) }
    var category by remember(editingStage?.id) { mutableStateOf(editingStage?.category ?: initialCategory) }
    var difficulty by remember(editingStage?.id) { mutableStateOf(editingStage?.difficulty ?: TaskDifficulty.MEDIUM) }
    var priority by remember(editingStage?.id) { mutableStateOf(editingStage?.priority ?: TaskPriority.NORMAL) }
    var showToday by remember(editingStage?.id) { mutableStateOf(editingStage?.showInToday ?: false) }
    var inProgress by remember(editingStage?.id) { mutableStateOf(editingStage?.belongsToProgressPath ?: true) }
    var pinned by remember(editingStage?.id) { mutableStateOf(editingStage?.pinnedNext ?: false) }
    var repeat by remember(editingStage?.id) { mutableStateOf(editingStage?.repeatRule ?: RepeatRule.NONE) }
    var timeText by remember(editingStage?.id) { mutableStateOf(editingStage?.dueMinuteOfDay?.let { String.format("%02d:%02d", it / 60, it % 60) }.orEmpty()) }
    var categoryMenu by remember { mutableStateOf(false) }
    var repeatMenu by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editingStage == null) "افزودن تسک" else "ویرایش تسک", color = Navy, fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("عنوان") }, singleLine = true)

                Box {
                    OutlinedButton(onClick = { categoryMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(categoryTitle(category)) }
                    DropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                        ProgressCategory.entries.forEach { item ->
                            DropdownMenuItem(text = { Text(categoryTitle(item)) }, onClick = { category = item; categoryMenu = false })
                        }
                    }
                }

                Text("سختی", color = Muted, style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    DifficultyChip("کم", TaskDifficulty.LOW, difficulty) { difficulty = it }
                    DifficultyChip("متوسط", TaskDifficulty.MEDIUM, difficulty) { difficulty = it }
                    DifficultyChip("زیاد", TaskDifficulty.HIGH, difficulty) { difficulty = it }
                }

                Text("اولویت", color = Muted, style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    PriorityChip("عادی", TaskPriority.NORMAL, priority) { priority = it }
                    PriorityChip("بالا", TaskPriority.HIGH, priority) { priority = it }
                    PriorityChip("حیاتی", TaskPriority.CRITICAL, priority) { priority = it }
                }

                SettingSwitch("نمایش در امروز من", showToday) { showToday = it }
                SettingSwitch("نمایش در مسیر پیشرفت", inProgress) { inProgress = it }
                SettingSwitch("قدم بعدی پین شود", pinned) { pinned = it }

                if (showToday) {
                    OutlinedTextField(
                        value = timeText,
                        onValueChange = { timeText = it.take(5) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("ساعت (مثال 18:30)") },
                        singleLine = true
                    )
                    Box {
                        OutlinedButton(onClick = { repeatMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(repeatTitle(repeat)) }
                        DropdownMenu(expanded = repeatMenu, onDismissRequest = { repeatMenu = false }) {
                            RepeatRule.entries.forEach { item ->
                                DropdownMenuItem(text = { Text(repeatTitle(item)) }, onClick = { repeat = item; repeatMenu = false })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val today = LocalDate.now().toEpochDay()
                    onSave(
                        TaskDraft(
                            title = title,
                            category = category,
                            difficulty = difficulty,
                            priority = priority,
                            showInToday = showToday,
                            belongsToProgressPath = inProgress,
                            dueMinuteOfDay = parseTime(timeText),
                            repeatRule = if (showToday) repeat else RepeatRule.NONE,
                            plannedEpochDay = if (showToday) today else null,
                            pinnedNext = pinned
                        )
                    )
                },
                enabled = title.isNotBlank()
            ) { Text(if (editingStage == null) "افزودن" else "ذخیره", fontWeight = FontWeight.Black) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun DifficultyChip(label: String, value: TaskDifficulty, selected: TaskDifficulty, onSelect: (TaskDifficulty) -> Unit) {
    FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
}

@Composable
private fun PriorityChip(label: String, value: TaskPriority, selected: TaskPriority, onSelect: (TaskPriority) -> Unit) {
    FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Switch(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, color = Navy, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun TaskQuickActionsDialog(stage: ProgressStage, onEdit: () -> Unit, onDismiss: () -> Unit) {
    var moveMenu by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stage.title, color = Navy, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ListItem(headlineContent = { Text("اقدامات سریع") }, leadingContent = { Icon(Icons.Rounded.MoreHoriz, null) }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("ویرایش")
                }
                Button(onClick = { ProgressPathStore.pinAsNext(stage.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("پین قدم بعدی") }
                OutlinedButton(onClick = { moveMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("انتقال به دسته دیگر") }
                DropdownMenu(expanded = moveMenu, onDismissRequest = { moveMenu = false }) {
                    ProgressCategory.entries.filter { it != stage.category }.forEach { category ->
                        DropdownMenuItem(text = { Text(categoryTitle(category)) }, onClick = { ProgressPathStore.moveToCategory(stage.id, category); moveMenu = false; onDismiss() })
                    }
                }
                OutlinedButton(onClick = { ProgressPathStore.skipMission(stage.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("رد کردن بدون شکستن کمبو") }
                TextButton(onClick = { ProgressPathStore.deleteStage(stage.id); onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("حذف", color = FailRed) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
private fun ProgressSkeleton(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = NetworkDimens.ScreenHorizontalPadding, vertical = NetworkDimens.ScreenVerticalPadding),
        verticalArrangement = Arrangement.spacedBy(NetworkDimens.SectionGap)
    ) {
        repeat(4) {
            Surface(
                modifier = Modifier.fillMaxWidth().height(if (it == 0) 64.dp else 184.dp),
                shape = RoundedCornerShape(NetworkDimens.SectionRadius),
                color = Color.White,
                border = BorderStroke(1.dp, SurfaceOutline)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.fillMaxWidth(0.42f).height(14.dp).background(SoftBlue, RoundedCornerShape(8.dp)))
                    Box(Modifier.fillMaxWidth().weight(1f).background(AppBackground, RoundedCornerShape(16.dp)))
                }
            }
        }
    }
}

@Composable
private fun ProgressErrorState(modifier: Modifier = Modifier, onRetry: () -> Unit) {
    Box(modifier = modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(NetworkDimens.SectionRadius),
            color = Color.White,
            border = BorderStroke(1.dp, FailRed.copy(alpha = 0.20f))
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.WarningAmber, null, tint = FailRed, modifier = Modifier.size(32.dp))
                Text("اطلاعات مسیر کامل بارگذاری نشد", color = Navy, fontWeight = FontWeight.Black)
                OutlinedButton(onClick = onRetry) { Text("تلاش مجدد") }
            }
        }
    }
}

private fun parseTime(raw: String): Int? {
    val parts = raw.trim().split(':')
    if (parts.size != 2) return null
    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}

private fun categoryTitle(category: ProgressCategory): String = when (category) {
    ProgressCategory.PERSONAL -> "کارهای شخصی"
    ProgressCategory.SALES -> "کارهای فروش"
    ProgressCategory.NETWORKING -> "کارهای شبکه‌سازی"
    ProgressCategory.SUPPORT -> "کارهای حمایتی"
    ProgressCategory.SPONSOR -> "کارهای حامی"
}

private fun repeatTitle(rule: RepeatRule): String = when (rule) {
    RepeatRule.NONE -> "بدون تکرار"
    RepeatRule.DAILY -> "تکرار روزانه"
    RepeatRule.WEEKLY -> "تکرار هفتگی"
}
