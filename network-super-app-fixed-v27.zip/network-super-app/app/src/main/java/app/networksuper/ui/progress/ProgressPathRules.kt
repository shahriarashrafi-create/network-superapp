package app.networksuper.ui.progress

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Pure progress/task rules. No persistence or Compose state lives here. */
internal object ProgressPathRules {
    fun currentOrdinal(items: List<ProgressStage>): Int {
        val ordered = items.sortedBy { it.number }
        val currentIndex = ordered.indexOfFirst { it.status == StageStatus.CURRENT }
        if (currentIndex >= 0) return currentIndex + 1
        return ordered.count { it.status == StageStatus.COMPLETED }
    }

    fun overallProgress(items: List<ProgressStage>): Float {
        val pathItems = items.filter { it.belongsToProgressPath }
        if (pathItems.isEmpty()) return 0f
        return pathItems.count { it.status == StageStatus.COMPLETED }.toFloat() / pathItems.size.toFloat()
    }

    fun categoryProgress(items: List<ProgressStage>, category: ProgressCategory): Pair<Int, Int> {
        val categoryItems = items.filter { it.belongsToProgressPath && it.category == category }
        return categoryItems.count { it.status == StageStatus.COMPLETED } to categoryItems.size
    }

    fun isDueToday(stage: ProgressStage, todayEpochDay: Long = LocalDate.now().toEpochDay()): Boolean {
        if (!stage.showInToday) return false
        return when (stage.repeatRule) {
            RepeatRule.DAILY -> true
            RepeatRule.WEEKLY -> {
                val anchor = stage.repeatAnchorEpochDay ?: stage.plannedEpochDay ?: todayEpochDay
                val delta = todayEpochDay - anchor
                delta >= 0 && delta % 7L == 0L
            }
            RepeatRule.NONE -> stage.plannedEpochDay == null || stage.plannedEpochDay == todayEpochDay
        }
    }

    fun todayItems(items: List<ProgressStage>, todayEpochDay: Long = LocalDate.now().toEpochDay()): List<ProgressStage> =
        items.filter { isDueToday(it, todayEpochDay) }
            .sortedWith(
                compareBy<ProgressStage> { it.status == StageStatus.COMPLETED }
                    .thenBy { it.dueMinuteOfDay ?: Int.MAX_VALUE }
                    .thenByDescending { it.priority.weight }
                    .thenBy { it.number }
            )

    /**
     * Home's next-action order:
     * 1) manually pinned, 2) closest scheduled task today, 3) active mission,
     * 4) highest priority open task. UPCOMING is not locked and can be selected.
     */
    fun nextAction(items: List<ProgressStage>, nowMillis: Long = System.currentTimeMillis()): ProgressStage? {
        val open = items.filterNot { it.status == StageStatus.COMPLETED || it.status == StageStatus.FAILED || it.skipped }
        if (open.isEmpty()) return null

        open.filter { it.pinnedNext }
            .minByOrNull { it.number }
            ?.let { return it }

        val localNow = Instant.ofEpochMilli(nowMillis).atZone(ZoneId.systemDefault())
        val nowMinute = localNow.hour * 60 + localNow.minute
        val today = localNow.toLocalDate().toEpochDay()
        open.filter { isDueToday(it, today) && it.dueMinuteOfDay != null }
            .minWithOrNull(compareBy<ProgressStage> {
                val due = it.dueMinuteOfDay ?: Int.MAX_VALUE
                if (due >= nowMinute) due - nowMinute else 24 * 60 + (nowMinute - due)
            }.thenByDescending { it.priority.weight })
            ?.let { return it }

        open.firstOrNull { it.missionStatus == MissionStatus.ACTIVE }?.let { return it }

        return open.sortedWith(
            compareByDescending<ProgressStage> { it.priority.weight }
                .thenBy { it.number }
        ).firstOrNull()
    }

    /** Every card stays accessible. This only picks the recommended CURRENT marker. */
    fun normalize(items: List<ProgressStage>): List<ProgressStage> {
        val ordered = items
            .sortedWith(compareBy<ProgressStage> { it.number }.thenBy { it.id })
            .mapIndexed { index, stage ->
                stage.copy(
                    number = index + 1,
                    title = stage.title.trim(),
                    dueMinuteOfDay = stage.dueMinuteOfDay?.coerceIn(0, 23 * 60 + 59)
                )
            }
            .toMutableList()

        val currentIndices = ordered.indices.filter { ordered[it].status == StageStatus.CURRENT }
        currentIndices.drop(1).forEach { index ->
            ordered[index] = ordered[index].copy(status = StageStatus.UPCOMING)
        }

        if (ordered.none { it.status == StageStatus.CURRENT }) {
            val recommended = ordered.indexOfFirst {
                it.status == StageStatus.UPCOMING && !it.skipped
            }
            if (recommended >= 0) ordered[recommended] = ordered[recommended].copy(status = StageStatus.CURRENT)
        }
        return ordered
    }
}
