package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

/** SharedPreferences boundary for the progress path. */
internal class ProgressPathPersistence(context: Context) {
    private val preferences: SharedPreferences = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun restore(): List<ProgressStage>? =
        ProgressPathJsonCodec.decodeV5(preferences.getString(KEY_STAGES_JSON, null))
            ?: ProgressPathJsonCodec.decodeV5(preferences.getString(KEY_STAGES_JSON_BACKUP, null))
            ?: ProgressPathJsonCodec.decodeV4(preferences.getString(KEY_STAGES_JSON_V4, null))
            ?: ProgressPathJsonCodec.decodeV4(preferences.getString(KEY_STAGES_JSON_V4_BACKUP, null))
            ?: ProgressPathJsonCodec.decodeV3(preferences.getString(KEY_STAGES_JSON_V3, null))
            ?: ProgressPathJsonCodec.decodeV3(preferences.getString(KEY_STAGES_JSON_V3_BACKUP, null))
            ?: ProgressPathJsonCodec.decodeV2(preferences.getString(KEY_STAGES_JSON_V2, null))
            ?: ProgressPathJsonCodec.decodeV2(preferences.getString(KEY_STAGES_JSON_V2_BACKUP, null))
            ?: ProgressPathJsonCodec.decodeLegacy(preferences.getString(KEY_STAGES_LEGACY, null))

    fun persist(items: List<ProgressStage>) {
        val payload = ProgressPathJsonCodec.encodeV5(items)
        val previous = preferences.getString(KEY_STAGES_JSON, null)

        preferences.edit().apply {
            if (!previous.isNullOrBlank() && previous != payload && ProgressPathJsonCodec.decodeV5(previous) != null) {
                putString(KEY_STAGES_JSON_BACKUP, previous)
            }
            putString(KEY_STAGES_JSON, payload)
        }.apply()
    }

    /** Old primary keys remain readable as backup migrations but are no longer primary. */
    fun removeMigratedPrimaryKeys() {
        preferences.edit()
            .remove(KEY_STAGES_LEGACY)
            .remove(KEY_STAGES_JSON_V2)
            .remove(KEY_STAGES_JSON_V3)
            .remove(KEY_STAGES_JSON_V4)
            .apply()
    }

    private companion object {
        const val PREFS_NAME = "progress_path_v1"
        const val KEY_STAGES_JSON = "stages_json_v5"
        const val KEY_STAGES_JSON_BACKUP = "stages_json_v5_backup"
        const val KEY_STAGES_JSON_V4 = "stages_json_v4"
        const val KEY_STAGES_JSON_V4_BACKUP = "stages_json_v4_backup"
        const val KEY_STAGES_JSON_V3 = "stages_json_v3"
        const val KEY_STAGES_JSON_V3_BACKUP = "stages_json_v3_backup"
        const val KEY_STAGES_JSON_V2 = "stages_json_v2"
        const val KEY_STAGES_JSON_V2_BACKUP = "stages_json_v2_backup"
        const val KEY_STAGES_LEGACY = "stages"
    }
}

/** Versioned JSON codec isolated from app state so migration logic is deterministic and testable. */
internal object ProgressPathJsonCodec {
    private const val CURRENT_SCHEMA_VERSION = 5

    fun encodeV5(items: List<ProgressStage>): String {
        val stagesJson = JSONArray()
        items.sortedBy { it.number }.forEach { stage ->
            val checklistJson = JSONArray()
            stage.checklist.forEach { item ->
                checklistJson.put(
                    JSONObject()
                        .put("id", item.id)
                        .put("text", item.text)
                        .put("required", item.required)
                        .put("checked", item.checked)
                )
            }

            stagesJson.put(
                JSONObject()
                    .put("id", stage.id)
                    .put("number", stage.number)
                    .put("title", stage.title)
                    .put("status", stage.status.name)
                    .put("category", stage.category.name)
                    .put("difficulty", stage.difficulty.name)
                    .put("priority", stage.priority.name)
                    .put("pinnedNext", stage.pinnedNext)
                    .put("showInToday", stage.showInToday)
                    .put("belongsToProgressPath", stage.belongsToProgressPath)
                    .put("plannedEpochDay", stage.plannedEpochDay ?: JSONObject.NULL)
                    .put("dueMinuteOfDay", stage.dueMinuteOfDay ?: JSONObject.NULL)
                    .put("repeatRule", stage.repeatRule.name)
                    .put("repeatAnchorEpochDay", stage.repeatAnchorEpochDay ?: JSONObject.NULL)
                    .put("skipped", stage.skipped)
                    .put("createdAtMillis", stage.createdAtMillis)
                    .put("description", stage.description)
                    .put("missionStatus", stage.missionStatus.name)
                    .put("durationMinutes", stage.durationMinutes)
                    .put("startedAtMillis", stage.startedAtMillis ?: JSONObject.NULL)
                    .put("endAtMillis", stage.endAtMillis ?: JSONObject.NULL)
                    .put("completedAtMillis", stage.completedAtMillis ?: JSONObject.NULL)
                    .put("attemptCount", stage.attemptCount)
                    .put("note", stage.note)
                    .put("noteDraft", stage.noteDraft ?: JSONObject.NULL)
                    .put("checklist", checklistJson)
            )
        }

        return JSONObject()
            .put("version", CURRENT_SCHEMA_VERSION)
            .put("stages", stagesJson)
            .toString()
    }

    fun decodeV5(raw: String?): List<ProgressStage>? = decodeVersioned(raw, 5)
    fun decodeV4(raw: String?): List<ProgressStage>? = decodeVersioned(raw, 4)
    fun decodeV3(raw: String?): List<ProgressStage>? = decodeVersioned(raw, 3)
    fun decodeV2(raw: String?): List<ProgressStage>? = decodeVersioned(raw, 2)

    fun decodeLegacy(raw: String?): List<ProgressStage>? {
        if (raw == null) return null
        if (raw.isBlank()) return emptyList()

        return runCatching {
            val parsed = raw.split('|').map { token ->
                val parts = token.split(',', limit = 4)
                require(parts.size == 4)
                val title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                ProgressStageFactory.withMissionDefaults(
                    ProgressStage(
                        id = parts[0].toLong(),
                        number = parts[1].toInt(),
                        status = StageStatus.valueOf(parts[2]),
                        title = title,
                        category = ProgressCategory.fromLegacy(parts[1].toInt(), title)
                    )
                )
            }
            validate(parsed)
        }.getOrNull()
    }

    private fun decodeVersioned(raw: String?, expectedVersion: Int): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null

        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != expectedVersion) return@runCatching null

            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    if (expectedVersion == 2) {
                        add(
                            ProgressStageFactory.withMissionDefaults(
                                ProgressStage(
                                    id = item.getLong("id"),
                                    number = item.getInt("number"),
                                    title = item.getString("title"),
                                    status = StageStatus.valueOf(item.getString("status")),
                                    category = ProgressCategory.fromLegacy(item.getInt("number"), item.getString("title"))
                                )
                            )
                        )
                    } else {
                        add(ProgressStageFactory.withMissionDefaults(decodeMissionStage(item, expectedVersion)))
                    }
                }
            }
            validate(parsed)
        }.getOrNull()
    }

    private fun decodeMissionStage(item: JSONObject, version: Int): ProgressStage {
        val checklistArray = item.optJSONArray("checklist") ?: JSONArray()
        val checklist = buildList {
            for (index in 0 until checklistArray.length()) {
                val check = checklistArray.getJSONObject(index)
                add(
                    MissionChecklistItem(
                        id = check.getLong("id"),
                        text = check.getString("text"),
                        required = check.optBoolean("required", false),
                        checked = check.optBoolean("checked", false)
                    )
                )
            }
        }

        val number = item.getInt("number")
        val title = item.getString("title")
        val legacyTodayMinute = if (version < 5) {
            when {
                title.contains("مشتری") -> 10 * 60
                title.contains("ارتباطی") -> 15 * 60
                title.contains("رهبری") || title.contains("تیم") -> 18 * 60
                title.contains("مهارت") -> 21 * 60
                else -> null
            }
        } else null
        return ProgressStage(
            id = item.getLong("id"),
            number = number,
            title = title,
            status = StageStatus.valueOf(item.getString("status")),
            category = runCatching { ProgressCategory.valueOf(item.optString("category", "")) }
                .getOrElse { ProgressCategory.fromLegacy(number, title) },
            difficulty = if (version >= 5) runCatching { TaskDifficulty.valueOf(item.optString("difficulty", TaskDifficulty.MEDIUM.name)) }.getOrDefault(TaskDifficulty.MEDIUM) else TaskDifficulty.MEDIUM,
            priority = if (version >= 5) runCatching { TaskPriority.valueOf(item.optString("priority", TaskPriority.NORMAL.name)) }.getOrDefault(TaskPriority.NORMAL) else TaskPriority.NORMAL,
            pinnedNext = version >= 5 && item.optBoolean("pinnedNext", false),
            showInToday = if (version >= 5) item.optBoolean("showInToday", false) else legacyTodayMinute != null,
            belongsToProgressPath = version < 5 || item.optBoolean("belongsToProgressPath", true),
            plannedEpochDay = if (version >= 5) item.optNullableLong("plannedEpochDay") else null,
            dueMinuteOfDay = if (version >= 5 && !item.isNull("dueMinuteOfDay")) item.optInt("dueMinuteOfDay") else legacyTodayMinute,
            repeatRule = if (version >= 5) runCatching { RepeatRule.valueOf(item.optString("repeatRule", RepeatRule.NONE.name)) }.getOrDefault(RepeatRule.NONE) else if (legacyTodayMinute != null) RepeatRule.DAILY else RepeatRule.NONE,
            repeatAnchorEpochDay = if (version >= 5) item.optNullableLong("repeatAnchorEpochDay") else null,
            skipped = version >= 5 && item.optBoolean("skipped", false),
            createdAtMillis = if (version >= 5) item.optLong("createdAtMillis", 0L) else 0L,
            description = item.optString("description", ""),
            missionStatus = runCatching { MissionStatus.valueOf(item.optString("missionStatus", MissionStatus.NOT_STARTED.name)) }.getOrDefault(MissionStatus.NOT_STARTED),
            durationMinutes = item.optInt("durationMinutes", ProgressStage.DEFAULT_MISSION_DURATION_MINUTES),
            startedAtMillis = item.optNullableLong("startedAtMillis"),
            endAtMillis = item.optNullableLong("endAtMillis"),
            completedAtMillis = item.optNullableLong("completedAtMillis"),
            attemptCount = item.optInt("attemptCount", 0),
            note = item.optString("note", ""),
            noteDraft = if (version >= 4) item.optNullableString("noteDraft") else null,
            checklist = checklist
        )
    }

    private fun validate(items: List<ProgressStage>): List<ProgressStage>? {
        if (items.any { it.id <= 0L || it.number <= 0 || it.title.isBlank() }) return null
        if (items.map { it.id }.toSet().size != items.size) return null
        if (items.map { it.number }.toSet().size != items.size) return null
        if (items.any { it.durationMinutes !in 1..(24 * 60) }) return null
        if (items.any { it.dueMinuteOfDay != null && it.dueMinuteOfDay !in 0..(23 * 60 + 59) }) return null
        if (items.any { stage -> stage.checklist.map { it.id }.toSet().size != stage.checklist.size }) return null
        return items
    }

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (!has(key) || isNull(key)) null else optLong(key)

    private fun JSONObject.optNullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else optString(key)
}
