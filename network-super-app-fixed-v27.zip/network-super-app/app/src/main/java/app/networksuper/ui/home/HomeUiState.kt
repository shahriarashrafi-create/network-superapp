package app.networksuper.ui.home

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import app.networksuper.ui.theme.*

data class HomeUiState(
    val userName: String,
    val rankName: String,
    val comboCount: Int,
    val hasRewardNotification: Boolean,
    val xpCurrent: Int,
    val xpTarget: Int,
    val todayTitle: String,
    val todayDateLabel: String,
    val scheduleItems: List<HomeCardItem>
)

data class HomeCardItem(
    val id: Long? = null,
    val title: String,
    val icon: ImageVector,
    val accent: Color,
    val done: Boolean = false,
    val meta: String? = null
)

object HomeDefaults {
    val state = HomeUiState(
        userName = "شهریار اشرفی",
        rankName = "Builder",
        comboCount = 3,
        hasRewardNotification = true,
        xpCurrent = 2480,
        xpTarget = 3000,
        todayTitle = "امروز من",
        todayDateLabel = "دوشنبه ۲۳ مهر",
        scheduleItems = listOf(
            HomeCardItem(title = "تماس", icon = Icons.Rounded.Call, accent = SuccessGreen, done = true, meta = "10:00"),
            HomeCardItem(title = "جلسه معرفی", icon = Icons.Rounded.Groups, accent = PrimaryBlue, meta = "15:00"),
            HomeCardItem(title = "جلسه تیم", icon = Icons.Rounded.Group, accent = WarningOrange, meta = "18:00"),
            HomeCardItem(title = "پیگیری", icon = Icons.Rounded.Assignment, accent = AccentPurple, meta = "21:00")
        )
    )
}
