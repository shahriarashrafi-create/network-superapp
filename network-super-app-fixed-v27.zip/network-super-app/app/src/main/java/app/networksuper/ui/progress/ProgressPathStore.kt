package app.networksuper.ui.progress

import app.networksuper.ui.theme.toPersianNumber
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.networksuper.ui.gamification.GamificationStore
import app.networksuper.ui.gamification.TaskRewardReceipt
import java.time.LocalDate

/**
 * Persistent single source of truth for Home actions and Progress Path.
 * UPCOMING cards are always interactive; there is no startup locking rule.
 */
object ProgressPathStore {
    val stages = mutableStateListOf<ProgressStage>()

    enum class LoadState { LOADING, READY, RECOVERED_WITH_DEFAULTS, ERROR }
    var loadState by mutableStateOf(LoadState.LOADING)
        private set

    var feedbackEvent by mutableStateOf<ProgressFeedbackEvent?>(null)
        private set

    private var persistence: ProgressPathPersistence? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return
        loadState = LoadState.LOADING
        val storage = ProgressPathPersistence(context)
        persistence = storage

        runCatching {
            val now = System.currentTimeMillis()
            val restoredPayload = storage.restore()
            val restored = (restoredPayload ?: ProgressStageFactory.defaults).map { stage ->
                val normalized = ProgressStageFactory.withMissionDefaults(stage)
                if (MissionRules.shouldExpire(normalized, now)) normalized.copy(missionStatus = MissionStatus.EXPIRED)
                else normalized
            }
            loadState = if (restoredPayload == null) LoadState.RECOVERED_WITH_DEFAULTS else LoadState.READY
            replaceWithRenumbered(restored, persistAfter = false)
            persist()
            storage.removeMigratedPrimaryKeys()
        }.onFailure {
            loadState = LoadState.ERROR
            replaceWithRenumbered(ProgressStageFactory.defaults, persistAfter = false)
        }
        initialized = true
    }

    fun retryLoad(context: Context) {
        initialized = false
        initialize(context)
    }

    fun stage(id: Long): ProgressStage? = stages.firstOrNull { it.id == id }
    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }
    fun nextAction(nowMillis: Long = System.currentTimeMillis()): ProgressStage? = ProgressPathRules.nextAction(stages, nowMillis)
    fun todayTasks(todayEpochDay: Long = LocalDate.now().toEpochDay()): List<ProgressStage> = ProgressPathRules.todayItems(stages, todayEpochDay)
    fun currentOrdinal(): Int = ProgressPathRules.currentOrdinal(stages)
    fun overallProgress(): Float = ProgressPathRules.overallProgress(stages)
    fun categoryProgress(category: ProgressCategory): Pair<Int, Int> = ProgressPathRules.categoryProgress(stages, category)

    fun isComplete(): Boolean = stages.isNotEmpty() && stages.none { it.status == StageStatus.CURRENT || it.status == StageStatus.UPCOMING }
    fun positionCount(isNew: Boolean): Int = (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    fun addTask(draft: TaskDraft) {
        val cleanTitle = draft.title.trim()
        if (cleanTitle.isBlank()) return
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val id = nextAvailableId(ordered)
        ordered.add(
            ProgressStageFactory.withMissionDefaults(
                ProgressStage(
                    id = id,
                    number = ordered.size + 1,
                    title = cleanTitle,
                    status = if (ordered.none { it.status == StageStatus.CURRENT }) StageStatus.CURRENT else StageStatus.UPCOMING,
                    category = draft.category,
                    difficulty = draft.difficulty,
                    priority = draft.priority,
                    pinnedNext = draft.pinnedNext,
                    showInToday = draft.showInToday,
                    belongsToProgressPath = draft.belongsToProgressPath,
                    plannedEpochDay = draft.plannedEpochDay,
                    dueMinuteOfDay = draft.dueMinuteOfDay,
                    repeatRule = draft.repeatRule,
                    repeatAnchorEpochDay = draft.plannedEpochDay,
                    createdAtMillis = System.currentTimeMillis()
                )
            )
        )
        replaceWithRenumbered(ordered)
    }

    /** Legacy helper retained for older dialog callers. */
    fun addStage(title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(
            insertionIndex,
            ProgressStageFactory.withMissionDefaults(
                ProgressStage(
                    id = nextAvailableId(ordered),
                    number = position,
                    title = cleanTitle,
                    status = if (ordered.none { it.status == StageStatus.CURRENT }) StageStatus.CURRENT else StageStatus.UPCOMING,
                    category = ProgressCategory.PERSONAL,
                    createdAtMillis = System.currentTimeMillis()
                )
            )
        )
        replaceWithRenumbered(ordered)
    }

    fun updateTask(id: Long, draft: TaskDraft) {
        updateStage(id) { old ->
            old.copy(
                title = draft.title.trim().ifBlank { old.title },
                category = draft.category,
                difficulty = draft.difficulty,
                priority = draft.priority,
                pinnedNext = draft.pinnedNext,
                showInToday = draft.showInToday,
                belongsToProgressPath = draft.belongsToProgressPath,
                plannedEpochDay = draft.plannedEpochDay,
                dueMinuteOfDay = draft.dueMinuteOfDay,
                repeatRule = draft.repeatRule,
                repeatAnchorEpochDay = draft.plannedEpochDay ?: old.repeatAnchorEpochDay
            )
        }
    }

    fun pinAsNext(id: Long) {
        val ordered = stages.sortedBy { it.number }.map { it.copy(pinnedNext = it.id == id) }
        replaceWithRenumbered(ordered)
    }

    fun moveToCategory(id: Long, category: ProgressCategory) {
        updateStage(id) { it.copy(category = category) }
    }

    fun updateStageSetup(id: Long, title: String, position: Int, durationMinutes: Int, checklist: List<MissionChecklistItem>) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return
        val cleanDuration = durationMinutes.coerceIn(1, 24 * 60)
        val cleanChecklist = checklist.mapIndexedNotNull { index, item ->
            val text = item.text.trim()
            if (text.isBlank()) null else item.copy(
                id = item.id.takeIf { it > 0L } ?: ProgressStageFactory.checklistId(id, index),
                text = text
            )
        }.distinctBy { it.id }

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return
        val old = ordered.removeAt(oldIndex)
        val recalculatedEndAt = if (old.missionStatus == MissionStatus.ACTIVE && old.startedAtMillis != null) old.startedAtMillis + cleanDuration * 60_000L else old.endAtMillis
        val updated = old.copy(title = cleanTitle, durationMinutes = cleanDuration, checklist = cleanChecklist, endAtMillis = recalculatedEndAt)
        ordered.add((position - 1).coerceIn(0, ordered.size), updated)
        replaceWithRenumbered(ordered)
    }

    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val target = ordered[targetIndex]
        if (target.status == StageStatus.COMPLETED) {
            // Historical migrated completions may not have a v2 reward ledger entry; deletion still
            // remains available while their already-earned historical reward stays untouched.
            GamificationStore.undoTaskCompletion(id)
        }
        ordered.removeAt(targetIndex)
        if (target.status == StageStatus.CURRENT) promoteNextUpcoming(ordered, targetIndex)
        replaceWithRenumbered(ordered)
    }

    /** Every card can start immediately, regardless of CURRENT/UPCOMING marker. */
    fun startMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { stage ->
            val duration = stage.durationMinutes.coerceAtLeast(1)
            stage.copy(
                skipped = false,
                missionStatus = MissionStatus.ACTIVE,
                startedAtMillis = nowMillis,
                endAtMillis = nowMillis + duration * 60_000L,
                completedAtMillis = null,
                attemptCount = stage.attemptCount + 1
            )
        }
    }

    fun markExpiredIfNeeded(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        val current = stage(id) ?: return
        if (!MissionRules.shouldExpire(current, nowMillis)) return
        updateStage(id) { it.copy(missionStatus = MissionStatus.EXPIRED) }
    }

    fun toggleChecklistItem(stageId: Long, itemId: Long, checked: Boolean) {
        updateStage(stageId) { stage -> stage.copy(checklist = stage.checklist.map { if (it.id == itemId) it.copy(checked = checked) else it }) }
    }

    fun updateNoteDraft(id: Long, draft: String) { updateStage(id) { it.copy(noteDraft = draft.takeIf { value -> value != it.note }) } }
    fun commitNote(id: Long, text: String) { updateStage(id) { it.copy(note = text, noteDraft = null) } }
    fun discardNoteDraft(id: Long) { updateStage(id) { it.copy(noteDraft = null) } }

    fun completeMission(id: Long, nowMillis: Long = System.currentTimeMillis()): TaskRewardReceipt? {
        val current = stage(id) ?: return null
        if (!MissionRules.requiredComplete(current.checklist)) return null
        updateStage(id, persistAfter = false) { it.copy(skipped = false, missionStatus = MissionStatus.COMPLETED, completedAtMillis = nowMillis) }
        markResult(id, StageStatus.COMPLETED)
        val receipt = GamificationStore.onTaskCompleted(id, current.difficulty)
        if (receipt != null) {
            feedbackEvent = ProgressFeedbackEvent(
                id = System.nanoTime(),
                message = "+${receipt.xp.toPersianNumber()} XP   +${receipt.coins.toPersianNumber()} Coin" + if (receipt.multiplier > 1f) "   Combo ×۱.۵" else "",
                undoStageId = id
            )
        }
        return receipt
    }

    fun failMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        updateStage(id, persistAfter = false) { it.copy(skipped = false, missionStatus = MissionStatus.FAILED, completedAtMillis = nowMillis) }
        markResult(id, StageStatus.FAILED)
        GamificationStore.onTaskFailed()
        feedbackEvent = ProgressFeedbackEvent(System.nanoTime(), "کمبو ریست شد", null)
    }

    /** Skip is reversible, gives no reward and does not reset Combo. */
    fun skipMission(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val index = ordered.indexOfFirst { it.id == id }
        if (index < 0) return
        val wasCurrent = ordered[index].status == StageStatus.CURRENT
        ordered[index] = ordered[index].copy(
            skipped = true,
            status = StageStatus.UPCOMING,
            missionStatus = MissionStatus.NOT_STARTED,
            startedAtMillis = null,
            endAtMillis = null,
            completedAtMillis = null
        )
        if (wasCurrent) promoteNextUpcoming(ordered, index + 1)
        replaceWithRenumbered(ordered)
        GamificationStore.onTaskSkipped()
        feedbackEvent = ProgressFeedbackEvent(System.nanoTime(), "تسک رد شد؛ کمبو حفظ شد", null)
    }

    fun retryMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { MissionRules.retried(it.copy(skipped = false), nowMillis) }
    }

    /** Undo exact task reward before reopening the task. Returns false if rollback is unsafe. */
    fun restoreMission(id: Long): Boolean {
        val target = stage(id) ?: return false
        if (target.status == StageStatus.COMPLETED && GamificationStore.undoTaskCompletion(id) == null) return false
        setCurrent(id)
        updateStage(id) { MissionRules.restored(it).copy(status = StageStatus.CURRENT, skipped = false) }
        return true
    }

    private fun setCurrent(id: Long) {
        if (stages.none { it.id == id }) return
        replaceWithRenumbered(stages.sortedBy { it.number }.map { stage ->
            when {
                stage.id == id -> stage.copy(status = StageStatus.CURRENT, skipped = false)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        })
    }

    private fun markResult(id: Long, result: StageStatus) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)
        if (wasCurrent) promoteNextUpcoming(ordered, targetIndex + 1)
        replaceWithRenumbered(ordered)
    }

    private fun promoteNextUpcoming(ordered: MutableList<ProgressStage>, preferredStartIndex: Int) {
        if (ordered.any { it.status == StageStatus.CURRENT }) return
        val safeStart = preferredStartIndex.coerceIn(0, ordered.size)
        val nextIndex = (safeStart until ordered.size).firstOrNull { ordered[it].status == StageStatus.UPCOMING && !ordered[it].skipped }
            ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING && !it.skipped }.takeIf { it >= 0 }
        if (nextIndex != null) ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
    }

    private fun updateStage(id: Long, persistAfter: Boolean = true, transform: (ProgressStage) -> ProgressStage) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val index = ordered.indexOfFirst { it.id == id }
        if (index < 0) return
        ordered[index] = ProgressStageFactory.withMissionDefaults(transform(ordered[index]))
        replaceWithRenumbered(ordered, persistAfter)
    }

    private fun replaceWithRenumbered(ascendingItems: List<ProgressStage>, persistAfter: Boolean = true) {
        val normalized = ProgressPathRules.normalize(ascendingItems).map(ProgressStageFactory::withMissionDefaults)
        stages.clear()
        stages.addAll(normalized.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun nextAvailableId(items: List<ProgressStage>): Long {
        val usedIds = items.asSequence().map { it.id }.toHashSet()
        var candidate = (usedIds.maxOrNull() ?: 0L) + 1L
        while (candidate <= 0L || candidate in usedIds) candidate++
        return candidate
    }

    fun consumeFeedback(id: Long) {
        if (feedbackEvent?.id == id) feedbackEvent = null
    }

    private fun persist() { persistence?.persist(stages) }
}

data class ProgressFeedbackEvent(
    val id: Long,
    val message: String,
    val undoStageId: Long?
)
