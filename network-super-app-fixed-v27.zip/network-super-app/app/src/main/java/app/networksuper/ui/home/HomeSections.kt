package app.networksuper.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.components.EdgePreviewLazyRow
import app.networksuper.ui.components.ProgressTaskCard
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.progress.ProgressStage
import app.networksuper.ui.progress.StageStatus
import app.networksuper.ui.theme.*

@Composable
private fun SyncedHomeSection(
    modifier: Modifier = Modifier,
    title: String,
    titleIcon: ImageVector,
    titleIconTint: Color,
    badgeText: String,
    badgeIcon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    HomeSectionCard(modifier = modifier) {
        SectionHeader(
            title = title,
            rightIcon = titleIcon,
            rightIconTint = titleIconTint,
            leftContent = { SectionMetaPill(text = badgeText, icon = badgeIcon) }
        )
        Spacer(Modifier.height(5.dp))
        content()
    }
}

@Composable
private fun SectionMetaPill(text: String, icon: ImageVector? = null) {
    Surface(modifier = Modifier.height(30.dp), shape = RoundedCornerShape(12.dp), color = SoftBlue) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (icon != null) Icon(icon, null, tint = PrimaryBlue, modifier = Modifier.size(17.dp))
            Text(
                text = text,
                color = if (icon == null) PrimaryBlueDark else Navy,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun SyncedItemCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    done: Boolean,
    meta: String? = null,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick),
            shape = RoundedCornerShape(NetworkDimens.CardRadius),
            colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.052f)),
            border = BorderStroke(1.dp, accent.copy(alpha = 0.16f))
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth().height(23.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusMark(done)
                        if (meta != null) {
                            Text(meta, color = accent, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
                        } else Spacer(Modifier.width(1.dp))
                    }
                }
                PremiumIconBubble(icon, accent, title, Modifier.size(42.dp))
                Text(
                    text = title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun SyncedItemRow(
    items: List<HomeCardItem>,
    onItemClick: (HomeCardItem) -> Unit,
    onItemLongClick: (HomeCardItem) -> Unit,
    modifier: Modifier = Modifier
) {
    EdgePreviewLazyRow(items = items, key = { it.id ?: "${it.title}|${it.meta.orEmpty()}" }, modifier = modifier) { item, itemModifier ->
        SyncedItemCard(
            item.title, item.icon, item.accent, item.done, item.meta,
            onClick = { onItemClick(item) },
            onLongClick = { onItemLongClick(item) },
            modifier = itemModifier
        )
    }
}

@Composable
internal fun TodaySection(
    title: String,
    dateLabel: String,
    scheduleItems: List<HomeCardItem>,
    onItemClick: (HomeCardItem) -> Unit,
    onItemLongClick: (HomeCardItem) -> Unit,
    modifier: Modifier = Modifier
) {
    SyncedHomeSection(
        modifier = modifier,
        title = title,
        titleIcon = Icons.Rounded.CheckCircle,
        titleIconTint = SuccessGreen,
        badgeText = dateLabel,
        badgeIcon = Icons.Rounded.CalendarMonth
    ) {
        if (scheduleItems.isEmpty()) {
            HomeEmptyState(
                icon = Icons.Rounded.EventAvailable,
                text = "برای امروز کاری ثبت نشده",
                modifier = Modifier.weight(1f)
            )
        } else {
            SyncedItemRow(scheduleItems, onItemClick, onItemLongClick, Modifier.weight(1f))
        }
    }
}

@Composable
internal fun ProgressSection(onStageClick: (Long) -> Unit, onStageLongClick: (ProgressStage) -> Unit, modifier: Modifier = Modifier) {
    val stages = ProgressPathStore.stages.filter { it.belongsToProgressPath }.sortedBy { it.number }
    val focus = ProgressPathStore.nextAction() ?: ProgressPathStore.currentStage()
    val focusIndex = stages.indexOfFirst { it.id == focus?.id }
    val start = when {
        stages.size <= 4 -> 0
        focusIndex < 0 -> 0
        focusIndex <= 1 -> 0
        focusIndex >= stages.lastIndex - 1 -> (stages.size - 4).coerceAtLeast(0)
        else -> focusIndex - 1
    }
    val visibleStages = stages.drop(start).take(4)
    val completed = stages.count { it.status == StageStatus.COMPLETED }

    SyncedHomeSection(
        modifier = modifier,
        title = stringResource(R.string.progress_path),
        titleIcon = Icons.Rounded.EmojiEvents,
        titleIconTint = RewardGold,
        badgeText = "${completed.toPersianNumber()}/${stages.size.toPersianNumber()}"
    ) {
        if (visibleStages.isEmpty()) {
            HomeEmptyState(Icons.Rounded.Route, "مسیر پیشرفت هنوز تسکی ندارد", Modifier.weight(1f))
        } else {
            EdgePreviewLazyRow(items = visibleStages, key = { it.id }, modifier = Modifier.weight(1f)) { item, itemModifier ->
                ProgressTaskCard(
                    stage = item,
                    categoryAccent = categoryAccent(item.category.name),
                    onClick = { onStageClick(item.id) },
                    onLongClick = { onStageLongClick(item) },
                    modifier = itemModifier
                )
            }
        }
    }
}

@Composable
private fun HomeEmptyState(icon: ImageVector, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Muted.copy(alpha = 0.55f), modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(4.dp))
        Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}

@Composable
private fun StatusMark(done: Boolean) {
    Icon(
        imageVector = if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
        contentDescription = if (done) stringResource(R.string.done) else stringResource(R.string.not_done),
        tint = if (done) SuccessGreen else Muted.copy(alpha = 0.50f),
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun PremiumIconBubble(icon: ImageVector, accent: Color, contentDescription: String?, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(2.dp, CircleShape)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.92f), accent.copy(alpha = 0.18f))))
            .border(1.dp, Color.White.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription, tint = accent, modifier = Modifier.size(25.dp))
    }
}

@Composable
private fun HomeSectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(NetworkDimens.SectionRadius),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(10.dp), content = content)
    }
}

@Composable
private fun SectionHeader(title: String, rightIcon: ImageVector, rightIconTint: Color, leftContent: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            leftContent()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier.size(30.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color.White, rightIconTint.copy(alpha = 0.14f))))
                            .border(1.dp, Color.White.copy(alpha = 0.82f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(rightIcon, null, tint = rightIconTint, modifier = Modifier.size(22.dp))
                    }
                    Text(title, color = Navy, style = MaterialTheme.typography.titleLarge)
                }
            }
        }
    }
}
