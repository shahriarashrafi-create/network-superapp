package app.networksuper.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged

private object HorizontalRowMemory {
    val positions = mutableMapOf<String, Pair<Int, Int>>()
}

/** Horizontal card row with RTL browsing, partial-edge fade and navigation-safe scroll memory. */
@Composable
fun <T> EdgePreviewLazyRow(
    items: List<T>,
    key: (T) -> Any,
    modifier: Modifier = Modifier,
    memoryKey: String? = null,
    itemContent: @Composable (item: T, modifier: Modifier) -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val resolvedMemoryKey = memoryKey ?: remember(items) {
            if (items.isEmpty()) "empty-row" else "${key(items.first())}|${key(items.last())}|${items.size}"
        }
        val saved = HorizontalRowMemory.positions[resolvedMemoryKey]
        val safeIndex = saved?.first?.coerceIn(0, (items.size - 1).coerceAtLeast(0)) ?: 0
        val rowState = rememberLazyListState(
            initialFirstVisibleItemIndex = safeIndex,
            initialFirstVisibleItemScrollOffset = saved?.second ?: 0
        )

        LaunchedEffect(resolvedMemoryKey, rowState) {
            snapshotFlow { rowState.firstVisibleItemIndex to rowState.firstVisibleItemScrollOffset }
                .distinctUntilChanged()
                .collectLatest { HorizontalRowMemory.positions[resolvedMemoryKey] = it }
        }

        LazyRow(
            state = rowState,
            modifier = modifier,
            reverseLayout = true,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 0.dp)
        ) {
            itemsIndexed(items, key = { _, item -> key(item) }) { index, item ->
                val visibleItem = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                val isEdgePreview = visibleItem != null && (
                    visibleItem.offset < rowState.layoutInfo.viewportStartOffset ||
                        visibleItem.offset + visibleItem.size > rowState.layoutInfo.viewportEndOffset
                    )
                itemContent(
                    item,
                    Modifier
                        .width(140.dp)
                        .fillMaxHeight()
                        .graphicsLayer { alpha = if (isEdgePreview) 0.78f else 1f }
                )
            }
        }
    }
}
