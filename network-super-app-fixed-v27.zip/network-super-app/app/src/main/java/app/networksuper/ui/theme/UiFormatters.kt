package app.networksuper.ui.theme

import java.util.Locale
import kotlin.math.abs

private val persianDigits = charArrayOf('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹')

fun String.toPersianDigits(): String = buildString(length) {
    this@toPersianDigits.forEach { ch ->
        append(if (ch in '0'..'9') persianDigits[ch - '0'] else ch)
    }
}

fun Int.toPersianNumber(): String = toString().toPersianDigits()
fun Long.toPersianNumber(): String = toString().toPersianDigits()

/** Fixed, compact display for the header; prevents large counters from pushing nearby assets. */
fun formatCompactPersianNumber(value: Int): String {
    val safe = value.coerceAtLeast(0)
    val raw = when {
        safe < 10_000 -> safe.toString()
        safe < 1_000_000 -> {
            val number = safe / 1_000.0
            if (number < 100) String.format(Locale.US, "%.1fK", number) else "${(number).toInt()}K"
        }
        else -> {
            val number = safe / 1_000_000.0
            if (number < 100) String.format(Locale.US, "%.1fM", number) else "${number.toInt()}M"
        }
    }
    return raw.toPersianDigits()
}

fun formatMinuteOfDayPersian(minuteOfDay: Int?): String? {
    minuteOfDay ?: return null
    val safe = minuteOfDay.coerceIn(0, 23 * 60 + 59)
    val hour = safe / 60
    val minute = safe % 60
    return String.format(Locale.US, "%02d:%02d", hour, minute).toPersianDigits()
}

fun formatPercentPersian(value: Float): String =
    "${(value.coerceIn(0f, 1f) * 100f).toInt()}٪".toPersianDigits()
