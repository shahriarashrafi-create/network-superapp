package app.networksuper.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppLightColors = lightColorScheme(
    primary = PrimaryBlue,
    onPrimary = Color.White,
    secondary = AccentPurple,
    background = AppBackground,
    surface = Color.White,
    onSurface = Navy
)

/** Prepared token set for a later dark-mode design pass. It is not enabled by default in V27. */
private val AppDarkColors = darkColorScheme(
    primary = Color(0xFF79B4FF),
    onPrimary = Color(0xFF002D68),
    secondary = Color(0xFFB99AFF),
    background = Color(0xFF0F1522),
    surface = Color(0xFF171E2D),
    onSurface = Color(0xFFF4F7FF)
)

@Composable
fun NetworkSuperAppTheme(
    useDarkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (useDarkTheme) AppDarkColors else AppLightColors,
        typography = NetworkTypography,
        content = content
    )
}
