package app.networksuper.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.networksuper.ui.progress.ProgressStage
import app.networksuper.ui.progress.StageStatus
import app.networksuper.ui.theme.*

/**
 * The exact same progress-card surface is shared by Home and the full Progress screen.
 * UPCOMING is intentionally interactive and never rendered as locked.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProgressTaskCard(
    stage: ProgressStage,
    categoryAccent: Color,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val accent = when {
        stage.skipped -> WarningOrange
        stage.status == StageStatus.COMPLETED -> SuccessGreen
        stage.status == StageStatus.FAILED -> FailRed
        current -> PrimaryBlue
        else -> categoryAccent
    }
    val borderColor by animateColorAsState(
        targetValue = accent.copy(alpha = if (current) 0.58f else 0.22f),
        animationSpec = tween(NetworkMotion.StandardMillis),
        label = "progressCardBorder"
    )
    val elevation by animateDpAsState(
        targetValue = if (current) 5.dp else 1.5.dp,
        animationSpec = tween(NetworkMotion.StandardMillis),
        label = "progressCardElevation"
    )

    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(NetworkDimens.CardRadius))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape = RoundedCornerShape(NetworkDimens.CardRadius),
        color = Color.White,
        border = BorderStroke(if (current) NetworkDimens.ActiveBorder else NetworkDimens.Hairline, borderColor),
        shadowElevation = elevation
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 9.dp, vertical = 8.dp)
        ) {
            StatusPill(stage = stage, accent = accent, modifier = Modifier.align(Alignment.TopEnd))

            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(top = 18.dp, start = 3.dp, end = 3.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = stage.title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "تسک مسیر",
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun StatusPill(stage: ProgressStage, accent: Color, modifier: Modifier = Modifier) {
    val (label, icon) = when {
        stage.skipped -> "رد شده" to Icons.Rounded.SkipNext
        stage.status == StageStatus.COMPLETED -> "انجام شد" to Icons.Rounded.Check
        stage.status == StageStatus.FAILED -> "ناموفق" to Icons.Rounded.Close
        stage.status == StageStatus.CURRENT -> "مرحله فعلی" to Icons.Rounded.Schedule
        else -> "بعدی" to null
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = accent.copy(alpha = if (stage.status == StageStatus.CURRENT) 1f else 0.10f),
        border = if (stage.status == StageStatus.CURRENT) null else BorderStroke(1.dp, accent.copy(alpha = 0.16f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (stage.status == StageStatus.CURRENT) Color.White else accent,
                    modifier = Modifier.size(12.dp)
                )
            }
            Text(
                text = label,
                color = if (stage.status == StageStatus.CURRENT) Color.White else accent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}
