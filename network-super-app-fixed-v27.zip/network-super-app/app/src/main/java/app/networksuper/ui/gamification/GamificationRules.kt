package app.networksuper.ui.gamification

import app.networksuper.ui.progress.TaskDifficulty
import kotlin.math.roundToInt

/** Pure reward math. Kept outside persistence/UI so it can be unit-tested deterministically. */
internal object GamificationRules {
    const val COMBO_START = 3
    const val TASKS_PER_CHEST = 5
    const val XP_LEVEL_STEP = 3000

    fun baseReward(difficulty: TaskDifficulty): Pair<Int, Int> = when (difficulty) {
        TaskDifficulty.LOW -> 2 to 10
        TaskDifficulty.MEDIUM -> 4 to 20
        TaskDifficulty.HIGH -> 7 to 35
    }

    fun taskReward(
        difficulty: TaskDifficulty,
        currentCombo: Int,
        currentSuccessCount: Int,
        countForChestMilestone: Boolean = true
    ): ComputedTaskReward {
        val newCombo = currentCombo.coerceAtLeast(0) + 1
        val multiplier = if (newCombo >= COMBO_START) 1.5f else 1f
        val (baseCoins, baseXp) = baseReward(difficulty)
        val safeSuccessCount = currentSuccessCount.coerceAtLeast(0)
        val newSuccessCount = safeSuccessCount + if (countForChestMilestone) 1 else 0
        return ComputedTaskReward(
            coins = (baseCoins * multiplier).roundToInt(),
            xp = (baseXp * multiplier).roundToInt(),
            comboCount = newCombo,
            multiplier = multiplier,
            successCount = newSuccessCount,
            chestEarned = countForChestMilestone && newSuccessCount > 0 && newSuccessCount % TASKS_PER_CHEST == 0
        )
    }

    fun xpTarget(totalXp: Int): Int {
        val safeXp = totalXp.coerceAtLeast(0)
        return ((safeXp / XP_LEVEL_STEP) + 1) * XP_LEVEL_STEP
    }

    fun xpLevelStart(totalXp: Int): Int =
        (totalXp.coerceAtLeast(0) / XP_LEVEL_STEP) * XP_LEVEL_STEP
}

internal data class ComputedTaskReward(
    val coins: Int,
    val xp: Int,
    val comboCount: Int,
    val multiplier: Float,
    val successCount: Int,
    val chestEarned: Boolean
)
