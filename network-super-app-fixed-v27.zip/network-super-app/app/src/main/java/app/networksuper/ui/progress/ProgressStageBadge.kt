package app.networksuper.ui.progress

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.FailRed
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.NetworkTextSize
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.SuccessGreen
import app.networksuper.ui.theme.toPersianNumber

@Composable
fun StageStatusBadge(
    stage: ProgressStage,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    when (stage.status) {
        StageStatus.CURRENT -> {
            Surface(
                modifier = modifier,
                shape = RoundedCornerShape(14.dp),
                color = PrimaryBlue,
                shadowElevation = if (compact) 1.dp else 3.dp
            ) {
                Text(
                    text = when (stage.missionStatus) {
                        MissionStatus.ACTIVE -> stringResource(R.string.mission_active)
                        MissionStatus.EXPIRED -> stringResource(R.string.mission_expired_badge)
                        else -> stringResource(R.string.current_stage)
                    },
                    modifier = Modifier.padding(
                        horizontal = if (compact) 8.dp else 12.dp,
                        vertical = if (compact) 4.dp else 6.dp
                    ),
                    color = Color.White,
                    fontSize = if (compact) NetworkTextSize.Micro else NetworkTextSize.Label,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }

        StageStatus.COMPLETED -> StatusCircle(
            icon = Icons.Rounded.Check,
            color = SuccessGreen,
            description = stringResource(R.string.done),
            modifier = modifier,
            compact = compact
        )

        StageStatus.FAILED -> StatusCircle(
            icon = Icons.Rounded.Close,
            color = FailRed,
            description = stringResource(R.string.not_done),
            modifier = modifier,
            compact = compact
        )

        StageStatus.UPCOMING -> {
            val size = if (compact) 29.dp else 36.dp
            Surface(
                modifier = modifier.size(size),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = if (compact) 1.dp else 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFB9C7DA))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = stage.number.toPersianNumber(),
                        color = Navy.copy(alpha = 0.78f),
                        fontSize = if (compact) NetworkTextSize.CompactLabel else NetworkTextSize.Body,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusCircle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    description: String,
    modifier: Modifier,
    compact: Boolean
) {
    val size = if (compact) 29.dp else 36.dp
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = color,
        shadowElevation = if (compact) 1.dp else 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = Color.White,
                modifier = Modifier.size(if (compact) 18.dp else 21.dp)
            )
        }
    }
}
