# Network Super App — V25 Clean Rebuild

پروتوتایپ Android برای سوپر اپ نتورک مارکتینگ با Kotlin، Jetpack Compose و Material 3.

V25 بازسازی تمیز کدهای V24 است: **ظاهر و منطق فعلی حفظ شده‌اند** اما state، business rules، persistence و Mission Detail ساختار مسئولیت‌محور‌تری دارند.

## تکنولوژی

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Jetpack Compose / Material 3
- Min SDK 26 / Target SDK 35
- Java 17

## Build

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

GitHub Actions همین دو task را اجرا می‌کند و APK debug را به‌عنوان artifact تحویل می‌دهد.

## ساختار اصلی

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
└── ui/
    ├── components/
    ├── navigation/
    ├── home/
    ├── progress/
    │   ├── ProgressStage.kt
    │   ├── MissionRules.kt
    │   ├── ProgressPathRules.kt
    │   ├── ProgressStageFactory.kt
    │   ├── ProgressPathPersistence.kt
    │   ├── ProgressPathStore.kt
    │   ├── ProgressPathScreen.kt
    │   ├── ProgressPathHeader.kt
    │   ├── ProgressPathWorld.kt
    │   ├── ProgressPathDialogs.kt
    │   ├── MissionDetailScreen.kt
    │   ├── MissionDetailContent.kt
    │   └── MissionDialogs.kt
    └── theme/
```

## سازگاری داده

SharedPreferences و payload schema نسخه V24 حفظ شده‌اند. داده‌های `v4` مستقیم خوانده می‌شوند و migration از `v3`، `v2` و legacy همچنان موجود است.

## Visual baseline

`docs/home-reference.png` و UI فعلی Progress Path مبنای بصری هستند. Refactorهای بعدی نباید بدون درخواست صریح، رنگ، spacing، اندازه، Canvas geometry یا RTL behavior را تغییر دهند.
