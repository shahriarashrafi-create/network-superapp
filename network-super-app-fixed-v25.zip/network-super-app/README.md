# Network Super App

پروتوتایپ اندروید RTL برای سوپر اپ نتورک مارکتینگ با Kotlin، Jetpack Compose و Material 3.

## وضعیت فعلی — V25 Progress Path + Gamification

V25 مسیر پیشرفت را از یک مسیر تزئینی به هسته‌ی اجرایی و گیمیفیکیشنی تبدیل می‌کند:

- هدر مشترک Home / Progress / Execution با Level، XP، Coin، Combo و Rewards.
- کارت‌ها مستقل از ترتیب هستند؛ هیچ مرحله‌ای قفل زنجیره‌ای ندارد.
- فقط یک کار در هر لحظه می‌تواند Active باشد.
- چهار سطح Importance با Reward مشخص.
- XP برای Level Up، Coin برای اقتصاد آینده و Combo ×1.5 از سومین Completion.
- Countdown واقعی، Required To-Do، Note draft auto-save، Done/Failed/Restore و Retry.
- Reward transaction idempotent، Undo واقعی و Replay کمبو/پاداش بعد از Restore.
- Notification پایان تایمر و هشدار 5 دقیقه‌ی آخر Combo.
- Persistence مسیر V5 + Game State versioned و Migration از V24.

> داده‌های برنامه‌ی روزانه Home هنوز Mock هستند؛ ولی Game State و Progress Path واقعی و Persisted هستند.

## تکنولوژی

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Jetpack Compose / Material 3
- Min SDK 26 / Target SDK 35
- Java 17

## اجرا

پروژه را در Android Studio باز کنید و Gradle Sync را اجرا کنید. سپس ماژول `app` را Run کنید.

از خط فرمان:

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

اگر `gradle-wrapper.jar` در یک آرشیو source-only موجود نباشد، `gradlew` Wrapper رسمی Gradle 8.9 را یک‌بار بازیابی و SHA-256 رسمی آن را قبل از اجرا بررسی می‌کند. نسخه و SHA-256 توزیع Gradle نیز در `gradle-wrapper.properties` pin شده‌اند.

## ساختار

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
└── ui/
    ├── components/
    │   ├── ActionVisuals.kt
    │   ├── EdgePreviewLazyRow.kt
    │   └── GameHeader.kt
    ├── navigation/
    │   └── AppRoot.kt
    ├── home/
    │   ├── HomeScreen.kt
    │   ├── HomeUiState.kt
    │   ├── HomeHeader.kt
    │   ├── HomeActions.kt
    │   └── HomeSections.kt
    ├── progress/
    │   ├── ProgressStage.kt
    │   ├── ProgressPathRules.kt
    │   ├── ProgressPathStore.kt
    │   ├── ProgressPathLayout.kt
    │   ├── ProgressPathScreen.kt
    │   ├── ProgressPathWorld.kt
    │   ├── UnifiedStageEditorDialog.kt
    │   ├── MissionDetailScreen.kt
    │   ├── MissionRules.kt
    │   ├── GameRules.kt
    │   ├── GameStore.kt
    │   └── GameNotificationScheduler.kt
    └── theme/
        ├── Color.kt
        ├── Theme.kt
        └── Type.kt
```

## مستندات

- `docs/home-reference.png` — مرجع تصویری Home
- `docs/HOME_SPEC_FA.md` — تاریخچه و مشخصات طراحی Home
- `docs/CURRENT_ARCHITECTURE.md` — مرجع معماری جاری و قواعد توسعه‌ی بعدی

## قواعد ادامه‌ی پروژه

Home و Progress visual baseline محسوب می‌شوند؛ Refactorهای بعدی نباید بدون درخواست صریح اندازه‌ها، spacing، Canvas geometry، رنگ‌ها یا RTL behavior این دو صفحه را تغییر دهند. قابلیت‌های جدید از AppRoot به مقصد مستقل وصل شوند و منطق persistence/business داخل Composableها قرار نگیرد.

## V22 — Mission Detail / Stage Execution

The progress path now has a real mission flow implemented entirely with Jetpack Compose (no image backgrounds/assets):

- Stage cards and Home "Start" open a dedicated mission detail screen.
- Timestamp-based countdown survives navigation, app backgrounding, and process recreation via persisted `startedAt/endAt` values.
- Required/optional checklist items with required-item completion gating.
- Editable mission title, short description, default duration, checklist text/type/order, and item add/delete.
- Full-screen note editor with debounced auto-save; Restore intentionally preserves notes.
- Explicit mission states: `NOT_STARTED`, `ACTIVE`, `EXPIRED`, `COMPLETED`, `FAILED`.
- Expired time warns only; it never auto-fails a mission.
- Large primary "Done" action, smaller "Failed" action with confirmation, and Restore with confirmation.
- Retry resets checklist/timer but preserves the note and custom mission setup.
- Success state advances to the next current stage or returns to the progress path.
- Persistence schema upgraded to v3 with migration from v2/legacy data.
- Pure mission rules have unit coverage for required gating, persisted countdown math, expiration semantics, progress, and Restore note preservation.


## V23

جزئیات تغییرات V23 در `docs/V23_CHANGELOG_FA.md` ثبت شده است.
