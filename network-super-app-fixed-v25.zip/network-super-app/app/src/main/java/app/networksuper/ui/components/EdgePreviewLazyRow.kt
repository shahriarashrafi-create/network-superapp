package app.networksuper.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

/** Horizontal card row with the same partial-edge fade used across the dashboard. */
@Composable
fun <T> EdgePreviewLazyRow(
    items: List<T>,
    key: (T) -> Any,
    modifier: Modifier = Modifier,
    itemContent: @Composable (item: T, modifier: Modifier) -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val rowState = rememberLazyListState()
        LazyRow(
            state = rowState,
            modifier = modifier,
            reverseLayout = true,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 0.dp)
        ) {
            itemsIndexed(items, key = { _, item -> key(item) }) { index, item ->
                val visibleItem = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                val isEdgePreview = visibleItem != null && (
                    visibleItem.offset < rowState.layoutInfo.viewportStartOffset ||
                        visibleItem.offset + visibleItem.size > rowState.layoutInfo.viewportEndOffset
                )
                itemContent(
                    item,
                    Modifier
                        .width(140.dp)
                        .fillMaxHeight()
                        .graphicsLayer { alpha = if (isEdgePreview) 0.78f else 1f }
                )
            }
        }
    }
}
