package app.networksuper.ui.progress

import androidx.compose.ui.unit.dp

internal val StageSpacing = 184.dp
internal val StageCardHeight = 94.dp
internal val WorldTopPadding = 66.dp
