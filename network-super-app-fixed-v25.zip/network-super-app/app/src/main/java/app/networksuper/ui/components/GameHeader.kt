package app.networksuper.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.networksuper.ui.progress.GameRules
import app.networksuper.ui.progress.GameStore
import app.networksuper.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun GameHeader(
    userName: String,
    modifier: Modifier = Modifier
) {
    var showWallet by remember { mutableStateOf(false) }
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val game = GameStore.state

    LaunchedEffect(game.comboExpiresAtMillis, game.comboCount) {
        if (game.comboCount > 0 && game.comboExpiresAtMillis != null) {
            while (true) {
                nowMillis = System.currentTimeMillis()
                GameStore.expireComboIfNeeded(nowMillis)
                if (GameStore.state.comboCount <= 0) break
                delay(1_000L)
            }
        }
    }

    Box(
        modifier = modifier
            .heightIn(min = 126.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFFF8FCFF))
            .border(1.dp, PrimaryBlue.copy(alpha = 0.10f), RoundedCornerShape(24.dp))
    ) {
        HeaderWaveBackdrop(Modifier.matchParentSize())
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 11.dp, vertical = 9.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ComboCapsule(nowMillis = nowMillis)
                    WalletButton(
                        showDot = game.hasRewardNotification,
                        onClick = {
                            GameStore.clearRewardNotification()
                            showWallet = true
                        }
                    )
                    XpCoinCapsule()
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = userName,
                            color = Navy,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            maxLines = 1
                        )
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = PrimaryBlue.copy(alpha = 0.10f)
                        ) {
                            Text(
                                text = "Level ${game.level}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                color = PrimaryBlueDark,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    ProfileAvatar()
                }
            }

            LevelProgressRow()
        }
    }

    if (showWallet) RewardsSummaryDialog(onDismiss = { showWallet = false })
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val wave = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.40f)
            cubicTo(w * .72f, h * .12f, w * .58f, h * .50f, w * .36f, h * .30f)
            cubicTo(w * .20f, h * .16f, w * .08f, h * .38f, 0f, h * .22f)
            close()
        }
        drawPath(
            wave,
            Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = .34f),
                    Color(0xFF8CCBFF).copy(alpha = .18f),
                    Color.Transparent
                )
            )
        )
        drawCircle(Color.White.copy(alpha = .34f), radius = 38.dp.toPx(), center = Offset(w * .48f, h * .10f))
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(48.dp)
            .shadow(5.dp, CircleShape)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))))
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.Person, contentDescription = "پروفایل", tint = Color.White, modifier = Modifier.size(27.dp))
    }
}

@Composable
private fun XpCoinCapsule() {
    val game = GameStore.state
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White.copy(alpha = .95f),
        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = .12f)),
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(Icons.Rounded.Star, contentDescription = "XP", tint = RewardGold, modifier = Modifier.size(19.dp))
            Text(formatCompactNumber(game.totalXp), color = Navy, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
            Box(Modifier.height(20.dp).width(1.dp).background(SurfaceOutline))
            CoinAsset(Modifier.size(20.dp))
            Text(formatCompactNumber(game.coinBalance), color = Navy, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun CoinAsset(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawCircle(Color(0xFFFFC83D))
        drawCircle(Color(0xFFFFE69B), radius = size.minDimension * .37f)
        val star = Path().apply {
            val cx = size.width / 2f
            val cy = size.height / 2f
            moveTo(cx, cy - size.height * .20f)
            lineTo(cx + size.width * .06f, cy - size.height * .06f)
            lineTo(cx + size.width * .21f, cy - size.height * .05f)
            lineTo(cx + size.width * .09f, cy + size.height * .04f)
            lineTo(cx + size.width * .13f, cy + size.height * .19f)
            lineTo(cx, cy + size.height * .10f)
            lineTo(cx - size.width * .13f, cy + size.height * .19f)
            lineTo(cx - size.width * .09f, cy + size.height * .04f)
            lineTo(cx - size.width * .21f, cy - size.height * .05f)
            lineTo(cx - size.width * .06f, cy - size.height * .06f)
            close()
        }
        drawPath(star, Color(0xFFE19A00))
    }
}

@Composable
private fun WalletButton(showDot: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = Modifier.size(43.dp),
        shape = RoundedCornerShape(15.dp),
        color = Color(0xFFFFF7E8),
        border = androidx.compose.foundation.BorderStroke(1.dp, RewardGold.copy(alpha = .25f)),
        shadowElevation = 2.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Inventory2, contentDescription = "پاداش‌ها", tint = Color(0xFFB87800), modifier = Modifier.size(26.dp))
            Icon(Icons.Rounded.Star, contentDescription = null, tint = RewardGold, modifier = Modifier.size(12.dp).offset(y = (-1).dp))
            if (showDot) Box(Modifier.align(Alignment.TopEnd).padding(5.dp).size(7.dp).background(FailRed, CircleShape))
        }
    }
}

@Composable
private fun ComboCapsule(nowMillis: Long) {
    val game = GameStore.state
    val remaining = GameStore.remainingComboMillis(nowMillis)
    val active = game.comboCount > 0 && remaining > 0L
    val warning = active && remaining <= GameRules.COMBO_WARNING_MILLIS
    val urgent = active && remaining <= 60_000L
    val pulseTransition = rememberInfiniteTransition(label = "comboPulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (urgent) 1.055f else 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "comboPulseScale"
    )
    val color = when {
        warning -> WarningOrange
        game.comboCount >= GameRules.COMBO_TRIGGER_COUNT -> Color(0xFFFF6A1A)
        else -> PrimaryBlue
    }
    Surface(
        modifier = Modifier.scale(pulse),
        shape = RoundedCornerShape(15.dp),
        color = color.copy(alpha = .09f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .20f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(Icons.Rounded.Whatshot, contentDescription = "کمبو", tint = color, modifier = Modifier.size(20.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (game.comboCount >= GameRules.COMBO_TRIGGER_COUNT) "×${game.comboCount}" else "${game.comboCount}/3",
                    color = Navy,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black
                )
                if (active) Text(formatComboTime(remaining), color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LevelProgressRow() {
    val game = GameStore.state
    val progress = if (game.xpTarget <= 0) 0f else game.xpIntoLevel.toFloat() / game.xpTarget.toFloat()
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Icon(Icons.Rounded.Star, contentDescription = null, tint = RewardGold, modifier = Modifier.size(16.dp))
        LinearProgressIndicator(
            progress = progress.coerceIn(0f, 1f),
            modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape),
            color = PrimaryBlue,
            trackColor = Color(0xFFDDEAF9)
        )
        Text(
            text = "${game.xpIntoLevel}/${game.xpTarget} XP",
            color = Navy,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
private fun RewardsSummaryDialog(onDismiss: () -> Unit) {
    val game = GameStore.state
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Inventory2, contentDescription = null, tint = RewardGold) },
        title = { Text("پاداش‌ها", color = Navy, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Level ${game.level}", color = Navy, fontWeight = FontWeight.Bold)
                Text("${game.totalXp} XP", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                Text("${game.coinBalance} سکه", color = Color(0xFFB87800), fontWeight = FontWeight.Bold)
                Text("بهترین کمبو: ${game.bestCombo}", color = Muted)
                val last = game.transactions.lastOrNull { it.reversedAtMillis == null }
                if (last != null) {
                    HorizontalDivider()
                    Text("آخرین پاداش", color = Muted, style = MaterialTheme.typography.labelMedium)
                    Text("${last.stageTitle}: +${last.xpDelta} XP • +${last.coinDelta} سکه", color = Navy, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp)
    )
}

private fun formatCompactNumber(value: Int): String = when (value) {
        in 0..9_999 -> value.toString()
        in 10_000..999_999 -> "%.1fK".format(value / 1000.0)
        else -> "%.1fM".format(value / 1_000_000.0)
}

private fun formatComboTime(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) + 999L) / 1000L
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%02d:%02d".format(minutes, seconds)
}
