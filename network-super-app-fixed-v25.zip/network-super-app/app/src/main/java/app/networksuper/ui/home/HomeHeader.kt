package app.networksuper.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import app.networksuper.ui.components.GameHeader

/** V25: one shared gameplay header is used on Home, Progress and task execution. */
@Composable
internal fun HomeHeader(state: HomeUiState, modifier: Modifier = Modifier) {
    GameHeader(userName = state.userName, modifier = modifier)
}
