package app.networksuper.ui.progress

/** Defaults and normalization that belong to stage construction, not persistence/UI. */
internal object ProgressStageFactory {
    val defaults: List<ProgressStage> = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    ).map(::withMissionDefaults)

    fun withMissionDefaults(stage: ProgressStage): ProgressStage {
        val normalizedMissionStatus = when (stage.status) {
            StageStatus.COMPLETED -> MissionStatus.COMPLETED
            StageStatus.FAILED -> MissionStatus.FAILED
            StageStatus.CURRENT, StageStatus.UPCOMING -> stage.missionStatus
        }
        return stage.copy(
            missionStatus = normalizedMissionStatus,
            durationMinutes = stage.durationMinutes.coerceIn(1, 24 * 60),
            checklist = stage.checklist.ifEmpty { defaultChecklist(stage.id) }
        )
    }

    fun checklistId(stageId: Long, index: Int): Long =
        stageId.coerceAtLeast(1L) * 10_000L + index + 1L

    private fun defaultChecklist(stageId: Long): List<MissionChecklistItem> = listOf(
        MissionChecklistItem(checklistId(stageId, 0), "مرور هدف این مرحله", required = true),
        MissionChecklistItem(checklistId(stageId, 1), "انجام اقدام اصلی مرحله", required = true),
        MissionChecklistItem(checklistId(stageId, 2), "ثبت جمع‌بندی کوتاه", required = false)
    )
}
