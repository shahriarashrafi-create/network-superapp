package app.networksuper

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.networksuper.ui.navigation.AppRoot
import app.networksuper.ui.progress.GameStore
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.theme.NetworkSuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        GameStore.initialize(applicationContext)
        ProgressPathStore.initialize(applicationContext)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }

        setContent {
            NetworkSuperAppTheme {
                AppRoot()
            }
        }
    }
}
