package app.networksuper.ui.progress

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.R
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.FailRed
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.PrimaryBlueDark
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen
import app.networksuper.ui.theme.SurfaceOutline
import app.networksuper.ui.theme.WarningOrange
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
internal fun ConfirmActionDialog(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    message: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(modifier = Modifier.size(52.dp), shape = CircleShape, color = iconColor.copy(alpha = 0.10f)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(28.dp))
                }
            }
        },
        title = { Text(title, color = Navy, fontWeight = FontWeight.Black, textAlign = TextAlign.Center) },
        text = { Text(message, color = Muted, textAlign = TextAlign.Center) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = iconColor),
                shape = RoundedCornerShape(14.dp)
            ) { Text(confirmText, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel), color = Muted) }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White
    )
}

@Composable
internal fun NoteDialog(
    stageId: Long,
    committedNote: String,
    draftNote: String?,
    stageTitle: String,
    onDismiss: () -> Unit
) {
    var text by remember(stageId) { mutableStateOf(draftNote ?: committedNote) }
    var committedText by remember(stageId) { mutableStateOf(committedNote) }
    var showExitPrompt by remember(stageId) { mutableStateOf(false) }
    var draftSaved by remember(stageId) { mutableStateOf(true) }

    fun requestClose() {
        if (text != committedText) showExitPrompt = true else onDismiss()
    }

    BackHandler { requestClose() }

    Dialog(
        onDismissRequest = { requestClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFFFFCF3),
            border = BorderStroke(1.dp, RewardGold.copy(alpha = 0.18f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { requestClose() }) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_close), tint = Navy)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.mission_note_title),
                            color = Navy,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = stageTitle,
                            color = Muted,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton(
                        onClick = {
                            ProgressPathStore.commitNote(stageId, text)
                            committedText = text
                            draftSaved = true
                        }
                    ) {
                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.action_save), fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { value ->
                        text = value
                        draftSaved = false
                        ProgressPathStore.updateNoteDraft(stageId, value)
                        draftSaved = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    placeholder = { Text(stringResource(R.string.mission_note_hint)) },
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (draftSaved) Icons.Rounded.Check else Icons.Rounded.Sync,
                        contentDescription = null,
                        tint = if (draftSaved) SuccessGreen else Muted,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (text == committedText) {
                            stringResource(R.string.mission_note_saved)
                        } else {
                            stringResource(R.string.mission_note_saving)
                        },
                        color = if (text == committedText) SuccessGreen else Muted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        if (showExitPrompt) {
            AlertDialog(
                onDismissRequest = { showExitPrompt = false },
                title = {
                    Text(
                        stringResource(R.string.mission_note_exit_title),
                        color = Navy,
                        fontWeight = FontWeight.Black
                    )
                },
                text = { Text(stringResource(R.string.mission_note_exit_message), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            ProgressPathStore.commitNote(stageId, text)
                            committedText = text
                            showExitPrompt = false
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) { Text(stringResource(R.string.action_save)) }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            ProgressPathStore.discardNoteDraft(stageId)
                            showExitPrompt = false
                            onDismiss()
                        }) {
                            Text(stringResource(R.string.action_discard), color = FailRed)
                        }
                        TextButton(onClick = { showExitPrompt = false }) {
                            Text(stringResource(R.string.action_cancel), color = Muted)
                        }
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }
    }
}

@Composable
internal fun StageSetupDialog(
    stage: ProgressStage,
    positionCount: Int,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int, List<MissionChecklistItem>) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(stage.id) { mutableStateOf(stage.title) }
    var selectedPosition by remember(stage.id) { mutableIntStateOf(stage.number.coerceIn(1, positionCount)) }
    var selectedDuration by remember(stage.id) { mutableIntStateOf(stage.durationMinutes) }
    var durationExpanded by remember(stage.id) { mutableStateOf(false) }
    var positionExpanded by remember(stage.id) { mutableStateOf(false) }
    var pendingDeleteItemId by remember(stage.id) { mutableStateOf<Long?>(null) }
    var confirmDeleteCard by remember(stage.id) { mutableStateOf(false) }
    val checklistItems = remember(stage.id) {
        mutableStateListOf<MissionChecklistItem>().apply { addAll(stage.checklist) }
    }
    var nextLocalId by remember(stage.id) {
        mutableLongStateOf((stage.checklist.maxOfOrNull { it.id } ?: stage.id * 10_000L) + 1L)
    }
    val density = LocalDensity.current
    val dragThresholdPx = with(density) { 26.dp.toPx() }
    val durationOptions = listOf(5, 10, 15, 20, 30)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = AppBackground,
            border = BorderStroke(1.dp, SurfaceOutline)
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_close), tint = Navy)
                    }
                    Text(
                        text = stringResource(R.string.mission_edit_title),
                        modifier = Modifier.weight(1f),
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    IconButton(onClick = { confirmDeleteCard = true }) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = stringResource(R.string.delete_card),
                            tint = FailRed
                        )
                    }
                }
                Spacer(Modifier.height(5.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.card_name)) },
                    singleLine = true,
                    shape = RoundedCornerShape(15.dp)
                )

                Spacer(Modifier.height(7.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, SurfaceOutline)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.position),
                            modifier = Modifier.weight(1f),
                            color = Navy,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Box {
                            OutlinedButton(
                                onClick = { positionExpanded = true },
                                modifier = Modifier.height(40.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(stringResource(R.string.edit_position_value, selectedPosition))
                                Spacer(Modifier.width(3.dp))
                                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                            DropdownMenu(
                                expanded = positionExpanded,
                                onDismissRequest = { positionExpanded = false }
                            ) {
                                (1..positionCount).forEach { position ->
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.edit_position_value, position)) },
                                        onClick = {
                                            selectedPosition = position
                                            positionExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(7.dp))
                Surface(
                    onClick = { durationExpanded = !durationExpanded },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, SurfaceOutline)
                ) {
                    Column(Modifier.padding(horizontal = 11.dp, vertical = 7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Timer, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(
                                text = stringResource(R.string.mission_default_duration),
                                modifier = Modifier.weight(1f),
                                color = Navy,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = stringResource(R.string.mission_minutes_value, selectedDuration),
                                color = PrimaryBlue,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(Modifier.width(3.dp))
                            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
                        }
                        if (durationExpanded) {
                            Spacer(Modifier.height(7.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                durationOptions.forEach { option ->
                                    FilterChip(
                                        selected = selectedDuration == option,
                                        onClick = {
                                            selectedDuration = option
                                            durationExpanded = false
                                        },
                                        modifier = Modifier.weight(1f),
                                        label = {
                                            Text(
                                                text = stringResource(R.string.mission_minutes_value, option),
                                                maxLines = 1,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = SoftBlue,
                                            selectedLabelColor = PrimaryBlueDark
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.mission_checklist),
                        modifier = Modifier.weight(1f),
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Surface(
                        onClick = {
                            checklistItems.add(
                                MissionChecklistItem(
                                    id = nextLocalId++,
                                    text = "",
                                    required = false
                                )
                            )
                        },
                        modifier = Modifier.size(38.dp),
                        shape = CircleShape,
                        color = SoftBlue
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.Add,
                                contentDescription = stringResource(R.string.mission_add_item),
                                tint = PrimaryBlue,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(checklistItems, key = { it.id }) { item ->
                        val index = checklistItems.indexOfFirst { it.id == item.id }
                        var dragDistance by remember(item.id) { mutableFloatStateOf(0f) }
                        Surface(
                            modifier = Modifier.pointerInput(item.id, checklistItems.size) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragDistance = 0f },
                                    onDragEnd = { dragDistance = 0f },
                                    onDragCancel = { dragDistance = 0f },
                                    onDrag = { _, dragAmount ->
                                        dragDistance += dragAmount.y
                                        val currentIndex = checklistItems.indexOfFirst { it.id == item.id }
                                        if (dragDistance > dragThresholdPx && currentIndex < checklistItems.lastIndex) {
                                            val moved = checklistItems.removeAt(currentIndex)
                                            checklistItems.add(currentIndex + 1, moved)
                                            dragDistance = 0f
                                        } else if (dragDistance < -dragThresholdPx && currentIndex > 0) {
                                            val moved = checklistItems.removeAt(currentIndex)
                                            checklistItems.add(currentIndex - 1, moved)
                                            dragDistance = 0f
                                        }
                                    }
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, SurfaceOutline)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Rounded.DragIndicator,
                                    contentDescription = stringResource(R.string.mission_reorder),
                                    tint = Muted,
                                    modifier = Modifier.size(25.dp)
                                )
                                Spacer(Modifier.width(3.dp))
                                OutlinedTextField(
                                    value = item.text,
                                    onValueChange = { value ->
                                        if (index >= 0) checklistItems[index] = item.copy(text = value)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 50.dp),
                                    placeholder = { Text(stringResource(R.string.mission_item_hint)) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                FilterChip(
                                    selected = item.required,
                                    onClick = {
                                        if (index >= 0) checklistItems[index] = item.copy(required = !item.required)
                                    },
                                    label = {
                                        Text(
                                            if (item.required) stringResource(R.string.mission_required) else stringResource(R.string.mission_optional),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    leadingIcon = if (item.required) {
                                        { Icon(Icons.Rounded.PriorityHigh, contentDescription = null, modifier = Modifier.size(15.dp)) }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FailRed.copy(alpha = 0.08f),
                                        selectedLabelColor = FailRed,
                                        selectedLeadingIconColor = FailRed
                                    )
                                )
                                IconButton(
                                    onClick = {
                                        if (index >= 0) {
                                            if (item.checked) pendingDeleteItemId = item.id
                                            else checklistItems.removeAt(index)
                                        }
                                    },
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = stringResource(R.string.action_delete),
                                        tint = FailRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(7.dp))
                Button(
                    onClick = {
                        onSave(title, selectedPosition, selectedDuration, checklistItems.toList())
                    },
                    enabled = title.isNotBlank() && checklistItems.any { it.text.isNotBlank() },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.action_save), fontWeight = FontWeight.Black)
                }
            }
        }

        if (pendingDeleteItemId != null) {
            AlertDialog(
                onDismissRequest = { pendingDeleteItemId = null },
                title = { Text(stringResource(R.string.mission_delete_checked_title), color = Navy, fontWeight = FontWeight.Black) },
                text = { Text(stringResource(R.string.mission_delete_checked_message), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = pendingDeleteItemId
                            if (target != null) checklistItems.removeAll { it.id == target }
                            pendingDeleteItemId = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FailRed)
                    ) { Text(stringResource(R.string.action_delete)) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeleteItemId = null }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }

        if (confirmDeleteCard) {
            AlertDialog(
                onDismissRequest = { confirmDeleteCard = false },
                icon = { Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed) },
                title = { Text(stringResource(R.string.delete_card_question), color = Navy, fontWeight = FontWeight.Black) },
                text = { Text(stringResource(R.string.delete_card_message, stage.title), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            confirmDeleteCard = false
                            onDelete()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FailRed)
                    ) { Text(stringResource(R.string.action_delete)) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmDeleteCard = false }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }
    }
}
