package app.networksuper.ui.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.home.HomeScreen
import app.networksuper.ui.progress.MissionDetailScreen
import app.networksuper.ui.progress.ProgressPathContent
import app.networksuper.ui.theme.*

enum class AppDestination(
    val labelRes: Int,
    val icon: ImageVector
) {
    HOME(R.string.nav_home, Icons.Rounded.Home),
    PROGRESS(R.string.nav_progress, Icons.Rounded.TrendingUp),
    CUSTOMERS(R.string.nav_customers, Icons.Rounded.Groups),
    NETWORKING(R.string.nav_networking, Icons.Rounded.AccountTree),
    MORE(R.string.nav_more, Icons.Rounded.MoreHoriz)
}

@Composable
fun AppRoot() {
    var destinationName by rememberSaveable { mutableStateOf(AppDestination.HOME.name) }
    var missionStageId by rememberSaveable { mutableStateOf<Long?>(null) }
    val destination = runCatching { AppDestination.valueOf(destinationName) }
        .getOrDefault(AppDestination.HOME)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val activeMissionId = missionStageId
        if (activeMissionId != null) {
            MissionDetailScreen(
                stageId = activeMissionId,
                onBack = {
                    missionStageId = null
                    destinationName = AppDestination.PROGRESS.name
                },
                onOpenNextStage = { missionStageId = it }
            )
        } else {
            Scaffold(
                containerColor = AppBackground,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    AppBottomBar(
                        selected = destination,
                        onSelected = { destinationName = it.name }
                    )
                }
            ) { padding ->
                when (destination) {
                    AppDestination.HOME -> HomeScreen(
                        modifier = Modifier.padding(padding),
                        onOpenMission = { missionStageId = it }
                    )
                    AppDestination.PROGRESS -> ProgressPathContent(
                        modifier = Modifier.padding(padding),
                        onOpenMission = { missionStageId = it }
                    )
                    AppDestination.CUSTOMERS,
                    AppDestination.NETWORKING,
                    AppDestination.MORE -> PendingDestinationScreen(
                        destination = destination,
                        modifier = Modifier.padding(padding)
                    )
                }
            }
        }
    }
}

@Composable
private fun PendingDestinationScreen(
    destination: AppDestination,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceOutline),
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = destination.icon,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(32.dp)
                )
                Text(
                    text = stringResource(destination.labelRes),
                    color = Navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = stringResource(R.string.feature_ready_for_next_step),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun AppBottomBar(
    selected: AppDestination,
    onSelected: (AppDestination) -> Unit
) {
    val items = AppDestination.entries

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 7.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val active = item == selected
                val containerColor by animateColorAsState(
                    targetValue = if (active) SoftBlue else Color.Transparent,
                    label = "navColor"
                )
                val elevation by animateDpAsState(
                    targetValue = if (active) 7.dp else 0.dp,
                    label = "navElevation"
                )
                val scale by animateFloatAsState(
                    targetValue = if (active) 1.06f else 1f,
                    label = "navScale"
                )
                val tint by animateColorAsState(
                    targetValue = if (active) PrimaryBlue else Muted,
                    label = "navTint"
                )

                Surface(
                    onClick = { onSelected(item) },
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = containerColor,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.25.dp,
                        PrimaryBlue.copy(alpha = 0.22f)
                    ) else null,
                    shadowElevation = elevation
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = stringResource(item.labelRes),
                            tint = tint,
                            modifier = Modifier.size(if (active) 26.dp else 22.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = stringResource(item.labelRes),
                            color = tint,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
