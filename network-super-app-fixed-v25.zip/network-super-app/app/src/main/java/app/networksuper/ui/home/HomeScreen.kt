package app.networksuper.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.progress.ProgressPathStore

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    uiState: HomeUiState = HomeDefaults.state,
    onOpenMission: (Long) -> Unit = {}
) {
    val currentStage = ProgressPathStore.suggestedStage()
    val nextActionTitle = currentStage?.title ?: stringResource(R.string.next_step_missing)
    val rewardLabel = currentStage?.let { stage ->
        val multiplier = app.networksuper.ui.progress.GameStore.projectedMultiplier()
        val baseXp = stage.activeRewardXpSnapshot ?: stage.importance.baseXp
        val baseCoin = stage.activeRewardCoinSnapshot ?: stage.importance.baseCoin
        val xp = app.networksuper.ui.progress.GameRules.applyMultiplier(baseXp, multiplier)
        val coin = app.networksuper.ui.progress.GameRules.applyMultiplier(baseCoin, multiplier)
        "+$xp XP • +$coin"
    }
    val currentIsActive = currentStage?.let { it.missionStatus == app.networksuper.ui.progress.MissionStatus.ACTIVE || it.missionStatus == app.networksuper.ui.progress.MissionStatus.EXPIRED } == true

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HomeHeader(
            state = uiState,
            modifier = Modifier
                .fillMaxWidth()
                .height(126.dp)
        )
        NextActionCard(
            nextActionTitle = nextActionTitle,
            rewardLabel = rewardLabel,
            active = currentIsActive,
            onStart = { currentStage?.let { onOpenMission(it.id) } },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.25f)
        )
        TodaySection(
            title = uiState.todayTitle,
            dateLabel = uiState.todayDateLabel,
            scheduleItems = uiState.scheduleItems,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.375f)
        )
        ProgressSection(
            onStageClick = onOpenMission,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.375f)
        )
    }

}

