package app.networksuper.ui.progress

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.ui.theme.*
import kotlin.math.abs

@Composable
internal fun UnifiedStageEditorDialog(
    stage: ProgressStage?,
    positionCount: Int,
    onDismiss: () -> Unit,
    onSave: (title: String, position: Int, duration: Int, checklist: List<MissionChecklistItem>, importance: ImportanceLevel) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val isNew = stage == null
    val tempStageId = stage?.id ?: (System.currentTimeMillis() % 900_000L + 100_000L)
    var title by remember(stage?.id) { mutableStateOf(stage?.title.orEmpty()) }
    var position by remember(stage?.id, positionCount) { mutableIntStateOf((stage?.number ?: positionCount).coerceIn(1, positionCount)) }
    var duration by remember(stage?.id) { mutableIntStateOf(stage?.durationMinutes ?: ProgressStage.DEFAULT_MISSION_DURATION_MINUTES) }
    var importance by remember(stage?.id) { mutableStateOf(stage?.importance ?: ImportanceLevel.NORMAL) }
    val todos = remember(stage?.id) {
        mutableStateListOf<MissionChecklistItem>().apply {
            addAll(stage?.checklist ?: listOf(
                MissionChecklistItem(ProgressPathStore.nextChecklistId(tempStageId, 0), "", required = true)
            ))
        }
    }
    var confirmDelete by remember { mutableStateOf(false) }
    var pendingCheckedDelete by remember { mutableStateOf<Long?>(null) }
    val durationOptions = listOf(5, 10, 15, 20, 30)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.90f)
                .windowInsetsPadding(WindowInsets.safeDrawing),
            shape = RoundedCornerShape(26.dp),
            color = Color.White,
            border = BorderStroke(1.dp, SurfaceOutline),
            shadowElevation = 12.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "بستن", tint = Navy)
                    }
                    Text(
                        text = if (isNew) "افزودن کارت" else "ویرایش",
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black
                    )
                    if (!isNew && onDelete != null) {
                        IconButton(onClick = { confirmDelete = true }, modifier = Modifier.size(42.dp)) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "حذف کارت", tint = FailRed)
                        }
                    } else Spacer(Modifier.size(42.dp))
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
                    label = { Text("نام کارت") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                CompactPositionSelector(
                    selected = position,
                    max = positionCount,
                    onSelected = { position = it }
                )

                Text("زمان", color = Muted, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    durationOptions.forEach { option ->
                        FilterChip(
                            selected = duration == option,
                            onClick = { duration = option },
                            label = { Text(option.toString(), textAlign = TextAlign.Center) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PrimaryBlue,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Text("اهمیت", color = Muted, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ImportanceLevel.entries.forEach { level ->
                        FilterChip(
                            selected = importance == level,
                            onClick = { importance = level },
                            label = { Text(importanceLabel(level), maxLines = 1) },
                            modifier = Modifier.weight(1f),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = importanceColor(level),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SoftBlue.copy(alpha = .55f),
                    border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = .12f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Rounded.Star, contentDescription = null, tint = RewardGold, modifier = Modifier.size(18.dp))
                        Text(" +${importance.baseXp} XP", color = Navy, fontWeight = FontWeight.Black)
                        Spacer(Modifier.width(10.dp))
                        Text("🪙 +${importance.baseCoin}", color = Navy, fontWeight = FontWeight.Black)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("To-Do List", color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    IconButton(
                        onClick = {
                            val next = (todos.maxOfOrNull { it.id } ?: ProgressPathStore.nextChecklistId(tempStageId, 0)) + 1
                            todos.add(MissionChecklistItem(next, "", required = false))
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(Icons.Rounded.AddCircle, contentDescription = "افزودن", tint = PrimaryBlue)
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(todos, key = { it.id }) { item ->
                        val index = todos.indexOfFirst { it.id == item.id }
                        var dragAccum by remember(item.id) { mutableFloatStateOf(0f) }
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .pointerInput(item.id, todos.size) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { dragAccum = 0f },
                                        onDragEnd = { dragAccum = 0f },
                                        onDragCancel = { dragAccum = 0f },
                                        onDrag = { _, amount ->
                                            dragAccum += amount.y
                                            if (abs(dragAccum) > 45f) {
                                                val currentIndex = todos.indexOfFirst { it.id == item.id }
                                                val newIndex = if (dragAccum > 0) currentIndex + 1 else currentIndex - 1
                                                if (currentIndex >= 0 && newIndex in todos.indices) {
                                                    val moved = todos.removeAt(currentIndex)
                                                    todos.add(newIndex, moved)
                                                }
                                                dragAccum = 0f
                                            }
                                        }
                                    )
                                },
                            shape = RoundedCornerShape(13.dp),
                            color = Color(0xFFFCFDFF),
                            border = BorderStroke(1.dp, SurfaceOutline)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.DragIndicator, contentDescription = "جابجایی", tint = Muted, modifier = Modifier.size(23.dp))
                                OutlinedTextField(
                                    value = item.text,
                                    onValueChange = { if (index >= 0) todos[index] = item.copy(text = it) },
                                    modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                                    placeholder = { Text("عنوان فعالیت") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(11.dp)
                                )
                                FilterChip(
                                    selected = item.required,
                                    onClick = { if (index >= 0) todos[index] = item.copy(required = !item.required) },
                                    label = { Text(if (item.required) "ضروری" else "اختیاری", style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FailRed.copy(alpha = .10f),
                                        selectedLabelColor = FailRed
                                    )
                                )
                                IconButton(
                                    onClick = {
                                        if (item.checked) pendingCheckedDelete = item.id else if (index >= 0) todos.removeAt(index)
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "حذف", tint = FailRed, modifier = Modifier.size(19.dp))
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        onSave(
                            title.trim(),
                            position,
                            duration,
                            todos.filter { it.text.isNotBlank() },
                            importance
                        )
                    },
                    enabled = title.isNotBlank() && todos.any { it.text.isNotBlank() },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(Modifier.width(5.dp))
                    Text(if (isNew) "افزودن" else "ذخیره", fontWeight = FontWeight.Black)
                }
            }
        }
    }

    if (pendingCheckedDelete != null) {
        AlertDialog(
            onDismissRequest = { pendingCheckedDelete = null },
            title = { Text("حذف مورد انجام‌شده؟", fontWeight = FontWeight.Black) },
            text = { Text("این مورد قبلاً تیک خورده است. مطمئنی حذف شود؟") },
            confirmButton = {
                Button(
                    onClick = {
                        val id = pendingCheckedDelete
                        if (id != null) todos.removeAll { it.id == id }
                        pendingCheckedDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FailRed)
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { pendingCheckedDelete = null }) { Text("انصراف") } }
        )
    }

    if (confirmDelete && onDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            icon = { Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed) },
            title = { Text(if (stage?.missionStatus == MissionStatus.ACTIVE || stage?.missionStatus == MissionStatus.EXPIRED) "حذف کار در حال اجرا؟" else "حذف کارت؟", fontWeight = FontWeight.Black) },
            text = { Text(if (stage?.missionStatus == MissionStatus.ACTIVE || stage?.missionStatus == MissionStatus.EXPIRED) "با حذف این کارت، تایمر و وضعیت اجرای آن هم حذف می‌شود." else "این کارت از مسیر حذف می‌شود.") },
            confirmButton = {
                Button(onClick = { confirmDelete = false; onDelete() }, colors = ButtonDefaults.buttonColors(containerColor = FailRed)) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun CompactPositionSelector(selected: Int, max: Int, onSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Surface(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            color = Color.White,
            border = BorderStroke(1.dp, SurfaceOutline)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Icon(Icons.Rounded.ExpandMore, contentDescription = null, tint = PrimaryBlue)
                Column(horizontalAlignment = Alignment.End) {
                    Text("جایگاه در مسیر", color = Muted, style = MaterialTheme.typography.labelSmall)
                    Text("قدم $selected از $max", color = Navy, fontWeight = FontWeight.Bold)
                }
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (1..max).forEach { value ->
                DropdownMenuItem(
                    text = { Text("قدم $value") },
                    onClick = { onSelected(value); expanded = false },
                    leadingIcon = { if (value == selected) Icon(Icons.Rounded.Check, contentDescription = null, tint = PrimaryBlue) }
                )
            }
        }
    }
}

internal fun importanceLabel(level: ImportanceLevel): String = when (level) {
    ImportanceLevel.LOW -> "کم"
    ImportanceLevel.NORMAL -> "معمولی"
    ImportanceLevel.IMPORTANT -> "مهم"
    ImportanceLevel.VERY_IMPORTANT -> "خیلی مهم"
}

internal fun importanceColor(level: ImportanceLevel): Color = when (level) {
    ImportanceLevel.LOW -> Muted
    ImportanceLevel.NORMAL -> PrimaryBlue
    ImportanceLevel.IMPORTANT -> WarningOrange
    ImportanceLevel.VERY_IMPORTANT -> FailRed
}
