package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

object GameStore {
    private const val PREFS_NAME = "game_state_v1"
    private const val KEY_STATE = "game_state_v1_json"
    private const val VERSION = 1

    data class State(
        val totalXp: Int = 0,
        val coinBalance: Int = 0,
        val comboCount: Int = 0,
        val comboExpiresAtMillis: Long? = null,
        val bestCombo: Int = 0,
        val hasRewardNotification: Boolean = false,
        val transactions: List<RewardTransaction> = emptyList(),
        val events: List<GameEvent> = emptyList()
    ) {
        val level: Int get() = GameRules.levelForXp(totalXp)
        val xpIntoLevel: Int get() = GameRules.xpIntoLevel(totalXp)
        val xpTarget: Int get() = GameRules.xpTargetForCurrentLevel(totalXp)
    }

    var state by mutableStateOf(State())
        private set

    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) {
            expireComboIfNeeded(System.currentTimeMillis())
            return
        }
        appContext = context.applicationContext
        prefs = appContext!!.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        state = decode(prefs?.getString(KEY_STATE, null)) ?: State()
        initialized = true
        expireComboIfNeeded(System.currentTimeMillis())
        GameNotificationScheduler.ensureChannel(appContext!!)
        rescheduleComboAlarms()
    }

    fun projectedComboCount(nowMillis: Long = System.currentTimeMillis()): Int {
        val active = state.comboExpiresAtMillis?.let { it > nowMillis } == true
        return (if (active) state.comboCount else 0) + 1
    }

    fun projectedMultiplier(nowMillis: Long = System.currentTimeMillis()): Double =
        GameRules.multiplierForCombo(projectedComboCount(nowMillis))

    fun remainingComboMillis(nowMillis: Long = System.currentTimeMillis()): Long =
        ((state.comboExpiresAtMillis ?: nowMillis) - nowMillis).coerceAtLeast(0L)

    fun expireComboIfNeeded(nowMillis: Long = System.currentTimeMillis()): Boolean {
        val expiry = state.comboExpiresAtMillis ?: return false
        if (state.comboCount <= 0 || expiry > nowMillis) return false
        state = state.copy(
            comboCount = 0,
            comboExpiresAtMillis = null,
            events = appendEvent(state.events, "COMBO_BREAK", null, nowMillis)
        )
        persist()
        appContext?.let { GameNotificationScheduler.cancelCombo(it) }
        return true
    }

    fun grantCompletion(
        stageId: Long,
        stageTitle: String,
        baseXp: Int,
        baseCoin: Int,
        nowMillis: Long = System.currentTimeMillis(),
        preferredTransactionId: Long? = null
    ): RewardGrant {
        val existing = preferredTransactionId?.let { id -> state.transactions.firstOrNull { it.id == id && it.reversedAtMillis == null } }
        if (existing != null) {
            val previousLevel = GameRules.levelForXp((state.totalXp - existing.xpDelta).coerceAtLeast(0))
            return RewardGrant(
                transactionId = existing.id,
                stageId = existing.stageId,
                baseXp = existing.baseXp,
                baseCoin = existing.baseCoin,
                comboCount = existing.comboCount,
                multiplier = existing.multiplier,
                xpGranted = existing.xpDelta,
                coinGranted = existing.coinDelta,
                previousLevel = previousLevel,
                newLevel = state.level,
                grantedAtMillis = existing.createdAtMillis
            )
        }
        expireComboIfNeeded(nowMillis)
        val previousLevel = state.level
        val nextCombo = (if (state.comboExpiresAtMillis?.let { it > nowMillis } == true) state.comboCount else 0) + 1
        val multiplier = GameRules.multiplierForCombo(nextCombo)
        val xpGranted = GameRules.applyMultiplier(baseXp, multiplier)
        val coinGranted = GameRules.applyMultiplier(baseCoin, multiplier)
        val transactionId = preferredTransactionId?.takeIf { id -> state.transactions.none { it.id == id } } ?: uniqueId(nowMillis)
        val tx = RewardTransaction(
            id = transactionId,
            stageId = stageId,
            stageTitle = stageTitle,
            baseXp = baseXp,
            baseCoin = baseCoin,
            comboCount = nextCombo,
            multiplier = multiplier,
            xpDelta = xpGranted,
            coinDelta = coinGranted,
            createdAtMillis = nowMillis
        )
        val newXp = (state.totalXp + xpGranted).coerceAtLeast(0)
        val expiry = nowMillis + GameRules.COMBO_WINDOW_MILLIS
        state = state.copy(
            totalXp = newXp,
            coinBalance = (state.coinBalance + coinGranted).coerceAtLeast(0),
            comboCount = nextCombo,
            comboExpiresAtMillis = expiry,
            bestCombo = max(state.bestCombo, nextCombo),
            hasRewardNotification = true,
            transactions = (state.transactions + tx).takeLast(300),
            events = appendEvent(state.events, "DONE", stageId, nowMillis)
        )
        persist()
        rescheduleComboAlarms()
        return RewardGrant(
            transactionId = transactionId,
            stageId = stageId,
            baseXp = baseXp,
            baseCoin = baseCoin,
            comboCount = nextCombo,
            multiplier = multiplier,
            xpGranted = xpGranted,
            coinGranted = coinGranted,
            previousLevel = previousLevel,
            newLevel = GameRules.levelForXp(newXp),
            grantedAtMillis = nowMillis
        )
    }

    fun reverseReward(transactionId: Long?, nowMillis: Long = System.currentTimeMillis()): Boolean {
        if (transactionId == null) return false
        val index = state.transactions.indexOfFirst { it.id == transactionId && it.reversedAtMillis == null }
        if (index < 0) return false
        val tx = state.transactions[index]
        val marked = state.transactions.toMutableList().also {
            it[index] = tx.copy(reversedAtMillis = nowMillis)
        }
        state = state.copy(
            transactions = marked,
            events = appendEvent(state.events, "REWARD_RESTORE", tx.stageId, nowMillis)
        )
        replayValidTransactions(nowMillis)
        persist()
        rescheduleComboAlarms()
        return true
    }

    fun recordEvent(type: String, stageId: Long? = null, nowMillis: Long = System.currentTimeMillis()) {
        state = state.copy(events = appendEvent(state.events, type, stageId, nowMillis))
        persist()
    }

    fun clearRewardNotification() {
        if (!state.hasRewardNotification) return
        state = state.copy(hasRewardNotification = false)
        persist()
    }

    /**
     * Replays valid completions after an undo. This is stronger than just combo--: if removing an
     * older completion changes whether later completions qualified for ×1.5, their rewards are
     * recalculated too, keeping XP/Coin and combo history mathematically consistent.
     */
    private fun replayValidTransactions(nowMillis: Long) {
        val sorted = state.transactions.sortedBy { it.createdAtMillis }.toMutableList()
        var runningCombo = 0
        var previousTime: Long? = null
        var totalXp = 0
        var totalCoin = 0
        var best = 0

        for (i in sorted.indices) {
            val tx = sorted[i]
            if (tx.reversedAtMillis != null) continue
            runningCombo = if (previousTime != null && tx.createdAtMillis - previousTime!! < GameRules.COMBO_WINDOW_MILLIS) {
                runningCombo + 1
            } else {
                1
            }
            previousTime = tx.createdAtMillis
            best = max(best, runningCombo)
            val multiplier = GameRules.multiplierForCombo(runningCombo)
            val xp = GameRules.applyMultiplier(tx.baseXp, multiplier)
            val coin = GameRules.applyMultiplier(tx.baseCoin, multiplier)
            sorted[i] = tx.copy(
                comboCount = runningCombo,
                multiplier = multiplier,
                xpDelta = xp,
                coinDelta = coin
            )
            totalXp += xp
            totalCoin += coin
        }

        val lastValid = sorted.lastOrNull { it.reversedAtMillis == null }
        val comboStillAlive = lastValid != null && nowMillis - lastValid.createdAtMillis < GameRules.COMBO_WINDOW_MILLIS
        val currentCombo = if (comboStillAlive && lastValid != null) {
            var count = 0
            var newer: Long? = null
            for (candidate in sorted.asReversed()) {
                if (candidate.reversedAtMillis != null) continue
                if (newer != null && newer!! - candidate.createdAtMillis >= GameRules.COMBO_WINDOW_MILLIS) break
                count++
                newer = candidate.createdAtMillis
            }
            count
        } else 0

        state = state.copy(
            totalXp = totalXp.coerceAtLeast(0),
            coinBalance = totalCoin.coerceAtLeast(0),
            comboCount = currentCombo,
            comboExpiresAtMillis = if (comboStillAlive && lastValid != null) lastValid.createdAtMillis + GameRules.COMBO_WINDOW_MILLIS else null,
            bestCombo = best,
            transactions = sorted
        )
    }

    private fun appendEvent(
        events: List<GameEvent>,
        type: String,
        stageId: Long?,
        at: Long
    ): List<GameEvent> = (events + GameEvent(uniqueId(at + events.size), type, stageId, at)).takeLast(500)

    private fun uniqueId(seed: Long): Long {
        var value = seed.coerceAtLeast(1L)
        val used = state.transactions.asSequence().map { it.id }.toHashSet()
        while (value in used) value++
        return value
    }

    private fun rescheduleComboAlarms() {
        val context = appContext ?: return
        val expiry = state.comboExpiresAtMillis
        if (state.comboCount <= 0 || expiry == null) {
            GameNotificationScheduler.cancelCombo(context)
        } else {
            GameNotificationScheduler.scheduleCombo(context, expiry)
        }
    }

    private fun persist() {
        prefs?.edit()?.putString(KEY_STATE, encode(state))?.apply()
    }

    private fun encode(value: State): String {
        val txArray = JSONArray()
        value.transactions.forEach { tx ->
            txArray.put(JSONObject()
                .put("id", tx.id)
                .put("stageId", tx.stageId)
                .put("stageTitle", tx.stageTitle)
                .put("baseXp", tx.baseXp)
                .put("baseCoin", tx.baseCoin)
                .put("comboCount", tx.comboCount)
                .put("multiplier", tx.multiplier)
                .put("xpDelta", tx.xpDelta)
                .put("coinDelta", tx.coinDelta)
                .put("createdAtMillis", tx.createdAtMillis)
                .put("reversedAtMillis", tx.reversedAtMillis ?: JSONObject.NULL))
        }
        val eventArray = JSONArray()
        value.events.forEach { event ->
            eventArray.put(JSONObject()
                .put("id", event.id)
                .put("type", event.type)
                .put("stageId", event.stageId ?: JSONObject.NULL)
                .put("createdAtMillis", event.createdAtMillis))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("totalXp", value.totalXp)
            .put("coinBalance", value.coinBalance)
            .put("comboCount", value.comboCount)
            .put("comboExpiresAtMillis", value.comboExpiresAtMillis ?: JSONObject.NULL)
            .put("bestCombo", value.bestCombo)
            .put("hasRewardNotification", value.hasRewardNotification)
            .put("transactions", txArray)
            .put("events", eventArray)
            .toString()
    }

    private fun decode(raw: String?): State? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != VERSION) return@runCatching null
            val txs = buildList {
                val array = root.optJSONArray("transactions") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(RewardTransaction(
                        id = o.getLong("id"),
                        stageId = o.getLong("stageId"),
                        stageTitle = o.optString("stageTitle", ""),
                        baseXp = o.optInt("baseXp", 0),
                        baseCoin = o.optInt("baseCoin", 0),
                        comboCount = o.optInt("comboCount", 0),
                        multiplier = o.optDouble("multiplier", 1.0),
                        xpDelta = o.optInt("xpDelta", 0),
                        coinDelta = o.optInt("coinDelta", 0),
                        createdAtMillis = o.optLong("createdAtMillis", 0L),
                        reversedAtMillis = if (o.isNull("reversedAtMillis")) null else o.optLong("reversedAtMillis")
                    ))
                }
            }
            val events = buildList {
                val array = root.optJSONArray("events") ?: JSONArray()
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(GameEvent(
                        id = o.getLong("id"),
                        type = o.optString("type", ""),
                        stageId = if (o.isNull("stageId")) null else o.optLong("stageId"),
                        createdAtMillis = o.optLong("createdAtMillis", 0L)
                    ))
                }
            }
            State(
                totalXp = root.optInt("totalXp", 0).coerceAtLeast(0),
                coinBalance = root.optInt("coinBalance", 0).coerceAtLeast(0),
                comboCount = root.optInt("comboCount", 0).coerceAtLeast(0),
                comboExpiresAtMillis = if (root.isNull("comboExpiresAtMillis")) null else root.optLong("comboExpiresAtMillis"),
                bestCombo = root.optInt("bestCombo", 0).coerceAtLeast(0),
                hasRewardNotification = root.optBoolean("hasRewardNotification", false),
                transactions = txs,
                events = events
            )
        }.getOrNull()
    }
}
