package app.networksuper.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.components.GeometricBlueBackdrop
import app.networksuper.ui.components.StartActionButton
import app.networksuper.ui.theme.*

@Composable
internal fun NextActionCard(
    nextActionTitle: String,
    rewardLabel: String? = null,
    active: Boolean = false,
    onStart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(
                6.dp,
                RoundedCornerShape(24.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.10f),
                spotColor = PrimaryBlue.copy(alpha = 0.12f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        ActionBlueDeep,
                        ActionBlueMid,
                        ActionBlueLight
                    )
                )
            )
    ) {
        GeometricBlueBackdrop(Modifier.fillMaxSize())

        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 10.dp, start = 10.dp)
                .width(98.dp)
                .height(28.dp),
            shape = RoundedCornerShape(13.dp),
            color = Color(0xFF0B5FBE).copy(alpha = 0.76f),
            border = androidx.compose.foundation.BorderStroke(
                1.4.dp,
                Color.White.copy(alpha = 0.90f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.TrackChanges,
                    contentDescription = null,
                    tint = Color(0xFFFF5A4D),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = stringResource(R.string.next_step),
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Right,
                    maxLines = 1
                )
            }
        }


        if (!rewardLabel.isNullOrBlank()) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 10.dp, end = 10.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color.White.copy(alpha = 0.92f)
            ) {
                Text(
                    text = rewardLabel,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    color = Navy,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-4).dp)
                .fillMaxWidth(0.64f)
                .height(48.dp),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.98f),
            shadowElevation = 4.dp
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = nextActionTitle,
                    modifier = Modifier.padding(horizontal = 14.dp),
                    textAlign = TextAlign.Center,
                    color = Navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        StartActionButton(
            onClick = onStart,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 48.dp)
                .fillMaxWidth(0.55f)
                .height(46.dp),
            iconSize = 22.dp,
            shadowElevation = 1.dp,
            forceLtr = true,
            label = if (active) "ادامه" else null
        )
    }
}

