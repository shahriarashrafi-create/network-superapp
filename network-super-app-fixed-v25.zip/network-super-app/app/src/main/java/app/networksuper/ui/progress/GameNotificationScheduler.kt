package app.networksuper.ui.progress

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object GameNotificationScheduler {
    private const val CHANNEL_ID = "progress_gameplay"
    private const val REQUEST_COMBO_WARNING = 8101
    private const val REQUEST_COMBO_EXPIRE = 8102
    private const val REQUEST_STAGE_BASE = 9000

    const val ACTION_COMBO_WARNING = "app.networksuper.COMBO_WARNING"
    const val ACTION_COMBO_EXPIRE = "app.networksuper.COMBO_EXPIRE"
    const val ACTION_STAGE_EXPIRE = "app.networksuper.STAGE_EXPIRE"
    const val EXTRA_STAGE_ID = "stage_id"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "یادآوری کارها و کمبو",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "هشدار پایان زمان کار و کمبو"
                }
            )
        }
    }

    fun scheduleStageExpiry(context: Context, stageId: Long, endAtMillis: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, GameAlarmReceiver::class.java)
            .setAction(ACTION_STAGE_EXPIRE)
            .putExtra(EXTRA_STAGE_ID, stageId)
        val pending = PendingIntent.getBroadcast(
            context,
            REQUEST_STAGE_BASE + (stageId % 1000).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAtMillis, pending)
    }

    fun cancelStage(context: Context, stageId: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, GameAlarmReceiver::class.java).setAction(ACTION_STAGE_EXPIRE)
        val pending = PendingIntent.getBroadcast(
            context,
            REQUEST_STAGE_BASE + (stageId % 1000).toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) alarm.cancel(pending)
    }

    fun scheduleCombo(context: Context, expiresAtMillis: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        cancelCombo(context)
        val warningAt = expiresAtMillis - GameRules.COMBO_WARNING_MILLIS
        val now = System.currentTimeMillis()
        if (warningAt > now) {
            alarm.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                warningAt,
                comboPendingIntent(context, ACTION_COMBO_WARNING, REQUEST_COMBO_WARNING)
            )
        }
        if (expiresAtMillis > now) {
            alarm.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                expiresAtMillis,
                comboPendingIntent(context, ACTION_COMBO_EXPIRE, REQUEST_COMBO_EXPIRE)
            )
        }
    }

    fun cancelCombo(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        listOf(
            ACTION_COMBO_WARNING to REQUEST_COMBO_WARNING,
            ACTION_COMBO_EXPIRE to REQUEST_COMBO_EXPIRE
        ).forEach { (action, request) ->
            val pending = PendingIntent.getBroadcast(
                context,
                request,
                Intent(context, GameAlarmReceiver::class.java).setAction(action),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pending != null) alarm.cancel(pending)
        }
    }

    fun notify(context: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ensureChannel(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(context, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") android.app.Notification.Builder(context)
        }
        manager.notify(
            id,
            builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
        )
    }

    private fun comboPendingIntent(context: Context, action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            requestCode,
            Intent(context, GameAlarmReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}

class GameAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            GameNotificationScheduler.ACTION_COMBO_WARNING -> {
                GameStore.initialize(context)
                if (GameStore.state.comboCount > 0 && GameStore.remainingComboMillis() > 0L) {
                    GameNotificationScheduler.notify(
                        context,
                        701,
                        "کمبو در حال پایان است",
                        "۵ دقیقه تا پایان کمبو باقی مانده؛ یک کار دیگر را کامل کن."
                    )
                }
            }
            GameNotificationScheduler.ACTION_COMBO_EXPIRE -> {
                GameStore.initialize(context)
                if (GameStore.expireComboIfNeeded()) {
                    GameNotificationScheduler.notify(
                        context,
                        702,
                        "کمبو پایان یافت",
                        "با انجام یک کار جدید، زنجیره‌ی بعدی را شروع کن."
                    )
                }
            }
            GameNotificationScheduler.ACTION_STAGE_EXPIRE -> {
                val stageId = intent.getLongExtra(GameNotificationScheduler.EXTRA_STAGE_ID, -1L)
                if (stageId > 0L) {
                    ProgressPathStore.initialize(context)
                    ProgressPathStore.markExpiredIfNeeded(stageId)
                    val stage = ProgressPathStore.stage(stageId)
                    if (stage?.missionStatus == MissionStatus.EXPIRED) {
                        GameNotificationScheduler.notify(
                            context,
                            1000 + (stageId % 1000).toInt(),
                            "زمان تمام شد",
                            "زمان «${stage.title}» تمام شده؛ نتیجه را خودت ثبت کن."
                        )
                    }
                }
            }
        }
    }
}
