package app.networksuper.ui.progress

/** Pure progress-path rules. No persistence or Compose state lives here. */
internal object ProgressPathRules {
    fun currentOrdinal(items: List<ProgressStage>): Int {
        val ordered = items.sortedBy { it.number }
        val currentIndex = ordered.indexOfFirst { it.status == StageStatus.CURRENT }
        if (currentIndex >= 0) return currentIndex + 1

        return if (ordered.isNotEmpty() && ordered.none { it.status == StageStatus.UPCOMING }) {
            ordered.size
        } else {
            0
        }
    }

    /**
     * Return the path to the exact execution point represented by [targetId]. Earlier history stays
     * intact; the target becomes current; every later card becomes upcoming and execution-reset.
     */
    fun rollbackTo(items: List<ProgressStage>, targetId: Long): List<ProgressStage> {
        val ordered = items.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == targetId }
        if (targetIndex < 0) return normalize(items)

        ordered.indices.forEach { index ->
            when {
                index < targetIndex -> Unit
                index == targetIndex -> {
                    ordered[index] = MissionRules.restored(ordered[index])
                        .copy(status = StageStatus.CURRENT)
                }
                else -> {
                    ordered[index] = MissionRules.restored(ordered[index])
                        .copy(status = StageStatus.UPCOMING)
                }
            }
        }
        return normalize(ordered)
    }

    /** Enforces contiguous numbering and the single-current invariant. */
    fun normalize(items: List<ProgressStage>): List<ProgressStage> {
        val ordered = items
            .sortedWith(compareBy<ProgressStage> { it.number }.thenBy { it.id })
            .mapIndexed { index, stage ->
                stage.copy(number = index + 1, title = stage.title.trim())
            }
            .toMutableList()

        val currentIndices = ordered.indices.filter { ordered[it].status == StageStatus.CURRENT }
        currentIndices.drop(1).forEach { index ->
            ordered[index] = ordered[index].copy(status = StageStatus.UPCOMING)
        }

        if (ordered.none { it.status == StageStatus.CURRENT }) {
            val firstUpcoming = ordered.indexOfFirst { it.status == StageStatus.UPCOMING }
            if (firstUpcoming >= 0) {
                ordered[firstUpcoming] = ordered[firstUpcoming].copy(status = StageStatus.CURRENT)
            }
        }
        return ordered
    }
}
