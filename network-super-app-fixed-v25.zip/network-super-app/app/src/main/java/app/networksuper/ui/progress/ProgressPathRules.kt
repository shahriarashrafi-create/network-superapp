package app.networksuper.ui.progress

/** Pure progress-path rules. Cards are ordered suggestions, never access gates. */
internal object ProgressPathRules {
    fun currentOrdinal(items: List<ProgressStage>): Int {
        val ordered = items.sortedBy { it.number }
        val currentIndex = ordered.indexOfFirst { it.status == StageStatus.CURRENT }
        return if (currentIndex >= 0) currentIndex + 1 else 0
    }

    fun completedCount(items: List<ProgressStage>): Int =
        items.count { it.missionStatus == MissionStatus.COMPLETED }

    fun completionProgress(items: List<ProgressStage>): Float =
        if (items.isEmpty()) 0f else completedCount(items).toFloat() / items.size.toFloat()

    /** Restores only the selected card. Other cards are independent and are never rolled back. */
    fun rollbackTo(items: List<ProgressStage>, targetId: Long): List<ProgressStage> {
        val ordered = items.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == targetId }
        if (targetIndex < 0) return normalize(items)

        val otherExecutionActive = ordered.any {
            it.id != targetId && (it.missionStatus == MissionStatus.ACTIVE || it.missionStatus == MissionStatus.EXPIRED)
        }
        ordered.indices.forEach { index ->
            val stage = ordered[index]
            ordered[index] = when {
                stage.id == targetId -> MissionRules.restored(stage).copy(
                    status = if (otherExecutionActive) StageStatus.UPCOMING else StageStatus.CURRENT
                )
                !otherExecutionActive && stage.status == StageStatus.CURRENT && stage.missionStatus == MissionStatus.NOT_STARTED -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        return normalize(ordered)
    }

    fun normalize(items: List<ProgressStage>): List<ProgressStage> {
        val ordered = items
            .sortedWith(compareBy<ProgressStage> { it.number }.thenBy { it.id })
            .mapIndexed { index, stage ->
                stage.copy(number = index + 1, title = stage.title.trim())
            }
            .toMutableList()

        val currentIndices = ordered.indices.filter { ordered[it].status == StageStatus.CURRENT }
        if (currentIndices.size > 1) {
            currentIndices.drop(1).forEach { index ->
                val stage = ordered[index]
                ordered[index] = stage.copy(
                    status = when (stage.missionStatus) {
                        MissionStatus.COMPLETED -> StageStatus.COMPLETED
                        MissionStatus.FAILED -> StageStatus.FAILED
                        else -> StageStatus.UPCOMING
                    }
                )
            }
        }

        if (ordered.none { it.status == StageStatus.CURRENT }) {
            val firstOpen = ordered.indexOfFirst {
                it.missionStatus == MissionStatus.NOT_STARTED || it.missionStatus == MissionStatus.ACTIVE || it.missionStatus == MissionStatus.EXPIRED
            }
            if (firstOpen >= 0) ordered[firstOpen] = ordered[firstOpen].copy(status = StageStatus.CURRENT)
        }
        return ordered
    }
}
