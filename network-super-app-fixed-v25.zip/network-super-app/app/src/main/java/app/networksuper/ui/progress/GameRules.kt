package app.networksuper.ui.progress

import kotlin.math.roundToInt

object GameRules {
    const val COMBO_TRIGGER_COUNT = 3
    const val COMBO_WINDOW_MILLIS = 30L * 60L * 1000L
    const val COMBO_WARNING_MILLIS = 5L * 60L * 1000L
    const val COMBO_MULTIPLIER = 1.5

    fun baseReward(importance: ImportanceLevel): Pair<Int, Int> =
        importance.baseXp to importance.baseCoin

    fun multiplierForCombo(comboCount: Int): Double =
        if (comboCount >= COMBO_TRIGGER_COUNT) COMBO_MULTIPLIER else 1.0

    fun applyMultiplier(value: Int, multiplier: Double): Int =
        (value * multiplier).roundToInt().coerceAtLeast(0)

    /** XP needed to move from [level] to level+1. Centralized for future admin control. */
    fun xpRequiredForLevel(level: Int): Int = 100 + (level.coerceAtLeast(1) - 1) * 50

    fun levelStartXp(level: Int): Int {
        var total = 0
        for (l in 1 until level.coerceAtLeast(1)) total += xpRequiredForLevel(l)
        return total
    }

    fun levelForXp(totalXp: Int): Int {
        var level = 1
        var remaining = totalXp.coerceAtLeast(0)
        while (remaining >= xpRequiredForLevel(level)) {
            remaining -= xpRequiredForLevel(level)
            level++
        }
        return level
    }

    fun xpIntoLevel(totalXp: Int): Int {
        val level = levelForXp(totalXp)
        return (totalXp - levelStartXp(level)).coerceAtLeast(0)
    }

    fun xpTargetForCurrentLevel(totalXp: Int): Int = xpRequiredForLevel(levelForXp(totalXp))
}

data class RewardGrant(
    val transactionId: Long,
    val stageId: Long,
    val baseXp: Int,
    val baseCoin: Int,
    val comboCount: Int,
    val multiplier: Double,
    val xpGranted: Int,
    val coinGranted: Int,
    val previousLevel: Int,
    val newLevel: Int,
    val grantedAtMillis: Long
) {
    val leveledUp: Boolean get() = newLevel > previousLevel
}

data class RewardTransaction(
    val id: Long,
    val stageId: Long,
    val stageTitle: String,
    val baseXp: Int,
    val baseCoin: Int,
    val comboCount: Int,
    val multiplier: Double,
    val xpDelta: Int,
    val coinDelta: Int,
    val createdAtMillis: Long,
    val reversedAtMillis: Long? = null
)

data class GameEvent(
    val id: Long,
    val type: String,
    val stageId: Long? = null,
    val createdAtMillis: Long
)
