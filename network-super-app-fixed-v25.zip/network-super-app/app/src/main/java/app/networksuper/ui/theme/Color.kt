package app.networksuper.ui.theme

import androidx.compose.ui.graphics.Color

val AppBackground = Color(0xFFF6F9FE)
val Navy = Color(0xFF0D1B4C)
val PrimaryBlue = Color(0xFF0E6FFF)
val PrimaryBlueDark = Color(0xFF064DCC)
val SoftBlue = Color(0xFFEAF3FF)
val SuccessGreen = Color(0xFF10B963)
val FailRed = Color(0xFFE5484D)
val WarningOrange = Color(0xFFFF7A1A)
val AccentPurple = Color(0xFF8A4DFF)
val RewardGold = Color(0xFFF5B51B)
val Muted = Color(0xFF7888AA)

// Semantic visual tokens shared across existing locked screens.
val SurfaceOutline = Color(0xFFEAF2FC)
val ActionBlueDeep = Color(0xFF075BD3)
val ActionBlueMid = Color(0xFF0879EA)
val ActionBlueLight = Color(0xFF1594F8)
val ActionButtonBlue = Color(0xFF1478F3)
