package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

enum class StartMissionResult { STARTED, ALREADY_ACTIVE, BLOCKED_BY_OTHER_ACTIVE, NOT_FOUND }

data class CompletionResult(
    val reward: RewardGrant,
    val stageTitle: String
)

/** Single source of truth for ordered cards and their execution state. */
object ProgressPathStore {
    private const val PREFS_NAME = "progress_path_v1"
    private const val KEY_STAGES_JSON = "stages_json_v5"
    private const val KEY_STAGES_JSON_V4 = "stages_json_v4"
    private const val KEY_STAGES_JSON_V3 = "stages_json_v3"
    private const val KEY_STAGES_JSON_V2 = "stages_json_v2"
    private const val KEY_STAGES_JSON_BACKUP = "stages_json_v5_backup"
    private const val KEY_STAGES_JSON_V4_BACKUP = "stages_json_v4_backup"
    private const val KEY_STAGES_JSON_V3_BACKUP = "stages_json_v3_backup"
    private const val KEY_STAGES_JSON_V2_BACKUP = "stages_json_v2_backup"
    private const val KEY_STAGES_LEGACY = "stages"
    private const val SCHEMA_VERSION = 5

    private val defaultStages = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING, importance = ImportanceLevel.VERY_IMPORTANT),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING, importance = ImportanceLevel.IMPORTANT),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING, importance = ImportanceLevel.IMPORTANT),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING, importance = ImportanceLevel.IMPORTANT),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    ).map { ensureMissionDefaults(it) }

    val stages = mutableStateListOf<ProgressStage>()

    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) {
            refreshExpiredStates()
            return
        }
        appContext = context.applicationContext
        GameStore.initialize(appContext!!)
        val sharedPreferences = appContext!!.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sharedPreferences
        val restored = restore(sharedPreferences) ?: defaultStages
        replaceWithRenumbered(sanitizeSingleActive(restored), persistAfter = false)
        refreshExpiredStates(persistAfter = false)
        persist()
        sharedPreferences.edit().remove(KEY_STAGES_LEGACY).apply()
        rescheduleActiveTimer()
        initialized = true
    }

    fun stage(id: Long): ProgressStage? = stages.firstOrNull { it.id == id }

    /** The recommended/current card, not an access gate. */
    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    /** The only execution that can be active at a time. EXPIRED still counts until resolved/restored. */
    fun activeStage(): ProgressStage? = stages.firstOrNull {
        it.missionStatus == MissionStatus.ACTIVE || it.missionStatus == MissionStatus.EXPIRED
    }

    fun suggestedStage(): ProgressStage? = activeStage()
        ?: currentStage()
        ?: stages.sortedBy { it.number }.firstOrNull { it.missionStatus == MissionStatus.NOT_STARTED }

    fun currentOrdinal(): Int = ProgressPathRules.currentOrdinal(stages)
    fun completedCount(): Int = ProgressPathRules.completedCount(stages)
    fun completionProgress(): Float = ProgressPathRules.completionProgress(stages)

    fun isComplete(): Boolean = stages.isNotEmpty() && stages.all { it.missionStatus == MissionStatus.COMPLETED }

    fun positionCount(isNew: Boolean): Int = (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    fun addStage(
        title: String,
        position: Int,
        durationMinutes: Int = ProgressStage.DEFAULT_MISSION_DURATION_MINUTES,
        checklist: List<MissionChecklistItem> = emptyList(),
        importance: ImportanceLevel = ImportanceLevel.NORMAL
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        val nextId = nextAvailableId(ordered)
        ordered.add(
            insertionIndex,
            ensureMissionDefaults(
                ProgressStage(
                    id = nextId,
                    number = position,
                    title = cleanTitle,
                    status = if (ordered.none { it.status == StageStatus.CURRENT }) StageStatus.CURRENT else StageStatus.UPCOMING,
                    durationMinutes = durationMinutes,
                    checklist = checklist,
                    importance = importance
                )
            )
        )
        replaceWithRenumbered(ordered)
        GameStore.recordEvent("CARD_ADD", nextId)
    }

    fun updateStageSetup(
        id: Long,
        title: String,
        position: Int,
        durationMinutes: Int,
        checklist: List<MissionChecklistItem>,
        importance: ImportanceLevel
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return
        val cleanDuration = durationMinutes.coerceIn(1, 24 * 60)
        val oldStage = stage(id) ?: return
        val cleanChecklist = checklist
            .mapIndexedNotNull { index, item ->
                val text = item.text.trim()
                if (text.isBlank()) null else {
                    val oldChecked = oldStage.checklist.firstOrNull { it.id == item.id }?.checked ?: item.checked
                    item.copy(
                        id = item.id.takeIf { it > 0 } ?: nextChecklistId(id, index),
                        text = text,
                        checked = oldChecked
                    )
                }
            }
            .distinctBy { it.id }

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return
        val old = ordered.removeAt(oldIndex)
        // Active timer and active reward snapshots never change mid-run.
        val updated = old.copy(
            title = cleanTitle,
            durationMinutes = cleanDuration,
            checklist = cleanChecklist,
            importance = importance
        )
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(insertionIndex, updated)
        replaceWithRenumbered(ordered)
        GameStore.recordEvent("CARD_EDIT", id)
    }

    fun editStage(id: Long, title: String, position: Int) {
        val current = stage(id) ?: return
        updateStageSetup(id, title, position, current.durationMinutes, current.checklist, current.importance)
    }

    fun updateMissionConfig(
        id: Long,
        title: String,
        description: String,
        durationMinutes: Int,
        checklist: List<MissionChecklistItem>
    ) {
        val current = stage(id) ?: return
        updateStageSetup(id, title, current.number, durationMinutes, checklist, current.importance)
    }

    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val target = ordered.removeAt(targetIndex)
        if (target.missionStatus == MissionStatus.ACTIVE || target.missionStatus == MissionStatus.EXPIRED) {
            appContext?.let { GameNotificationScheduler.cancelStage(it, target.id) }
        }
        if (target.lastRewardTransactionId != null) GameStore.reverseReward(target.lastRewardTransactionId)
        replaceWithRenumbered(ordered)
        GameStore.recordEvent("CARD_DELETE", id)
    }

    fun setCurrent(id: Long) {
        if (stages.none { it.id == id }) return
        val ordered = stages.sortedBy { it.number }.map { stage ->
            when {
                stage.id == id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(
                    status = when (stage.missionStatus) {
                        MissionStatus.COMPLETED -> StageStatus.COMPLETED
                        MissionStatus.FAILED -> StageStatus.FAILED
                        else -> StageStatus.UPCOMING
                    }
                )
                else -> stage
            }
        }
        replaceWithRenumbered(ordered)
    }

    fun startMission(id: Long, nowMillis: Long = System.currentTimeMillis()): StartMissionResult {
        val target = stage(id) ?: return StartMissionResult.NOT_FOUND
        val active = activeStage()
        if (active?.id == id) return StartMissionResult.ALREADY_ACTIVE
        if (active != null) return StartMissionResult.BLOCKED_BY_OTHER_ACTIVE

        setCurrent(id)
        updateStage(id, persistAfter = false) { stage ->
            val duration = stage.durationMinutes.coerceAtLeast(1)
            stage.copy(
                missionStatus = MissionStatus.ACTIVE,
                startedAtMillis = nowMillis,
                endAtMillis = nowMillis + duration * 60_000L,
                completedAtMillis = null,
                attemptCount = stage.attemptCount + 1,
                checklist = stage.checklist.map { it.copy(checked = false) },
                activeRewardXpSnapshot = stage.importance.baseXp,
                activeRewardCoinSnapshot = stage.importance.baseCoin,
                activeDurationMinutesSnapshot = duration,
                lastRewardTransactionId = null
            )
        }
        persist()
        stage(id)?.endAtMillis?.let { end -> appContext?.let { GameNotificationScheduler.scheduleStageExpiry(it, id, end) } }
        GameStore.recordEvent("START", id, nowMillis)
        return StartMissionResult.STARTED
    }

    fun markExpiredIfNeeded(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        val target = stage(id) ?: return
        if (!MissionRules.shouldExpire(target, nowMillis)) return
        updateStage(id) { it.copy(missionStatus = MissionStatus.EXPIRED) }
        GameStore.recordEvent("TIME_EXPIRED", id, nowMillis)
    }

    fun refreshExpiredStates(nowMillis: Long = System.currentTimeMillis(), persistAfter: Boolean = true) {
        var changed = false
        val updated = stages.map { stage ->
            if (MissionRules.shouldExpire(stage, nowMillis)) {
                changed = true
                stage.copy(missionStatus = MissionStatus.EXPIRED)
            } else stage
        }
        if (changed) replaceWithRenumbered(updated, persistAfter)
        GameStore.expireComboIfNeeded(nowMillis)
    }

    fun toggleChecklistItem(stageId: Long, itemId: Long, checked: Boolean) {
        updateStage(stageId) { stage ->
            stage.copy(checklist = stage.checklist.map { if (it.id == itemId) it.copy(checked = checked) else it })
        }
    }

    fun updateNoteDraft(id: Long, draft: String) {
        updateStage(id) { stage -> stage.copy(noteDraft = draft.takeIf { it != stage.note }) }
    }

    fun commitNote(id: Long, text: String) {
        updateStage(id) { it.copy(note = text, noteDraft = null) }
        GameStore.recordEvent("NOTE_SAVE", id)
    }

    fun discardNoteDraft(id: Long) { updateStage(id) { it.copy(noteDraft = null) } }
    fun updateNote(id: Long, note: String) = commitNote(id, note)

    fun canCompleteMission(id: Long): Boolean =
        stage(id)?.let { MissionRules.requiredComplete(it.checklist) } == true

    fun completeMission(id: Long, nowMillis: Long = System.currentTimeMillis()): CompletionResult? {
        val target = stage(id) ?: return null
        if (target.missionStatus != MissionStatus.ACTIVE && target.missionStatus != MissionStatus.EXPIRED) return null
        if (!MissionRules.requiredComplete(target.checklist)) return null

        val baseXp = target.activeRewardXpSnapshot ?: target.importance.baseXp
        val baseCoin = target.activeRewardCoinSnapshot ?: target.importance.baseCoin
        val deterministicTxId = completionTransactionId(target)
        val reward = GameStore.grantCompletion(
            stageId = target.id,
            stageTitle = target.title,
            baseXp = baseXp,
            baseCoin = baseCoin,
            nowMillis = nowMillis,
            preferredTransactionId = deterministicTxId
        )
        updateStage(id, persistAfter = false) {
            it.copy(
                missionStatus = MissionStatus.COMPLETED,
                completedAtMillis = nowMillis,
                lastRewardTransactionId = reward.transactionId
            )
        }
        markResult(id, StageStatus.COMPLETED, persistAfter = false)
        persist()
        appContext?.let { GameNotificationScheduler.cancelStage(it, id) }
        return CompletionResult(reward, target.title)
    }

    fun failMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        val target = stage(id) ?: return
        if (target.missionStatus != MissionStatus.ACTIVE && target.missionStatus != MissionStatus.EXPIRED) return
        updateStage(id, persistAfter = false) {
            it.copy(missionStatus = MissionStatus.FAILED, completedAtMillis = nowMillis)
        }
        markResult(id, StageStatus.FAILED, persistAfter = false)
        persist()
        appContext?.let { GameNotificationScheduler.cancelStage(it, id) }
        GameStore.recordEvent("FAILED", id, nowMillis)
    }

    fun retryMission(id: Long, nowMillis: Long = System.currentTimeMillis()): StartMissionResult {
        val target = stage(id) ?: return StartMissionResult.NOT_FOUND
        val active = activeStage()
        if (active != null && active.id != id) return StartMissionResult.BLOCKED_BY_OTHER_ACTIVE
        setCurrent(id)
        updateStage(id, persistAfter = false) { stage -> MissionRules.retried(stage, nowMillis) }
        persist()
        stage(id)?.endAtMillis?.let { end -> appContext?.let { GameNotificationScheduler.scheduleStageExpiry(it, id, end) } }
        GameStore.recordEvent("RETRY", id, nowMillis)
        return StartMissionResult.STARTED
    }

    /** Restore only this card; other cards remain exactly as they are. */
    fun restoreMission(id: Long) {
        val target = stage(id) ?: return
        if (target.lastRewardTransactionId != null) GameStore.reverseReward(target.lastRewardTransactionId)
        val rolledBack = ProgressPathRules.rollbackTo(stages, id)
        replaceWithRenumbered(rolledBack)
        appContext?.let { GameNotificationScheduler.cancelStage(it, id) }
        GameStore.recordEvent("RESTORE", id)
    }

    fun markCompleted(id: Long) {
        updateStage(id, persistAfter = false) { it.copy(missionStatus = MissionStatus.COMPLETED) }
        markResult(id, StageStatus.COMPLETED)
    }

    fun markFailed(id: Long) {
        updateStage(id, persistAfter = false) { it.copy(missionStatus = MissionStatus.FAILED) }
        markResult(id, StageStatus.FAILED)
    }

    private fun markResult(id: Long, result: StageStatus, persistAfter: Boolean = true) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)
        if (wasCurrent) promoteNextRecommended(ordered, targetIndex + 1)
        replaceWithRenumbered(ordered, persistAfter)
    }

    private fun promoteNextRecommended(ordered: MutableList<ProgressStage>, preferredStartIndex: Int) {
        if (ordered.any { it.status == StageStatus.CURRENT }) return
        val start = preferredStartIndex.coerceIn(0, ordered.size)
        val nextIndex = (start until ordered.size).firstOrNull {
            ordered[it].missionStatus == MissionStatus.NOT_STARTED
        } ?: ordered.indexOfFirst { it.missionStatus == MissionStatus.NOT_STARTED }.takeIf { it >= 0 }
        if (nextIndex != null) ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
    }

    private fun completionTransactionId(stage: ProgressStage): Long =
        (stage.id.coerceAtLeast(1L) * 1_000_000L) + stage.attemptCount.coerceAtLeast(1)

    private fun updateStage(
        id: Long,
        persistAfter: Boolean = true,
        transform: (ProgressStage) -> ProgressStage
    ) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val index = ordered.indexOfFirst { it.id == id }
        if (index < 0) return
        ordered[index] = ensureMissionDefaults(transform(ordered[index]))
        replaceWithRenumbered(ordered, persistAfter)
    }

    private fun replaceWithRenumbered(ascendingItems: List<ProgressStage>, persistAfter: Boolean = true) {
        val ordered = ProgressPathRules.normalize(ascendingItems).map { ensureMissionDefaults(it) }
        stages.clear()
        stages.addAll(ordered.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun nextAvailableId(items: List<ProgressStage>): Long {
        val used = items.asSequence().map { it.id }.toHashSet()
        var candidate = (used.maxOrNull() ?: 0L) + 1L
        while (candidate in used || candidate <= 0L) candidate++
        return candidate
    }

    private fun restore(sharedPreferences: SharedPreferences): List<ProgressStage>? {
        decodeV5(sharedPreferences.getString(KEY_STAGES_JSON, null))?.let { return it }
        decodeV5(sharedPreferences.getString(KEY_STAGES_JSON_BACKUP, null))?.let { return it }
        decodeV4(sharedPreferences.getString(KEY_STAGES_JSON_V4, null))?.let { return it }
        decodeV4(sharedPreferences.getString(KEY_STAGES_JSON_V4_BACKUP, null))?.let { return it }
        decodeV3(sharedPreferences.getString(KEY_STAGES_JSON_V3, null))?.let { return it }
        decodeV3(sharedPreferences.getString(KEY_STAGES_JSON_V3_BACKUP, null))?.let { return it }
        decodeV2(sharedPreferences.getString(KEY_STAGES_JSON_V2, null))?.let { return it }
        decodeV2(sharedPreferences.getString(KEY_STAGES_JSON_V2_BACKUP, null))?.let { return it }
        decodeLegacy(sharedPreferences.getString(KEY_STAGES_LEGACY, null))?.let { return it }
        return null
    }

    private fun persist() {
        val sharedPreferences = prefs ?: return
        val payload = encodeJson(stages)
        val previous = sharedPreferences.getString(KEY_STAGES_JSON, null)
        sharedPreferences.edit().apply {
            if (!previous.isNullOrBlank() && previous != payload && decodeV5(previous) != null) {
                putString(KEY_STAGES_JSON_BACKUP, previous)
            }
            putString(KEY_STAGES_JSON, payload)
        }.apply()
    }

    private fun encodeJson(items: List<ProgressStage>): String {
        val array = JSONArray()
        items.sortedBy { it.number }.forEach { stage ->
            val checklist = JSONArray()
            stage.checklist.forEach { item ->
                checklist.put(JSONObject()
                    .put("id", item.id)
                    .put("text", item.text)
                    .put("required", item.required)
                    .put("checked", item.checked))
            }
            array.put(JSONObject()
                .put("id", stage.id)
                .put("number", stage.number)
                .put("title", stage.title)
                .put("status", stage.status.name)
                .put("description", stage.description)
                .put("missionStatus", stage.missionStatus.name)
                .put("durationMinutes", stage.durationMinutes)
                .put("startedAtMillis", stage.startedAtMillis ?: JSONObject.NULL)
                .put("endAtMillis", stage.endAtMillis ?: JSONObject.NULL)
                .put("completedAtMillis", stage.completedAtMillis ?: JSONObject.NULL)
                .put("attemptCount", stage.attemptCount)
                .put("note", stage.note)
                .put("noteDraft", stage.noteDraft ?: JSONObject.NULL)
                .put("checklist", checklist)
                .put("importance", stage.importance.name)
                .put("activeRewardXpSnapshot", stage.activeRewardXpSnapshot ?: JSONObject.NULL)
                .put("activeRewardCoinSnapshot", stage.activeRewardCoinSnapshot ?: JSONObject.NULL)
                .put("activeDurationMinutesSnapshot", stage.activeDurationMinutesSnapshot ?: JSONObject.NULL)
                .put("lastRewardTransactionId", stage.lastRewardTransactionId ?: JSONObject.NULL))
        }
        return JSONObject().put("version", SCHEMA_VERSION).put("stages", array).toString()
    }

    private fun decodeV5(raw: String?): List<ProgressStage>? = decodeJson(raw, expectedVersion = 5, includeV5 = true)
    private fun decodeV4(raw: String?): List<ProgressStage>? = decodeJson(raw, expectedVersion = 4, includeV5 = false)
    private fun decodeV3(raw: String?): List<ProgressStage>? = decodeJson(raw, expectedVersion = 3, includeV5 = false)

    private fun decodeJson(raw: String?, expectedVersion: Int, includeV5: Boolean): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != expectedVersion) return@runCatching null
            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val checklistArray = item.optJSONArray("checklist") ?: JSONArray()
                    val checklist = buildList {
                        for (checkIndex in 0 until checklistArray.length()) {
                            val check = checklistArray.getJSONObject(checkIndex)
                            add(MissionChecklistItem(
                                id = check.getLong("id"),
                                text = check.getString("text"),
                                required = check.optBoolean("required", false),
                                checked = check.optBoolean("checked", false)
                            ))
                        }
                    }
                    add(ensureMissionDefaults(ProgressStage(
                        id = item.getLong("id"),
                        number = item.getInt("number"),
                        title = item.getString("title"),
                        status = StageStatus.valueOf(item.getString("status")),
                        description = item.optString("description", ""),
                        missionStatus = MissionStatus.valueOf(item.optString("missionStatus", MissionStatus.NOT_STARTED.name)),
                        durationMinutes = item.optInt("durationMinutes", ProgressStage.DEFAULT_MISSION_DURATION_MINUTES),
                        startedAtMillis = item.optNullableLong("startedAtMillis"),
                        endAtMillis = item.optNullableLong("endAtMillis"),
                        completedAtMillis = item.optNullableLong("completedAtMillis"),
                        attemptCount = item.optInt("attemptCount", 0),
                        note = item.optString("note", ""),
                        noteDraft = item.optNullableString("noteDraft"),
                        checklist = checklist,
                        importance = if (includeV5) runCatching { ImportanceLevel.valueOf(item.optString("importance", ImportanceLevel.NORMAL.name)) }.getOrDefault(ImportanceLevel.NORMAL) else ImportanceLevel.NORMAL,
                        activeRewardXpSnapshot = if (includeV5) item.optNullableInt("activeRewardXpSnapshot") else null,
                        activeRewardCoinSnapshot = if (includeV5) item.optNullableInt("activeRewardCoinSnapshot") else null,
                        activeDurationMinutesSnapshot = if (includeV5) item.optNullableInt("activeDurationMinutesSnapshot") else null,
                        lastRewardTransactionId = if (includeV5) item.optNullableLong("lastRewardTransactionId") else null
                    )))
                }
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun decodeV2(raw: String?): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != 2) return@runCatching null
            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(ensureMissionDefaults(ProgressStage(
                        id = item.getLong("id"),
                        number = item.getInt("number"),
                        title = item.getString("title"),
                        status = StageStatus.valueOf(item.getString("status"))
                    )))
                }
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun decodeLegacy(raw: String?): List<ProgressStage>? {
        if (raw == null) return null
        if (raw.isBlank()) return emptyList()
        return runCatching {
            val parsed = raw.split('|').map { token ->
                val parts = token.split(',', limit = 4)
                require(parts.size == 4)
                ensureMissionDefaults(ProgressStage(
                    id = parts[0].toLong(),
                    number = parts[1].toInt(),
                    status = StageStatus.valueOf(parts[2]),
                    title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                ))
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun validateParsed(items: List<ProgressStage>): List<ProgressStage>? {
        if (items.any { it.id <= 0L || it.number <= 0 || it.title.isBlank() }) return null
        if (items.map { it.id }.toSet().size != items.size) return null
        if (items.map { it.number }.toSet().size != items.size) return null
        if (items.any { it.durationMinutes !in 1..(24 * 60) }) return null
        if (items.any { stage -> stage.checklist.map { it.id }.toSet().size != stage.checklist.size }) return null
        return items
    }

    private fun ensureMissionDefaults(stage: ProgressStage): ProgressStage {
        val missionStatus = when (stage.status) {
            StageStatus.COMPLETED -> MissionStatus.COMPLETED
            StageStatus.FAILED -> MissionStatus.FAILED
            else -> stage.missionStatus
        }
        val checklist = if (stage.checklist.isEmpty()) defaultChecklist(stage.id) else stage.checklist
        return stage.copy(
            missionStatus = missionStatus,
            durationMinutes = stage.durationMinutes.coerceIn(1, 24 * 60),
            checklist = checklist
        )
    }

    private fun defaultChecklist(stageId: Long): List<MissionChecklistItem> = listOf(
        MissionChecklistItem(nextChecklistId(stageId, 0), "مرور هدف این مرحله", required = true),
        MissionChecklistItem(nextChecklistId(stageId, 1), "انجام اقدام اصلی مرحله", required = true),
        MissionChecklistItem(nextChecklistId(stageId, 2), "ثبت جمع‌بندی کوتاه", required = false)
    )

    internal fun nextChecklistId(stageId: Long, index: Int): Long =
        (stageId.coerceAtLeast(1L) * 10_000L) + index + 1L


    private fun sanitizeSingleActive(items: List<ProgressStage>): List<ProgressStage> {
        val active = items.filter { it.missionStatus == MissionStatus.ACTIVE || it.missionStatus == MissionStatus.EXPIRED }
        if (active.size <= 1) return items
        val keepId = active.minByOrNull { it.startedAtMillis ?: Long.MAX_VALUE }?.id ?: active.first().id
        return items.map { stage ->
            if (stage.id != keepId && (stage.missionStatus == MissionStatus.ACTIVE || stage.missionStatus == MissionStatus.EXPIRED)) {
                MissionRules.restored(stage).copy(
                    status = if (stage.status == StageStatus.CURRENT) StageStatus.UPCOMING else stage.status
                )
            } else stage
        }
    }

    private fun rescheduleActiveTimer() {
        val active = activeStage() ?: return
        if (active.missionStatus == MissionStatus.ACTIVE) {
            active.endAtMillis?.let { end -> appContext?.let { GameNotificationScheduler.scheduleStageExpiry(it, active.id, end) } }
        }
    }

    private fun JSONObject.optNullableLong(key: String): Long? = if (!has(key) || isNull(key)) null else optLong(key)
    private fun JSONObject.optNullableInt(key: String): Int? = if (!has(key) || isNull(key)) null else optInt(key)
    private fun JSONObject.optNullableString(key: String): String? = if (!has(key) || isNull(key)) null else optString(key)
}
