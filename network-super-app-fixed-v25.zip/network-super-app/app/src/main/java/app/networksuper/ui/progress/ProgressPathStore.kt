package app.networksuper.ui.progress

import android.content.Context
import androidx.compose.runtime.mutableStateListOf

/**
 * Single in-memory source of truth consumed by Compose.
 *
 * UI state, business rules and persistence are intentionally separated: this object coordinates
 * mutations; [ProgressPathRules]/[MissionRules] own pure rules; [ProgressPathPersistence] owns IO.
 */
object ProgressPathStore {
    val stages = mutableStateListOf<ProgressStage>()

    private var persistence: ProgressPathPersistence? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return

        val storage = ProgressPathPersistence(context)
        persistence = storage

        val now = System.currentTimeMillis()
        val restored = (storage.restore() ?: ProgressStageFactory.defaults).map { stage ->
            val normalized = ProgressStageFactory.withMissionDefaults(stage)
            if (MissionRules.shouldExpire(normalized, now)) {
                normalized.copy(missionStatus = MissionStatus.EXPIRED)
            } else {
                normalized
            }
        }

        replaceWithRenumbered(restored, persistAfter = false)
        persist()
        storage.removeMigratedPrimaryKeys()
        initialized = true
    }

    fun stage(id: Long): ProgressStage? = stages.firstOrNull { it.id == id }

    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    fun currentOrdinal(): Int = ProgressPathRules.currentOrdinal(stages)

    fun isComplete(): Boolean = stages.isNotEmpty() &&
        stages.none { it.status == StageStatus.CURRENT || it.status == StageStatus.UPCOMING }

    fun positionCount(isNew: Boolean): Int =
        (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    fun addStage(title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(
            insertionIndex,
            ProgressStageFactory.withMissionDefaults(
                ProgressStage(
                    id = nextAvailableId(ordered),
                    number = position,
                    title = cleanTitle,
                    status = StageStatus.UPCOMING
                )
            )
        )
        replaceWithRenumbered(ordered)
    }

    fun updateStageSetup(
        id: Long,
        title: String,
        position: Int,
        durationMinutes: Int,
        checklist: List<MissionChecklistItem>
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val cleanDuration = durationMinutes.coerceIn(1, 24 * 60)
        val cleanChecklist = checklist
            .mapIndexedNotNull { index, item ->
                val text = item.text.trim()
                if (text.isBlank()) {
                    null
                } else {
                    item.copy(
                        id = item.id.takeIf { it > 0L }
                            ?: ProgressStageFactory.checklistId(id, index),
                        text = text
                    )
                }
            }
            .distinctBy { it.id }

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return

        val old = ordered.removeAt(oldIndex)
        val recalculatedEndAt = if (
            old.missionStatus == MissionStatus.ACTIVE &&
            old.startedAtMillis != null
        ) {
            old.startedAtMillis + cleanDuration * 60_000L
        } else {
            old.endAtMillis
        }

        val updated = old.copy(
            title = cleanTitle,
            durationMinutes = cleanDuration,
            checklist = cleanChecklist,
            endAtMillis = recalculatedEndAt
        )
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(insertionIndex, updated)
        replaceWithRenumbered(ordered)
    }

    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val target = ordered.removeAt(targetIndex)
        if (target.status == StageStatus.CURRENT) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex)
        }
        replaceWithRenumbered(ordered)
    }

    fun startMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { stage ->
            val duration = stage.durationMinutes.coerceAtLeast(1)
            stage.copy(
                missionStatus = MissionStatus.ACTIVE,
                startedAtMillis = nowMillis,
                endAtMillis = nowMillis + duration * 60_000L,
                completedAtMillis = null,
                attemptCount = stage.attemptCount + 1
            )
        }
    }

    fun markExpiredIfNeeded(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        val current = stage(id) ?: return
        if (!MissionRules.shouldExpire(current, nowMillis)) return
        updateStage(id) { it.copy(missionStatus = MissionStatus.EXPIRED) }
    }

    fun toggleChecklistItem(stageId: Long, itemId: Long, checked: Boolean) {
        updateStage(stageId) { stage ->
            stage.copy(
                checklist = stage.checklist.map { item ->
                    if (item.id == itemId) item.copy(checked = checked) else item
                }
            )
        }
    }

    /** Persist the working note draft so background/process death cannot lose typing. */
    fun updateNoteDraft(id: Long, draft: String) {
        updateStage(id) { stage ->
            stage.copy(noteDraft = draft.takeIf { it != stage.note })
        }
    }

    fun commitNote(id: Long, text: String) {
        updateStage(id) { it.copy(note = text, noteDraft = null) }
    }

    fun discardNoteDraft(id: Long) {
        updateStage(id) { it.copy(noteDraft = null) }
    }

    fun completeMission(id: Long, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val current = stage(id) ?: return false
        if (!MissionRules.requiredComplete(current.checklist)) return false

        updateStage(id, persistAfter = false) {
            it.copy(
                missionStatus = MissionStatus.COMPLETED,
                completedAtMillis = nowMillis
            )
        }
        markResult(id, StageStatus.COMPLETED)
        return true
    }

    fun failMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        updateStage(id, persistAfter = false) {
            it.copy(
                missionStatus = MissionStatus.FAILED,
                completedAtMillis = nowMillis
            )
        }
        markResult(id, StageStatus.FAILED)
    }

    fun retryMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { stage -> MissionRules.retried(stage, nowMillis) }
    }

    fun restoreMission(id: Long) {
        replaceWithRenumbered(ProgressPathRules.rollbackTo(stages, id))
    }

    private fun setCurrent(id: Long) {
        if (stages.none { it.id == id }) return

        val ordered = stages.sortedBy { it.number }.map { stage ->
            when {
                stage.id == id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        replaceWithRenumbered(ordered)
    }

    private fun markResult(id: Long, result: StageStatus) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)

        if (wasCurrent) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex + 1)
        }
        replaceWithRenumbered(ordered)
    }

    private fun promoteNextUpcoming(
        ordered: MutableList<ProgressStage>,
        preferredStartIndex: Int
    ) {
        if (ordered.any { it.status == StageStatus.CURRENT }) return

        val safeStart = preferredStartIndex.coerceIn(0, ordered.size)
        val nextIndex = (safeStart until ordered.size)
            .firstOrNull { ordered[it].status == StageStatus.UPCOMING }
            ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING }.takeIf { it >= 0 }

        if (nextIndex != null) {
            ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
        }
    }

    private fun updateStage(
        id: Long,
        persistAfter: Boolean = true,
        transform: (ProgressStage) -> ProgressStage
    ) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val index = ordered.indexOfFirst { it.id == id }
        if (index < 0) return

        ordered[index] = ProgressStageFactory.withMissionDefaults(transform(ordered[index]))
        replaceWithRenumbered(ordered, persistAfter)
    }

    private fun replaceWithRenumbered(
        ascendingItems: List<ProgressStage>,
        persistAfter: Boolean = true
    ) {
        val normalized = ProgressPathRules.normalize(ascendingItems)
            .map(ProgressStageFactory::withMissionDefaults)

        stages.clear()
        stages.addAll(normalized.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun nextAvailableId(items: List<ProgressStage>): Long {
        val usedIds = items.asSequence().map { it.id }.toHashSet()
        var candidate = (usedIds.maxOrNull() ?: 0L) + 1L
        while (candidate <= 0L || candidate in usedIds) candidate++
        return candidate
    }

    private fun persist() {
        persistence?.persist(stages)
    }
}
