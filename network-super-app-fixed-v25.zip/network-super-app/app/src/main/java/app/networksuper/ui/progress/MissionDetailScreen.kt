package app.networksuper.ui.progress

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.R
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.FailRed
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.PrimaryBlueDark
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen
import app.networksuper.ui.theme.SurfaceOutline
import app.networksuper.ui.theme.WarningOrange
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun MissionDetailScreen(
    stageId: Long,
    onBack: () -> Unit,
    onOpenNextStage: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val stage = ProgressPathStore.stages.firstOrNull { it.id == stageId }
    if (stage == null) {
        LaunchedEffect(stageId) { onBack() }
        return
    }

    var showEditor by remember(stageId) { mutableStateOf(false) }
    var showNote by remember(stageId) { mutableStateOf(false) }
    var confirmFailed by remember(stageId) { mutableStateOf(false) }
    var confirmRestore by remember(stageId) { mutableStateOf(false) }
    var nowMillis by remember(stageId) { mutableLongStateOf(System.currentTimeMillis()) }

    val totalStages = ProgressPathStore.stages.size.coerceAtLeast(1)
    val pathOrdinal = ProgressPathStore.currentOrdinal().coerceIn(0, totalStages)
    val pathProgress = pathOrdinal.toFloat() / totalStages.toFloat()
    val remainingMillis = MissionRules.remainingMillis(stage, nowMillis)

    LaunchedEffect(stageId, stage.missionStatus, stage.endAtMillis) {
        if (stage.missionStatus == MissionStatus.ACTIVE) {
            while (true) {
                nowMillis = System.currentTimeMillis()
                ProgressPathStore.markExpiredIfNeeded(stageId, nowMillis)
                if (ProgressPathStore.stage(stageId)?.missionStatus != MissionStatus.ACTIVE) break
                delay(1_000L)
            }
        } else {
            nowMillis = System.currentTimeMillis()
        }
    }

    BackHandler(onBack = onBack)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        DetailToolbar(
            stage = stage,
            totalStages = totalStages,
            pathProgress = pathProgress,
            onBack = onBack,
            onEdit = { showEditor = true },
            onNote = { showNote = true }
        )

        Spacer(Modifier.height(8.dp))
        StageIdentityCard(stage = stage, totalStages = totalStages)
        Spacer(Modifier.height(8.dp))

        when (stage.missionStatus) {
            MissionStatus.COMPLETED -> SuccessContent(
                stage = stage,
                pathProgress = pathProgress,
                onNextStage = {
                    val next = ProgressPathStore.currentStage()?.takeIf { it.id != stage.id }
                    if (next != null) onOpenNextStage(next.id) else onBack()
                },
                onBackToPath = onBack,
                onRestore = { confirmRestore = true },
                modifier = Modifier.weight(1f)
            )

            MissionStatus.FAILED -> FailedContent(
                stage = stage,
                onRetry = { ProgressPathStore.retryMission(stage.id) },
                onRestore = { confirmRestore = true },
                modifier = Modifier.weight(1f)
            )

            else -> {
                TimerCard(stage = stage, remainingMillis = remainingMillis)
                Spacer(Modifier.height(8.dp))

                ChecklistCard(
                    stage = stage,
                    enabled = stage.missionStatus == MissionStatus.ACTIVE || stage.missionStatus == MissionStatus.EXPIRED,
                    onCheckedChange = { itemId, checked ->
                        ProgressPathStore.toggleChecklistItem(stage.id, itemId, checked)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                Spacer(Modifier.height(8.dp))

                if (stage.missionStatus == MissionStatus.NOT_STARTED) {
                    val canStart = stage.status == StageStatus.CURRENT
                    if (!canStart) {
                        Text(
                            text = stringResource(R.string.mission_locked_message),
                            modifier = Modifier.fillMaxWidth(),
                            color = Muted,
                            style = MaterialTheme.typography.labelLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(5.dp))
                    }
                    StartButton(
                        onClick = { ProgressPathStore.startMission(stage.id) },
                        enabled = canStart,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    ResultActions(
                        stage = stage,
                        onDone = { ProgressPathStore.completeMission(stage.id) },
                        onFailed = { confirmFailed = true },
                        onRestore = { confirmRestore = true }
                    )
                }
            }
        }
    }

    if (showEditor) {
        StageSetupDialog(
            stage = stage,
            positionCount = ProgressPathStore.positionCount(isNew = false),
            onDismiss = { showEditor = false },
            onSave = { title, position, duration, checklist ->
                ProgressPathStore.updateStageSetup(stage.id, title, position, duration, checklist)
                showEditor = false
            },
            onDelete = {
                ProgressPathStore.deleteStage(stage.id)
                showEditor = false
                onBack()
            }
        )
    }

    if (showNote) {
        NoteDialog(
            stageId = stage.id,
            committedNote = stage.note,
            draftNote = stage.noteDraft,
            stageTitle = stage.title,
            onDismiss = { showNote = false }
        )
    }

    if (confirmFailed) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Close,
            iconColor = FailRed,
            title = stringResource(R.string.mission_fail_confirm_title),
            message = stringResource(R.string.mission_fail_confirm_message),
            confirmText = stringResource(R.string.mission_fail_confirm_action),
            onDismiss = { confirmFailed = false },
            onConfirm = {
                ProgressPathStore.failMission(stage.id)
                confirmFailed = false
            }
        )
    }

    if (confirmRestore) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Restore,
            iconColor = PrimaryBlue,
            title = stringResource(R.string.mission_restore_confirm_title),
            message = stringResource(R.string.mission_restore_confirm_message),
            confirmText = stringResource(R.string.mission_restore_confirm_action),
            onDismiss = { confirmRestore = false },
            onConfirm = {
                ProgressPathStore.restoreMission(stage.id)
                confirmRestore = false
            }
        )
    }
}
