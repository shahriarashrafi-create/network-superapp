package app.networksuper.ui.progress

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.ui.components.GameHeader
import app.networksuper.ui.components.GeometricBlueBackdrop
import app.networksuper.ui.components.StartActionButton
import app.networksuper.ui.home.HomeDefaults
import app.networksuper.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun MissionDetailScreen(
    stageId: Long,
    onBack: () -> Unit,
    onOpenNextStage: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val stage = ProgressPathStore.stages.firstOrNull { it.id == stageId }
    if (stage == null) {
        LaunchedEffect(stageId) { onBack() }
        return
    }

    var showEditor by remember(stageId) { mutableStateOf(false) }
    var showNote by remember(stageId) { mutableStateOf(false) }
    var confirmFailed by remember(stageId) { mutableStateOf(false) }
    var confirmRestore by remember(stageId) { mutableStateOf(false) }
    var blockedByStage by remember(stageId) { mutableStateOf<ProgressStage?>(null) }
    var rewardFeedback by remember(stageId) { mutableStateOf<RewardGrant?>(null) }
    var nowMillis by remember(stageId) { mutableLongStateOf(System.currentTimeMillis()) }

    val totalStages = ProgressPathStore.stages.size.coerceAtLeast(1)
    val pathProgress = ProgressPathStore.completionProgress()
    val remainingMillis = MissionRules.remainingMillis(stage, nowMillis)

    LaunchedEffect(stageId, stage.missionStatus, stage.endAtMillis) {
        if (stage.missionStatus == MissionStatus.ACTIVE) {
            while (true) {
                nowMillis = System.currentTimeMillis()
                ProgressPathStore.markExpiredIfNeeded(stageId, nowMillis)
                if (ProgressPathStore.stage(stageId)?.missionStatus != MissionStatus.ACTIVE) break
                delay(1_000L)
            }
        } else {
            nowMillis = System.currentTimeMillis()
        }
    }

    BackHandler(onBack = onBack)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GameHeader(
                userName = HomeDefaults.state.userName,
                modifier = Modifier.fillMaxWidth().height(126.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Rounded.ArrowForward, contentDescription = "بازگشت", tint = Navy)
                }
                Spacer(Modifier.weight(1f))
            }

            StageIdentityCard(
                stage = stage,
                totalStages = totalStages,
                onEdit = { showEditor = true },
                onNote = { showNote = true }
            )

            when (stage.missionStatus) {
                MissionStatus.COMPLETED -> SuccessContent(
                    stage = stage,
                    pathProgress = pathProgress,
                    onNextStage = {
                        val next = ProgressPathStore.suggestedStage()?.takeIf { it.id != stage.id }
                        if (next != null) onOpenNextStage(next.id) else onBack()
                    },
                    onBackToPath = onBack,
                    onRestore = { confirmRestore = true },
                    modifier = Modifier.weight(1f)
                )

                MissionStatus.FAILED -> FailedContent(
                    stage = stage,
                    onRetry = {
                        when (ProgressPathStore.retryMission(stage.id)) {
                            StartMissionResult.BLOCKED_BY_OTHER_ACTIVE -> blockedByStage = ProgressPathStore.activeStage()
                            else -> Unit
                        }
                    },
                    onRestore = { confirmRestore = true },
                    modifier = Modifier.weight(1f)
                )

                else -> {
                    TimerCard(stage = stage, remainingMillis = remainingMillis)

                    ChecklistCard(
                        stage = stage,
                        enabled = stage.missionStatus == MissionStatus.ACTIVE || stage.missionStatus == MissionStatus.EXPIRED,
                        onCheckedChange = { itemId, checked ->
                            ProgressPathStore.toggleChecklistItem(stage.id, itemId, checked)
                        },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    )

                    if (stage.missionStatus == MissionStatus.NOT_STARTED) {
                        StartActionButton(
                            onClick = {
                                when (ProgressPathStore.startMission(stage.id)) {
                                    StartMissionResult.BLOCKED_BY_OTHER_ACTIVE -> blockedByStage = ProgressPathStore.activeStage()
                                    else -> Unit
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp)
                        )
                    } else {
                        ResultActions(
                            stage = stage,
                            onDone = {
                                val result = ProgressPathStore.completeMission(stage.id)
                                rewardFeedback = result?.reward
                            },
                            onFailed = { confirmFailed = true },
                            onRestore = { confirmRestore = true }
                        )
                    }
                }
            }
        }

        rewardFeedback?.let { reward ->
            RewardBurstOverlay(
                reward = reward,
                modifier = Modifier.align(Alignment.Center),
                onFinished = { rewardFeedback = null }
            )
        }
    }

    if (showEditor) {
        UnifiedStageEditorDialog(
            stage = stage,
            positionCount = ProgressPathStore.positionCount(isNew = false),
            onDismiss = { showEditor = false },
            onSave = { title, position, duration, checklist, importance ->
                ProgressPathStore.updateStageSetup(stage.id, title, position, duration, checklist, importance)
                showEditor = false
            },
            onDelete = {
                ProgressPathStore.deleteStage(stage.id)
                showEditor = false
                onBack()
            }
        )
    }

    if (showNote) {
        NoteDialog(
            stageId = stage.id,
            committedNote = stage.note,
            draftNote = stage.noteDraft,
            stageTitle = stage.title,
            onDismiss = { showNote = false }
        )
    }

    if (confirmFailed) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Close,
            iconColor = FailRed,
            title = "مطمئنی؟",
            message = "این کار به‌عنوان انجام‌نشده ثبت شود؟",
            confirmText = "بله، انجام نشد",
            onDismiss = { confirmFailed = false },
            onConfirm = {
                ProgressPathStore.failMission(stage.id)
                confirmFailed = false
            }
        )
    }

    if (confirmRestore) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Restore,
            iconColor = PrimaryBlue,
            title = "بازگشت به حالت قبل؟",
            message = "نتیجه، تایمر، تیک‌ها، XP، سکه و کمبوی مرتبط با این کارت اصلاح می‌شوند. یادداشت حفظ می‌شود.",
            confirmText = "بازگردانی",
            onDismiss = { confirmRestore = false },
            onConfirm = {
                ProgressPathStore.restoreMission(stage.id)
                confirmRestore = false
            }
        )
    }

    blockedByStage?.let { active ->
        AlertDialog(
            onDismissRequest = { blockedByStage = null },
            icon = { Icon(Icons.Rounded.Timer, contentDescription = null, tint = WarningOrange) },
            title = { Text("یک کار در حال انجام داری", fontWeight = FontWeight.Black, color = Navy) },
            text = { Text("«${active.title}» هنوز در حال اجراست. ابتدا آن را انجام‌شده، انجام‌نشده یا بازنشانی کن و بعد این کار را شروع کن.", color = Muted) },
            confirmButton = { TextButton(onClick = { blockedByStage = null }) { Text("متوجه شدم") } },
            containerColor = Color.White,
            shape = RoundedCornerShape(22.dp)
        )
    }
}

@Composable
private fun StageIdentityCard(
    stage: ProgressStage,
    totalStages: Int,
    onEdit: () -> Unit,
    onNote: () -> Unit
) {
    val statusText = when (stage.missionStatus) {
        MissionStatus.NOT_STARTED -> "آماده شروع"
        MissionStatus.ACTIVE -> "در حال انجام"
        MissionStatus.EXPIRED -> "زمان تمام شده"
        MissionStatus.COMPLETED -> "انجام شد"
        MissionStatus.FAILED -> "انجام نشد"
    }
    val statusColor = when (stage.missionStatus) {
        MissionStatus.NOT_STARTED -> PrimaryBlue
        MissionStatus.ACTIVE -> PrimaryBlue
        MissionStatus.EXPIRED -> WarningOrange
        MissionStatus.COMPLETED -> SuccessGreen
        MissionStatus.FAILED -> FailRed
    }
    val multiplier = if (stage.missionStatus == MissionStatus.COMPLETED) 1.0 else GameStore.projectedMultiplier()
    val baseXp = stage.activeRewardXpSnapshot ?: stage.importance.baseXp
    val baseCoin = stage.activeRewardCoinSnapshot ?: stage.importance.baseCoin
    val xp = GameRules.applyMultiplier(baseXp, multiplier)
    val coin = GameRules.applyMultiplier(baseCoin, multiplier)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(ActionBlueDeep, ActionBlueMid, ActionBlueLight)))
    ) {
        GeometricBlueBackdrop(Modifier.matchParentSize())

        Surface(
            modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0B5FBE).copy(alpha = .78f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = .75f))
        ) {
            Text(
                text = "قدم ${stage.number} از $totalStages",
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.ExtraBold
            )
        }

        Row(
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IdentityIcon(Icons.Rounded.Notes, "یادداشت", onNote, stage.note.isNotBlank() || !stage.noteDraft.isNullOrBlank())
            IdentityIcon(Icons.Rounded.Edit, "ویرایش", onEdit, false)
        }

        Surface(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(.72f),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = .98f),
            shadowElevation = 4.dp
        ) {
            Text(
                text = stage.title,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                textAlign = TextAlign.Center,
                color = Navy,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
            shape = RoundedCornerShape(11.dp),
            color = statusColor.copy(alpha = .92f)
        ) {
            Text(statusText, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp),
            shape = RoundedCornerShape(11.dp),
            color = Color.White.copy(alpha = .92f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(Icons.Rounded.Star, contentDescription = null, tint = RewardGold, modifier = Modifier.size(15.dp))
                Text("+$xp XP", color = Navy, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
                Text("• +$coin", color = Navy, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
                if (multiplier > 1.0) Text("×1.5", color = WarningOrange, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun IdentityIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit, showDot: Boolean) {
    Box {
        Surface(
            onClick = onClick,
            modifier = Modifier.size(38.dp),
            shape = CircleShape,
            color = Color.White.copy(alpha = .92f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = description, tint = Navy, modifier = Modifier.size(19.dp))
            }
        }
        if (showDot) Box(Modifier.align(Alignment.TopEnd).size(7.dp).background(SuccessGreen, CircleShape).border(1.dp, Color.White, CircleShape))
    }
}

@Composable
private fun TimerCard(stage: ProgressStage, remainingMillis: Long) {
    val durationForRun = stage.activeDurationMinutesSnapshot ?: stage.durationMinutes
    val totalMillis = durationForRun.coerceAtLeast(1) * 60_000L
    val rawFraction = when (stage.missionStatus) {
        MissionStatus.NOT_STARTED -> 1f
        else -> (remainingMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f)
    }
    val fraction by animateFloatAsState(rawFraction, tween(350), label = "timerProgress")
    val timerColorTarget = when {
        stage.missionStatus == MissionStatus.EXPIRED -> FailRed
        stage.missionStatus != MissionStatus.ACTIVE -> PrimaryBlue
        fraction <= .05f -> FailRed
        fraction <= .20f -> WarningOrange
        else -> PrimaryBlue
    }
    val timerColor by animateColorAsState(timerColorTarget, label = "timerColor")
    val pulseTransition = rememberInfiniteTransition(label = "timerPulse")
    val pulse by pulseTransition.animateFloat(1f, 1.055f, infiniteRepeatable(tween(850), RepeatMode.Reverse), label = "timerPulseScale")

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(21.dp),
        color = Color.White,
        border = BorderStroke(1.dp, timerColor.copy(alpha = .18f)),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    imageVector = if (stage.missionStatus == MissionStatus.EXPIRED) Icons.Rounded.WarningAmber else Icons.Rounded.Timer,
                    contentDescription = null,
                    tint = timerColor,
                    modifier = Modifier.size(24.dp).scale(if (stage.missionStatus == MissionStatus.ACTIVE) pulse else 1f)
                )
                Text(
                    text = if (stage.missionStatus == MissionStatus.EXPIRED) "00:00" else formatDuration(if (stage.missionStatus == MissionStatus.NOT_STARTED) totalMillis else remainingMillis),
                    color = timerColor,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(Modifier.height(7.dp))
            Box(
                Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(timerColor.copy(alpha = .10f))
            ) {
                Box(
                    Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(timerColor.copy(alpha = .60f), timerColor, PrimaryBlueDark)))
                )
            }
            if (stage.attemptCount > 1 && stage.missionStatus != MissionStatus.NOT_STARTED) {
                Spacer(Modifier.height(4.dp))
                Text("تلاش ${stage.attemptCount}", color = Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
            if (stage.missionStatus == MissionStatus.EXPIRED) {
                Spacer(Modifier.height(5.dp))
                Text("زمان تمام شده؛ نتیجه را خودت تعیین کن.", color = FailRed, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ChecklistCard(
    stage: ProgressStage,
    enabled: Boolean,
    onCheckedChange: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val checked = MissionRules.checkedCount(stage.checklist)
    val total = stage.checklist.size
    val progress = MissionRules.checklistProgress(stage.checklist)

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(21.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline)
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 9.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("To-Do List", color = Navy, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    Text("$checked از $total انجام شده", color = Muted, style = MaterialTheme.typography.labelMedium)
                }
                Text("${(progress * 100).roundToInt()}٪", color = PrimaryBlue, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = progress,
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = SuccessGreen,
                trackColor = SoftBlue
            )
            Spacer(Modifier.height(6.dp))

            if (stage.checklist.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("هنوز موردی تعریف نشده است.", color = Muted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(stage.checklist, key = { it.id }) { item ->
                        Surface(
                            shape = RoundedCornerShape(13.dp),
                            color = if (item.checked) SuccessGreen.copy(alpha = .06f) else Color(0xFFFCFDFF),
                            border = BorderStroke(1.dp, if (item.checked) SuccessGreen.copy(alpha = .18f) else SurfaceOutline)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = item.checked,
                                    onCheckedChange = if (enabled) ({ onCheckedChange(item.id, it) }) else null,
                                    colors = CheckboxDefaults.colors(checkedColor = SuccessGreen)
                                )
                                Text(
                                    text = item.text,
                                    modifier = Modifier.weight(1f),
                                    color = if (enabled || item.checked) Navy else Muted,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (item.required) FailRed.copy(alpha = .08f) else PrimaryBlue.copy(alpha = .07f)
                                ) {
                                    Text(
                                        text = if (item.required) "ضروری" else "اختیاری",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = if (item.required) FailRed else PrimaryBlue,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultActions(
    stage: ProgressStage,
    onDone: () -> Unit,
    onFailed: () -> Unit,
    onRestore: () -> Unit
) {
    val remainingRequired = MissionRules.requiredRemaining(stage.checklist)
    val canDone = remainingRequired == 0
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        if (!canDone) {
            Text(
                text = "$remainingRequired مورد ضروری باقی مانده",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                color = WarningOrange,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onRestore,
                modifier = Modifier.size(48.dp).background(SoftBlue, RoundedCornerShape(15.dp))
            ) {
                Icon(Icons.Rounded.Restore, contentDescription = "بازنشانی", tint = PrimaryBlue)
            }
            OutlinedButton(
                onClick = onFailed,
                modifier = Modifier.weight(.72f).height(50.dp),
                shape = RoundedCornerShape(15.dp),
                border = BorderStroke(1.dp, FailRed.copy(alpha = .35f))
            ) {
                Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("انجام نشد", color = FailRed, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onDone,
                enabled = canDone,
                modifier = Modifier.weight(1.35f).height(56.dp),
                shape = RoundedCornerShape(17.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
            ) {
                Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(27.dp))
                Spacer(Modifier.width(6.dp))
                Text("انجام شد", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun FailedContent(stage: ProgressStage, onRetry: () -> Unit, onRestore: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, border = BorderStroke(1.dp, FailRed.copy(alpha = .15f))) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(52.dp))
                Text("انجام نشد", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                if (stage.attemptCount > 1) Text("تلاش ${stage.attemptCount}", color = Muted)
                Text("می‌توانی دوباره تلاش کنی یا نتیجه را به حالت قبل برگردانی.", color = Muted, textAlign = TextAlign.Center)
                Button(onClick = onRetry, colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue), shape = RoundedCornerShape(15.dp)) {
                    Icon(Icons.Rounded.Replay, contentDescription = null)
                    Spacer(Modifier.width(5.dp))
                    Text("تلاش دوباره", fontWeight = FontWeight.Black)
                }
                TextButton(onClick = onRestore) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("بازگردانی نتیجه")
                }
            }
        }
    }
}

@Composable
private fun SuccessContent(
    stage: ProgressStage,
    pathProgress: Float,
    onNextStage: () -> Unit,
    onBackToPath: () -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Surface(shape = RoundedCornerShape(25.dp), color = Color.White, border = BorderStroke(1.dp, SuccessGreen.copy(alpha = .18f)), shadowElevation = 2.dp) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.Verified, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(56.dp))
                Text("با موفقیت انجام شد!", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(stage.title, color = Muted, textAlign = TextAlign.Center)
                LinearProgressIndicator(
                    progress = pathProgress,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = SuccessGreen,
                    trackColor = SoftBlue
                )
                Text("${(pathProgress * 100).roundToInt()}٪ مسیر تکمیل شده", color = PrimaryBlue, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    OutlinedButton(onClick = onBackToPath, modifier = Modifier.weight(1f), shape = RoundedCornerShape(15.dp)) { Text("بازگشت به مسیر") }
                    Button(onClick = onNextStage, modifier = Modifier.weight(1f), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)) { Text("کار پیشنهادی بعدی", fontWeight = FontWeight.Black) }
                }
                TextButton(onClick = onRestore) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("بازگردانی نتیجه")
                }
            }
        }
    }
}

@Composable
private fun RewardBurstOverlay(reward: RewardGrant, modifier: Modifier = Modifier, onFinished: () -> Unit) {
    var play by remember(reward.transactionId) { mutableStateOf(false) }
    val offset by animateDpAsState(if (play) (-190).dp else 0.dp, tween(900, easing = FastOutSlowInEasing), label = "rewardFly")
    val scale by animateFloatAsState(if (play) .78f else 1.12f, tween(900), label = "rewardScale")
    val alpha by animateFloatAsState(if (play) 0f else 1f, tween(900), label = "rewardAlpha")

    LaunchedEffect(reward.transactionId) {
        play = true
        delay(1050)
        onFinished()
    }

    Surface(
        modifier = modifier.offset(y = offset).scale(scale),
        shape = RoundedCornerShape(22.dp),
        color = Color.White.copy(alpha = alpha),
        shadowElevation = 12.dp,
        border = BorderStroke(1.5.dp, RewardGold.copy(alpha = alpha))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("+${reward.xpGranted} XP   •   +${reward.coinGranted} 🪙", color = Navy.copy(alpha = alpha), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
            if (reward.multiplier > 1.0) Text("COMBO ×${reward.comboCount}  •  پاداش ×1.5", color = WarningOrange.copy(alpha = alpha), fontWeight = FontWeight.Black)
            if (reward.leveledUp) Text("LEVEL ${reward.newLevel}!", color = PrimaryBlue.copy(alpha = alpha), fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun NoteDialog(
    stageId: Long,
    committedNote: String,
    draftNote: String?,
    stageTitle: String,
    onDismiss: () -> Unit
) {
    var text by remember(stageId, committedNote, draftNote) { mutableStateOf(draftNote ?: committedNote) }
    var showExitConfirm by remember { mutableStateOf(false) }
    val dirty = text != committedNote

    fun requestClose() {
        if (dirty) showExitConfirm = true else onDismiss()
    }

    Dialog(onDismissRequest = { requestClose() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(.96f)
                .fillMaxHeight(.90f)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .windowInsetsPadding(WindowInsets.ime),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFFFBFDFF),
            border = BorderStroke(1.dp, SurfaceOutline)
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = { requestClose() }) { Icon(Icons.Rounded.Close, contentDescription = "بستن") }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("یادداشت", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                        Text(stageTitle, color = Muted, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        onClick = {
                            ProgressPathStore.commitNote(stageId, text)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) { Text("ذخیره", fontWeight = FontWeight.Bold) }
                }
                Text(
                    text = if (dirty) "پیش‌نویس خودکار ذخیره می‌شود" else "ذخیره شد ✓",
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                    color = if (dirty) PrimaryBlue else SuccessGreen,
                    style = MaterialTheme.typography.labelSmall
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        ProgressPathStore.updateNoteDraft(stageId, it)
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    placeholder = { Text("اینجا بنویس…") },
                    shape = RoundedCornerShape(18.dp)
                )
            }
        }
    }

    if (showExitConfirm) {
        AlertDialog(
            onDismissRequest = { showExitConfirm = false },
            title = { Text("تغییرات ذخیره شود؟", fontWeight = FontWeight.Black) },
            text = { Text("پیش‌نویس به‌صورت خودکار نگه داشته شده؛ می‌توانی نسخه نهایی را ذخیره کنی یا تغییرات را کنار بگذاری.") },
            confirmButton = {
                Button(onClick = {
                    ProgressPathStore.commitNote(stageId, text)
                    showExitConfirm = false
                    onDismiss()
                }) { Text("ذخیره") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showExitConfirm = false }) { Text("انصراف") }
                    TextButton(onClick = {
                        ProgressPathStore.discardNoteDraft(stageId)
                        showExitConfirm = false
                        onDismiss()
                    }) { Text("ذخیره نکن", color = FailRed) }
                }
            },
            shape = RoundedCornerShape(22.dp),
            containerColor = Color.White
        )
    }
}

@Composable
private fun ConfirmActionDialog(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    title: String,
    message: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(icon, contentDescription = null, tint = iconColor) },
        title = { Text(title, color = Navy, fontWeight = FontWeight.Black) },
        text = { Text(message, color = Muted) },
        confirmButton = {
            Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = iconColor), shape = RoundedCornerShape(14.dp)) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
        containerColor = Color.White,
        shape = RoundedCornerShape(22.dp)
    )
}

private fun formatDuration(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) + 999L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) "%02d:%02d:%02d".format(hours, minutes, seconds)
    else "%02d:%02d".format(minutes, seconds)
}
