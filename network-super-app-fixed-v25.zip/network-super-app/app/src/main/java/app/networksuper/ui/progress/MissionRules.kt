package app.networksuper.ui.progress

object MissionRules {
    fun requiredComplete(items: List<MissionChecklistItem>): Boolean =
        items.filter { it.required }.all { it.checked }

    fun requiredRemaining(items: List<MissionChecklistItem>): Int =
        items.count { it.required && !it.checked }

    fun checkedCount(items: List<MissionChecklistItem>): Int = items.count { it.checked }

    fun checklistProgress(items: List<MissionChecklistItem>): Float =
        if (items.isEmpty()) 0f else checkedCount(items).toFloat() / items.size.toFloat()

    fun remainingMillis(stage: ProgressStage, nowMillis: Long): Long {
        val end = stage.endAtMillis ?: return stage.durationMinutes.coerceAtLeast(1) * 60_000L
        return (end - nowMillis).coerceAtLeast(0L)
    }

    fun shouldExpire(stage: ProgressStage, nowMillis: Long): Boolean =
        stage.missionStatus == MissionStatus.ACTIVE &&
            stage.endAtMillis != null &&
            nowMillis >= stage.endAtMillis

    fun restored(stage: ProgressStage): ProgressStage = stage.copy(
        missionStatus = MissionStatus.NOT_STARTED,
        startedAtMillis = null,
        endAtMillis = null,
        completedAtMillis = null,
        checklist = stage.checklist.map { it.copy(checked = false) },
        activeRewardXpSnapshot = null,
        activeRewardCoinSnapshot = null,
        activeDurationMinutesSnapshot = null,
        lastRewardTransactionId = null
    )

    fun retried(stage: ProgressStage, nowMillis: Long): ProgressStage {
        val duration = stage.durationMinutes.coerceAtLeast(1)
        return stage.copy(
            missionStatus = MissionStatus.ACTIVE,
            startedAtMillis = nowMillis,
            endAtMillis = nowMillis + duration * 60_000L,
            completedAtMillis = null,
            attemptCount = stage.attemptCount + 1,
            checklist = stage.checklist.map { it.copy(checked = false) },
            activeRewardXpSnapshot = stage.importance.baseXp,
            activeRewardCoinSnapshot = stage.importance.baseCoin,
            activeDurationMinutesSnapshot = duration,
            lastRewardTransactionId = null
        )
    }
}
