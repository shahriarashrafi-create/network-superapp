package app.networksuper.ui.progress

/** Pure mission execution rules. No Android or Compose dependency. */
internal object MissionRules {
    fun requiredComplete(items: List<MissionChecklistItem>): Boolean =
        items.filter { it.required }.all { it.checked }

    fun remainingRequired(items: List<MissionChecklistItem>): Int =
        items.count { it.required && !it.checked }

    fun completedCount(items: List<MissionChecklistItem>): Int =
        items.count { it.checked }

    fun completionFraction(items: List<MissionChecklistItem>): Float =
        if (items.isEmpty()) 0f else completedCount(items).toFloat() / items.size.toFloat()

    fun remainingMillis(stage: ProgressStage, nowMillis: Long): Long {
        val end = stage.endAtMillis ?: return stage.durationMinutes * 60_000L
        return (end - nowMillis).coerceAtLeast(0L)
    }

    fun shouldExpire(stage: ProgressStage, nowMillis: Long): Boolean =
        stage.missionStatus == MissionStatus.ACTIVE &&
            stage.endAtMillis != null &&
            nowMillis >= stage.endAtMillis

    /** Reset execution state while intentionally preserving configuration and notes. */
    fun restored(stage: ProgressStage): ProgressStage = stage.copy(
        missionStatus = MissionStatus.NOT_STARTED,
        startedAtMillis = null,
        endAtMillis = null,
        completedAtMillis = null,
        attemptCount = 0,
        checklist = stage.checklist.map { it.copy(checked = false) }
    )

    fun retried(stage: ProgressStage, nowMillis: Long): ProgressStage = stage.copy(
        missionStatus = MissionStatus.ACTIVE,
        startedAtMillis = nowMillis,
        endAtMillis = nowMillis + stage.durationMinutes.coerceAtLeast(1) * 60_000L,
        completedAtMillis = null,
        attemptCount = stage.attemptCount + 1,
        checklist = stage.checklist.map { it.copy(checked = false) }
    )
}
