package app.networksuper.ui.progress

enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

enum class MissionStatus { NOT_STARTED, ACTIVE, EXPIRED, COMPLETED, FAILED }

enum class ImportanceLevel(
    val baseXp: Int,
    val baseCoin: Int
) {
    LOW(10, 2),
    NORMAL(20, 4),
    IMPORTANT(35, 7),
    VERY_IMPORTANT(60, 12)
}

data class MissionChecklistItem(
    val id: Long,
    val text: String,
    val required: Boolean,
    val checked: Boolean = false
)

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus,
    val description: String = "",
    val missionStatus: MissionStatus = when (status) {
        StageStatus.COMPLETED -> MissionStatus.COMPLETED
        StageStatus.FAILED -> MissionStatus.FAILED
        StageStatus.CURRENT, StageStatus.UPCOMING -> MissionStatus.NOT_STARTED
    },
    val durationMinutes: Int = DEFAULT_MISSION_DURATION_MINUTES,
    val startedAtMillis: Long? = null,
    val endAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val attemptCount: Int = 0,
    val note: String = "",
    val noteDraft: String? = null,
    val checklist: List<MissionChecklistItem> = emptyList(),
    val importance: ImportanceLevel = ImportanceLevel.NORMAL,
    /** Reward is frozen at Start so editing importance during an active run cannot change it. */
    val activeRewardXpSnapshot: Int? = null,
    val activeRewardCoinSnapshot: Int? = null,
    /** Duration is frozen at Start; editing the default duration only affects a future run. */
    val activeDurationMinutesSnapshot: Int? = null,
    /** Last reward transaction attached to a successful completion, used for exact undo. */
    val lastRewardTransactionId: Long? = null
) {
    companion object {
        const val DEFAULT_MISSION_DURATION_MINUTES = 15
    }
}
