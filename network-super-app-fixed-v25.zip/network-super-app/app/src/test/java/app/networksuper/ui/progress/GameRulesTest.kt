package app.networksuper.ui.progress

import org.junit.Assert.assertEquals
import org.junit.Test

class GameRulesTest {
    @Test
    fun importanceMapsToExpectedBaseRewards() {
        assertEquals(10 to 2, GameRules.baseReward(ImportanceLevel.LOW))
        assertEquals(20 to 4, GameRules.baseReward(ImportanceLevel.NORMAL))
        assertEquals(35 to 7, GameRules.baseReward(ImportanceLevel.IMPORTANT))
        assertEquals(60 to 12, GameRules.baseReward(ImportanceLevel.VERY_IMPORTANT))
    }

    @Test
    fun comboMultiplierStartsAtThree() {
        assertEquals(1.0, GameRules.multiplierForCombo(1), 0.0)
        assertEquals(1.0, GameRules.multiplierForCombo(2), 0.0)
        assertEquals(1.5, GameRules.multiplierForCombo(3), 0.0)
        assertEquals(1.5, GameRules.multiplierForCombo(8), 0.0)
    }

    @Test
    fun levelRulesAreCentralAndMonotonic() {
        assertEquals(1, GameRules.levelForXp(0))
        assertEquals(2, GameRules.levelForXp(100))
        assertEquals(3, GameRules.levelForXp(250))
        assertEquals(0, GameRules.xpIntoLevel(250))
    }
}
