# V25 — Clean Rebuild

این نسخه با هدف حفظ دقیق رفتار و ظاهر نسخه V24، اما با پایه‌ی کدنویسی تمیزتر بازسازی شده است.

## مواردی که عمداً ثابت مانده‌اند

- `applicationId = app.networksuper`
- تم، رنگ‌ها، ابعاد، spacing و هندسه‌ی UIهای تأییدشده
- منطق Home، Bottom Navigation، Progress Path و جزئیات مرحله
- کلید SharedPreferences و Schema v4
- Migration از v3، v2 و Legacy
- رفتار تایمر، To-Do، یادداشت Draft/Commit، Retry و Restore
- Workflow ساخت Android در GitHub Actions

## تغییرات ساختاری

- مدل و قوانین خالص از persistence و UI جدا شده‌اند.
- JSON codec و SharedPreferences در `ProgressPathPersistence.kt` ایزوله شده‌اند.
- ساخت defaults و normalization مرحله‌ها در `ProgressStageFactory.kt` متمرکز شده است.
- `ProgressPathStore` فقط هماهنگ‌کننده‌ی state و mutationهاست و کد migration/JSON داخل آن نیست.
- APIهای قدیمی و بلااستفاده‌ی Store حذف شده‌اند.
- فایل بسیار بزرگ Mission Detail به سه فایل مسئولیت‌محور تقسیم شده است:
  - `MissionDetailScreen.kt` — orchestration/state
  - `MissionDetailContent.kt` — محتوای اصلی و stateهای نتیجه
  - `MissionDialogs.kt` — یادداشت، ویرایش و تاییدها
- Unit testهای قوانین مسیر و مأموریت حفظ شده‌اند.

## اصل این نسخه

V25 یک redesign نیست. ظاهر و منطق V24 baseline محسوب می‌شوند و بازنویسی باید behavior-preserving و visual-preserving باشد.
