# V21 Changelog

## رفع خطای GitHub Actions / Kotlin compile

در `ProgressPathDialogs.kt`، کامپوننت grid برای انتخاب موقعیت مرحله از APIهای `foundation.lazy.grid` استفاده می‌کرد، اما importهای لازم بعد از refactor فایل‌ها جا افتاده بود. این موضوع باعث خطاهای زنجیره‌ای زیر در `:app:compileDebugKotlin` می‌شد:

- `Unresolved reference 'LazyVerticalGrid'`
- `Unresolved reference 'GridCells'`
- `Unresolved reference 'items'`
- خطاهای type inference و `@Composable invocations` به‌عنوان پیام‌های ثانویه

در V21 این importها اضافه شدند:

```kotlin
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
```

هیچ تغییر ظاهری یا رفتاری در UI انجام نشده است.
