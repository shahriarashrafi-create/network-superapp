# V20 — CI / Gradle Wrapper Hotfix

این نسخه فقط خطای Build در GitHub Actions را برطرف می‌کند و هیچ تغییری در ظاهر UI ندارد.

## اصلاحات

- آدرس اشتباه `gradle-8.9-wrapper.jar` در `gradlew` و `gradlew.bat` اصلاح شد.
- منبع بازیابی Wrapper به فایل رسمی Gradle 8.9 در repository رسمی `gradle/gradle` تغییر کرد.
- SHA-256 رسمی Wrapper همچنان بررسی می‌شود.
- Workflow داخلی پروژه Gradle 8.9 را صریحاً نصب می‌کند و Wrapper استاندارد را قبل از Build تولید می‌کند.
- مرحله `Show build environment` اضافه شد تا خطاهای Java/Gradle قبل از Build اصلی واضح‌تر دیده شوند.

## ظاهر

هیچ فایل UI، اندازه، رنگ، spacing، Canvas یا typography نسبت به V19 تغییر نکرده است.
