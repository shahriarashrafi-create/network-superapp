# V25 Validation

کنترل‌های انجام‌شده روی Clean Rebuild:

- فایل‌های بصری Home، Progress Path، Navigation، Theme و shared components با V24 byte-for-byte مقایسه شدند و بدون تغییر باقی مانده‌اند.
- Mission Detail بدون تغییر در بدنه‌ی composableها به فایل‌های مسئولیت‌محور شکسته شد؛ فقط visibility توابعی که بین فایل‌ها استفاده می‌شوند از `private` به `internal` تغییر کرده است.
- `strings.xml` و همه XMLهای resources parse شدند.
- تمام `R.string.*`های سورس بررسی شدند و reference گمشده وجود ندارد.
- اسکن `TODO` / `FIXME` / `NotImplementedError` / click handler خالی انجام شد و موردی در سورس اصلی وجود ندارد.
- قوانین خالص `MissionRules` و `ProgressPathRules` با Kotlin compiler محلی compile و smoke-test شدند.
- source parse با Kotlin compiler اجرا شد؛ خطای parser/syntax گزارش نشد. خطاهای unresolved Android/Compose در این محیط طبیعی‌اند چون Android SDK/dependency cache محلی نصب نیست.
- Workflow پروژه همچنان `:app:testDebugUnitTest` و `:app:assembleDebug` را در GitHub Actions اجرا می‌کند.

## محدودیت محیط

Full Android Gradle build در محیط تولید ZIP قابل اجرا نبود، چون `gradle-wrapper.jar` و Android/Compose dependency cache محلی موجود نیست و این محیط دسترسی مستقیم برای bootstrap Gradle ندارد. CI موجود پروژه برای build کامل نگه داشته شده است.
