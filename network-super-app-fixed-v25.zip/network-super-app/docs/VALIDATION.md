# V19 Validation

کنترل‌های انجام‌شده روی خروجی این refactor:

- XML و `strings.xml`: well-formed و بدون `R.string` گمشده.
- قوانین خالص Progress: smoke test برای ordinal مسیر کامل، مرحله‌ی جاری و normalize اجرا شده و پاس شده است.
- Kotlin parser: خطای syntax/parser در سورس‌های اصلی پیدا نشد.
- no-op click handlerهای شناخته‌شده حذف شده‌اند.
- ارجاع‌های Navigation قدیمی (`selectedNav` / `GameBottomNav`) حذف شده‌اند.
- `gradlew` از نظر shell syntax بررسی شده و Wrapper 8.9 و checksumهای رسمی را pin می‌کند.
- مقادیر بصری اصلی Home/Progress با baseline قبلی حفظ شده‌اند؛ تغییرات عمده‌ی UI فقط extraction/parameterization بوده است.

## محدودیت محیط بررسی

Full Android Gradle build داخل محیط تولید این ZIP اجرا نشد، چون Gradle distribution/dependency cache محلی در دسترس نبود و محیط اجرایی دسترسی مستقیم لازم برای bootstrap را نداشت. CI پروژه برای اجرای `:app:testDebugUnitTest` و `:app:assembleDebug` تنظیم شده و `gradlew` در محیط دارای شبکه Wrapper رسمی 8.9 را با checksum بازیابی می‌کند.

## V21
- Fixed missing `foundation.lazy.grid` imports in `ProgressPathDialogs.kt`.
- The previously reported `LazyVerticalGrid` / `GridCells` / `items` Kotlin compile errors are resolved at source level.
