# V25 — Progress Path Gamification Core

این نسخه بسته‌ی کامل اصلاحات مسیر پیشرفت و گیمیفیکیشن است.

## هدر مشترک
- Home، Progress Path و صفحه اجرای کار دقیقاً از `GameHeader` مشترک استفاده می‌کنند.
- Level، XP، Coin، Combo و صندوق پاداش از State واقعی و Persisted خوانده می‌شوند.
- Rank حذف شده است؛ XP فقط برای Level Up استفاده می‌شود.
- صندوق پاداش یک Summary واقعی باز می‌کند و Badge فقط بعد از Reward معتبر دیده می‌شود.

## مسیر و اجرای کارت
- هیچ کارت به انجام کارت قبلی وابسته نیست؛ ترتیب فقط پیشنهاد/جایگاه است.
- فقط یک کارت در هر لحظه می‌تواند ACTIVE/EXPIRED باشد.
- تلاش برای Start کارت دوم، کار فعال را قطع نمی‌کند و پیام راهنما نشان می‌دهد.
- Progress کل مسیر از تعداد کارت‌های COMPLETED محاسبه می‌شود.
- Restore فقط همان کارت را برمی‌گرداند و دیگر کارت‌ها را دستکاری نمی‌کند.

## کارت جزئیات
- عنوان در کارت آبی هم‌خانواده با Next Action Home قرار گرفته است.
- چهار گوشه شامل قدم X از Y، Edit/Note، وضعیت و Reward Preview هستند.
- تایمر جمع‌وجورتر و گیمیفیکیشنی است و نزدیک پایان رنگ هشدار می‌گیرد.
- To-Do List جمع‌وجور، اسکرول‌پذیر و Required-gated است.

## ویرایش یکپارچه
- Add/Edit فقط یک UI و یک منطق دارند.
- Name، Position، Duration، Importance، To-Do و Delete در یک صفحه هستند.
- Durationهای 5/10/15/20/30 دقیقه و پیش‌فرض 15 دقیقه.
- چهار سطح اهمیت: کم، معمولی، مهم، خیلی مهم.
- Reward پایه: 10/2، 20/4، 35/7، 60/12 XP/Coin.
- Duration و Reward در لحظه Start Snapshot می‌شوند تا Edit وسط اجرا روی اجرای جاری اثر نگذارد.

## XP / Coin / Level
- Reward Transaction برای هر Completion معتبر ثبت می‌شود.
- Done → XP/Coin، Failed → بدون Reward.
- Level rule در `GameRules` متمرکز است.
- Reward Animation و Level Up feedback در Success flow وجود دارد.
- Restore تراکنش Reward را برمی‌گرداند و XP/Coin هیچ‌وقت منفی نمی‌شوند.
- Completion transaction idempotent است؛ Crash در میانه ثبت Reward باعث Double Reward نمی‌شود.

## Combo
- هر Done معتبر Combo را یک واحد زیاد می‌کند.
- Combo 1 و 2 ضریب ندارند؛ از Combo 3 به بعد XP/Coin ×1.5 می‌شوند.
- بعد از Done پنجره 30 دقیقه‌ای ایجاد/Reset می‌شود.
- پایان 30 دقیقه بدون Done جدید Combo را می‌شکند ولی Rewardهای معتبر قبلی را حذف نمی‌کند.
- 5 دقیقه آخر Notification و Warning UI دارد و 60 ثانیه آخر Pulse ظریف فعال می‌شود.
- Restore، Combo را از History واقعی دوباره محاسبه می‌کند؛ اگر حذف یک Completion ضریب Rewardهای بعدی را تغییر دهد، آن Rewardها نیز Replay می‌شوند.
- Best Combo و Event History ذخیره می‌شوند.

## Note / Restore / Safety
- Note حین تایپ Draft auto-save دارد و دکمه Save نیز وجود دارد.
- خروج با تغییر ذخیره‌نشده سه انتخاب Save/Discard/Cancel دارد.
- Crash/Process death متن Draft را از بین نمی‌برد.
- Restore Note را پاک نمی‌کند.
- حذف کارت Active هشدار مشخص دارد و Alarm مربوطه Cancel می‌شود.

## Notifications / Persistence
- پایان تایمر کارت با AlarmManager حتی در Background قابل Notification است.
- Combo warning و combo expiry نیز Alarm مستقل دارند.
- Android 13+ permission برای Notification درخواست می‌شود.
- Schema مسیر از V4 به V5 مهاجرت می‌کند و داده‌های قبلی حفظ می‌شوند.
- Game State در SharedPreferences مستقل و versioned ذخیره می‌شود.

## Build validation
- Pure Kotlin rules با `kotlinc` بررسی شده‌اند.
- XML string references بررسی شده‌اند و Reference مفقود وجود ندارد.
- Full Gradle build در محیط محلی به علت نبود دسترسی شبکه برای دریافت Wrapper قابل اجرا نبود؛ CI باید `testDebugUnitTest` و `assembleDebug` را اجرا کند.
