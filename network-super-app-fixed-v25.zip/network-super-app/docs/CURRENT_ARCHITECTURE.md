# Current Architecture — V25

V25 پایه‌ی تمیز بازسازی‌شده‌ی پروژه است. ظاهر و رفتار V24 قفل و مبنای مقایسه هستند.

## App shell

- `MainActivity`: فقط initialization قبل از Composition و بالا آوردن Theme/AppRoot.
- `AppRoot`: مالک مقصد جاری، Bottom Navigation و routing صفحه جزئیات مرحله.

## Home

- `HomeUiState` و `HomeDefaults`: قرارداد داده‌ی Home.
- `HomeScreen`: composition سطح صفحه.
- `HomeHeader`, `HomeActions`, `HomeSections`: اجزای بصری مسئولیت‌محور.

## Progress domain/state

- `ProgressStage.kt`: مدل‌ها و enumها.
- `MissionRules.kt`: قوانین خالص اجرای مرحله.
- `ProgressPathRules.kt`: قوانین خالص ترتیب و rollback مسیر.
- `ProgressStageFactory.kt`: defaults، checklist ids و normalization سازنده.
- `ProgressPathPersistence.kt`: SharedPreferences + JSON codec + migration.
- `ProgressPathStore.kt`: تنها source of truth برای Compose state و mutation orchestration.

## Progress UI

- `ProgressPathScreen/Header/World/Dialogs`: UI مسیر.
- `MissionDetailScreen`: orchestration و state صفحه جزئیات.
- `MissionDetailContent`: کارت‌ها و stateهای اصلی صفحه.
- `MissionDialogs`: Note/Edit/Confirm dialogs.

## Invariants

1. `id` و `number` مثبت و یکتا هستند.
2. شماره‌ها بعد از mutation از 1 تا N پیوسته بازسازی می‌شوند.
3. حداکثر یک `CURRENT` وجود دارد.
4. اگر Current وجود نداشته باشد ولی Upcoming وجود داشته باشد، اولین Upcoming به Current تبدیل می‌شود.
5. اگر Current/Upcoming وجود نداشته باشد، مسیر کامل است و ordinal برابر N است.
6. Restore نتیجه، target را Current و مراحل بعدی را Upcoming/Not Started می‌کند؛ note/config حفظ می‌شوند.
7. تایمر timestamp-based است و با خروج یا background متوقف نمی‌شود.
8. payload خراب باعث حذف بخشی از داده نمی‌شود؛ primary → backup → نسخه‌های قدیمی → defaults بررسی می‌شوند.

## Visual lock

بدون درخواست صریح طراحی، این موارد تغییر نکنند:

- وزن و ارتفاع سکشن‌های Home
- padding/spacing اصلی
- radius و ابعاد CTAها
- هندسه Canvas جاده و backdropها
- رنگ‌ها
- RTL/LTR موضعی
