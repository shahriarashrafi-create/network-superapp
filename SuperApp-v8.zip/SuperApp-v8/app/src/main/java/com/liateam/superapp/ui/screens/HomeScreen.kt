package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.MotivationalQuotes
import com.liateam.superapp.ui.model.homeDestinations

private data class ShortcutVisual(
    val icon: ImageVector,
    val accent: Color,
    val accent2: Color,
    val soft: Color
)

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val nextAction = tasks.firstOrNull { it.status.name == "TODO" } ?: tasks.first()
    val quote = remember { MotivationalQuotes.all.random() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF9FCFF), Color.White, Color(0xFFF4FAFF))
                )
            )
    ) {
        HomeAmbientBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 3.dp,
                    bottom = contentPadding.calculateBottomPadding() + 3.dp
                )
        ) {
            HomeHeader(
                quote = quote,
                onNotifications = { onOpenDestination(HomeDestination.NOTIFICATIONS) },
                onProfile = { onOpenDestination(HomeDestination.PROFILE) }
            )
            Spacer(Modifier.height(6.dp))
            StatusStrip()
            Spacer(Modifier.height(7.dp))
            NextActionHero(
                modifier = Modifier.height(154.dp),
                task = nextAction,
                onStart = onOpenActions
            )
            Spacer(Modifier.height(7.dp))
            RewardStrip(onClick = { onOpenDestination(HomeDestination.REWARD_STORE) })
            Spacer(Modifier.height(7.dp))
            ShortcutPager(
                modifier = Modifier.weight(1f),
                onOpenDestination = onOpenDestination
            )
        }
    }
}

@Composable
private fun HomeAmbientBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
            color = Color(0xFFB9DEFF).copy(alpha = 0.18f),
            radius = size.width * 0.34f,
            center = Offset(size.width * 0.93f, size.height * 0.11f)
        )
        drawCircle(
            color = Color(0xFFE4F3FF).copy(alpha = 0.32f),
            radius = size.width * 0.32f,
            center = Offset(size.width * 0.06f, size.height * 0.02f)
        )
    }
}

@Composable
private fun HomeHeader(
    quote: String,
    onNotifications: () -> Unit,
    onProfile: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(42.dp)
                    .shadow(5.dp, RoundedCornerShape(14.dp), clip = false)
                    .background(Color.White, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onNotifications, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.NotificationsNone,
                        contentDescription = "اعلان‌ها",
                        tint = SuperColors.Navy,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(10.dp)
                        .background(SuperColors.Red, CircleShape)
                        .border(2.dp, Color.White, CircleShape)
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.68f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "شهریار",
                        color = SuperColors.Navy,
                        fontWeight = FontWeight.Black,
                        fontSize = 23.sp,
                        lineHeight = 24.sp,
                        maxLines = 1
                    )
                    AdaptiveMotivationText(quote)
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(50.dp)
                    .shadow(4.dp, CircleShape, clip = false)
                    .background(Color.White, CircleShape)
                    .border(2.dp, SuperColors.Blue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                CodeAvatar(modifier = Modifier.size(44.dp))
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(18.dp)
                        .background(SuperColors.GoldBright, CircleShape)
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    CrownMini(modifier = Modifier.size(11.dp))
                }
                IconButton(onClick = onProfile, modifier = Modifier.fillMaxSize()) { }
            }
        }
    }
}

@Composable
private fun AdaptiveMotivationText(quote: String) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val widthPerChar = maxWidth.value / quote.length.coerceAtLeast(1)
        val font = when {
            widthPerChar >= 12f -> 12.sp
            widthPerChar >= 9f -> 11.2.sp
            widthPerChar >= 7f -> 10.4.sp
            widthPerChar >= 5.5f -> 9.6.sp
            else -> 8.8.sp
        }
        Text(
            text = quote,
            color = SuperColors.TextSecondary,
            fontSize = font,
            lineHeight = font,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun StatusStrip() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(61.dp)
            .shadow(5.dp, SuperShapes.Card, clip = false),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = SuperShapes.Card,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .border(0.8.dp, SuperColors.Border.copy(alpha = 0.65f), SuperShapes.Card)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RankStat(modifier = Modifier.weight(1.0f))
                Hairline()
                Column(modifier = Modifier.weight(1.55f), verticalArrangement = Arrangement.Center) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("240 / 500 XP", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { 0.48f },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = Color(0xFFE1ECF8)
                    )
                }
                Hairline()
                CoinStat(modifier = Modifier.weight(0.82f))
                Hairline()
                StreakStat(modifier = Modifier.weight(0.9f))
            }
        }
    }
}

@Composable
private fun RankStat(modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        CrownBadge(modifier = Modifier.size(31.dp))
        Spacer(Modifier.width(5.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text("سطح ۳", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
            Text("مسیر لیدر", color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 8.sp)
        }
    }
}

@Composable
private fun CoinStat(modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        CoinIcon(modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(4.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text("۶۹۵", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Text("سکه", color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 8.sp)
        }
    }
}

@Composable
private fun StreakStat(modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        FlameIcon(modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(4.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text("۷", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Text("روز متوالی", color = SuperColors.Orange, fontWeight = FontWeight.Bold, fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun Hairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 7.dp)
            .width(1.dp)
            .height(31.dp)
            .background(SuperColors.Border.copy(alpha = 0.8f))
    )
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(24.dp), clip = false),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFFFDFEFF), Color(0xFFF0F8FF), Color(0xFFE5F3FF))
                    )
                )
                .border(0.9.dp, Color(0xFFBBDDFB), RoundedCornerShape(24.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color(0xFFFFFFFF).copy(alpha = 0.52f),
                    radius = size.height * 0.66f,
                    center = Offset(size.width * 0.82f, size.height * 0.48f)
                )
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            modifier = Modifier.weight(1.12f).fillMaxHeight(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.End
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(29.dp).background(Color.White.copy(alpha = 0.75f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(7.dp))
                                Text("قدم بعدی", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                            }
                            Spacer(Modifier.height(3.dp))
                            Text(
                                task.title,
                                color = SuperColors.Navy,
                                fontWeight = FontWeight.Black,
                                fontSize = 21.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                task.subtitle,
                                color = SuperColors.TextSecondary,
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(9.dp))
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = onStart,
                                        modifier = Modifier.height(39.dp).width(112.dp),
                                        shape = RoundedCornerShape(13.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                                    ) {
                                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("شروع", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                                    }
                                    RewardChip("+20 XP", SuperColors.Blue, SuperColors.BlueSoft)
                                    RewardChip("+2 Coin", SuperColors.GoldDeep, SuperColors.GoldSoft)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    GoalPathIllustration(modifier = Modifier.weight(0.95f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun RewardChip(text: String, accent: Color, background: Color) {
    Box(
        modifier = Modifier
            .height(34.dp)
            .background(background, SuperShapes.Pill)
            .border(1.dp, accent.copy(alpha = 0.18f), SuperShapes.Pill)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = accent, fontWeight = FontWeight.Black, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun GoalPathIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawCircle(Color(0xFFCFEAFF).copy(alpha = 0.62f), radius = h * 0.43f, center = Offset(w * 0.58f, h * 0.53f))

        fun cube(cx: Float, cy: Float, s: Float, top: Color, left: Color, right: Color) {
            val topPath = Path().apply {
                moveTo(cx, cy - s * 0.45f)
                lineTo(cx + s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx - s * 0.55f, cy - s * 0.15f)
                close()
            }
            val leftPath = Path().apply {
                moveTo(cx - s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx, cy + s * 0.72f)
                lineTo(cx - s * 0.55f, cy + s * 0.42f)
                close()
            }
            val rightPath = Path().apply {
                moveTo(cx + s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx, cy + s * 0.72f)
                lineTo(cx + s * 0.55f, cy + s * 0.42f)
                close()
            }
            drawPath(topPath, top)
            drawPath(leftPath, left)
            drawPath(rightPath, right)
        }

        cube(w * 0.25f, h * 0.65f, h * 0.23f, Color.White, Color(0xFFD6E8FB), Color(0xFFE8F3FF))
        cube(w * 0.46f, h * 0.56f, h * 0.25f, Color(0xFF55B5FF), SuperColors.BlueStrong, Color(0xFF3599EF))
        cube(w * 0.66f, h * 0.47f, h * 0.28f, Color.White, Color(0xFFD9EAFB), Color(0xFFF4FAFF))
        cube(w * 0.80f, h * 0.31f, h * 0.31f, SuperColors.GoldBright, SuperColors.Gold, Color(0xFFEAA215))

        val arrow = Path().apply {
            moveTo(w * 0.17f, h * 0.58f)
            cubicTo(w * 0.31f, h * 0.50f, w * 0.39f, h * 0.35f, w * 0.55f, h * 0.30f)
        }
        drawPath(arrow, SuperColors.Blue, style = Stroke(width = 7f, cap = StrokeCap.Round))
        val arrowHead = Path().apply {
            moveTo(w * 0.55f, h * 0.30f)
            lineTo(w * 0.48f, h * 0.27f)
            lineTo(w * 0.52f, h * 0.38f)
            close()
        }
        drawPath(arrowHead, SuperColors.Blue)

        drawLine(SuperColors.GoldDeep, Offset(w * 0.80f, h * 0.12f), Offset(w * 0.80f, h * 0.29f), strokeWidth = 4f, cap = StrokeCap.Round)
        val flag = Path().apply {
            moveTo(w * 0.80f, h * 0.12f)
            lineTo(w * 0.93f, h * 0.15f)
            lineTo(w * 0.80f, h * 0.20f)
            close()
        }
        drawPath(flag, SuperColors.Gold)

        cube(w * 0.34f, h * 0.24f, h * 0.09f, Color(0xFFFFE99B), SuperColors.GoldBright, SuperColors.Gold)
        cube(w * 0.58f, h * 0.20f, h * 0.08f, Color(0xFFB8DFFF), Color(0xFF76B9F2), SuperColors.Blue)
    }
}

@Composable
private fun RewardStrip(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(70.dp)
            .shadow(4.dp, RoundedCornerShape(21.dp), clip = false),
        shape = RoundedCornerShape(21.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFFFFAEB), Color(0xFFFFF7E4), Color(0xFFFFFCF4))
                        )
                    )
                    .border(0.9.dp, Color(0xFFF3D995), RoundedCornerShape(21.dp))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChestIllustration(modifier = Modifier.width(82.dp).fillMaxHeight())
                Spacer(Modifier.width(6.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                        Text("صندوق پاداش", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
                        Text("هر ۳ ساعت یک پاداش جدید", color = SuperColors.TextSecondary, fontWeight = FontWeight.Medium, fontSize = 8.8.sp)
                        Spacer(Modifier.height(3.dp))
                        Box(
                            modifier = Modifier.background(Color.White.copy(alpha = 0.82f), SuperShapes.Pill).padding(horizontal = 10.dp, vertical = 3.dp)
                        ) {
                            Text("02:15:36", color = SuperColors.Navy, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
                        }
                    }
                }
                Button(
                    onClick = onClick,
                    modifier = Modifier.height(42.dp).width(83.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 8.dp)
                ) {
                    Text("مشاهده", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
                }
            }
        }
    }
}

@Composable
private fun ChestIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawCircle(SuperColors.Gold.copy(alpha = 0.10f), radius = h * 0.48f, center = Offset(w * 0.52f, h * 0.53f))

        val bodyLeft = w * 0.22f
        val bodyTop = h * 0.37f
        val bodyWidth = w * 0.58f
        val bodyHeight = h * 0.42f
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFF4EA7F6), SuperColors.BlueDeep)),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            color = Color(0xFF2D77C8),
            topLeft = Offset(bodyLeft, h * 0.24f),
            size = Size(bodyWidth, h * 0.24f),
            cornerRadius = CornerRadius(18f, 18f)
        )
        drawRoundRect(
            color = SuperColors.GoldBright,
            topLeft = Offset(bodyLeft + bodyWidth * 0.43f, h * 0.43f),
            size = Size(bodyWidth * 0.14f, h * 0.24f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        drawCircle(Color(0xFFFFE16F), radius = w * 0.095f, center = Offset(w * 0.18f, h * 0.80f))
        drawCircle(SuperColors.Gold, radius = w * 0.082f, center = Offset(w * 0.84f, h * 0.76f))
        drawCircle(Color(0xFFFFF1A9), radius = w * 0.045f, center = Offset(w * 0.18f, h * 0.80f))
        drawCircle(Color(0xFFFFE16F), radius = w * 0.04f, center = Offset(w * 0.84f, h * 0.76f))

        drawLine(SuperColors.GoldBright, Offset(w * 0.12f, h * 0.20f), Offset(w * 0.08f, h * 0.08f), 3f, StrokeCap.Round)
        drawLine(SuperColors.GoldBright, Offset(w * 0.88f, h * 0.18f), Offset(w * 0.92f, h * 0.07f), 3f, StrokeCap.Round)
    }
}

@Composable
private fun ShortcutPager(
    modifier: Modifier,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val pages = remember { homeDestinations().chunked(6) }
    val pagerState = rememberPagerState(pageCount = { pages.size })

    Column(modifier = modifier.fillMaxWidth()) {
        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val pageWidth = maxWidth - 13.dp
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    pageSize = PageSize.Fixed(pageWidth),
                    pageSpacing = 8.dp,
                    contentPadding = PaddingValues(start = 0.dp, end = 13.dp),
                    beyondViewportPageCount = 1
                ) { page ->
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ShortcutGrid(
                            destinations = pages[page],
                            onOpenDestination = onOpenDestination
                        )
                    }
                }
            }

            if (pagerState.currentPage < pages.lastIndex) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .width(15.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Color(0xFFF8FCFF).copy(alpha = 0.88f))
                            )
                        )
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().height(15.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(pages.size) { index ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (index == pagerState.currentPage) 8.dp else 5.dp)
                        .background(
                            if (index == pagerState.currentPage) SuperColors.Blue else Color(0xFFD6E3F1),
                            CircleShape
                        )
                )
            }
        }
    }
}

@Composable
private fun ShortcutGrid(
    destinations: List<HomeDestination>,
    onOpenDestination: (HomeDestination) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        val top = destinations.take(3)
        val bottom = destinations.drop(3)
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            top.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bottom.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
            repeat(3 - bottom.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun ShortcutTile(
    modifier: Modifier,
    destination: HomeDestination,
    onClick: () -> Unit
) {
    val visual = shortcutVisual(destination)
    Card(
        modifier = modifier.shadow(4.dp, RoundedCornerShape(18.dp), clip = false),
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White, visual.soft.copy(alpha = 0.72f), Color.White)
                    )
                )
                .border(0.8.dp, visual.accent.copy(alpha = 0.15f), RoundedCornerShape(18.dp))
        ) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                ShortcutIllustration(destination = destination, visual = visual)
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(31.dp)
                    .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(bottomStart = 17.dp, bottomEnd = 17.dp))
                    .border(0.6.dp, SuperColors.Border.copy(alpha = 0.6f), RoundedCornerShape(bottomStart = 17.dp, bottomEnd = 17.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    destination.title,
                    color = SuperColors.Navy,
                    fontWeight = FontWeight.Black,
                    fontSize = 9.8.sp,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ShortcutIllustration(destination: HomeDestination, visual: ShortcutVisual) {
    when (destination) {
        HomeDestination.PROGRESS -> CastleIllustration(Modifier.fillMaxSize().padding(4.dp))
        HomeDestination.NETWORK -> TreeIllustration(Modifier.fillMaxSize().padding(4.dp))
        HomeDestination.ACADEMY -> AcademyIllustration(Modifier.fillMaxSize().padding(4.dp))
        HomeDestination.MY_WEEK -> GlobeIllustration(Modifier.fillMaxSize().padding(4.dp))
        HomeDestination.ACTIONS -> ClipboardIllustration(Modifier.fillMaxSize().padding(4.dp))
        HomeDestination.CUSTOMERS -> PeopleIllustration(Modifier.fillMaxSize().padding(4.dp))
        else -> GenericShortcutIllustration(visual = visual)
    }
}

@Composable
private fun CastleIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFDFF4FF), Offset(w * 0.12f, h * 0.70f), Size(w * 0.76f, h * 0.20f))
        drawRoundRect(Color.White, Offset(w * 0.20f, h * 0.48f), Size(w * 0.60f, h * 0.30f), CornerRadius(12f))
        listOf(0.24f, 0.50f, 0.76f).forEach { x ->
            drawRoundRect(Color(0xFF5CAAF5), Offset(w * (x - 0.09f), h * 0.32f), Size(w * 0.18f, h * 0.40f), CornerRadius(8f))
            val roof = Path().apply {
                moveTo(w * x, h * 0.16f)
                lineTo(w * (x - 0.12f), h * 0.35f)
                lineTo(w * (x + 0.12f), h * 0.35f)
                close()
            }
            drawPath(roof, Color(0xFF236FD6))
            drawLine(SuperColors.GoldDeep, Offset(w * x, h * 0.14f), Offset(w * x, h * 0.07f), 2.5f)
            val flag = Path().apply {
                moveTo(w * x, h * 0.07f)
                lineTo(w * (x + 0.09f), h * 0.09f)
                lineTo(w * x, h * 0.13f)
                close()
            }
            drawPath(flag, SuperColors.Gold)
        }
        drawRoundRect(SuperColors.BlueDeep, Offset(w * 0.43f, h * 0.56f), Size(w * 0.14f, h * 0.22f), CornerRadius(18f, 18f))
        drawCircle(Color(0xFFBFE8FF).copy(alpha = 0.65f), radius = w * 0.08f, center = Offset(w * 0.50f, h * 0.75f))
    }
}

@Composable
private fun TreeIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFD9F5E9), Offset(w * 0.12f, h * 0.72f), Size(w * 0.76f, h * 0.17f))
        drawRoundRect(Color(0xFF9B5D2E), Offset(w * 0.46f, h * 0.43f), Size(w * 0.10f, h * 0.34f), CornerRadius(8f))
        drawCircle(Color(0xFF2FB176), radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.38f))
        drawCircle(Color(0xFF46C789), radius = w * 0.16f, center = Offset(w * 0.35f, h * 0.43f))
        drawCircle(Color(0xFF56D59A), radius = w * 0.15f, center = Offset(w * 0.65f, h * 0.43f))
        drawCircle(Color(0xFF238E61), radius = w * 0.14f, center = Offset(w * 0.50f, h * 0.25f))
        repeat(5) { i ->
            val x = w * (0.20f + i * 0.15f)
            val color = if (i % 2 == 0) Color(0xFF1C8A60) else Color(0xFF35A978)
            val p = Path().apply {
                moveTo(x, h * 0.69f)
                lineTo(x - w * 0.05f, h * 0.82f)
                lineTo(x + w * 0.05f, h * 0.82f)
                close()
            }
            drawPath(p, color)
        }
    }
}

@Composable
private fun AcademyIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        for (i in 0..3) {
            drawRoundRect(
                color = if (i % 2 == 0) Color.White else Color(0xFFE9F3FF),
                topLeft = Offset(w * (0.22f + i * 0.08f), h * (0.69f - i * 0.10f)),
                size = Size(w * 0.46f, h * 0.12f),
                cornerRadius = CornerRadius(8f)
            )
        }
        val cap = Path().apply {
            moveTo(w * 0.50f, h * 0.20f)
            lineTo(w * 0.80f, h * 0.33f)
            lineTo(w * 0.50f, h * 0.46f)
            lineTo(w * 0.20f, h * 0.33f)
            close()
        }
        drawPath(cap, Color(0xFF205DC2))
        drawRoundRect(Color(0xFF154898), Offset(w * 0.36f, h * 0.39f), Size(w * 0.28f, h * 0.12f), CornerRadius(5f))
        drawLine(SuperColors.Gold, Offset(w * 0.76f, h * 0.34f), Offset(w * 0.76f, h * 0.56f), 3f, StrokeCap.Round)
        drawCircle(SuperColors.GoldBright, radius = w * 0.025f, center = Offset(w * 0.76f, h * 0.58f))
    }
}

@Composable
private fun GlobeIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w * 0.48f, h * 0.47f)
        val r = minOf(w, h) * 0.28f
        drawCircle(Color(0xFF3B93E9), radius = r, center = c)
        drawCircle(Color(0xFF0E6FD1), radius = r, center = c, style = Stroke(width = 4f))
        drawArc(Color(0xFFB7E4FF), -70f, 140f, false, Offset(c.x - r * 0.75f, c.y - r), Size(r * 1.5f, r * 2f), style = Stroke(width = 3f))
        drawArc(Color(0xFFB7E4FF), 110f, 140f, false, Offset(c.x - r, c.y - r * 0.7f), Size(r * 2f, r * 1.4f), style = Stroke(width = 3f))
        val land = Path().apply {
            moveTo(c.x - r * 0.55f, c.y - r * 0.25f)
            lineTo(c.x - r * 0.05f, c.y - r * 0.55f)
            lineTo(c.x + r * 0.35f, c.y - r * 0.15f)
            lineTo(c.x + r * 0.10f, c.y + r * 0.10f)
            lineTo(c.x - r * 0.30f, c.y + r * 0.18f)
            close()
        }
        drawPath(land, Color(0xFF57C57D))
        drawArc(SuperColors.Gold, 200f, 235f, false, Offset(c.x - r * 1.28f, c.y - r * 0.86f), Size(r * 2.6f, r * 1.75f), style = Stroke(width = 3f))
        val plane = Path().apply {
            moveTo(w * 0.78f, h * 0.20f)
            lineTo(w * 0.91f, h * 0.17f)
            lineTo(w * 0.82f, h * 0.27f)
            lineTo(w * 0.79f, h * 0.37f)
            lineTo(w * 0.74f, h * 0.27f)
            close()
        }
        drawPath(plane, Color(0xFF246EC8))
    }
}

@Composable
private fun ClipboardIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(Color(0xFFFFC84A), Offset(w * 0.27f, h * 0.18f), Size(w * 0.48f, h * 0.64f), CornerRadius(13f))
        drawRoundRect(Color.White, Offset(w * 0.31f, h * 0.24f), Size(w * 0.40f, h * 0.53f), CornerRadius(10f))
        drawRoundRect(Color(0xFF2E78D4), Offset(w * 0.41f, h * 0.13f), Size(w * 0.20f, h * 0.12f), CornerRadius(9f))
        for (i in 0..2) {
            val y = h * (0.38f + i * 0.14f)
            drawRoundRect(Color(0xFFE9F3FF), Offset(w * 0.38f, y - h * 0.04f), Size(w * 0.09f, h * 0.08f), CornerRadius(4f))
            drawLine(SuperColors.Blue, Offset(w * 0.39f, y), Offset(w * 0.42f, y + h * 0.02f), 2.5f, StrokeCap.Round)
            drawLine(SuperColors.Blue, Offset(w * 0.42f, y + h * 0.02f), Offset(w * 0.46f, y - h * 0.025f), 2.5f, StrokeCap.Round)
            drawLine(Color(0xFF86A6C7), Offset(w * 0.51f, y), Offset(w * 0.65f, y), 3f, StrokeCap.Round)
        }
        drawLine(Color(0xFFEC8F21), Offset(w * 0.72f, h * 0.30f), Offset(w * 0.62f, h * 0.72f), 7f, StrokeCap.Round)
        drawLine(Color(0xFFF6B548), Offset(w * 0.70f, h * 0.30f), Offset(w * 0.60f, h * 0.72f), 3f, StrokeCap.Round)
    }
}

@Composable
private fun PeopleIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFE8F3FF), Offset(w * 0.12f, h * 0.70f), Size(w * 0.76f, h * 0.16f))
        val xs = listOf(0.31f, 0.50f, 0.69f)
        val colors = listOf(Color(0xFF4D92E7), Color(0xFF1B6BCB), Color(0xFFF1A33B))
        xs.forEachIndexed { index, x ->
            drawCircle(Color(0xFFFFD0AE), radius = w * 0.08f, center = Offset(w * x, h * (0.37f + if (index == 1) -0.04f else 0f)))
            drawRoundRect(colors[index], Offset(w * (x - 0.09f), h * (0.49f + if (index == 1) -0.04f else 0f)), Size(w * 0.18f, h * 0.25f), CornerRadius(18f, 18f))
            val hairY = h * (0.31f + if (index == 1) -0.04f else 0f)
            drawArc(Color(0xFF263B55), 180f, 180f, true, Offset(w * (x - 0.08f), hairY), Size(w * 0.16f, w * 0.12f))
        }
        drawRoundRect(Color(0xFFFFF0D7), Offset(w * 0.68f, h * 0.21f), Size(w * 0.18f, h * 0.12f), CornerRadius(8f))
        drawCircle(SuperColors.Gold, radius = w * 0.025f, center = Offset(w * 0.78f, h * 0.27f))
    }
}

@Composable
private fun GenericShortcutIllustration(visual: ShortcutVisual) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawOval(visual.soft, Offset(w * 0.15f, h * 0.63f), Size(w * 0.70f, h * 0.20f))
            val pedestal = Path().apply {
                moveTo(w * 0.27f, h * 0.63f)
                lineTo(w * 0.50f, h * 0.52f)
                lineTo(w * 0.73f, h * 0.63f)
                lineTo(w * 0.50f, h * 0.76f)
                close()
            }
            drawPath(pedestal, visual.accent.copy(alpha = 0.18f))
            drawCircle(visual.accent2.copy(alpha = 0.13f), radius = h * 0.16f, center = Offset(w * 0.72f, h * 0.28f))
        }
        Box(
            modifier = Modifier
                .size(43.dp)
                .shadow(3.dp, CircleShape, clip = false)
                .background(Color.White, CircleShape)
                .border(1.dp, visual.accent.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun CodeAvatar(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawCircle(Color(0xFFD7EDFF), radius = minOf(w, h) * 0.48f, center = center)
        drawCircle(Color(0xFFFFCFAC), radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.43f))
        drawArc(Color(0xFF243B5A), 180f, 180f, true, Offset(w * 0.26f, h * 0.18f), Size(w * 0.48f, h * 0.33f))
        drawRoundRect(SuperColors.Blue, Offset(w * 0.27f, h * 0.66f), Size(w * 0.46f, h * 0.28f), CornerRadius(18f, 18f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.43f, h * 0.43f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.57f, h * 0.43f))
        drawArc(Color(0xFFE48A6A), 15f, 150f, false, Offset(w * 0.42f, h * 0.49f), Size(w * 0.16f, h * 0.09f), style = Stroke(width = 2f, cap = StrokeCap.Round))
    }
}

@Composable
private fun CrownMini(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * 0.10f, size.height * 0.72f)
            lineTo(size.width * 0.22f, size.height * 0.25f)
            lineTo(size.width * 0.46f, size.height * 0.53f)
            lineTo(size.width * 0.62f, size.height * 0.18f)
            lineTo(size.width * 0.88f, size.height * 0.68f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun CrownBadge(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawCircle(Color(0xFFFFF6D8), radius = minOf(size.width, size.height) * 0.48f, center = center)
        val p = Path().apply {
            moveTo(size.width * 0.12f, size.height * 0.70f)
            lineTo(size.width * 0.20f, size.height * 0.30f)
            lineTo(size.width * 0.42f, size.height * 0.50f)
            lineTo(size.width * 0.55f, size.height * 0.20f)
            lineTo(size.width * 0.72f, size.height * 0.50f)
            lineTo(size.width * 0.88f, size.height * 0.28f)
            lineTo(size.width * 0.84f, size.height * 0.74f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(SuperColors.GoldBright, SuperColors.Gold)))
        drawRoundRect(SuperColors.GoldDeep, Offset(size.width * 0.18f, size.height * 0.72f), Size(size.width * 0.67f, size.height * 0.11f), CornerRadius(4f))
    }
}

@Composable
private fun CoinIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawCircle(SuperColors.GoldBright, radius = minOf(size.width, size.height) * 0.45f, center = center)
        drawCircle(SuperColors.GoldDeep, radius = minOf(size.width, size.height) * 0.45f, center = center, style = Stroke(width = 2.5f))
        drawCircle(Color(0xFFFFE885), radius = minOf(size.width, size.height) * 0.29f, center = center)
        drawCircle(SuperColors.Gold, radius = minOf(size.width, size.height) * 0.10f, center = center)
    }
}

@Composable
private fun FlameIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * 0.52f, size.height * 0.08f)
            cubicTo(size.width * 0.70f, size.height * 0.34f, size.width * 0.90f, size.height * 0.43f, size.width * 0.80f, size.height * 0.70f)
            cubicTo(size.width * 0.70f, size.height * 0.95f, size.width * 0.28f, size.height * 0.96f, size.width * 0.18f, size.height * 0.70f)
            cubicTo(size.width * 0.10f, size.height * 0.48f, size.width * 0.30f, size.height * 0.34f, size.width * 0.38f, size.height * 0.16f)
            cubicTo(size.width * 0.42f, size.height * 0.30f, size.width * 0.50f, size.height * 0.34f, size.width * 0.52f, size.height * 0.08f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFF7A24), Color(0xFFFFB21E))))
        drawCircle(Color(0xFFFFE26A), radius = size.width * 0.12f, center = Offset(size.width * 0.51f, size.height * 0.68f))
    }
}

private fun shortcutVisual(destination: HomeDestination): ShortcutVisual = when (destination) {
    HomeDestination.PROGRESS -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.Sky, SuperColors.BlueSoft)
    HomeDestination.NETWORK -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, Color(0xFF59C995), SuperColors.GreenSoft)
    HomeDestination.ACADEMY -> ShortcutVisual(Icons.Outlined.School, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.MY_WEEK -> ShortcutVisual(Icons.Outlined.CalendarMonth, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.ACTIONS -> ShortcutVisual(Icons.Outlined.TaskAlt, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.CUSTOMERS -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Orange, SuperColors.Gold, SuperColors.OrangeSoft)
    HomeDestination.LEADER_CENTER -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.BlueDeep, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.GOALS -> ShortcutVisual(Icons.Outlined.TrackChanges, SuperColors.Red, SuperColors.Orange, SuperColors.RedSoft)
    HomeDestination.RANK_REWARDS -> ShortcutVisual(Icons.Outlined.EmojiEvents, SuperColors.GoldDeep, SuperColors.GoldBright, SuperColors.GoldSoft)
    HomeDestination.EVENTS -> ShortcutVisual(Icons.Outlined.Event, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.LIBRARY -> ShortcutVisual(Icons.Outlined.MenuBook, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.SALES -> ShortcutVisual(Icons.Outlined.ShoppingCart, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.REPORTS -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.PERSONAL_STORE -> ShortcutVisual(Icons.Outlined.Storefront, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.PROFILE -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.SETTINGS -> ShortcutVisual(Icons.Outlined.Settings, SuperColors.TextSecondary, SuperColors.Blue, SuperColors.NeutralSoft)
    HomeDestination.SEARCH -> ShortcutVisual(Icons.Outlined.Search, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.NOTIFICATIONS -> ShortcutVisual(Icons.Outlined.NotificationsNone, SuperColors.Red, SuperColors.Gold, SuperColors.RedSoft)
    HomeDestination.FOCUS -> ShortcutVisual(Icons.Outlined.Timer, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TREE -> ShortcutVisual(Icons.Outlined.AccountTree, SuperColors.Green, SuperColors.Blue, SuperColors.GreenSoft)
    HomeDestination.PROFILE_360 -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.GROUPS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Orange, SuperColors.Green, SuperColors.OrangeSoft)
    HomeDestination.CHANNELS -> ShortcutVisual(Icons.Outlined.ChatBubbleOutline, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TEAM_MEMBERS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.DREAM_BOARD -> ShortcutVisual(Icons.Outlined.Flag, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.ACHIEVEMENTS -> ShortcutVisual(Icons.Outlined.WorkspacePremium, SuperColors.GoldDeep, SuperColors.Purple, SuperColors.GoldSoft)
    HomeDestination.LEADERBOARD -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.REWARD_STORE -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.WEBSITE -> ShortcutVisual(Icons.Outlined.Language, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.ORDERS -> ShortcutVisual(Icons.Outlined.ReceiptLong, SuperColors.Green, SuperColors.Orange, SuperColors.GreenSoft)
}
