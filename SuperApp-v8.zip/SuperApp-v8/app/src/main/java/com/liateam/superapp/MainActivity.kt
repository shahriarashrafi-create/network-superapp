package com.liateam.superapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppSection
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.TaskStatus
import com.liateam.superapp.ui.model.initialTasks
import com.liateam.superapp.ui.screens.ActionsScreen
import com.liateam.superapp.ui.screens.HomeScreen
import com.liateam.superapp.ui.screens.PlaceholderScreen
import com.liateam.superapp.ui.screens.ProfileScreen
import com.liateam.superapp.ui.screens.ProgressScreen
import com.liateam.superapp.ui.theme.SuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SuperAppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SuperAppRoot()
                }
            }
        }
    }
}

@Composable
private fun SuperAppRoot() {
    var section by remember { mutableStateOf(AppSection.HOME) }
    var homeDestination by remember { mutableStateOf<HomeDestination?>(null) }
    val tasks = remember { mutableStateListOf<AppTask>().apply { addAll(initialTasks()) } }

    fun updateTask(id: Int, status: TaskStatus) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index >= 0) tasks[index] = tasks[index].copy(status = status)
    }

    fun openDestination(destination: HomeDestination) {
        homeDestination = null
        when (destination) {
            HomeDestination.PROGRESS -> section = AppSection.PROGRESS
            HomeDestination.NETWORK -> section = AppSection.NETWORK
            HomeDestination.ACTIONS -> section = AppSection.ACTIONS
            else -> {
                section = AppSection.HOME
                homeDestination = destination
            }
        }
    }

    val profileIsOpen = homeDestination == HomeDestination.PROFILE

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SuperColors.Background,
        bottomBar = {
            if (!profileIsOpen) {
                MainBottomBar(
                    section = section,
                    onSelect = {
                        homeDestination = null
                        section = it
                    }
                )
            }
        }
    ) { innerPadding ->
        val destination = homeDestination
        when {
            destination == HomeDestination.PROFILE -> ProfileScreen(
                contentPadding = innerPadding,
                onBack = {
                    homeDestination = null
                    section = AppSection.HOME
                },
                onOpenDestination = ::openDestination
            )

            destination != null -> PlaceholderScreen(
                contentPadding = innerPadding,
                title = destination.title,
                subtitle = destination.subtitle,
                onBack = {
                    homeDestination = null
                    section = AppSection.HOME
                }
            )

            else -> when (section) {
                AppSection.HOME -> HomeScreen(
                    contentPadding = innerPadding,
                    tasks = tasks,
                    onOpenActions = { section = AppSection.ACTIONS },
                    onOpenDestination = ::openDestination
                )

                AppSection.ACTIONS -> ActionsScreen(
                    contentPadding = innerPadding,
                    tasks = tasks,
                    onTaskStatus = ::updateTask,
                    onOpenProgress = { section = AppSection.PROGRESS }
                )

                AppSection.PROGRESS -> ProgressScreen(
                    contentPadding = innerPadding,
                    onBack = { section = AppSection.HOME }
                )

                AppSection.NETWORK -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "شبکه من",
                    subtitle = "درختواره، اعضای سازمان و Profile 360 از این بخش باز می‌شوند."
                )

                AppSection.MESSAGES -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "پیام‌ها",
                    subtitle = "Messenger، گروه‌ها و کانال‌های تیمی در این بخش قرار می‌گیرند."
                )

                AppSection.MORE -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "بیشتر",
                    subtitle = "تمام ابزارهای کم‌استفاده‌تر و Shortcutهای قابل Pin از اینجا در دسترس خواهند بود."
                )
            }
        }
    }
}

private data class BottomItem(
    val section: AppSection,
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainBottomBar(
    section: AppSection,
    onSelect: (AppSection) -> Unit
) {
    val items = listOf(
        BottomItem(AppSection.HOME, "خانه", Icons.Outlined.Home),
        BottomItem(AppSection.ACTIONS, "اقدام‌ها", Icons.Outlined.TaskAlt),
        BottomItem(AppSection.NETWORK, "شبکه من", Icons.Outlined.Groups),
        BottomItem(AppSection.MESSAGES, "پیام‌ها", Icons.Outlined.ChatBubbleOutline),
        BottomItem(AppSection.MORE, "بیشتر", Icons.Outlined.MoreHoriz)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .shadow(7.dp, RoundedCornerShape(24.dp), clip = false),
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 7.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                items.forEach { item ->
                    val selected = when (section) {
                        AppSection.PROGRESS -> item.section == AppSection.ACTIONS
                        else -> section == item.section
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelect(item.section) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .height(31.dp)
                                .background(
                                    if (selected) SuperColors.BlueSoft else Color.Transparent,
                                    SuperShapes.Pill
                                )
                                .padding(horizontal = if (selected) 15.dp else 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                item.icon,
                                contentDescription = item.label,
                                tint = if (selected) SuperColors.Blue else Color(0xFF6F7F99),
                                modifier = Modifier.size(21.dp)
                            )
                        }
                        Text(
                            item.label,
                            color = if (selected) SuperColors.Blue else Color(0xFF77869D),
                            fontWeight = if (selected) FontWeight.Black else FontWeight.Medium,
                            fontSize = 8.7.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
