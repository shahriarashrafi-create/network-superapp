# SuperApp v8

Android prototype for the Network Marketing Super App.

Version: **1.6.0**  
Build: **8**

Highlights in this build:
- Legacy-inspired Home visual pass using only Jetpack Compose, Canvas, shapes, gradients and vector icons.
- Code-drawn avatar, crown, coin, streak, goal-path and reward-chest illustrations.
- Five-page Home shortcut carousel with 30 linked destinations and 6 shortcuts per page.
- First shortcut page uses custom code-drawn illustrations for Progress, Network, Academy, My Week, Actions and Customers.
- 500 short motivational lines remain available for the single-line adaptive Home subtitle.
- New rich Profile screen with identity, rank, XP, achievements, personal stats, goal/rank progress, academy, links, account and security entry points.
- Floating Legacy-style bottom navigation.
- No raster UI/background images are included in the Android app.

Application ID and signing identity are unchanged for update compatibility.
