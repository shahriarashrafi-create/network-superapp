# SuperApp v12

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## v12 focus
- Home Next Action opens a real task flow.
- Task details with subtasks, CRM deep-link entry, time presets and rewards.
- Full-screen Focus Mode with countdown, pause, optional music affordance and finish flow.
- Result sheet: Done / Later / Fail.
- Completion state with XP, Coin and Combo feedback, then Next Action.
- Progress Path redesigned as a vertical zigzag-like staged journey with stats, Done/Fail/Current/Locked states, rewards and step details.
- Current path step can launch directly into the task flow.
- Existing Home, Profile, Notifications, Level, Coin, Combo, Wallet, Reward Store and 30-link pager are retained.
- UI remains code/vector/canvas based; no decorative bitmap background is used.

Application ID and signing configuration are intentionally preserved for in-place APK updates.
