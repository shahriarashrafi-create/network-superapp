from pathlib import Path
import json
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]

required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradlew",
    "gradle/wrapper/gradle-wrapper.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/superapp/progressgame/MainActivity.kt",
    "app/src/main/java/com/superapp/progressgame/ui/GameFoundationApp.kt",
    "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt",
    "app/src/main/java/com/superapp/progressgame/ui/components/MissionPanel.kt",
    "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraPreset.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraDirector.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraSafety.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionModels.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionCatalog.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionEngine.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionValidator.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/LocalMissionRepository.kt",
    "app/src/main/java/com/superapp/progressgame/gameplay/mission/LevelRules.kt",
    "app/src/main/assets/definitions/mission_manifest_v1.json",
    "app/src/main/assets/definitions/asset_manifest_v1.json",
    "docs/VERSION_06_SCOPE.md",
    "keystore/superapp.jks",
]

errors = []
for item in required:
    if not (root / item).is_file():
        errors.append(f"missing: {item}")

build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
root_build = (root / "build.gradle.kts").read_text(encoding="utf-8")
manifest_path = root / "app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")
gradlew = (root / "gradlew").read_text(encoding="utf-8")
wrapper = (root / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
world_shell = (root / "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt").read_text(encoding="utf-8")
scene = (root / "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt").read_text(encoding="utf-8")
app_config = (root / "app/src/main/java/com/superapp/progressgame/core/config/AppConfig.kt").read_text(encoding="utf-8")
mission_engine = (root / "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionEngine.kt").read_text(encoding="utf-8")
mission_catalog = (root / "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionCatalog.kt").read_text(encoding="utf-8")
mission_repo = (root / "app/src/main/java/com/superapp/progressgame/gameplay/mission/LocalMissionRepository.kt").read_text(encoding="utf-8")
mission_models = (root / "app/src/main/java/com/superapp/progressgame/gameplay/mission/MissionModels.kt").read_text(encoding="utf-8")
mission_panel = (root / "app/src/main/java/com/superapp/progressgame/ui/components/MissionPanel.kt").read_text(encoding="utf-8")
feature_flags = (root / "app/src/main/java/com/superapp/progressgame/core/config/FeatureFlags.kt").read_text(encoding="utf-8")

checks = {
    "applicationId": 'applicationId = "com.superapp.progressgame"' in build,
    "versionCode 14": bool(re.search(r"versionCode\s*=\s*14\b", build)),
    "versionName V6": 'versionName = "6.0.0-mission-gameplay-core"' in build,
    "compileSdk 36": bool(re.search(r"compileSdk\s*=\s*36\b", build)),
    "targetSdk 36": bool(re.search(r"targetSdk\s*=\s*36\b", build)),
    "stable signing": 'signingConfigs.getByName("stable")' in build,
    "SceneView 4.32": 'io.github.sceneview:sceneview:4.32.0' in build,
    "AGP 8.13.2": 'com.android.application") version "8.13.2"' in root_build,
    "Kotlin 2.4.10": 'org.jetbrains.kotlin.android") version "2.4.10"' in root_build,
    "Compose compiler plugin": 'org.jetbrains.kotlin.plugin.compose") version "2.4.10"' in root_build,
    "Gradle launcher 8.13": 'GRADLE_VERSION="8.13"' in gradlew,
    "Gradle wrapper 8.13": 'gradle-8.13-bin.zip' in wrapper,
    "landscape": 'android:screenOrientation="landscape"' in manifest,
    "hardware accelerated": 'android:hardwareAccelerated="true"' in manifest,
    "real SceneView": 'SceneView(' in world_shell,
    "V5 camera retained": all(x in world_shell for x in ['CameraMode.FREE', 'CameraMode.FOCUS', 'CameraMode.TOP_VIEW', 'CameraMode.CINEMATIC']),
    "top view retained": 'topViewForObject' in world_shell,
    "mission engine wired": 'missionEngine' in world_shell and 'class MissionEngine' in mission_engine,
    "mission states": all(x in mission_models for x in ['LOCKED', 'AVAILABLE', 'ACTIVE', 'PAUSED', 'COMPLETED', 'CANCELLED', 'FAILED', 'ERROR']),
    "mission objectives": all(x in mission_models for x in ['MANUAL', 'INTERACT', 'COUNT', 'MULTI_STEP']),
    "8 mission pack": mission_catalog.count('id = "mission_') == 8,
    "transactional completion": 'commitCompletion' in mission_engine and 'commitCompletion' in mission_repo,
    "duplicate reward protection": 'rewardedMissionIds' in mission_engine and 'KEY_REWARDED_MISSIONS' in mission_repo,
    "weighted region progress": 'importance.weight' in mission_engine,
    "level progression": 'LevelRules.levelFromTotalXp' in mission_engine,
    "event bus": 'MissionEventType.MISSION_COMPLETED' in mission_engine,
    "camera directives": 'CameraDirective' in world_shell and 'CameraDirective.CELEBRATION' in world_shell,
    "world object states": 'worldObjectStates' in scene and 'fountain_main' in scene,
    "fountain state visible": 'active = worldObjectStates["fountain_main"] != "off"' in scene,
    "lamp state visible": 'enabled = worldObjectStates[instance.instanceId] == "on"' in scene,
    "mission panel": 'MissionPanel(' in world_shell and 'xpReward' in mission_panel and 'coinReward' in mission_panel,
    "missions enabled": 'val missions: Boolean = true' in feature_flags,
    "cinematic enabled": 'val cinematicCamera: Boolean = true' in feature_flags,
    "save schema 4": 'SAVE_SCHEMA_VERSION = 4' in app_config,
    "world schema 4": 'WORLD_SCHEMA_VERSION = 4' in app_config,
}

for name, ok in checks.items():
    if not ok:
        errors.append(f"check failed: {name}")

try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml invalid: {exc}")

asset_manifest_path = root / "app/src/main/assets/definitions/asset_manifest_v1.json"
try:
    asset_manifest = json.loads(asset_manifest_path.read_text(encoding="utf-8"))
    ids = [item["id"] for item in asset_manifest["assets"]]
    if len(ids) != len(set(ids)):
        errors.append("asset manifest contains duplicate ids")
    if asset_manifest.get("assetCount") != len(ids):
        errors.append("asset manifest assetCount mismatch")
except Exception as exc:
    errors.append(f"asset manifest invalid: {exc}")

mission_manifest_path = root / "app/src/main/assets/definitions/mission_manifest_v1.json"
try:
    mission_manifest = json.loads(mission_manifest_path.read_text(encoding="utf-8"))
    missions = mission_manifest.get("missions", [])
    mission_ids = [item["id"] for item in missions]
    if mission_manifest.get("schemaVersion") != 1:
        errors.append("mission manifest schemaVersion must be 1")
    if mission_manifest.get("missionCount") != len(missions):
        errors.append("mission manifest missionCount mismatch")
    if len(missions) != 8:
        errors.append("mission manifest must contain 8 starter missions")
    if len(mission_ids) != len(set(mission_ids)):
        errors.append("mission manifest contains duplicate ids")
    known = set(mission_ids)
    for mission in missions:
        if mission.get("xpReward", 0) < 0 or mission.get("coinReward", 0) < 0:
            errors.append(f"negative reward in {mission.get('id')}")
        for dependency in mission.get("prerequisites", []):
            if dependency not in known:
                errors.append(f"unknown mission dependency {dependency}")
except Exception as exc:
    errors.append(f"mission manifest invalid: {exc}")

for kt in root.rglob("*.kt"):
    text = kt.read_text(encoding="utf-8")
    if "androidx.compose.foundation.layout.RowColumnParentData" in text:
        errors.append(f"forbidden internal Compose API import: {kt.relative_to(root)}")

def strip_strings_and_comments(source: str) -> str:
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.S)
    source = re.sub(r'//.*', '', source)
    source = re.sub(r'""".*?"""', '""', source, flags=re.S)
    source = re.sub(r'"(?:\\.|[^"\\])*"', '""', source)
    source = re.sub(r"'(?:\\.|[^'\\])*'", "''", source)
    return source

for kt in root.rglob("*.kt"):
    src = strip_strings_and_comments(kt.read_text(encoding="utf-8"))
    for opener, closer in [("(", ")"), ("{", "}"), ("[", "]")]:
        if src.count(opener) != src.count(closer):
            errors.append(
                f"delimiter mismatch {opener}{closer}: {kt.relative_to(root)} "
                f"({src.count(opener)} != {src.count(closer)})"
            )

if errors:
    print("PROJECT VERIFY: FAILED")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("PROJECT VERIFY: OK")
print("Package: com.superapp.progressgame")
print("Version code: 14")
print("Version name: 6.0.0-mission-gameplay-core")
print("Renderer: SceneView 4.32.0 / Google Filament")
print("Starter missions:", mission_manifest["missionCount"])
print("Save schema: 4 | World schema: 4")
print("Project files:", sum(1 for p in root.rglob("*") if p.is_file()))
