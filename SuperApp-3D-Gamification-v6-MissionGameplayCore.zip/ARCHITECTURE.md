# Progress World Architecture — V6

## Layers

- `assets/` — asset definitions and starter estate layout
- `engine/scene/` — SceneView/Filament world rendering
- `engine/camera/` — V5 camera director, presets, top view and safety
- `gameplay/mission/` — V6 mission domain, rules, event bus, repository and engine
- `core/storage/` — stable progress save keys and repositories
- `ui/` — gateway, world HUD, mission panel, settings and debug console

## Mission domain

`MissionCatalog` is the authored mission source for V6. `mission_manifest_v1.json` mirrors its public data for validation/tooling. `MissionValidator` verifies ids, targets, rewards, prerequisites and dependency cycles.

`MissionEngine` owns all legal transitions. UI code requests actions but never directly mutates mission persistence.

## Transaction model

`LocalMissionRepository.commitCompletion()` writes mission runtime, active mission, object states, unlocks, reward claims, history, Level, total XP, Coin and Region Progress in one synchronous SharedPreferences commit. A completed/rewarded mission id is checked before reward calculation.

## World binding

`StarterWorldScene` receives persisted `worldObjectStates`. In V6 the fountain visibly switches from off to active and path lamps switch from off to on after their missions. Remaining object states are persisted now and can gain richer visual variants later without changing mission save data.

## Camera binding

Missions store start/completion `CameraDirective` values. WorldShell translates those directives into V5 CameraPresets/CameraDirector sequences, keeping mission logic independent from rendering APIs.
