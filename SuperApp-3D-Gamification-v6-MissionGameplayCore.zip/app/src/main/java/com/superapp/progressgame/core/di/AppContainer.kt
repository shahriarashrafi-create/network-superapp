package com.superapp.progressgame.core.di

import android.content.Context
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.core.storage.LocalProgressRepository
import com.superapp.progressgame.core.storage.ProgressRepository
import com.superapp.progressgame.gameplay.mission.LocalMissionRepository
import com.superapp.progressgame.gameplay.mission.MissionEngine
import com.superapp.progressgame.gameplay.mission.MissionRepository

class AppContainer(context: Context) {
    val preferences = FoundationPreferences(context)
    val progressRepository: ProgressRepository = LocalProgressRepository(context)
    val missionRepository: MissionRepository = LocalMissionRepository(context)
    val missionEngine = MissionEngine(
        repository = missionRepository,
        progressRepository = progressRepository,
    )
}
