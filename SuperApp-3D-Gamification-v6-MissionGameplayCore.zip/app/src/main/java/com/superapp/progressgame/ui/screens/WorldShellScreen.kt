package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.engine.camera.CameraDirector
import com.superapp.progressgame.engine.camera.CameraMode
import com.superapp.progressgame.engine.camera.CameraPreset
import com.superapp.progressgame.engine.camera.CameraPresets
import com.superapp.progressgame.engine.camera.constrainGameCamera
import com.superapp.progressgame.engine.scene.FrameStatsSampler
import com.superapp.progressgame.engine.scene.RendererStats
import com.superapp.progressgame.engine.scene.StarterWorldScene
import com.superapp.progressgame.gameplay.mission.CameraDirective
import com.superapp.progressgame.gameplay.mission.MissionActionResult
import com.superapp.progressgame.gameplay.mission.MissionDefinition
import com.superapp.progressgame.gameplay.mission.MissionEngine
import com.superapp.progressgame.gameplay.mission.MissionGameState
import com.superapp.progressgame.gameplay.mission.MissionRuntimeState
import com.superapp.progressgame.gameplay.mission.MissionState
import com.superapp.progressgame.ui.components.GameHud
import com.superapp.progressgame.ui.components.MissionPanel
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.PrimaryBlue
import com.superapp.progressgame.world.WorldObjectCatalog
import io.github.sceneview.RenderQuality
import io.github.sceneview.SceneView
import io.github.sceneview.SurfaceType
import io.github.sceneview.math.Position
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberFillLightNode
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberOnGestureListener
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun WorldShellScreen(
    progress: PlayerProgress,
    preferences: FoundationPreferences,
    missionEngine: MissionEngine,
    onProgressChanged: (PlayerProgress) -> Unit,
    onBack: () -> Unit,
    onSettings: () -> Unit,
) {
    val engine = rememberEngine()
    val cameraNode = rememberCameraNode(engine)
    val scope = rememberCoroutineScope()

    val persistedCamera = remember {
        val hasPose = preferences.cameraY > 0.8f
        if (preferences.entranceCinematicSeen && hasPose) {
            CameraPreset(
                id = "restored",
                eye = Position(preferences.cameraX, preferences.cameraY, preferences.cameraZ),
                target = Position(preferences.cameraTargetX, preferences.cameraTargetY, preferences.cameraTargetZ),
                minRadius = 2.0f,
                maxRadius = 30.0f,
                fovDegrees = 50f,
            )
        } else CameraPresets.EntranceFront
    }

    var selectedObjectId by remember { mutableStateOf(preferences.selectedObjectId) }
    var cameraPreset by remember { mutableStateOf(persistedCamera) }
    var cameraMode by remember {
        mutableStateOf(
            runCatching { CameraMode.valueOf(preferences.cameraMode.uppercase()) }
                .getOrDefault(CameraMode.FREE)
        )
    }
    var cinematicActive by remember { mutableStateOf(false) }
    var cinematicJob by remember { mutableStateOf<Job?>(null) }
    var stats by remember { mutableStateOf(RendererStats(selectedObjectId = selectedObjectId)) }
    val sampler = remember { FrameStatsSampler() }
    var showHint by remember { mutableStateOf(!preferences.worldHintSeen) }
    var missionState by remember { mutableStateOf(missionEngine.currentState()) }
    var missionPanelOpen by remember { mutableStateOf(missionState.activeMissionId != null) }
    var confirmCompletion by remember { mutableStateOf<Pair<MissionDefinition, MissionRuntimeState>?>(null) }
    var resultMessage by remember { mutableStateOf<String?>(null) }

    fun persistPreset(preset: CameraPreset) {
        preferences.cameraPresetId = preset.id
        preferences.cameraTargetX = preset.target.x
        preferences.cameraTargetY = preset.target.y
        preferences.cameraTargetZ = preset.target.z
    }

    fun applyPreset(preset: CameraPreset, mode: CameraMode) {
        cameraPreset = preset
        cameraMode = mode
        preferences.cameraMode = mode.name.lowercase()
        persistPreset(preset)
    }

    fun startSequence(shots: List<CameraPreset>, finalMode: CameraMode = CameraMode.FREE) {
        cinematicJob?.cancel()
        cinematicJob = scope.launch {
            cinematicActive = true
            cameraMode = CameraMode.CINEMATIC
            preferences.cameraMode = CameraMode.CINEMATIC.name.lowercase()
            shots.forEach { shot ->
                cameraPreset = shot
                persistPreset(shot)
                delay(shot.transitionMillis + 220L)
            }
            cinematicActive = false
            cameraMode = finalMode
            preferences.cameraMode = finalMode.name.lowercase()
            preferences.entranceCinematicSeen = true
        }
    }

    fun skipCinematic() {
        cinematicJob?.cancel()
        cinematicJob = null
        cinematicActive = false
        applyPreset(CameraPresets.Hero, CameraMode.FREE)
        preferences.entranceCinematicSeen = true
    }

    fun focusObject(objectId: String?) {
        val id = objectId ?: selectedObjectId ?: "fountain_main"
        selectedObjectId = id
        preferences.selectedObjectId = id
        applyPreset(CameraPresets.forObject(id), CameraMode.FOCUS)
    }

    fun topView() = applyPreset(CameraPresets.topViewForObject(selectedObjectId), CameraMode.TOP_VIEW)
    fun overview() = applyPreset(CameraPresets.Overview, CameraMode.FREE)
    fun replayEntrance() = startSequence(CameraDirector.entranceSequence, CameraMode.FREE)

    fun applyMissionCamera(definition: MissionDefinition, runtime: MissionRuntimeState?, completion: Boolean) {
        val directive = if (completion) definition.completionCamera else definition.startCamera
        val target = missionEngine.targetObjectFor(definition, runtime)
        selectedObjectId = target
        preferences.selectedObjectId = target
        when (directive) {
            CameraDirective.NONE -> Unit
            CameraDirective.FOCUS,
            CameraDirective.CLOSE_UP -> applyPreset(CameraPresets.forObject(target), CameraMode.FOCUS)
            CameraDirective.REVEAL -> startSequence(
                listOf(CameraPresets.forObject(target), CameraPresets.Hero),
                CameraMode.FREE,
            )
            CameraDirective.OVERVIEW -> applyPreset(CameraPresets.Overview, CameraMode.FREE)
            CameraDirective.TRAVEL -> startSequence(CameraDirector.travelSequence, CameraMode.FREE)
            CameraDirective.CELEBRATION -> startSequence(
                listOf(CameraPresets.forObject(target), CameraPresets.Celebration),
                CameraMode.FREE,
            )
        }
    }

    fun consumeResult(result: MissionActionResult, cameraDefinition: MissionDefinition? = null, completion: Boolean = false) {
        missionState = result.state
        onProgressChanged(result.progress)
        resultMessage = result.message ?: result.events.lastOrNull()?.message
        if (cameraDefinition != null) {
            val runtime = result.state.runtime(cameraDefinition.id)
            applyMissionCamera(cameraDefinition, runtime, completion)
        }
        missionPanelOpen = true
    }

    fun startMission(definition: MissionDefinition) {
        val result = missionEngine.startMission(definition.id)
        consumeResult(result, definition, completion = false)
    }

    fun advanceMission(definition: MissionDefinition, runtime: MissionRuntimeState) {
        val finalStep = runtime.progress + 1 >= definition.objective.requiredUnits
        if (definition.confirmCompletion && finalStep) {
            confirmCompletion = definition to runtime
            return
        }
        val result = missionEngine.advanceOrComplete(definition.id)
        consumeResult(result, definition, completion = result.state.runtime(definition.id)?.state == MissionState.COMPLETED)
    }

    LaunchedEffect(Unit) {
        missionState = missionEngine.currentState()
        if (!preferences.entranceCinematicSeen) {
            delay(350L)
            startSequence(CameraDirector.entranceSequence, CameraMode.FREE)
        }
    }

    LaunchedEffect(showHint) {
        if (showHint) {
            delay(5200)
            showHint = false
            preferences.worldHintSeen = true
        }
    }

    LaunchedEffect(resultMessage) {
        if (resultMessage != null) {
            delay(2800L)
            resultMessage = null
        }
    }

    LaunchedEffect(cameraPreset.fovDegrees) {
        delay(80L)
        cameraNode.setProjection(cameraPreset.fovDegrees.toDouble())
    }

    val cameraManipulator = rememberCameraManipulator(
        orbitHomePosition = cameraPreset.eye,
        targetPosition = cameraPreset.target,
    )

    fun selectObject(rawName: String?, focus: Boolean) {
        if (cinematicActive) return
        val objectId = WorldObjectCatalog.normalize(rawName)
        selectedObjectId = objectId
        preferences.selectedObjectId = objectId
        if (objectId != null) {
            missionEngine.recordInteraction(objectId)?.let { result ->
                val active = missionState.activeDefinition()
                consumeResult(result, active, completion = active != null && result.state.runtime(active.id)?.state == MissionState.COMPLETED)
            }
        }
        if (focus && objectId != null) {
            applyPreset(CameraPresets.forObject(objectId), CameraMode.FOCUS)
        } else if (objectId == null) {
            cameraMode = CameraMode.FREE
            preferences.cameraMode = CameraMode.FREE.name.lowercase()
        }
    }

    val activeRuntime = missionState.runtime(missionState.activeMissionId)
    val activeMissionRunning = activeRuntime?.state == MissionState.ACTIVE
    val panelMission = if (missionPanelOpen) missionState.focusMission() else null
    val panelRuntime = panelMission?.let { missionState.runtime(it.id) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF071521), Color(0xFF123349), Color(0xFF355968))
                )
            )
    ) {
        SceneView(
            modifier = Modifier.fillMaxSize(),
            surfaceType = SurfaceType.TextureSurface,
            isOpaque = false,
            renderQuality = RenderQuality.Cinematic,
            engine = engine,
            cameraNode = cameraNode,
            cameraManipulator = cameraManipulator,
            autoCenterContent = false,
            mainLightNode = rememberMainLightNode(engine) { intensity = 58_000f },
            fillLightNode = rememberFillLightNode(engine) { intensity = 8_000f },
            onGestureListener = rememberOnGestureListener(
                onSingleTapConfirmed = { _, node -> selectObject(node?.name, focus = false) },
                onDoubleTap = { _, node -> selectObject(node?.name, focus = true) },
            ),
            onFrame = { frameTimeNanos ->
                val constrained = constrainGameCamera(
                    camera = cameraNode.worldPosition,
                    preset = cameraPreset,
                    mode = cameraMode,
                )
                if (constrained != cameraNode.worldPosition) cameraNode.worldPosition = constrained

                sampler.sample(
                    frameTimeNanos = frameTimeNanos,
                    cameraPosition = constrained,
                    selectedObjectId = selectedObjectId,
                    cameraPresetId = cameraPreset.id,
                )?.let {
                    stats = it
                    preferences.cameraX = constrained.x
                    preferences.cameraY = constrained.y
                    preferences.cameraZ = constrained.z
                    preferences.cameraTargetX = cameraPreset.target.x
                    preferences.cameraTargetY = cameraPreset.target.y
                    preferences.cameraTargetZ = cameraPreset.target.z
                }
            },
        ) {
            StarterWorldScene(
                selectedObjectId = selectedObjectId,
                worldObjectStates = missionState.objectStates,
            )
        }

        if (activeMissionRunning) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.06f))
            )
        }

        GameHud(
            progress = progress,
            onSettings = onSettings,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        )

        Row(
            modifier = Modifier.align(Alignment.BottomStart).padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CameraIconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = "برگشت", tint = Color.White) }
            CameraIconButton(onClick = ::overview) { Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "نمای کلی", tint = Color.White) }
            CameraIconButton(onClick = ::topView) { Icon(Icons.Rounded.Map, contentDescription = "نمای بالا", tint = Color.White) }
        }

        Row(
            modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CameraIconButton(onClick = { focusObject(selectedObjectId) }) { Icon(Icons.Rounded.MyLocation, contentDescription = "فوکوس آبجکت", tint = Color.White) }
            CameraIconButton(onClick = ::replayEntrance) { Icon(Icons.Rounded.Movie, contentDescription = "پخش سینمای ورودی", tint = Color.White) }
            CameraIconButton(onClick = { startSequence(CameraDirector.travelSequence, CameraMode.FREE) }) { Icon(Icons.Rounded.Refresh, contentDescription = "سفر سینمایی", tint = Color.White) }
        }

        FloatingActionButton(
            onClick = {
                val mission = missionState.focusMission()
                if (mission != null) {
                    missionPanelOpen = true
                    val runtime = missionState.runtime(mission.id)
                    val target = missionEngine.targetObjectFor(mission, runtime)
                    focusObject(target)
                }
            },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 16.dp).size(38.dp),
            containerColor = PrimaryBlue,
            contentColor = Color.White,
        ) {
            Icon(Icons.Rounded.Flag, contentDescription = "ماموریت فعال")
        }

        if (panelMission != null && panelRuntime != null) {
            MissionPanel(
                definition = panelMission,
                runtime = panelRuntime,
                missionEngine = missionEngine,
                onStart = { startMission(panelMission) },
                onAdvanceOrComplete = { advanceMission(panelMission, panelRuntime) },
                onPause = { consumeResult(missionEngine.pauseMission(panelMission.id)) },
                onResume = { consumeResult(missionEngine.resumeMission(panelMission.id), panelMission, false) },
                onCancel = { consumeResult(missionEngine.cancelMission(panelMission.id)) },
                onFocusTarget = {
                    val target = missionEngine.targetObjectFor(panelMission, panelRuntime)
                    focusObject(target)
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 64.dp)
                    .widthIn(max = 540.dp),
            )
        }

        if (cinematicActive) {
            CameraIconButton(
                onClick = ::skipCinematic,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 54.dp),
            ) {
                Icon(Icons.Rounded.Close, contentDescription = "رد کردن سینماتیک", tint = Color.White)
            }
        }

        if (showHint) {
            Text(
                text = "Orbit 360° • Pan • Pinch/Dolly • دوبار لمس: Focus • Map: Top View • Flag: Mission",
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = if (panelMission == null) 62.dp else 190.dp)
                    .background(Color.Black.copy(alpha = 0.34f), RoundedCornerShape(12.dp))
                    .clickable {
                        showHint = false
                        preferences.worldHintSeen = true
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 9.sp,
            )
        }

        selectedObjectId?.let { selectedId ->
            WorldObjectCatalog.definition(selectedId)?.let { definition ->
                val activeTarget = missionState.activeDefinition()?.let { mission ->
                    missionEngine.targetObjectFor(mission, missionState.runtime(mission.id))
                }
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 14.dp)
                        .background(DeepSurface.copy(alpha = 0.76f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(definition.displayName, color = Color.White.copy(alpha = 0.96f), fontSize = 10.sp)
                    Text(
                        text = if (activeTarget == selectedId) "هدف ماموریت فعال" else if (cameraMode == CameraMode.FOCUS) "Orbit روی آبجکت فعال است" else "دوبار لمس برای فوکوس",
                        color = AccentCyan.copy(alpha = 0.88f),
                        fontSize = 8.sp,
                    )
                }
            }
        }

        resultMessage?.let { message ->
            Text(
                text = message,
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(DeepSurface.copy(alpha = 0.90f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                color = Color.White,
                fontSize = 11.sp,
            )
        }

        if (preferences.debugOverlayEnabled) {
            Debug3DOverlay(
                stats = stats,
                cameraMode = cameraMode,
                fovDegrees = cameraPreset.fovDegrees,
                missionState = missionState,
                modifier = Modifier.align(Alignment.CenterEnd).padding(14.dp),
            )
        }
    }

    confirmCompletion?.let { (definition, _) ->
        AlertDialog(
            onDismissRequest = { confirmCompletion = null },
            title = { Text("تکمیل ماموریت مهم") },
            text = { Text("«${definition.title}» کامل شود و پاداش و تغییر جهان ثبت شود؟") },
            confirmButton = {
                Button(onClick = {
                    confirmCompletion = null
                    val result = missionEngine.advanceOrComplete(definition.id)
                    consumeResult(result, definition, completion = true)
                }) { Text("تکمیل") }
            },
            dismissButton = {
                TextButton(onClick = { confirmCompletion = null }) { Text("فعلاً نه") }
            },
        )
    }
}

@Composable
private fun CameraIconButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    IconButton(
        onClick = onClick,
        modifier = modifier.size(34.dp).background(DeepSurface.copy(alpha = 0.74f), RoundedCornerShape(12.dp)),
    ) { content() }
}

@Composable
private fun Debug3DOverlay(
    stats: RendererStats,
    cameraMode: CameraMode,
    fovDegrees: Float,
    missionState: MissionGameState,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.background(Color.Black.copy(alpha = 0.58f), RoundedCornerShape(12.dp)).padding(horizontal = 11.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Text("3D + MISSION DEBUG", color = AccentCyan, fontSize = 9.sp)
        Text("FPS ${stats.fps}", color = Color.White, fontSize = 8.sp)
        Text("Objects ${stats.objectCount}", color = Color.White, fontSize = 8.sp)
        Text("Camera %.1f / %.1f / %.1f".format(stats.cameraPosition.x, stats.cameraPosition.y, stats.cameraPosition.z), color = Color.White, fontSize = 8.sp)
        Text("Mode ${cameraMode.name} • FOV ${fovDegrees.toInt()}°", color = Color.White, fontSize = 8.sp)
        Text("Mission ${missionState.activeMissionId ?: "—"}", color = Color.White, fontSize = 8.sp)
        Text("Region ${missionState.regionProgressPercent}%", color = Color.White, fontSize = 8.sp)
        Text("Hit ${stats.selectedObjectId ?: "—"}", color = Color.White, fontSize = 8.sp)
    }
}
