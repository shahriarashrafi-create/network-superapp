package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.core.storage.GraphicsProfile
import com.superapp.progressgame.ui.theme.DeepSurface

@Composable
fun SettingsScreen(
    preferences: FoundationPreferences,
    onResetMissionProgress: () -> Unit,
    onResetRegionProgress: () -> Unit,
    onResetProgress: () -> Unit,
    onBack: () -> Unit,
) {
    var graphics by remember { mutableStateOf(preferences.graphicsProfile) }
    var sound by remember { mutableStateOf(preferences.soundEnabled) }
    var haptics by remember { mutableStateOf(preferences.hapticsEnabled) }
    var debug by remember { mutableStateOf(preferences.debugOverlayEnabled) }
    var pendingReset by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("تنظیمات جهان", color = Color.White, fontSize = 27.sp)
        Text(
            "تنظیمات، دوربین، ماموریت‌ها و پیشرفت روی همین دستگاه ذخیره می‌شوند.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp,
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSurface, RoundedCornerShape(22.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp),
        ) {
            Text("کیفیت گرافیک", color = Color.White, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GraphicsProfile.entries.forEach { profile ->
                    FilterChip(
                        selected = graphics == profile,
                        onClick = {
                            graphics = profile
                            preferences.graphicsProfile = profile
                        },
                        label = { Text(profile.displayName()) },
                    )
                }
            }
            ToggleSetting("صدا", sound) {
                sound = it
                preferences.soundEnabled = it
            }
            ToggleSetting("بازخورد لمسی", haptics) {
                haptics = it
                preferences.hapticsEnabled = it
            }
            ToggleSetting("اطلاعات فنی روی جهان", debug) {
                debug = it
                preferences.debugOverlayEnabled = it
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSurface, RoundedCornerShape(22.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            Text("بازنشانی پیشرفت", color = Color.White, fontSize = 14.sp)
            Text(
                "بازنشانی ماموریت یا منطقه پاداش قبلی را دوباره قابل دریافت نمی‌کند؛ بازنشانی کامل همه‌چیز را صفر می‌کند.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 10.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { pendingReset = "mission" }) { Text("ماموریت فعال") }
                OutlinedButton(onClick = { pendingReset = "region" }) { Text("منطقه") }
                OutlinedButton(onClick = { pendingReset = "all" }) { Text("کل بازی") }
            }
        }

        Spacer(Modifier.height(2.dp))
        Button(onClick = onBack) { Text("ذخیره و برگشت") }
    }

    pendingReset?.let { kind ->
        val title = when (kind) {
            "mission" -> "بازنشانی ماموریت؟"
            "region" -> "بازنشانی منطقه؟"
            else -> "بازنشانی کامل بازی؟"
        }
        val body = when (kind) {
            "mission" -> "پیشرفت ماموریت فعال یا بعدی صفر شود؟"
            "region" -> "وضعیت ماموریت‌ها و تغییرات دنیای این منطقه به حالت اولیه برگردد؟"
            else -> "XP، Coin، ماموریت‌ها، Unlockها و وضعیت دنیا همگی صفر می‌شوند."
        }
        AlertDialog(
            onDismissRequest = { pendingReset = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = {
                TextButton(onClick = {
                    when (kind) {
                        "mission" -> onResetMissionProgress()
                        "region" -> onResetRegionProgress()
                        else -> onResetProgress()
                    }
                    pendingReset = null
                }) { Text("تأیید") }
            },
            dismissButton = {
                TextButton(onClick = { pendingReset = null }) { Text("لغو") }
            },
        )
    }
}

@Composable
private fun ToggleSetting(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Switch(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}

private fun GraphicsProfile.displayName(): String = when (this) {
    GraphicsProfile.AUTO -> "خودکار"
    GraphicsProfile.PERFORMANCE -> "روان‌تر"
    GraphicsProfile.QUALITY -> "کیفیت بیشتر"
}
