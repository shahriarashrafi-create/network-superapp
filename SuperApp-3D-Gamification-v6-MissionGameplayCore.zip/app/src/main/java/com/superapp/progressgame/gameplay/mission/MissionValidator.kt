package com.superapp.progressgame.gameplay.mission

import com.superapp.progressgame.world.WorldObjectCatalog

object MissionValidator {
    fun validate(definitions: List<MissionDefinition>): List<String> {
        val errors = mutableListOf<String>()
        val ids = definitions.map { it.id }
        if (ids.size != ids.toSet().size) errors += "mission ids must be unique"
        val byId = definitions.associateBy { it.id }

        definitions.forEach { mission ->
            if (mission.id.isBlank()) errors += "mission id is blank"
            if (mission.regionId.isBlank()) errors += "${mission.id}: region is blank"
            if (mission.xpReward < 0 || mission.coinReward < 0) errors += "${mission.id}: reward cannot be negative"
            if (WorldObjectCatalog.definition(mission.targetObjectId) == null) {
                errors += "${mission.id}: missing target ${mission.targetObjectId}"
            }
            mission.objective.steps.forEach { step ->
                val target = step.targetObjectId
                if (target != null && WorldObjectCatalog.definition(target) == null) {
                    errors += "${mission.id}: missing step target $target"
                }
            }
            mission.unlockRule.requiredMissionIds.forEach { dependency ->
                if (byId[dependency] == null) errors += "${mission.id}: missing dependency $dependency"
            }
            mission.nextMissionIds.forEach { next ->
                if (byId[next] == null) errors += "${mission.id}: missing next mission $next"
            }
        }

        val visiting = mutableSetOf<String>()
        val visited = mutableSetOf<String>()
        fun visit(id: String) {
            if (id in visited) return
            if (!visiting.add(id)) {
                errors += "dependency cycle detected at $id"
                return
            }
            byId[id]?.unlockRule?.requiredMissionIds?.forEach(::visit)
            visiting.remove(id)
            visited.add(id)
        }
        ids.forEach(::visit)

        return errors.distinct()
    }
}
