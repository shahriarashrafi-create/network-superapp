package com.superapp.progressgame.core.storage

import android.content.Context
import com.superapp.progressgame.core.config.AppConfig
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.gameplay.mission.LevelRules

class LocalProgressRepository(context: Context) : ProgressRepository {
    private val prefs = context.getSharedPreferences(SaveKeys.PREFS_NAME, Context.MODE_PRIVATE)

    override fun load(): PlayerProgress {
        val storedSchema = prefs.getInt(SaveKeys.KEY_SCHEMA, 1)
        if (storedSchema < AppConfig.SAVE_SCHEMA_VERSION) {
            prefs.edit().putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION).apply()
        }

        val totalXp = prefs.getInt(SaveKeys.KEY_XP, 0).coerceAtLeast(0)
        val storedLevel = prefs.getInt(SaveKeys.KEY_LEVEL, 1).coerceAtLeast(1)
        val derivedLevel = LevelRules.levelFromTotalXp(totalXp)
        return PlayerProgress(
            level = maxOf(storedLevel, derivedLevel),
            xp = totalXp,
            coins = prefs.getInt(SaveKeys.KEY_COINS, 0).coerceAtLeast(0),
            activeRegionId = prefs.getString(SaveKeys.KEY_REGION, AppConfig.DEFAULT_REGION_ID)
                ?: AppConfig.DEFAULT_REGION_ID,
            regionProgressPercent = prefs.getInt(SaveKeys.KEY_REGION_PROGRESS, 0).coerceIn(0, 100),
        )
    }

    override fun save(progress: PlayerProgress) {
        prefs.edit()
            .putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)
            .putInt(SaveKeys.KEY_LEVEL, progress.level)
            .putInt(SaveKeys.KEY_XP, progress.xp)
            .putInt(SaveKeys.KEY_COINS, progress.coins)
            .putString(SaveKeys.KEY_REGION, progress.activeRegionId)
            .putInt(SaveKeys.KEY_REGION_PROGRESS, progress.regionProgressPercent)
            .apply()
    }

    override fun reset(): PlayerProgress {
        val fresh = PlayerProgress()
        prefs.edit()
            .remove(SaveKeys.KEY_LEVEL)
            .remove(SaveKeys.KEY_XP)
            .remove(SaveKeys.KEY_COINS)
            .remove(SaveKeys.KEY_REGION)
            .remove(SaveKeys.KEY_REGION_PROGRESS)
            .putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)
            .apply()
        save(fresh)
        return fresh
    }
}
