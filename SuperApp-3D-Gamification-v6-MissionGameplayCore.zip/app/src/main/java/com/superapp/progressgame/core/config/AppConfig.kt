package com.superapp.progressgame.core.config

object AppConfig {
    const val APP_ID = "com.superapp.progressgame"
    const val FOUNDATION_VERSION = "6.0.0-mission-gameplay-core"
    const val SAVE_SCHEMA_VERSION = 4
    const val WORLD_SCHEMA_VERSION = 4
    const val ASSET_SCHEMA_VERSION = 1
    const val DEFAULT_REGION_ID = "starter_estate"
    const val DEFAULT_CAMERA_PROFILE = "hero"
    const val RENDERER_NAME = "SceneView 4.32 + Google Filament"
}
