package com.superapp.progressgame.gameplay.mission

object LevelRules {
    fun xpRequiredForLevel(level: Int): Int {
        val safe = level.coerceAtLeast(1)
        return 100 + (safe - 1) * 55 + (safe - 1) * (safe - 1) * 8
    }

    fun totalXpAtLevelStart(level: Int): Int {
        var total = 0
        for (current in 1 until level.coerceAtLeast(1)) {
            total += xpRequiredForLevel(current)
        }
        return total
    }

    fun levelFromTotalXp(totalXp: Int): Int {
        var level = 1
        var remaining = totalXp.coerceAtLeast(0)
        while (remaining >= xpRequiredForLevel(level) && level < 999) {
            remaining -= xpRequiredForLevel(level)
            level += 1
        }
        return level
    }

    fun xpIntoCurrentLevel(totalXp: Int): Int {
        val level = levelFromTotalXp(totalXp)
        return (totalXp - totalXpAtLevelStart(level)).coerceAtLeast(0)
    }

    fun xpNeededForCurrentLevel(totalXp: Int): Int = xpRequiredForLevel(levelFromTotalXp(totalXp))

    fun fraction(totalXp: Int): Float {
        val needed = xpNeededForCurrentLevel(totalXp).coerceAtLeast(1)
        return (xpIntoCurrentLevel(totalXp).toFloat() / needed.toFloat()).coerceIn(0f, 1f)
    }
}
