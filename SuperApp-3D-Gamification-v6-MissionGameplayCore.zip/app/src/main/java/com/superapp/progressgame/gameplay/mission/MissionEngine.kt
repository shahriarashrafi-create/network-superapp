package com.superapp.progressgame.gameplay.mission

import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.ProgressRepository
import com.superapp.progressgame.world.WorldObjectCatalog

class MissionEngine(
    private val repository: MissionRepository,
    private val progressRepository: ProgressRepository,
    val eventBus: MissionEventBus = MissionEventBus(),
) {
    private val definitions = MissionCatalog.all
    private val validationErrors = MissionValidator.validate(definitions)

    @Synchronized
    fun currentState(): MissionGameState = deriveState(repository.load(), progressRepository.load())

    @Synchronized
    fun startMission(missionId: String, force: Boolean = false): MissionActionResult {
        val progress = progressRepository.load()
        var snapshot = repository.load()
        val state = deriveState(snapshot, progress)
        val definition = state.definition(missionId)
            ?: return resultWithMessage(state, progress, "ماموریت پیدا نشد")
        val runtime = state.runtime(missionId) ?: MissionRuntimeState(missionId)
        val allowed = force || runtime.state in setOf(MissionState.AVAILABLE, MissionState.CANCELLED, MissionState.PAUSED)
        if (!allowed) return resultWithMessage(state, progress, "این ماموریت هنوز آماده شروع نیست")

        val now = System.currentTimeMillis()
        val states = snapshot.runtimeStates.toMutableMap()
        snapshot.activeMissionId?.takeIf { it != missionId }?.let { previousId ->
            val previous = states[previousId]
            if (previous?.state == MissionState.ACTIVE) {
                states[previousId] = previous.copy(state = MissionState.PAUSED)
            }
        }
        states[missionId] = runtime.copy(
            state = MissionState.ACTIVE,
            startedAtMillis = runtime.startedAtMillis.takeIf { it > 0L } ?: now,
            errorMessage = null,
        )
        snapshot = snapshot.copy(runtimeStates = states, activeMissionId = missionId)
        if (!repository.save(snapshot)) return storageFailure(progress)

        val event = MissionEvent(MissionEventType.MISSION_STARTED, missionId, "${definition.title} شروع شد")
        eventBus.emit(event)
        return MissionActionResult(deriveState(snapshot, progress), progress, listOf(event))
    }

    @Synchronized
    fun pauseMission(missionId: String): MissionActionResult = changeActiveState(
        missionId = missionId,
        expected = setOf(MissionState.ACTIVE),
        target = MissionState.PAUSED,
        eventType = MissionEventType.MISSION_PAUSED,
        message = "ماموریت متوقف شد",
        clearActive = false,
    )

    @Synchronized
    fun resumeMission(missionId: String): MissionActionResult {
        val progress = progressRepository.load()
        var snapshot = repository.load()
        val state = deriveState(snapshot, progress)
        val runtime = state.runtime(missionId) ?: return resultWithMessage(state, progress, "ماموریت پیدا نشد")
        if (runtime.state != MissionState.PAUSED) return resultWithMessage(state, progress, "ماموریت در حالت توقف نیست")
        val states = snapshot.runtimeStates.toMutableMap()
        snapshot.activeMissionId?.takeIf { it != missionId }?.let { previousId ->
            states[previousId]?.let { previous ->
                if (previous.state == MissionState.ACTIVE) states[previousId] = previous.copy(state = MissionState.PAUSED)
            }
        }
        states[missionId] = runtime.copy(state = MissionState.ACTIVE)
        snapshot = snapshot.copy(runtimeStates = states, activeMissionId = missionId)
        if (!repository.save(snapshot)) return storageFailure(progress)
        val event = MissionEvent(MissionEventType.MISSION_RESUMED, missionId, "ماموریت ادامه پیدا کرد")
        eventBus.emit(event)
        return MissionActionResult(deriveState(snapshot, progress), progress, listOf(event))
    }

    @Synchronized
    fun cancelMission(missionId: String): MissionActionResult = changeActiveState(
        missionId = missionId,
        expected = setOf(MissionState.ACTIVE, MissionState.PAUSED),
        target = MissionState.CANCELLED,
        eventType = MissionEventType.MISSION_CANCELLED,
        message = "ماموریت لغو شد و بعداً قابل شروع است",
        clearActive = true,
    )

    @Synchronized
    fun advanceOrComplete(missionId: String): MissionActionResult {
        val progress = progressRepository.load()
        var snapshot = repository.load()
        val state = deriveState(snapshot, progress)
        val definition = state.definition(missionId)
            ?: return resultWithMessage(state, progress, "ماموریت پیدا نشد")
        val runtime = state.runtime(missionId)
            ?: return resultWithMessage(state, progress, "وضعیت ماموریت پیدا نشد")
        if (runtime.state != MissionState.ACTIVE) {
            return resultWithMessage(state, progress, "برای ثبت پیشرفت ابتدا ماموریت را شروع کن")
        }

        val required = definition.objective.requiredUnits
        val nextProgress = (runtime.progress + 1).coerceAtMost(required)
        if (nextProgress < required) {
            val updated = runtime.copy(progress = nextProgress, stepIndex = nextProgress)
            snapshot = snapshot.copy(runtimeStates = snapshot.runtimeStates + (missionId to updated))
            if (!repository.save(snapshot)) return storageFailure(progress)
            val event = MissionEvent(
                MissionEventType.MISSION_PROGRESS,
                missionId,
                "پیشرفت ${definition.title}: $nextProgress/$required",
            )
            eventBus.emit(event)
            return MissionActionResult(deriveState(snapshot, progress), progress, listOf(event))
        }

        return completeInternal(definition, runtime.copy(progress = required, stepIndex = required), snapshot, progress)
    }

    @Synchronized
    fun recordInteraction(objectId: String): MissionActionResult? {
        val state = currentState()
        val active = state.activeDefinition() ?: return null
        val runtime = state.runtime(active.id) ?: return null
        if (runtime.state != MissionState.ACTIVE) return null
        val expectedTarget = targetObjectFor(active, runtime)
        if (objectId != expectedTarget) return null
        if (active.objective.type !in setOf(MissionObjectiveType.INTERACT, MissionObjectiveType.COUNT, MissionObjectiveType.MULTI_STEP)) {
            return null
        }
        return advanceOrComplete(active.id)
    }

    @Synchronized
    fun completeNowForDebug(missionId: String): MissionActionResult {
        val progress = progressRepository.load()
        var snapshot = repository.load()
        var state = deriveState(snapshot, progress)
        val definition = state.definition(missionId)
            ?: return resultWithMessage(state, progress, "ماموریت پیدا نشد")
        if (state.runtime(missionId)?.state == MissionState.COMPLETED) {
            return MissionActionResult(state, progress, message = "ماموریت قبلاً کامل شده")
        }
        if (state.runtime(missionId)?.state != MissionState.ACTIVE) {
            val start = startMission(missionId, force = true)
            snapshot = repository.load()
            state = start.state
        }
        val runtime = state.runtime(missionId) ?: MissionRuntimeState(missionId, MissionState.ACTIVE)
        return completeInternal(
            definition,
            runtime.copy(progress = definition.objective.requiredUnits, stepIndex = definition.objective.requiredUnits),
            snapshot,
            progressRepository.load(),
        )
    }

    @Synchronized
    fun forceUnlock(missionId: String): MissionActionResult {
        val progress = progressRepository.load()
        val snapshot = repository.load()
        if (MissionCatalog.definition(missionId) == null) return resultWithMessage(deriveState(snapshot, progress), progress, "ماموریت پیدا نشد")
        val updated = snapshot.copy(forcedUnlockedMissionIds = snapshot.forcedUnlockedMissionIds + missionId)
        if (!repository.save(updated)) return storageFailure(progress)
        return MissionActionResult(deriveState(updated, progress), progress, message = "ماموریت برای تست باز شد")
    }

    @Synchronized
    fun resetMission(missionId: String): MissionActionResult {
        val progress = progressRepository.load()
        val snapshot = repository.load()
        val runtimes = snapshot.runtimeStates - missionId
        val rebuiltObjects = rebuildObjectStates(runtimes)
        val updated = snapshot.copy(
            runtimeStates = runtimes,
            activeMissionId = snapshot.activeMissionId.takeUnless { it == missionId },
            objectStates = rebuiltObjects,
            forcedUnlockedMissionIds = snapshot.forcedUnlockedMissionIds - missionId,
        )
        if (!repository.save(updated)) return storageFailure(progress)
        val regionProgress = calculateRegionProgress(MissionCatalog.REGION_STARTER, runtimes)
        val updatedProgress = progress.copy(regionProgressPercent = regionProgress)
        progressRepository.save(updatedProgress)
        return MissionActionResult(deriveState(updated, updatedProgress), updatedProgress, message = "پیشرفت ماموریت بازنشانی شد؛ پاداش قبلی دوباره پرداخت نمی‌شود")
    }

    @Synchronized
    fun resetRegion(regionId: String = MissionCatalog.REGION_STARTER): MissionActionResult {
        val progress = progressRepository.load()
        val snapshot = repository.load()
        val ids = definitions.filter { it.regionId == regionId }.map { it.id }.toSet()
        val runtimes = snapshot.runtimeStates.filterKeys { it !in ids }
        val updated = snapshot.copy(
            runtimeStates = runtimes,
            activeMissionId = snapshot.activeMissionId?.takeUnless { it in ids },
            objectStates = rebuildObjectStates(runtimes),
            forcedUnlockedMissionIds = snapshot.forcedUnlockedMissionIds - ids,
        )
        if (!repository.save(updated)) return storageFailure(progress)
        val updatedProgress = progress.copy(regionProgressPercent = 0)
        progressRepository.save(updatedProgress)
        return MissionActionResult(deriveState(updated, updatedProgress), updatedProgress, message = "پیشرفت منطقه بازنشانی شد؛ پاداش‌های قبلی قابل تکرار نیستند")
    }

    @Synchronized
    fun resetAll(): MissionActionResult {
        repository.clearMissionData()
        val fresh = progressRepository.reset()
        return MissionActionResult(currentState(), fresh, message = "کل پیشرفت بازی بازنشانی شد")
    }

    fun targetObjectFor(definition: MissionDefinition, runtime: MissionRuntimeState?): String {
        val requested = if (definition.objective.type == MissionObjectiveType.MULTI_STEP && definition.objective.steps.isNotEmpty()) {
            val index = (runtime?.progress ?: 0).coerceIn(0, definition.objective.steps.lastIndex)
            definition.objective.steps[index].targetObjectId ?: definition.targetObjectId
        } else {
            definition.targetObjectId
        }
        return when {
            WorldObjectCatalog.definition(requested) != null -> requested
            WorldObjectCatalog.definition(definition.targetObjectId) != null -> definition.targetObjectId
            else -> "fountain_main"
        }
    }

    fun nextStepLabel(definition: MissionDefinition, runtime: MissionRuntimeState?): String? {
        if (definition.objective.type != MissionObjectiveType.MULTI_STEP || definition.objective.steps.isEmpty()) return null
        val index = (runtime?.progress ?: 0).coerceIn(0, definition.objective.steps.lastIndex)
        return definition.objective.steps[index].title
    }

    private fun completeInternal(
        definition: MissionDefinition,
        completedRuntime: MissionRuntimeState,
        originalSnapshot: MissionPersistenceSnapshot,
        originalProgress: PlayerProgress,
    ): MissionActionResult {
        if (definition.id in originalSnapshot.rewardedMissionIds || originalSnapshot.runtimeStates[definition.id]?.state == MissionState.COMPLETED) {
            val state = deriveState(originalSnapshot, originalProgress)
            return MissionActionResult(state, originalProgress, message = "این ماموریت قبلاً ثبت شده و پاداش دوباره پرداخت نمی‌شود")
        }

        val now = System.currentTimeMillis()
        val runtimes = originalSnapshot.runtimeStates.toMutableMap()
        runtimes[definition.id] = completedRuntime.copy(
            state = MissionState.COMPLETED,
            progress = definition.objective.requiredUnits,
            stepIndex = definition.objective.requiredUnits,
            completedAtMillis = now,
        )
        val objects = originalSnapshot.objectStates.toMutableMap().apply {
            definition.worldChanges.forEach { change -> put(change.objectId, change.newState) }
        }
        val history = (originalSnapshot.history + MissionHistoryEntry(
            missionId = definition.id,
            completedAtMillis = now,
            xpReward = definition.xpReward,
            coinReward = definition.coinReward,
        )).takeLast(100)

        val regionProgress = calculateRegionProgress(definition.regionId, runtimes)
        val newTotalXp = originalProgress.xp + definition.xpReward
        val newLevel = LevelRules.levelFromTotalXp(newTotalXp)
        var unlockedRegions = originalSnapshot.unlockedRegions
        val regionCompleted = regionProgress >= 100
        var regionUnlocked = false
        if (regionCompleted && "growth_district" !in unlockedRegions) {
            unlockedRegions = unlockedRegions + "growth_district"
            regionUnlocked = true
        }
        val updatedProgress = originalProgress.copy(
            level = newLevel,
            xp = newTotalXp,
            coins = originalProgress.coins + definition.coinReward,
            regionProgressPercent = regionProgress,
        )
        val snapshot = originalSnapshot.copy(
            runtimeStates = runtimes,
            activeMissionId = null,
            objectStates = objects,
            unlockedRegions = unlockedRegions,
            rewardedMissionIds = originalSnapshot.rewardedMissionIds + definition.id,
            history = history,
        )
        if (!repository.commitCompletion(snapshot, updatedProgress)) return storageFailure(originalProgress)

        val events = buildList {
            add(MissionEvent(MissionEventType.MISSION_COMPLETED, definition.id, "${definition.title} کامل شد"))
            add(MissionEvent(MissionEventType.REWARD_GRANTED, definition.id, "+${definition.xpReward} XP  •  +${definition.coinReward} Coin"))
            if (newLevel > originalProgress.level) {
                add(MissionEvent(MissionEventType.LEVEL_UP, definition.id, "Level $newLevel باز شد"))
            }
            if (regionCompleted) {
                add(MissionEvent(MissionEventType.REGION_COMPLETED, definition.id, "منطقهٔ آغازین ۱۰۰٪ کامل شد"))
            }
            if (regionUnlocked) {
                add(MissionEvent(MissionEventType.REGION_UNLOCKED, definition.id, "منطقهٔ بعدی باز شد"))
            }
        }
        events.forEach(eventBus::emit)
        return MissionActionResult(deriveState(snapshot, updatedProgress), updatedProgress, events)
    }

    private fun changeActiveState(
        missionId: String,
        expected: Set<MissionState>,
        target: MissionState,
        eventType: MissionEventType,
        message: String,
        clearActive: Boolean,
    ): MissionActionResult {
        val progress = progressRepository.load()
        val snapshot = repository.load()
        val state = deriveState(snapshot, progress)
        val runtime = state.runtime(missionId) ?: return resultWithMessage(state, progress, "ماموریت پیدا نشد")
        if (runtime.state !in expected) return resultWithMessage(state, progress, "تغییر وضعیت مجاز نیست")
        val updated = snapshot.copy(
            runtimeStates = snapshot.runtimeStates + (missionId to runtime.copy(state = target)),
            activeMissionId = if (clearActive) null else missionId,
        )
        if (!repository.save(updated)) return storageFailure(progress)
        val event = MissionEvent(eventType, missionId, message)
        eventBus.emit(event)
        return MissionActionResult(deriveState(updated, progress), progress, listOf(event))
    }

    private fun deriveState(snapshot: MissionPersistenceSnapshot, progress: PlayerProgress): MissionGameState {
        val completed = snapshot.runtimeStates.filterValues { it.state == MissionState.COMPLETED }.keys
        val regionProgress = calculateRegionProgress(MissionCatalog.REGION_STARTER, snapshot.runtimeStates)
        val derived = definitions.associate { definition ->
            val persisted = snapshot.runtimeStates[definition.id]
            val runtime = when {
                WorldObjectCatalog.definition(definition.targetObjectId) == null -> (persisted ?: MissionRuntimeState(definition.id)).copy(state = MissionState.ERROR, errorMessage = "target not found")
                persisted?.state == MissionState.COMPLETED -> persisted
                persisted != null && persisted.state in setOf(MissionState.ACTIVE, MissionState.PAUSED, MissionState.CANCELLED, MissionState.FAILED, MissionState.ERROR) -> persisted
                definition.id in snapshot.forcedUnlockedMissionIds -> (persisted ?: MissionRuntimeState(definition.id)).copy(state = MissionState.AVAILABLE)
                unlockSatisfied(definition.unlockRule, completed, progress.level, regionProgress, snapshot.objectStates) ->
                    (persisted ?: MissionRuntimeState(definition.id)).copy(state = MissionState.AVAILABLE)
                else -> (persisted ?: MissionRuntimeState(definition.id)).copy(state = MissionState.LOCKED)
            }
            definition.id to runtime
        }
        val active = snapshot.activeMissionId?.takeIf { id ->
            derived[id]?.state in setOf(MissionState.ACTIVE, MissionState.PAUSED)
        }
        return MissionGameState(
            definitions = definitions,
            runtimeStates = derived,
            activeMissionId = active,
            objectStates = snapshot.objectStates,
            unlockedRegions = snapshot.unlockedRegions,
            history = snapshot.history,
            regionProgressPercent = regionProgress,
            validationErrors = validationErrors,
        )
    }

    private fun unlockSatisfied(
        rule: UnlockRule,
        completedMissionIds: Set<String>,
        level: Int,
        regionProgress: Int,
        objectStates: Map<String, String>,
    ): Boolean {
        if (!completedMissionIds.containsAll(rule.requiredMissionIds)) return false
        if (level < rule.minLevel) return false
        if (regionProgress < rule.minRegionProgressPercent) return false
        return rule.requiredObjectStates.all { (id, state) -> objectStates[id] == state }
    }

    private fun calculateRegionProgress(regionId: String, runtimes: Map<String, MissionRuntimeState>): Int {
        val region = definitions.filter { it.regionId == regionId }
        val totalWeight = region.sumOf { it.importance.weight }.coerceAtLeast(1)
        val completedWeight = region.filter { runtimes[it.id]?.state == MissionState.COMPLETED }
            .sumOf { it.importance.weight }
        return ((completedWeight * 100f) / totalWeight).toInt().coerceIn(0, 100)
    }

    private fun rebuildObjectStates(runtimes: Map<String, MissionRuntimeState>): Map<String, String> {
        val states = defaultWorldObjectStates().toMutableMap()
        definitions.filter { runtimes[it.id]?.state == MissionState.COMPLETED }.forEach { definition ->
            definition.worldChanges.forEach { change -> states[change.objectId] = change.newState }
        }
        return states
    }

    private fun resultWithMessage(state: MissionGameState, progress: PlayerProgress, message: String) =
        MissionActionResult(state, progress, message = message)

    private fun storageFailure(progress: PlayerProgress): MissionActionResult {
        val event = MissionEvent(MissionEventType.MISSION_ERROR, message = "ذخیرهٔ تراکنش ماموریت ناموفق بود")
        eventBus.emit(event)
        return MissionActionResult(currentState(), progress, listOf(event), event.message)
    }
}
