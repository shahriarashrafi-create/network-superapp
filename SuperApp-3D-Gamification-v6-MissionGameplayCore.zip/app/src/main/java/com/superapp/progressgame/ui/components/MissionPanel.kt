package com.superapp.progressgame.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.gameplay.mission.MissionDefinition
import com.superapp.progressgame.gameplay.mission.MissionEngine
import com.superapp.progressgame.gameplay.mission.MissionRuntimeState
import com.superapp.progressgame.gameplay.mission.MissionState
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.SuccessGreen

@Composable
fun MissionPanel(
    definition: MissionDefinition,
    runtime: MissionRuntimeState,
    missionEngine: MissionEngine,
    onStart: () -> Unit,
    onAdvanceOrComplete: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onFocusTarget: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val required = definition.objective.requiredUnits
    val current = runtime.progress.coerceIn(0, required)
    val nextStep = missionEngine.nextStepLabel(definition, runtime)
    val worldPreview = definition.worldChanges.firstOrNull()?.previewLabel

    Column(
        modifier = modifier
            .background(DeepSurface.copy(alpha = 0.93f), RoundedCornerShape(18.dp))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(definition.title, color = Color.White, fontSize = 13.sp)
            Text(definition.importance.displayName, color = AccentCyan, fontSize = 9.sp)
        }

        Text(
            text = definition.description,
            color = Color.White.copy(alpha = 0.72f),
            fontSize = 9.sp,
            lineHeight = 13.sp,
        )

        if (required > 1) {
            Text(
                text = "پیشرفت $current/$required" + (nextStep?.let { "  •  مرحله بعد: $it" } ?: ""),
                color = SuccessGreen,
                fontSize = 9.sp,
            )
        }

        Text(
            text = "+${definition.xpReward} XP  •  +${definition.coinReward} Coin" +
                (worldPreview?.let { "  •  $it" } ?: ""),
            color = Color.White.copy(alpha = 0.88f),
            fontSize = 9.sp,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = onFocusTarget) {
                Text("تمرکز", fontSize = 9.sp)
            }
            when (runtime.state) {
                MissionState.AVAILABLE,
                MissionState.CANCELLED -> Button(onClick = onStart) { Text("شروع", fontSize = 9.sp) }

                MissionState.ACTIVE -> {
                    Button(onClick = onAdvanceOrComplete) {
                        Text(if (current + 1 >= required) "انجام شد" else "ثبت مرحله", fontSize = 9.sp)
                    }
                    OutlinedButton(onClick = onPause) { Text("توقف", fontSize = 9.sp) }
                }

                MissionState.PAUSED -> {
                    Button(onClick = onResume) { Text("ادامه", fontSize = 9.sp) }
                    OutlinedButton(onClick = onCancel) { Text("لغو", fontSize = 9.sp) }
                }

                MissionState.COMPLETED -> Text("✓ تکمیل شده", color = SuccessGreen, fontSize = 10.sp)
                MissionState.LOCKED -> Text("قفل است", color = Color.White.copy(alpha = 0.55f), fontSize = 9.sp)
                MissionState.FAILED,
                MissionState.ERROR -> Text("نیاز به بررسی", color = Color(0xFFFFB4AB), fontSize = 9.sp)
            }
        }
    }
}
