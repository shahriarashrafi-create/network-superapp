package com.superapp.progressgame.gameplay.mission

import android.content.Context
import android.content.SharedPreferences
import com.superapp.progressgame.core.config.AppConfig
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.SaveKeys

class LocalMissionRepository(context: Context) : MissionRepository {
    private val prefs = context.getSharedPreferences(SaveKeys.PREFS_NAME, Context.MODE_PRIVATE)

    override fun load(): MissionPersistenceSnapshot {
        migrateIfNeeded()
        return MissionPersistenceSnapshot(
            runtimeStates = decodeRuntime(prefs.getStringSet(SaveKeys.KEY_MISSION_RUNTIME, emptySet()).orEmpty()),
            activeMissionId = prefs.getString(SaveKeys.KEY_ACTIVE_MISSION, null),
            objectStates = decodeMap(prefs.getStringSet(SaveKeys.KEY_WORLD_OBJECT_STATES, emptySet()).orEmpty())
                .ifEmpty { defaultWorldObjectStates() },
            unlockedRegions = prefs.getStringSet(SaveKeys.KEY_UNLOCKED_REGIONS, setOf(MissionCatalog.REGION_STARTER))
                ?.toSet().orEmpty().ifEmpty { setOf(MissionCatalog.REGION_STARTER) },
            rewardedMissionIds = prefs.getStringSet(SaveKeys.KEY_REWARDED_MISSIONS, emptySet())?.toSet().orEmpty(),
            forcedUnlockedMissionIds = prefs.getStringSet(SaveKeys.KEY_FORCED_UNLOCK_MISSIONS, emptySet())?.toSet().orEmpty(),
            history = decodeHistory(prefs.getStringSet(SaveKeys.KEY_MISSION_HISTORY, emptySet()).orEmpty()),
        )
    }

    override fun save(snapshot: MissionPersistenceSnapshot): Boolean = writeSnapshot(prefs.edit(), snapshot).commit()

    override fun commitCompletion(snapshot: MissionPersistenceSnapshot, progress: PlayerProgress): Boolean {
        val editor = writeSnapshot(prefs.edit(), snapshot)
            .putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)
            .putInt(SaveKeys.KEY_LEVEL, progress.level)
            .putInt(SaveKeys.KEY_XP, progress.xp)
            .putInt(SaveKeys.KEY_COINS, progress.coins)
            .putString(SaveKeys.KEY_REGION, progress.activeRegionId)
            .putInt(SaveKeys.KEY_REGION_PROGRESS, progress.regionProgressPercent)
        return editor.commit()
    }

    override fun clearMissionData(): Boolean = prefs.edit()
        .remove(SaveKeys.KEY_MISSION_RUNTIME)
        .remove(SaveKeys.KEY_ACTIVE_MISSION)
        .remove(SaveKeys.KEY_WORLD_OBJECT_STATES)
        .remove(SaveKeys.KEY_UNLOCKED_REGIONS)
        .remove(SaveKeys.KEY_REWARDED_MISSIONS)
        .remove(SaveKeys.KEY_FORCED_UNLOCK_MISSIONS)
        .remove(SaveKeys.KEY_MISSION_HISTORY)
        .putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)
        .commit()

    private fun migrateIfNeeded() {
        val current = prefs.getInt(SaveKeys.KEY_SCHEMA, 1)
        if (current < AppConfig.SAVE_SCHEMA_VERSION) {
            prefs.edit().putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION).commit()
        }
    }

    private fun writeSnapshot(
        editor: SharedPreferences.Editor,
        snapshot: MissionPersistenceSnapshot,
    ): SharedPreferences.Editor = editor
        .putStringSet(SaveKeys.KEY_MISSION_RUNTIME, encodeRuntime(snapshot.runtimeStates))
        .apply {
            if (snapshot.activeMissionId == null) remove(SaveKeys.KEY_ACTIVE_MISSION)
            else putString(SaveKeys.KEY_ACTIVE_MISSION, snapshot.activeMissionId)
        }
        .putStringSet(SaveKeys.KEY_WORLD_OBJECT_STATES, encodeMap(snapshot.objectStates))
        .putStringSet(SaveKeys.KEY_UNLOCKED_REGIONS, snapshot.unlockedRegions.toSet())
        .putStringSet(SaveKeys.KEY_REWARDED_MISSIONS, snapshot.rewardedMissionIds.toSet())
        .putStringSet(SaveKeys.KEY_FORCED_UNLOCK_MISSIONS, snapshot.forcedUnlockedMissionIds.toSet())
        .putStringSet(SaveKeys.KEY_MISSION_HISTORY, encodeHistory(snapshot.history))
        .putInt(SaveKeys.KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)

    private fun encodeRuntime(states: Map<String, MissionRuntimeState>): Set<String> = states.values.map { state ->
        listOf(
            state.missionId,
            state.state.name,
            state.progress.toString(),
            state.stepIndex.toString(),
            state.startedAtMillis.toString(),
            state.completedAtMillis.toString(),
        ).joinToString("|")
    }.toSet()

    private fun decodeRuntime(values: Set<String>): Map<String, MissionRuntimeState> = values.mapNotNull { encoded ->
        val parts = encoded.split('|')
        if (parts.size < 6) return@mapNotNull null
        val state = runCatching { MissionState.valueOf(parts[1]) }.getOrDefault(MissionState.LOCKED)
        MissionRuntimeState(
            missionId = parts[0],
            state = state,
            progress = parts[2].toIntOrNull() ?: 0,
            stepIndex = parts[3].toIntOrNull() ?: 0,
            startedAtMillis = parts[4].toLongOrNull() ?: 0L,
            completedAtMillis = parts[5].toLongOrNull() ?: 0L,
        )
    }.associateBy { it.missionId }

    private fun encodeMap(values: Map<String, String>): Set<String> = values.map { (key, value) -> "$key=$value" }.toSet()

    private fun decodeMap(values: Set<String>): Map<String, String> = values.mapNotNull { encoded ->
        val index = encoded.indexOf('=')
        if (index <= 0) null else encoded.substring(0, index) to encoded.substring(index + 1)
    }.toMap()

    private fun encodeHistory(history: List<MissionHistoryEntry>): Set<String> = history.takeLast(100).map { entry ->
        "${entry.missionId}|${entry.completedAtMillis}|${entry.xpReward}|${entry.coinReward}"
    }.toSet()

    private fun decodeHistory(values: Set<String>): List<MissionHistoryEntry> = values.mapNotNull { encoded ->
        val parts = encoded.split('|')
        if (parts.size < 4) return@mapNotNull null
        MissionHistoryEntry(
            missionId = parts[0],
            completedAtMillis = parts[1].toLongOrNull() ?: return@mapNotNull null,
            xpReward = parts[2].toIntOrNull() ?: 0,
            coinReward = parts[3].toIntOrNull() ?: 0,
        )
    }.sortedBy { it.completedAtMillis }
}
