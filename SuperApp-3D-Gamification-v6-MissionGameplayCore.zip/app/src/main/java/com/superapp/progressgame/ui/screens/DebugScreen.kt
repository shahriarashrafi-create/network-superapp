package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.debug.createDebugSnapshot
import com.superapp.progressgame.gameplay.mission.MissionActionResult
import com.superapp.progressgame.gameplay.mission.MissionEngine
import com.superapp.progressgame.ui.theme.DeepSurface

@Composable
fun DebugScreen(
    progress: PlayerProgress,
    preferences: FoundationPreferences,
    missionEngine: MissionEngine,
    onProgressChanged: (PlayerProgress) -> Unit,
    onBack: () -> Unit,
) {
    val snapshot = createDebugSnapshot()
    var missionState by remember { mutableStateOf(missionEngine.currentState()) }
    var message by remember { mutableStateOf<String?>(null) }

    fun consume(result: MissionActionResult) {
        missionState = result.state
        onProgressChanged(result.progress)
        message = result.message ?: result.events.lastOrNull()?.message
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Developer Mission Console", color = Color.White, fontSize = 27.sp)
        Text(
            "V6: بررسی State Machine، Dependency، Reward، Save Recovery و World State.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSurface, RoundedCornerShape(22.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            DebugRow("Build", snapshot.buildType)
            DebugRow("App ID", snapshot.appId)
            DebugRow("Version", snapshot.appVersion)
            DebugRow("Save schema", snapshot.saveSchema.toString())
            DebugRow("World schema", snapshot.worldSchema.toString())
            DebugRow("Asset schema", snapshot.assetSchema.toString())
            DebugRow("Asset definitions", snapshot.assetDefinitions.toString())
            DebugRow("Renderer", snapshot.renderer)
            DebugRow("Foundation flags", snapshot.enabledFoundationFlags.toString())
            DebugRow("Active region", progress.activeRegionId)
            DebugRow("Region progress", "${missionState.regionProgressPercent}%")
            DebugRow("Camera preset", preferences.cameraPresetId)
            DebugRow("Selected object", preferences.selectedObjectId ?: "—")
            DebugRow("Level / XP / Coin", "${progress.level} / ${progress.xp} / ${progress.coins}")
            DebugRow("Active mission", missionState.activeMissionId ?: "—")
            DebugRow("Mission history", missionState.history.size.toString())
            DebugRow("Validation", if (missionState.validationErrors.isEmpty()) "OK" else missionState.validationErrors.joinToString("; "))
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSurface, RoundedCornerShape(22.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Mission States", color = Color.White, fontSize = 15.sp)
            missionState.definitions.forEach { definition ->
                val runtime = missionState.runtime(definition.id)
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        "${definition.title}  •  ${runtime?.state ?: "—"}  •  ${runtime?.progress ?: 0}/${definition.objective.requiredUnits}",
                        color = Color.White,
                        fontSize = 10.sp,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        OutlinedButton(onClick = { consume(missionEngine.forceUnlock(definition.id)) }) {
                            Text("Unlock", fontSize = 8.sp)
                        }
                        OutlinedButton(onClick = { consume(missionEngine.startMission(definition.id, force = true)) }) {
                            Text("Start", fontSize = 8.sp)
                        }
                        Button(onClick = { consume(missionEngine.completeNowForDebug(definition.id)) }) {
                            Text("Complete", fontSize = 8.sp)
                        }
                        OutlinedButton(onClick = { consume(missionEngine.resetMission(definition.id)) }) {
                            Text("Reset", fontSize = 8.sp)
                        }
                    }
                }
            }
        }

        if (missionEngine.eventBus.recentEvents().isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeepSurface, RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                Text("Recent Mission Events", color = Color.White, fontSize = 14.sp)
                missionEngine.eventBus.recentEvents().take(10).forEach { event ->
                    Text("${event.type}: ${event.message}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 9.sp)
                }
            }
        }

        message?.let { Text(it, color = Color(0xFF7DE3C3), fontSize = 10.sp) }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { consume(missionEngine.resetRegion()) }) { Text("Reset Region") }
            OutlinedButton(onClick = { consume(missionEngine.resetAll()) }) { Text("Reset All") }
            Button(onClick = onBack) { Text("برگشت") }
        }
    }
}

@Composable
private fun DebugRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(value, color = Color.White, fontSize = 12.sp)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
}
