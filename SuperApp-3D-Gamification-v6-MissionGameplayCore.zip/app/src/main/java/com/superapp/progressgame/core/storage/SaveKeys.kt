package com.superapp.progressgame.core.storage

object SaveKeys {
    const val PREFS_NAME = "progress_world_save"
    const val KEY_SCHEMA = "save_schema"
    const val KEY_LEVEL = "level"
    const val KEY_XP = "xp"
    const val KEY_COINS = "coins"
    const val KEY_REGION = "active_region"
    const val KEY_REGION_PROGRESS = "region_progress"

    const val KEY_MISSION_RUNTIME = "mission_runtime"
    const val KEY_ACTIVE_MISSION = "active_mission"
    const val KEY_WORLD_OBJECT_STATES = "world_object_states"
    const val KEY_UNLOCKED_REGIONS = "unlocked_regions"
    const val KEY_REWARDED_MISSIONS = "rewarded_missions"
    const val KEY_FORCED_UNLOCK_MISSIONS = "forced_unlocked_missions"
    const val KEY_MISSION_HISTORY = "mission_history"
}
