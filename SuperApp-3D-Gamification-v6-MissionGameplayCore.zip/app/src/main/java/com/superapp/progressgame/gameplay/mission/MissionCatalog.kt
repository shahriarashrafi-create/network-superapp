package com.superapp.progressgame.gameplay.mission

object MissionCatalog {
    const val REGION_STARTER = "starter_estate"

    val all: List<MissionDefinition> = listOf(
        MissionDefinition(
            id = "mission_enter_garden",
            title = "ورود به باغ",
            description = "ورود رسمی به محوطه و فعال‌کردن مسیر پیشرفت.",
            regionId = REGION_STARTER,
            targetObjectId = "entrance_gate",
            importance = MissionImportance.LOW,
            xpReward = 40,
            coinReward = 10,
            objective = MissionObjective(MissionObjectiveType.MANUAL),
            nextMissionIds = listOf("mission_activate_fountain"),
            startCamera = CameraDirective.FOCUS,
            completionCamera = CameraDirective.REVEAL,
            worldChanges = listOf(
                WorldStateChange("entrance_gate", "visited", "دروازه ورودی ثبت می‌شود")
            ),
        ),
        MissionDefinition(
            id = "mission_activate_fountain",
            title = "فعال‌سازی فواره",
            description = "فواره مرکزی را به اولین نشانهٔ زندهٔ جهان تبدیل کن.",
            regionId = REGION_STARTER,
            targetObjectId = "fountain_main",
            importance = MissionImportance.MEDIUM,
            xpReward = 70,
            coinReward = 20,
            objective = MissionObjective(MissionObjectiveType.MANUAL),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_enter_garden")),
            nextMissionIds = listOf("mission_prepare_rest_area"),
            startCamera = CameraDirective.CLOSE_UP,
            completionCamera = CameraDirective.REVEAL,
            worldChanges = listOf(
                WorldStateChange("fountain_main", "normal", "فواره روشن و فعال می‌شود")
            ),
        ),
        MissionDefinition(
            id = "mission_prepare_rest_area",
            title = "آماده‌سازی فضای استراحت",
            description = "چهار نقطهٔ استراحت اطراف محور مرکزی را تکمیل کن.",
            regionId = REGION_STARTER,
            targetObjectId = "bench_w_01",
            importance = MissionImportance.MEDIUM,
            xpReward = 85,
            coinReward = 24,
            objective = MissionObjective(
                type = MissionObjectiveType.MULTI_STEP,
                steps = listOf(
                    MissionStep("bench_w_01", "نیمکت غربی اول", "bench_w_01"),
                    MissionStep("bench_e_01", "نیمکت شرقی اول", "bench_e_01"),
                    MissionStep("bench_w_02", "نیمکت غربی دوم", "bench_w_02"),
                    MissionStep("bench_e_02", "نیمکت شرقی دوم", "bench_e_02"),
                ),
            ),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_activate_fountain")),
            nextMissionIds = listOf("mission_light_path"),
            worldChanges = listOf(
                WorldStateChange("bench_w_01", "ready", "نیمکت‌های استراحت آماده می‌شوند"),
                WorldStateChange("bench_e_01", "ready", "نیمکت‌های استراحت آماده می‌شوند"),
                WorldStateChange("bench_w_02", "ready", "نیمکت‌های استراحت آماده می‌شوند"),
                WorldStateChange("bench_e_02", "ready", "نیمکت‌های استراحت آماده می‌شوند"),
            ),
        ),
        MissionDefinition(
            id = "mission_light_path",
            title = "نورپردازی مسیر",
            description = "چهار چراغ اصلی محور ورودی تا عمارت را فعال کن.",
            regionId = REGION_STARTER,
            targetObjectId = "lamp_01",
            importance = MissionImportance.MEDIUM,
            xpReward = 95,
            coinReward = 30,
            objective = MissionObjective(
                type = MissionObjectiveType.MULTI_STEP,
                steps = listOf(
                    MissionStep("lamp_01", "چراغ مسیر ۱", "lamp_01"),
                    MissionStep("lamp_02", "چراغ مسیر ۲", "lamp_02"),
                    MissionStep("lamp_03", "چراغ مسیر ۳", "lamp_03"),
                    MissionStep("lamp_04", "چراغ مسیر ۴", "lamp_04"),
                ),
            ),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_prepare_rest_area")),
            nextMissionIds = listOf("mission_complete_greenery"),
            completionCamera = CameraDirective.TRAVEL,
            worldChanges = listOf(
                WorldStateChange("lamp_01", "on", "چراغ‌های مسیر روشن می‌شوند"),
                WorldStateChange("lamp_02", "on", "چراغ‌های مسیر روشن می‌شوند"),
                WorldStateChange("lamp_03", "on", "چراغ‌های مسیر روشن می‌شوند"),
                WorldStateChange("lamp_04", "on", "چراغ‌های مسیر روشن می‌شوند"),
            ),
        ),
        MissionDefinition(
            id = "mission_complete_greenery",
            title = "تکمیل فضای سبز",
            description = "چند نقطهٔ کلیدی فضای سبز را از حالت اولیه به محوطهٔ آماده تبدیل کن.",
            regionId = REGION_STARTER,
            targetObjectId = "plant_01",
            importance = MissionImportance.MEDIUM,
            xpReward = 110,
            coinReward = 34,
            objective = MissionObjective(
                type = MissionObjectiveType.MULTI_STEP,
                steps = listOf(
                    MissionStep("plant_01", "بوته تزئینی غربی", "plant_01"),
                    MissionStep("plant_02", "بوته تزئینی شرقی", "plant_02"),
                    MissionStep("tree_w_01", "درخت شاخص غربی", "tree_w_01"),
                ),
            ),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_light_path")),
            nextMissionIds = listOf("mission_prepare_mansion_entry"),
            worldChanges = listOf(
                WorldStateChange("plant_01", "finished", "فضای سبز مرتب می‌شود"),
                WorldStateChange("plant_02", "finished", "فضای سبز مرتب می‌شود"),
                WorldStateChange("plant_03", "finished", "فضای سبز مرتب می‌شود"),
                WorldStateChange("plant_04", "finished", "فضای سبز مرتب می‌شود"),
                WorldStateChange("plant_05", "finished", "فضای سبز مرتب می‌شود"),
                WorldStateChange("plant_06", "finished", "فضای سبز مرتب می‌شود"),
            ),
        ),
        MissionDefinition(
            id = "mission_prepare_mansion_entry",
            title = "آماده‌سازی ورودی عمارت",
            description = "محور اصلی را تا ورودی عمارت کامل کن.",
            regionId = REGION_STARTER,
            targetObjectId = "mansion_main",
            importance = MissionImportance.HIGH,
            xpReward = 145,
            coinReward = 52,
            objective = MissionObjective(MissionObjectiveType.MANUAL),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_complete_greenery")),
            nextMissionIds = listOf("mission_mansion_checklist"),
            startCamera = CameraDirective.FOCUS,
            completionCamera = CameraDirective.REVEAL,
            worldChanges = listOf(
                WorldStateChange("mansion_main", "ready", "ورودی عمارت آماده می‌شود")
            ),
        ),
        MissionDefinition(
            id = "mission_mansion_checklist",
            title = "چک‌لیست عمارت",
            description = "سه مرحلهٔ پایانی آماده‌سازی عمارت را ثبت کن.",
            regionId = REGION_STARTER,
            targetObjectId = "mansion_main",
            importance = MissionImportance.HIGH,
            xpReward = 170,
            coinReward = 65,
            objective = MissionObjective(
                type = MissionObjectiveType.MULTI_STEP,
                steps = listOf(
                    MissionStep("mansion_front", "نمای ورودی", "mansion_main"),
                    MissionStep("mansion_side", "نمای جانبی", "mansion_main"),
                    MissionStep("mansion_ready", "آمادگی نهایی", "mansion_main"),
                ),
            ),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_prepare_mansion_entry")),
            nextMissionIds = listOf("mission_complete_region"),
            completionCamera = CameraDirective.OVERVIEW,
            worldChanges = listOf(
                WorldStateChange("mansion_main", "prepared", "عمارت به وضعیت آماده ارتقا پیدا می‌کند")
            ),
        ),
        MissionDefinition(
            id = "mission_complete_region",
            title = "تکمیل منطقهٔ آغازین",
            description = "تمام تغییرات منطقه را تثبیت و منطقهٔ بعدی را باز کن.",
            regionId = REGION_STARTER,
            targetObjectId = "fountain_main",
            importance = MissionImportance.HIGH,
            xpReward = 220,
            coinReward = 90,
            objective = MissionObjective(MissionObjectiveType.MANUAL),
            unlockRule = UnlockRule(requiredMissionIds = setOf("mission_mansion_checklist")),
            startCamera = CameraDirective.OVERVIEW,
            completionCamera = CameraDirective.CELEBRATION,
            worldChanges = listOf(
                WorldStateChange("starter_estate", "completed", "منطقهٔ آغازین کامل می‌شود")
            ),
        ),
    )

    private val byId = all.associateBy { it.id }

    fun definition(id: String?): MissionDefinition? = id?.let(byId::get)
}
