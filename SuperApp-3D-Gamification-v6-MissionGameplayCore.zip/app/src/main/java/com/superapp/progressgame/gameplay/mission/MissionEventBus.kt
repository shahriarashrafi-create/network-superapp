package com.superapp.progressgame.gameplay.mission

import java.util.ArrayDeque

class MissionEventBus {
    private val listeners = linkedSetOf<(MissionEvent) -> Unit>()
    private val recent = ArrayDeque<MissionEvent>()

    fun emit(event: MissionEvent) {
        recent.addLast(event)
        while (recent.size > 30) recent.removeFirst()
        listeners.toList().forEach { it(event) }
    }

    fun subscribe(listener: (MissionEvent) -> Unit): () -> Unit {
        listeners += listener
        return { listeners -= listener }
    }

    fun recentEvents(): List<MissionEvent> = recent.toList().asReversed()
}
