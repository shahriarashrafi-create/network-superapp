package com.superapp.progressgame.gameplay.mission

enum class MissionState {
    LOCKED,
    AVAILABLE,
    ACTIVE,
    PAUSED,
    COMPLETED,
    CANCELLED,
    FAILED,
    ERROR,
}

enum class MissionImportance(val weight: Int, val displayName: String) {
    LOW(1, "کم"),
    MEDIUM(2, "متوسط"),
    HIGH(3, "مهم"),
}

enum class MissionObjectiveType {
    MANUAL,
    INTERACT,
    COUNT,
    MULTI_STEP,
}

enum class CameraDirective {
    NONE,
    FOCUS,
    CLOSE_UP,
    REVEAL,
    OVERVIEW,
    TRAVEL,
    CELEBRATION,
}

data class MissionStep(
    val id: String,
    val title: String,
    val targetObjectId: String? = null,
)

data class MissionObjective(
    val type: MissionObjectiveType,
    val requiredCount: Int = 1,
    val steps: List<MissionStep> = emptyList(),
) {
    val requiredUnits: Int
        get() = when (type) {
            MissionObjectiveType.MULTI_STEP -> steps.size.coerceAtLeast(1)
            else -> requiredCount.coerceAtLeast(1)
        }
}

data class WorldStateChange(
    val objectId: String,
    val newState: String,
    val previewLabel: String,
)

data class UnlockRule(
    val requiredMissionIds: Set<String> = emptySet(),
    val minLevel: Int = 1,
    val minRegionProgressPercent: Int = 0,
    val requiredObjectStates: Map<String, String> = emptyMap(),
)

data class MissionDefinition(
    val id: String,
    val title: String,
    val description: String,
    val regionId: String,
    val targetObjectId: String,
    val importance: MissionImportance,
    val xpReward: Int,
    val coinReward: Int,
    val objective: MissionObjective = MissionObjective(MissionObjectiveType.MANUAL),
    val unlockRule: UnlockRule = UnlockRule(),
    val nextMissionIds: List<String> = emptyList(),
    val startCamera: CameraDirective = CameraDirective.FOCUS,
    val completionCamera: CameraDirective = CameraDirective.REVEAL,
    val worldChanges: List<WorldStateChange> = emptyList(),
    val confirmCompletion: Boolean = importance == MissionImportance.HIGH,
)

data class MissionRuntimeState(
    val missionId: String,
    val state: MissionState = MissionState.LOCKED,
    val progress: Int = 0,
    val stepIndex: Int = 0,
    val startedAtMillis: Long = 0L,
    val completedAtMillis: Long = 0L,
    val errorMessage: String? = null,
)

data class MissionHistoryEntry(
    val missionId: String,
    val completedAtMillis: Long,
    val xpReward: Int,
    val coinReward: Int,
)

data class MissionPersistenceSnapshot(
    val runtimeStates: Map<String, MissionRuntimeState> = emptyMap(),
    val activeMissionId: String? = null,
    val objectStates: Map<String, String> = defaultWorldObjectStates(),
    val unlockedRegions: Set<String> = setOf("starter_estate"),
    val rewardedMissionIds: Set<String> = emptySet(),
    val forcedUnlockedMissionIds: Set<String> = emptySet(),
    val history: List<MissionHistoryEntry> = emptyList(),
)

data class MissionGameState(
    val definitions: List<MissionDefinition>,
    val runtimeStates: Map<String, MissionRuntimeState>,
    val activeMissionId: String?,
    val objectStates: Map<String, String>,
    val unlockedRegions: Set<String>,
    val history: List<MissionHistoryEntry>,
    val regionProgressPercent: Int,
    val validationErrors: List<String> = emptyList(),
) {
    fun definition(id: String?): MissionDefinition? = definitions.firstOrNull { it.id == id }
    fun runtime(id: String?): MissionRuntimeState? = id?.let(runtimeStates::get)

    fun activeDefinition(): MissionDefinition? = definition(activeMissionId)

    fun nextAvailable(): MissionDefinition? = definitions.firstOrNull { definition ->
        runtimeStates[definition.id]?.state == MissionState.AVAILABLE
    }

    fun focusMission(): MissionDefinition? = activeDefinition() ?: nextAvailable()
}

enum class MissionEventType {
    MISSION_STARTED,
    MISSION_PROGRESS,
    MISSION_PAUSED,
    MISSION_RESUMED,
    MISSION_CANCELLED,
    MISSION_COMPLETED,
    REWARD_GRANTED,
    LEVEL_UP,
    REGION_COMPLETED,
    REGION_UNLOCKED,
    MISSION_ERROR,
}

data class MissionEvent(
    val type: MissionEventType,
    val missionId: String? = null,
    val message: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
)

data class MissionActionResult(
    val state: MissionGameState,
    val progress: com.superapp.progressgame.core.model.PlayerProgress,
    val events: List<MissionEvent> = emptyList(),
    val message: String? = null,
)

fun defaultWorldObjectStates(): Map<String, String> = mapOf(
    "entrance_gate" to "new",
    "fountain_main" to "off",
    "bench_w_01" to "pending",
    "bench_e_01" to "pending",
    "bench_w_02" to "pending",
    "bench_e_02" to "pending",
    "lamp_01" to "off",
    "lamp_02" to "off",
    "lamp_03" to "off",
    "lamp_04" to "off",
    "plant_01" to "wild",
    "plant_02" to "wild",
    "plant_03" to "wild",
    "plant_04" to "wild",
    "plant_05" to "wild",
    "plant_06" to "wild",
    "mansion_main" to "locked",
)
