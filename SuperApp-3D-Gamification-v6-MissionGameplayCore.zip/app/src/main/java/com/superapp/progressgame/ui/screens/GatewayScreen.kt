package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.gameplay.mission.LevelRules
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.PrimaryBlue
import com.superapp.progressgame.ui.theme.SuccessGreen

@Composable
fun GatewayScreen(
    progress: PlayerProgress,
    onEnterWorld: () -> Unit,
    onSettings: () -> Unit,
    onDebug: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF06101C),
                        Color(0xFF092036),
                        Color(0xFF0C3146),
                        Color(0xFF08111A),
                    )
                )
            )
            .padding(horizontal = 38.dp, vertical = 28.dp),
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(250.dp)
                .background(Color(0xFF4D7FFF).copy(alpha = 0.05f), CircleShape)
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .size(160.dp)
                .background(Color(0xFF5FE1E6).copy(alpha = 0.04f), CircleShape)
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            PlayerCard(
                progress = progress,
                modifier = Modifier.weight(0.29f),
            )

            Column(
                modifier = Modifier.weight(0.60f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.End,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                ) {
                    Text(
                        text = "PROGRESS WORLD",
                        color = AccentCyan.copy(alpha = 0.95f),
                        fontSize = 10.sp,
                        letterSpacing = 1.2.sp,
                    )
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(AccentCyan.copy(alpha = 0.13f), RoundedCornerShape(11.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Rounded.Explore,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }

                Text(
                    text = "دنیای تو با اقدام‌هایت ساخته می‌شود",
                    color = Color.White,
                    fontSize = 32.sp,
                    lineHeight = 41.sp,
                )
                Text(
                    text = "وارد جهان سه‌بعدی شو، محیط را آزادانه ببین و روی نقاط مهم تمرکز کن.",
                    color = Color(0xFFB1C2D5),
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                )

                Spacer(Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    IconButton(
                        onClick = onDebug,
                        modifier = Modifier
                            .size(52.dp)
                            .background(DeepSurface.copy(alpha = 0.72f), RoundedCornerShape(17.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(17.dp)),
                    ) {
                        Icon(Icons.Rounded.BugReport, contentDescription = "اطلاعات توسعه", tint = Color.White)
                    }

                    IconButton(
                        onClick = onSettings,
                        modifier = Modifier
                            .size(52.dp)
                            .background(DeepSurface.copy(alpha = 0.72f), RoundedCornerShape(17.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(17.dp)),
                    ) {
                        Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات", tint = Color.White)
                    }

                    Button(
                        onClick = onEnterWorld,
                        modifier = Modifier.height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(18.dp),
                    ) {
                        Text("ورود به دنیا", fontSize = 14.sp)
                        Spacer(Modifier.width(10.dp))
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerCard(progress: PlayerProgress, modifier: Modifier = Modifier) {
    val xpProgress = LevelRules.fraction(progress.xp)

    Column(
        modifier = modifier
            .background(DeepSurface.copy(alpha = 0.70f), RoundedCornerShape(24.dp))
            .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(24.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("LEVEL ${progress.level}", color = Color.White, fontSize = 23.sp)
        LinearProgressIndicator(
            progress = { xpProgress },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = PrimaryBlue,
            trackColor = Color.White.copy(alpha = 0.10f),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("◉ ${progress.coins}", color = SuccessGreen, fontSize = 12.sp)
            Text("XP ${LevelRules.xpIntoCurrentLevel(progress.xp)}/${LevelRules.xpNeededForCurrentLevel(progress.xp)}", color = Color(0xFFB9C8DA), fontSize = 10.sp)
        }
        Text(
            text = "پیشرفت منطقه ${progress.regionProgressPercent}%",
            color = AccentCyan.copy(alpha = 0.90f),
            fontSize = 10.sp,
        )
    }
}
