package com.superapp.progressgame.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.superapp.progressgame.core.di.AppContainer
import com.superapp.progressgame.ui.screens.BootScreen
import com.superapp.progressgame.ui.screens.DebugScreen
import com.superapp.progressgame.ui.screens.GatewayScreen
import com.superapp.progressgame.ui.screens.SettingsScreen
import com.superapp.progressgame.ui.screens.WorldShellScreen
import com.superapp.progressgame.ui.theme.ProgressWorldTheme

enum class FoundationScreen {
    BOOT,
    GATEWAY,
    WORLD,
    SETTINGS,
    DEBUG,
}

@Composable
fun GameFoundationApp(appContainer: AppContainer) {
    var screen by rememberSaveable { mutableStateOf(FoundationScreen.BOOT) }
    var returnFromSettingsTo by rememberSaveable { mutableStateOf(FoundationScreen.GATEWAY) }
    var progress by remember { mutableStateOf(appContainer.progressRepository.load()) }

    fun refreshProgress() {
        progress = appContainer.progressRepository.load()
    }

    ProgressWorldTheme {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            when (screen) {
                FoundationScreen.BOOT -> BootScreen(onFinished = { screen = FoundationScreen.GATEWAY })

                FoundationScreen.GATEWAY -> GatewayScreen(
                    progress = progress,
                    onEnterWorld = {
                        refreshProgress()
                        screen = FoundationScreen.WORLD
                    },
                    onSettings = {
                        returnFromSettingsTo = FoundationScreen.GATEWAY
                        screen = FoundationScreen.SETTINGS
                    },
                    onDebug = { screen = FoundationScreen.DEBUG },
                )

                FoundationScreen.WORLD -> WorldShellScreen(
                    progress = progress,
                    preferences = appContainer.preferences,
                    missionEngine = appContainer.missionEngine,
                    onProgressChanged = { progress = it },
                    onBack = {
                        refreshProgress()
                        screen = FoundationScreen.GATEWAY
                    },
                    onSettings = {
                        returnFromSettingsTo = FoundationScreen.WORLD
                        screen = FoundationScreen.SETTINGS
                    },
                )

                FoundationScreen.SETTINGS -> SettingsScreen(
                    preferences = appContainer.preferences,
                    onResetMissionProgress = {
                        progress = appContainer.missionEngine.resetMission(
                            appContainer.missionEngine.currentState().activeMissionId
                                ?: appContainer.missionEngine.currentState().focusMission()?.id
                                ?: "mission_enter_garden"
                        ).progress
                    },
                    onResetRegionProgress = {
                        progress = appContainer.missionEngine.resetRegion().progress
                    },
                    onResetProgress = {
                        progress = appContainer.missionEngine.resetAll().progress
                    },
                    onBack = {
                        refreshProgress()
                        screen = returnFromSettingsTo
                    },
                )

                FoundationScreen.DEBUG -> DebugScreen(
                    progress = progress,
                    preferences = appContainer.preferences,
                    missionEngine = appContainer.missionEngine,
                    onProgressChanged = { progress = it },
                    onBack = {
                        refreshProgress()
                        screen = FoundationScreen.GATEWAY
                    },
                )
            }
        }
    }
}
