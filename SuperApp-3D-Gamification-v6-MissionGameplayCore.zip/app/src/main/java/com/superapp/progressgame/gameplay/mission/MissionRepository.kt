package com.superapp.progressgame.gameplay.mission

import com.superapp.progressgame.core.model.PlayerProgress

interface MissionRepository {
    fun load(): MissionPersistenceSnapshot
    fun save(snapshot: MissionPersistenceSnapshot): Boolean
    fun commitCompletion(snapshot: MissionPersistenceSnapshot, progress: PlayerProgress): Boolean
    fun clearMissionData(): Boolean
}
