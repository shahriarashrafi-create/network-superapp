# Progress World — V6 Mission Gameplay Core

این ZIP نسخه ششم پروژه‌ی `com.superapp.progressgame` است. V5 Camera & Cinematic Director حفظ شده و V6 حلقه‌ی واقعی گیم‌پلی را اضافه می‌کند:

**Mission → Camera Focus → Start → Progress/Done → World Change → XP/Coin → Level/Region Progress → Unlock → Next Mission**

## قابلیت‌های اصلی V6

- Mission Engine مرکزی و State Machine
- Objectiveهای Manual / Interact / Count / Multi-Step
- Dependency Graph و Unlock Rules
- 8 ماموریت واقعی در منطقه‌ی آغازین
- Mission FAB و Mission Bar مینیمال
- Start / Pause / Resume / Cancel / Done
- تأیید ماموریت‌های مهم
- Reward Preview و World Change Preview
- XP و Coin واقعی + Level Formula + XP Overflow
- Weighted Region Progress و Region Completion
- Object State Binding (فواره و چراغ‌ها در صحنه واقعاً State می‌گیرند)
- اتصال کامل به Camera Director V5
- Save/Restart Recovery و Schema Migration
- Transactional Completion + Duplicate Reward Protection
- Mission History و Event Bus
- Data Validator و Fallback Target
- Debug Mission Console
- Reset Mission / Region / Full Game
- Offline-first

## نسخه

- applicationId: `com.superapp.progressgame`
- versionCode: `14`
- versionName: `6.0.0-mission-gameplay-core`
- save schema: `4`
- world schema: `4`
- renderer: SceneView 4.32 + Google Filament
- Java: 17

## Build

Workflow موجود در ریشه‌ی ریپازیتوری می‌تواند ZIP را Extract کند و `assembleDebug` را اجرا کند. Keystore ثابت قبلی بدون تغییر داخل `keystore/superapp.jks` باقی مانده تا APK جدید روی نسخه‌های قبلی Update شود.
