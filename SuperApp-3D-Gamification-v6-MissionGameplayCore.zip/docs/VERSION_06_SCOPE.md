# V6 — Mission Gameplay Core

V6 turns the 3D world into a persistent gameplay loop. The package keeps the V5 camera/cinematic director and adds a data-driven mission engine, objectives, dependencies, rewards, level progression, weighted region progress, world-state binding, persistence, validation, debug controls, and recovery-safe completion transactions.

## Runtime flow

`AVAILABLE -> ACTIVE -> COMPLETED`

The engine also supports `PAUSED`, `CANCELLED`, `FAILED`, and `ERROR`. High-importance missions require completion confirmation. Only one primary mission is active at a time; starting another mission pauses the previous one.

Completion order is fixed:

`Validate -> Commit mission -> World state -> Reward -> Level -> Region progress -> Unlock -> Camera reveal -> Next mission`

Reward, mission completion, object states, unlocks, history, XP and Coin are committed to one SharedPreferences transaction so duplicate taps or process interruption cannot pay the same mission twice.

## Starter mission chain

1. ورود به باغ — Gate
2. فعال‌سازی فواره — Fountain
3. آماده‌سازی فضای استراحت — 4 Bench steps
4. نورپردازی مسیر — 4 Lamp steps
5. تکمیل فضای سبز — 3 steps
6. آماده‌سازی ورودی عمارت — Mansion
7. چک‌لیست عمارت — 3 Mansion steps
8. تکمیل منطقهٔ آغازین — Region completion

Completing the region unlocks the placeholder next region id `growth_district` for future versions.

## Persistence

Save schema 4 stores mission runtime states, active mission, object states, rewarded mission ids, forced debug unlocks, mission history, unlocked regions, XP, Coin, Level and weighted region progress. Camera persistence remains in FoundationPreferences.

## V7 boundary

V6 intentionally keeps feedback lightweight. Full particle bursts, Coin Fly, XP Fly, sound design, haptics, celebration VFX and advanced game feel remain V7 work.
