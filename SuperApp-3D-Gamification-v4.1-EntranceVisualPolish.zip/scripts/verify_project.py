from pathlib import Path
import json
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]

required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradlew",
    "gradle/wrapper/gradle-wrapper.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/superapp/progressgame/MainActivity.kt",
    "app/src/main/java/com/superapp/progressgame/ui/GameFoundationApp.kt",
    "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt",
    "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraPreset.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraSafety.kt",
    "app/src/main/java/com/superapp/progressgame/assets/AssetDefinition.kt",
    "app/src/main/java/com/superapp/progressgame/assets/AssetCatalog.kt",
    "app/src/main/java/com/superapp/progressgame/assets/StarterEstateLayout.kt",
    "app/src/main/java/com/superapp/progressgame/world/WorldObjectCatalog.kt",
    "app/src/main/assets/definitions/asset_manifest_v1.json",
    "docs/ASSET_STYLE_GUIDE.md",
    "keystore/superapp.jks",
]

errors = []
for item in required:
    if not (root / item).is_file():
        errors.append(f"missing: {item}")

build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
root_build = (root / "build.gradle.kts").read_text(encoding="utf-8")
manifest_path = root / "app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")
gradlew = (root / "gradlew").read_text(encoding="utf-8")
wrapper = (root / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
world_shell = (root / "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt").read_text(encoding="utf-8")
scene = (root / "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt").read_text(encoding="utf-8")
app_config = (root / "app/src/main/java/com/superapp/progressgame/core/config/AppConfig.kt").read_text(encoding="utf-8")
asset_catalog = (root / "app/src/main/java/com/superapp/progressgame/assets/AssetCatalog.kt").read_text(encoding="utf-8")
layout = (root / "app/src/main/java/com/superapp/progressgame/assets/StarterEstateLayout.kt").read_text(encoding="utf-8")

checks = {
    "applicationId": 'applicationId = "com.superapp.progressgame"' in build,
    "versionCode 10": bool(re.search(r"versionCode\s*=\s*10\b", build)),
    "versionName V4.1": 'versionName = "4.1.0-entrance-visual-polish"' in build,
    "compileSdk 36": bool(re.search(r"compileSdk\s*=\s*36\b", build)),
    "targetSdk 36": bool(re.search(r"targetSdk\s*=\s*36\b", build)),
    "stable signing": 'signingConfigs.getByName("stable")' in build,
    "SceneView 4.32": 'io.github.sceneview:sceneview:4.32.0' in build,
    "AGP 8.13.2": 'com.android.application") version "8.13.2"' in root_build,
    "Kotlin 2.4.10": 'org.jetbrains.kotlin.android") version "2.4.10"' in root_build,
    "Compose compiler plugin": 'org.jetbrains.kotlin.plugin.compose") version "2.4.10"' in root_build,
    "Gradle launcher 8.13": 'GRADLE_VERSION="8.13"' in gradlew,
    "Gradle wrapper 8.13": 'gradle-8.13-bin.zip' in wrapper,
    "landscape": 'android:screenOrientation="landscape"' in manifest,
    "hardware accelerated": 'android:hardwareAccelerated="true"' in manifest,
    "real SceneView": 'SceneView(' in world_shell,
    "camera safety": 'constrainGameCamera(' in world_shell,
    "hit gestures": 'rememberOnGestureListener(' in world_shell,
    "selection ring": 'selection_ring' in scene,
    "continuous terrain": 'name = "terrain_main"' in scene and 'terrain_mound_' not in scene,
    "continuous path base": 'path_main_base' in scene,
    "asset catalog": 'object AssetCatalog' in asset_catalog,
    "data driven layout": 'object StarterEstateLayout' in layout,
    "save schema 2": 'SAVE_SCHEMA_VERSION = 2' in app_config,
    "world schema 3": 'WORLD_SCHEMA_VERSION = 3' in app_config,
    "asset schema 1": 'ASSET_SCHEMA_VERSION = 1' in app_config,
}

for name, ok in checks.items():
    if not ok:
        errors.append(f"check failed: {name}")

try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml invalid: {exc}")

manifest_json_path = root / "app/src/main/assets/definitions/asset_manifest_v1.json"
try:
    asset_manifest = json.loads(manifest_json_path.read_text(encoding="utf-8"))
    ids = [item["id"] for item in asset_manifest["assets"]]
    if len(ids) != len(set(ids)):
        errors.append("asset manifest contains duplicate ids")
    if asset_manifest.get("schemaVersion") != 1:
        errors.append("asset manifest schemaVersion must be 1")
    if asset_manifest.get("assetCount") != len(ids):
        errors.append("asset manifest assetCount mismatch")
    if len(ids) < 80:
        errors.append("asset manifest unexpectedly small")
except Exception as exc:
    errors.append(f"asset manifest invalid: {exc}")

for kt in root.rglob("*.kt"):
    text = kt.read_text(encoding="utf-8")
    if "androidx.compose.foundation.layout.RowColumnParentData" in text:
        errors.append(f"forbidden internal Compose API import: {kt.relative_to(root)}")

def strip_strings_and_comments(source: str) -> str:
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.S)
    source = re.sub(r'//.*', '', source)
    source = re.sub(r'""".*?"""', '""', source, flags=re.S)
    source = re.sub(r'"(?:\\.|[^"\\])*"', '""', source)
    source = re.sub(r"'(?:\\.|[^'\\])*'", "''", source)
    return source

for kt in root.rglob("*.kt"):
    src = strip_strings_and_comments(kt.read_text(encoding="utf-8"))
    for opener, closer in [("(", ")"), ("{", "}"), ("[", "]")]:
        if src.count(opener) != src.count(closer):
            errors.append(
                f"delimiter mismatch {opener}{closer}: {kt.relative_to(root)} "
                f"({src.count(opener)} != {src.count(closer)})"
            )

large_raster_assets = []
for p in (root / "app/src/main").rglob("*"):
    if p.is_file() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"} and p.stat().st_size > 1_000_000:
        large_raster_assets.append(p)
if large_raster_assets:
    errors.append(
        "unexpected large raster world assets: "
        + ", ".join(str(p.relative_to(root)) for p in large_raster_assets)
    )

if errors:
    print("PROJECT VERIFY: FAILED")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("PROJECT VERIFY: OK")
print("Package: com.superapp.progressgame")
print("Version code: 10")
print("Version name: 4.1.0-entrance-visual-polish")
print("Renderer: SceneView 4.32.0 / Google Filament")
print("Asset definitions:", asset_manifest["assetCount"])
print("Gradle: 8.13 | AGP: 8.13.2 | Kotlin: 2.4.10 | compileSdk: 36")
print("Project files:", sum(1 for p in root.rglob("*") if p.is_file()))
