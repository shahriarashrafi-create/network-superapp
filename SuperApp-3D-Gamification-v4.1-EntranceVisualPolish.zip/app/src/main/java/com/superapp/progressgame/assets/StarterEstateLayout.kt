package com.superapp.progressgame.assets

object StarterEstateLayout {
    val trees = listOf(
        AssetInstance("tree_w_01", "tree_oak_01", Vec3(-9.4f, 0f, 7.1f), scale = 0.88f),
        AssetInstance("tree_w_02", "tree_garden_01", Vec3(-11.2f, 0f, 2.0f), scale = 0.96f),
        AssetInstance("tree_w_03", "tree_pine_01", Vec3(-9.8f, 0f, -4.4f), scale = 0.90f),
        AssetInstance("tree_w_04", "tree_maple_01", Vec3(-11.6f, 0f, -10.5f), scale = 1.00f),
        AssetInstance("tree_e_01", "tree_oak_02", Vec3(9.4f, 0f, 7.0f), scale = 0.90f),
        AssetInstance("tree_e_02", "tree_garden_02", Vec3(11.0f, 0f, 2.0f), scale = 0.96f),
        AssetInstance("tree_e_03", "tree_pine_02", Vec3(9.6f, 0f, -4.3f), scale = 0.90f),
        AssetInstance("tree_e_04", "tree_decorative_01", Vec3(11.7f, 0f, -10.4f), scale = 1.00f),
    )

    val benches = listOf(
        AssetInstance("bench_w_01", "bench_01", Vec3(-5.15f, 0f, 1.65f), Vec3(0f, 24f, 0f)),
        AssetInstance("bench_e_01", "bench_02", Vec3(5.15f, 0f, 1.65f), Vec3(0f, -24f, 0f)),
        AssetInstance("bench_w_02", "bench_03", Vec3(-5.25f, 0f, -4.95f), Vec3(0f, 16f, 0f)),
        AssetInstance("bench_e_02", "bench_01", Vec3(5.25f, 0f, -4.95f), Vec3(0f, -16f, 0f)),
    )

    val plants = listOf(
        AssetInstance("plant_01", "plant_01", Vec3(-3.7f, 0f, -1.2f), scale = 0.92f),
        AssetInstance("plant_02", "plant_02", Vec3(3.7f, 0f, -1.2f), scale = 0.92f),
        AssetInstance("plant_03", "plant_03", Vec3(-4.8f, 0f, -7.0f), scale = 1.00f),
        AssetInstance("plant_04", "plant_04", Vec3(4.8f, 0f, -7.0f), scale = 1.00f),
        AssetInstance("plant_05", "plant_05", Vec3(-6.2f, 0f, 5.2f), scale = 0.86f),
        AssetInstance("plant_06", "plant_06", Vec3(6.2f, 0f, 5.2f), scale = 0.86f),
    )

    val lamps = listOf(
        AssetInstance("lamp_01", "lamp_01", Vec3(-3.10f, 0f, 5.10f)),
        AssetInstance("lamp_02", "lamp_02", Vec3(3.10f, 0f, 5.10f)),
        AssetInstance("lamp_03", "lamp_03", Vec3(-3.00f, 0f, 0.45f)),
        AssetInstance("lamp_04", "lamp_01", Vec3(3.00f, 0f, 0.45f)),
        AssetInstance("lamp_05", "lamp_02", Vec3(-3.10f, 0f, -4.85f)),
        AssetInstance("lamp_06", "lamp_03", Vec3(3.10f, 0f, -4.85f)),
    )

    val allInteractive = trees + benches + plants + lamps + listOf(
        AssetInstance("fountain_main", "fountain_01", Vec3(0f, 0f, -1.2f), cameraAnchor = Vec3(0f, 1.1f, -1.2f)),
        AssetInstance("entrance_gate", "gate_01", Vec3(0f, 0f, 11.0f), cameraAnchor = Vec3(0f, 1.2f, 10.5f)),
        AssetInstance("mansion_main", "building_01", Vec3(0f, 0f, -9.3f), cameraAnchor = Vec3(0f, 2.0f, -8.6f)),
    )

    private val byInstanceId = allInteractive.associateBy { it.instanceId }

    fun instance(id: String?): AssetInstance? = id?.let(byInstanceId::get)
}
