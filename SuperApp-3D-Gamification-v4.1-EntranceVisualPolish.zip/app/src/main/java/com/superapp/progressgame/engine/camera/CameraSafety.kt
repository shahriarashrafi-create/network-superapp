package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

private data class CameraObstacle(
    val x: Float,
    val z: Float,
    val radius: Float,
)

private val obstacles = listOf(
    CameraObstacle(0f, -9.3f, 5.35f),
    CameraObstacle(0f, -1.2f, 2.75f),
    CameraObstacle(0f, 11.0f, 2.35f),
    CameraObstacle(-9.4f, 7.1f, 1.7f), CameraObstacle(-11.2f, 2.0f, 1.8f),
    CameraObstacle(-9.8f, -4.4f, 1.7f), CameraObstacle(-11.6f, -10.5f, 1.8f),
    CameraObstacle(9.4f, 7.0f, 1.7f), CameraObstacle(11.0f, 2.0f, 1.8f),
    CameraObstacle(9.6f, -4.3f, 1.7f), CameraObstacle(11.7f, -10.4f, 1.8f),
)

fun constrainGameCamera(camera: Position, preset: CameraPreset): Position {
    val target = preset.target
    val dx = camera.x - target.x
    val dz = camera.z - target.z
    val horizontal = sqrt(dx * dx + dz * dz).coerceAtLeast(0.001f)
    val dy = camera.y - target.y

    val distance = sqrt(horizontal * horizontal + dy * dy).coerceAtLeast(0.001f)
    val clampedDistance = distance.coerceIn(preset.minRadius, preset.maxRadius)

    // Game camera only: no near-vertical builder angles and no underground views.
    val minPitch = Math.toRadians(10.0).toFloat()
    val maxPitch = Math.toRadians(52.0).toFloat()
    val pitch = atan2(dy, horizontal).coerceIn(minPitch, maxPitch)

    val horizontalAtDistance = max(0.1f, clampedDistance * cos(pitch))
    val verticalAtDistance = clampedDistance * sin(pitch)
    val planarScale = horizontalAtDistance / horizontal

    var x = target.x + dx * planarScale
    var z = target.z + dz * planarScale
    val y = target.y + verticalAtDistance

    obstacles.forEach { obstacle ->
        val ox = x - obstacle.x
        val oz = z - obstacle.z
        val d = sqrt(ox * ox + oz * oz).coerceAtLeast(0.001f)
        val safe = obstacle.radius + 0.65f
        if (d < safe && y < 5.6f) {
            val push = safe / d
            x = obstacle.x + ox * push
            z = obstacle.z + oz * push
        }
    }

    return Position(
        x = x.coerceIn(-20f, 20f),
        y = y.coerceIn(1.65f, 8.7f),
        z = z.coerceIn(-22f, 20f),
    )
}
