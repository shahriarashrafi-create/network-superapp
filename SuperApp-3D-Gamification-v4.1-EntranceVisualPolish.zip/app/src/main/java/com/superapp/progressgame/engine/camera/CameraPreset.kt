package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position

data class CameraPreset(
    val id: String,
    val eye: Position,
    val target: Position,
    val minRadius: Float,
    val maxRadius: Float,
)

object CameraPresets {
    // First authored shot: outside the gate, centered on the world axis.
    val EntranceFront = CameraPreset(
        id = "entrance_front",
        eye = Position(x = 0f, y = 2.20f, z = 17.2f),
        target = Position(x = 0f, y = 1.25f, z = -0.8f),
        minRadius = 12.0f,
        maxRadius = 20.0f,
    )

    // Main playable hero shot, just inside the gate.
    val Hero = CameraPreset(
        id = "hero",
        eye = Position(x = 0f, y = 3.15f, z = 8.35f),
        target = Position(x = 0f, y = 1.15f, z = -1.9f),
        minRadius = 8.2f,
        maxRadius = 16.5f,
    )

    val Overview = CameraPreset(
        id = "overview",
        eye = Position(x = 8.8f, y = 5.6f, z = 10.2f),
        target = Position(x = 0f, y = 1.15f, z = -2.0f),
        minRadius = 10.5f,
        maxRadius = 22.0f,
    )

    val Fountain = CameraPreset(
        id = "fountain_main",
        eye = Position(x = 5.8f, y = 3.25f, z = 4.6f),
        target = Position(x = 0f, y = 1.0f, z = -1.2f),
        minRadius = 4.8f,
        maxRadius = 10.0f,
    )

    val Mansion = CameraPreset(
        id = "mansion_main",
        eye = Position(x = 5.8f, y = 3.55f, z = -2.0f),
        target = Position(x = 0f, y = 1.8f, z = -9.0f),
        minRadius = 7.0f,
        maxRadius = 15.0f,
    )

    val Entrance = CameraPreset(
        id = "entrance_gate",
        eye = Position(x = 0f, y = 2.2f, z = 17.2f),
        target = Position(x = 0f, y = 1.35f, z = 11.0f),
        minRadius = 5.5f,
        maxRadius = 11.5f,
    )

    val GardenWest = CameraPreset(
        id = "garden_west",
        eye = Position(x = -10.0f, y = 3.8f, z = 5.0f),
        target = Position(x = -6.0f, y = 1.1f, z = -0.8f),
        minRadius = 5.0f,
        maxRadius = 12.0f,
    )

    val GardenEast = CameraPreset(
        id = "garden_east",
        eye = Position(x = 10.0f, y = 3.8f, z = 5.0f),
        target = Position(x = 6.0f, y = 1.1f, z = -0.8f),
        minRadius = 5.0f,
        maxRadius = 12.0f,
    )

    fun forObject(objectId: String?): CameraPreset = when {
        objectId == null -> Hero
        objectId.startsWith("fountain") -> Fountain
        objectId.startsWith("mansion") -> Mansion
        objectId.startsWith("entrance") -> Entrance
        objectId.startsWith("tree_w") || objectId.startsWith("bench_w") || objectId.startsWith("plant_0") -> GardenWest
        objectId.startsWith("tree_e") || objectId.startsWith("bench_e") -> GardenEast
        objectId.startsWith("lamp_") -> Hero
        else -> Hero
    }

    fun byId(id: String?): CameraPreset = when (id) {
        EntranceFront.id -> EntranceFront
        Hero.id -> Hero
        Overview.id -> Overview
        Fountain.id -> Fountain
        Mansion.id -> Mansion
        Entrance.id -> Entrance
        GardenWest.id -> GardenWest
        GardenEast.id -> GardenEast
        else -> Hero
    }
}
