package com.superapp.progressgame.core.config

data class FeatureFlags(
    val real3DRenderer: Boolean = true,
    val free3DCamera: Boolean = true,
    val objectPicking: Boolean = true,
    val basicTerrain: Boolean = true,
    val basicLighting: Boolean = true,
    val cameraFocus: Boolean = true,
    val cinematicCamera: Boolean = false,
    val missions: Boolean = false,
    val worldBuilder: Boolean = false,
    val particles: Boolean = false,
    val weather: Boolean = false,
    val avatar: Boolean = false,
    val npcs: Boolean = false,
    val debugOverlay: Boolean = true,
)

object FoundationFeatureFlags {
    val current = FeatureFlags()
}
