package com.superapp.progressgame.engine.scene

import io.github.sceneview.math.Position
import kotlin.math.roundToInt

data class RendererStats(
    val fps: Int = 0,
    val objectCount: Int = StarterWorldMetrics.VISIBLE_OBJECTS,
    val estimatedTriangles: Int = StarterWorldMetrics.ESTIMATED_TRIANGLES,
    val cameraPosition: Position = Position(x = 0f, y = 0f, z = 0f),
    val selectedObjectId: String? = null,
    val cameraPresetId: String = "overview",
)

object StarterWorldMetrics {
    const val VISIBLE_OBJECTS = 74
    const val ESTIMATED_TRIANGLES = 13_800
}

class FrameStatsSampler {
    private var windowStartedAtNanos: Long = 0L
    private var framesInWindow: Int = 0

    fun sample(
        frameTimeNanos: Long,
        cameraPosition: Position,
        selectedObjectId: String?,
        cameraPresetId: String,
    ): RendererStats? {
        if (windowStartedAtNanos == 0L) windowStartedAtNanos = frameTimeNanos
        framesInWindow += 1
        val elapsed = frameTimeNanos - windowStartedAtNanos
        if (elapsed < 750_000_000L) return null

        val fps = (framesInWindow * 1_000_000_000.0 / elapsed).roundToInt().coerceAtLeast(0)
        framesInWindow = 0
        windowStartedAtNanos = frameTimeNanos
        return RendererStats(
            fps = fps,
            cameraPosition = cameraPosition,
            selectedObjectId = selectedObjectId,
            cameraPresetId = cameraPresetId,
        )
    }
}
