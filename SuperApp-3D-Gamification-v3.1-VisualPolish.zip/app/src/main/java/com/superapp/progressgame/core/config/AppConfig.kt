package com.superapp.progressgame.core.config

object AppConfig {
    const val APP_ID = "com.superapp.progressgame"
    const val FOUNDATION_VERSION = "2.0.0-3d-core"
    const val SAVE_SCHEMA_VERSION = 2
    const val WORLD_SCHEMA_VERSION = 2
    const val DEFAULT_REGION_ID = "starter_estate"
    const val DEFAULT_CAMERA_PROFILE = "overview"
    const val RENDERER_NAME = "SceneView 4.32 + Google Filament"
}
