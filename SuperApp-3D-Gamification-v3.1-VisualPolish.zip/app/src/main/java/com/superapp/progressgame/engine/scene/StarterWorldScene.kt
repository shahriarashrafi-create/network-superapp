package com.superapp.progressgame.engine.scene

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import io.github.sceneview.SceneScope
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.math.Size

@Composable
fun SceneScope.StarterWorldScene(selectedObjectId: String?) {
    val grass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF6FA875), metallic = 0f, roughness = 0.98f)
    }
    val grassDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF53885E), metallic = 0f, roughness = 0.99f)
    }
    val soil = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF8A6D51), metallic = 0f, roughness = 1f)
    }
    val stone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFD8D4CC), metallic = 0f, roughness = 0.72f)
    }
    val stoneWarm = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFCDBA9F), metallic = 0f, roughness = 0.76f)
    }
    val stoneDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF8D8B86), metallic = 0.06f, roughness = 0.58f)
    }
    val wall = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFE7E2D8), metallic = 0f, roughness = 0.66f)
    }
    val wallAccent = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFCFC6B9), metallic = 0f, roughness = 0.68f)
    }
    val glass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5FA5C4), metallic = 0.18f, roughness = 0.16f)
    }
    val roof = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF98958F), metallic = 0.12f, roughness = 0.54f)
    }
    val wood = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF865A3E), metallic = 0f, roughness = 0.82f)
    }
    val woodDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF553926), metallic = 0f, roughness = 0.88f)
    }
    val metal = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF2E3B44), metallic = 0.86f, roughness = 0.26f)
    }
    val leaf = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF4D965F), metallic = 0f, roughness = 0.94f)
    }
    val leafLight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF6FB27A), metallic = 0f, roughness = 0.94f)
    }
    val leafDeep = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF39794B), metallic = 0f, roughness = 0.96f)
    }
    val trunk = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF63412C), metallic = 0f, roughness = 0.96f)
    }
    val water = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF55AFC8), metallic = 0.08f, roughness = 0.10f)
    }
    val waterHighlight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF9DEAF6), metallic = 0.10f, roughness = 0.04f)
    }
    val lampGlow = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFFFFDEA1))
    }
    val selection = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFF66DAFF))
    }

    // Large neutral ground prevents the world from reading as a floating tablet.
    CubeNode(
        size = Size(x = 74f, y = 0.08f, z = 74f),
        materialInstance = soil,
        position = Position(x = 0f, y = -0.16f, z = -3f),
        apply = { name = "terrain_far"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 38f, y = 0.10f, z = 36f),
        materialInstance = grass,
        position = Position(x = 0f, y = 0f, z = -1.8f),
        apply = { name = "terrain_main"; isTouchable = false }
    )

    // Flatter perimeter landscaping: no giant overlapping bubbles across the playable zone.
    val edgeMounds = listOf(
        Mound(-13.5f, 7.2f, 4.2f, 1.55f, 0.13f, 1.0f),
        Mound(-14.0f, -3.5f, 5.0f, 1.35f, 0.12f, 1.2f),
        Mound(-11.5f, -12.0f, 4.8f, 1.55f, 0.12f, 0.95f),
        Mound(13.5f, 7.0f, 4.0f, 1.45f, 0.13f, 1.0f),
        Mound(14.0f, -3.3f, 5.0f, 1.35f, 0.12f, 1.2f),
        Mound(11.5f, -12.0f, 4.6f, 1.5f, 0.12f, 0.95f),
        Mound(0f, -15.5f, 6.8f, 1.7f, 0.11f, 0.78f),
    )
    edgeMounds.forEachIndexed { index, mound ->
        SphereNode(
            radius = mound.radius,
            materialInstance = if (index % 2 == 0) grassDark else grass,
            position = Position(x = mound.x, y = 0.05f, z = mound.z),
            scale = Scale(x = mound.scaleX, y = mound.scaleY, z = mound.scaleZ),
            apply = { name = "terrain_mound_$index"; isTouchable = false }
        )
    }

    // Flat authored zones for the important gameplay objects.
    CylinderNode(
        radius = 3.55f,
        height = 0.08f,
        materialInstance = stoneWarm,
        position = Position(x = 0f, y = 0.04f, z = -1.2f),
        apply = { name = "fountain_plaza"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 10.5f, y = 0.08f, z = 5.6f),
        materialInstance = grass,
        position = Position(x = 0f, y = 0.04f, z = -9.4f),
        apply = { name = "mansion_ground_zone"; isTouchable = false }
    )

    // Entry gate is lighter, narrower and aligned with the path axis.
    Node(position = Position(x = 0f, y = 0f, z = 11.0f)) {
        CubeNode(
            size = Size(x = 0.36f, y = 2.45f, z = 0.36f),
            materialInstance = stoneWarm,
            position = Position(x = -1.55f, y = 1.23f),
            apply = { name = "entrance_gate_left" }
        )
        CubeNode(
            size = Size(x = 0.36f, y = 2.45f, z = 0.36f),
            materialInstance = stoneWarm,
            position = Position(x = 1.55f, y = 1.23f),
            apply = { name = "entrance_gate_right" }
        )
        CubeNode(
            size = Size(x = 3.46f, y = 0.25f, z = 0.36f),
            materialInstance = stoneWarm,
            position = Position(x = 0f, y = 2.34f),
            apply = { name = "entrance_gate_top" }
        )
    }

    // Main path, kept inside the authored flat corridor.
    val pavers = listOf(
        Paver(0f, 9.5f, 0f), Paver(0.08f, 8.2f, -2f), Paver(0.20f, 6.9f, -4f),
        Paver(0.34f, 5.6f, -5f), Paver(0.40f, 4.3f, -4f), Paver(0.28f, 3.0f, -2f),
        Paver(0.12f, 1.7f, 0f), Paver(0f, 0.4f, 0f), Paver(0f, -3.35f, 0f),
        Paver(0f, -4.55f, 0f), Paver(0f, -5.75f, 0f), Paver(0f, -6.95f, 0f),
    )
    pavers.forEachIndexed { index, paver ->
        CubeNode(
            size = Size(x = 1.95f, y = 0.06f, z = 0.92f),
            materialInstance = if (index % 2 == 0) stone else stoneWarm,
            position = Position(x = paver.x, y = 0.08f, z = paver.z),
            rotation = Rotation(y = paver.yaw),
            apply = { name = "path_$index"; isTouchable = false }
        )
    }

    // Fountain keeps its own material when selected. Selection is shown separately by a ring.
    Node(position = Position(x = 0f, y = 0f, z = -1.2f)) {
        CylinderNode(
            radius = 1.92f,
            height = 0.28f,
            materialInstance = stone,
            position = Position(y = 0.14f),
            apply = { name = "fountain_main_base" }
        )
        CylinderNode(
            radius = 1.56f,
            height = 0.10f,
            materialInstance = water,
            position = Position(y = 0.34f),
            apply = { name = "fountain_main_water" }
        )
        CylinderNode(
            radius = 0.30f,
            height = 1.35f,
            materialInstance = stone,
            position = Position(y = 0.98f),
            apply = { name = "fountain_main_column" }
        )
        CylinderNode(
            radius = 0.78f,
            height = 0.16f,
            materialInstance = stone,
            position = Position(y = 1.38f),
            apply = { name = "fountain_main_bowl" }
        )
        CylinderNode(
            radius = 0.55f,
            height = 0.07f,
            materialInstance = water,
            position = Position(y = 1.50f),
            apply = { name = "fountain_main_upper_water" }
        )
        SphereNode(
            radius = 0.12f,
            materialInstance = waterHighlight,
            position = Position(y = 1.90f),
            apply = { name = "fountain_main_spray" }
        )
    }

    // Mansion with stronger architecture hierarchy and better proportions.
    Node(position = Position(x = 0f, y = 0f, z = -9.3f)) {
        CubeNode(
            size = Size(x = 8.9f, y = 2.8f, z = 3.7f),
            materialInstance = wall,
            position = Position(y = 1.4f),
            apply = { name = "mansion_main_body" }
        )
        CubeNode(
            size = Size(x = 2.8f, y = 1.75f, z = 1.55f),
            materialInstance = wallAccent,
            position = Position(x = -2.15f, y = 3.45f, z = 0.20f),
            apply = { name = "mansion_main_upper"; isTouchable = false }
        )
        CubeNode(
            size = Size(x = 9.5f, y = 0.20f, z = 4.1f),
            materialInstance = roof,
            position = Position(y = 2.92f),
            apply = { name = "mansion_main_roof"; isTouchable = false }
        )
        CubeNode(
            size = Size(x = 1.2f, y = 2.05f, z = 0.10f),
            materialInstance = woodDark,
            position = Position(x = 0f, y = 1.03f, z = 1.90f),
            apply = { name = "mansion_main_door" }
        )
        listOf(-3.1f, -1.55f, 1.55f, 3.1f).forEachIndexed { index, x ->
            CubeNode(
                size = Size(x = 1.05f, y = 1.28f, z = 0.08f),
                materialInstance = glass,
                position = Position(x = x, y = 1.45f, z = 1.90f),
                apply = { name = "mansion_main_window_$index"; isTouchable = false }
            )
            CubeNode(
                size = Size(x = 1.18f, y = 1.42f, z = 0.05f),
                materialInstance = wallAccent,
                position = Position(x = x, y = 1.45f, z = 1.86f),
                apply = { name = "mansion_main_frame_$index"; isTouchable = false }
            )
        }
        CubeNode(
            size = Size(x = 3.25f, y = 0.14f, z = 1.55f),
            materialInstance = stoneWarm,
            position = Position(y = 0.12f, z = 2.42f),
            apply = { name = "mansion_main_terrace"; isTouchable = false }
        )
        listOf(-1.30f, 1.30f).forEachIndexed { index, x ->
            CylinderNode(
                radius = 0.13f,
                height = 2.15f,
                materialInstance = wallAccent,
                position = Position(x = x, y = 1.08f, z = 2.55f),
                apply = { name = "mansion_main_column_$index"; isTouchable = false }
            )
        }
        CubeNode(
            size = Size(x = 3.25f, y = 0.14f, z = 1.55f),
            materialInstance = roof,
            position = Position(y = 2.15f, z = 2.55f),
            apply = { name = "mansion_main_canopy"; isTouchable = false }
        )
    }

    // Nature is held to the perimeter so camera views remain readable.
    val trees = listOf(
        TreePlacement("tree_w_01", -9.4f, 7.1f, 0.90f, 0),
        TreePlacement("tree_w_02", -11.2f, 2.0f, 1.00f, 1),
        TreePlacement("tree_w_03", -9.8f, -4.4f, 0.90f, 2),
        TreePlacement("tree_w_04", -11.6f, -10.5f, 1.05f, 1),
        TreePlacement("tree_e_01", 9.4f, 7.0f, 0.92f, 1),
        TreePlacement("tree_e_02", 11.0f, 2.0f, 1.00f, 2),
        TreePlacement("tree_e_03", 9.6f, -4.3f, 0.92f, 0),
        TreePlacement("tree_e_04", 11.7f, -10.4f, 1.04f, 1),
    )
    trees.forEach { tree ->
        renderTree(tree, trunk, leaf, leafLight, leafDeep)
    }

    renderBench("bench_w_01", -4.7f, 2.7f, 28f, wood, metal)
    renderBench("bench_e_01", 4.7f, 2.7f, -28f, wood, metal)
    renderBench("bench_w_02", -4.9f, -4.5f, 18f, wood, metal)
    renderBench("bench_e_02", 4.9f, -4.5f, -18f, wood, metal)

    val shrubs = listOf(
        Shrub(-3.7f, -1.2f, 0.48f), Shrub(3.7f, -1.2f, 0.48f),
        Shrub(-4.8f, -7.0f, 0.56f), Shrub(4.8f, -7.0f, 0.56f),
        Shrub(-6.2f, 5.2f, 0.44f), Shrub(6.2f, 5.2f, 0.44f),
    )
    shrubs.forEachIndexed { index, shrub ->
        SphereNode(
            radius = shrub.radius,
            materialInstance = if (index % 2 == 0) leaf else leafLight,
            position = Position(x = shrub.x, y = shrub.radius * 0.65f, z = shrub.z),
            scale = Scale(x = 1.25f, y = 0.74f, z = 1.0f),
            apply = { name = "shrub_$index"; isTouchable = false }
        )
    }

    listOf(
        Pair(-2.75f, 8.4f), Pair(2.75f, 8.4f),
        Pair(-2.5f, 4.3f), Pair(2.5f, 4.3f),
        Pair(-2.55f, 0.3f), Pair(2.55f, 0.3f),
        Pair(-2.65f, -4.3f), Pair(2.65f, -4.3f),
    ).forEachIndexed { index, (x, z) ->
        renderLamp(index, x, z, metal, lampGlow)
    }

    // Selection is now a lightweight ground ring; materials never get replaced.
    selectionMarker(selectedObjectId)?.let { marker ->
        TorusNode(
            majorRadius = marker.radius,
            minorRadius = 0.045f,
            materialInstance = selection,
            position = Position(x = marker.x, y = 0.16f, z = marker.z),
            apply = { name = "selection_ring"; isTouchable = false }
        )
    }
}

@Composable
private fun SceneScope.renderTree(
    tree: TreePlacement,
    trunk: com.google.android.filament.MaterialInstance,
    leaf: com.google.android.filament.MaterialInstance,
    leafLight: com.google.android.filament.MaterialInstance,
    leafDeep: com.google.android.filament.MaterialInstance,
) {
    val crown = when (tree.style % 3) {
        0 -> leaf
        1 -> leafLight
        else -> leafDeep
    }
    Node(position = Position(x = tree.x, y = 0f, z = tree.z), scale = Scale(tree.scale)) {
        CylinderNode(
            radius = 0.22f,
            height = 2.25f,
            materialInstance = trunk,
            position = Position(y = 1.12f),
            apply = { name = "${tree.id}_trunk" }
        )
        when (tree.style % 3) {
            0 -> {
                ConeNode(
                    radius = 1.06f,
                    height = 1.95f,
                    materialInstance = crown,
                    position = Position(y = 2.25f),
                    apply = { name = "${tree.id}_crown_a" }
                )
                ConeNode(
                    radius = 0.75f,
                    height = 1.65f,
                    materialInstance = crown,
                    position = Position(y = 3.05f),
                    apply = { name = "${tree.id}_crown_b" }
                )
            }
            1 -> {
                SphereNode(
                    radius = 0.82f,
                    materialInstance = crown,
                    position = Position(y = 2.15f),
                    scale = Scale(x = 1.15f, y = 0.95f, z = 1.05f),
                    apply = { name = "${tree.id}_crown_a" }
                )
                SphereNode(
                    radius = 0.58f,
                    materialInstance = crown,
                    position = Position(x = 0.10f, y = 2.95f),
                    apply = { name = "${tree.id}_crown_b" }
                )
            }
            else -> {
                ConeNode(
                    radius = 0.92f,
                    height = 1.85f,
                    materialInstance = crown,
                    position = Position(y = 2.12f),
                    apply = { name = "${tree.id}_crown_a" }
                )
                SphereNode(
                    radius = 0.55f,
                    materialInstance = crown,
                    position = Position(y = 2.95f),
                    apply = { name = "${tree.id}_crown_b" }
                )
            }
        }
    }
}

@Composable
private fun SceneScope.renderBench(
    id: String,
    x: Float,
    z: Float,
    yaw: Float,
    wood: com.google.android.filament.MaterialInstance,
    metal: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z), rotation = Rotation(y = yaw)) {
        CubeNode(
            size = Size(x = 1.7f, y = 0.12f, z = 0.54f),
            materialInstance = wood,
            position = Position(y = 0.50f),
            apply = { name = "${id}_seat" }
        )
        CubeNode(
            size = Size(x = 1.7f, y = 0.58f, z = 0.11f),
            materialInstance = wood,
            position = Position(y = 0.84f, z = -0.22f),
            apply = { name = "${id}_back" }
        )
        listOf(-0.66f, 0.66f).forEachIndexed { index, legX ->
            CubeNode(
                size = Size(x = 0.09f, y = 0.50f, z = 0.09f),
                materialInstance = metal,
                position = Position(x = legX, y = 0.25f),
                apply = { name = "${id}_leg_$index" }
            )
        }
    }
}

@Composable
private fun SceneScope.renderLamp(
    index: Int,
    x: Float,
    z: Float,
    metal: com.google.android.filament.MaterialInstance,
    lampGlow: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z)) {
        CylinderNode(
            radius = 0.065f,
            height = 1.90f,
            materialInstance = metal,
            position = Position(y = 0.95f),
            apply = { name = "lamp_${index}_post"; isTouchable = false }
        )
        SphereNode(
            radius = 0.16f,
            materialInstance = lampGlow,
            position = Position(y = 1.93f),
            apply = { name = "lamp_${index}_glow"; isTouchable = false }
        )
    }
}

private fun selectionMarker(id: String?): SelectionMarker? = when {
    id == null -> null
    id.startsWith("fountain") -> SelectionMarker(0f, -1.2f, 2.25f)
    id.startsWith("mansion") -> SelectionMarker(0f, -9.3f, 4.95f)
    id.startsWith("entrance") -> SelectionMarker(0f, 11.0f, 1.95f)
    id.startsWith("tree_w_01") -> SelectionMarker(-9.4f, 7.1f, 1.15f)
    id.startsWith("tree_w_02") -> SelectionMarker(-11.2f, 2.0f, 1.20f)
    id.startsWith("tree_w_03") -> SelectionMarker(-9.8f, -4.4f, 1.10f)
    id.startsWith("tree_w_04") -> SelectionMarker(-11.6f, -10.5f, 1.25f)
    id.startsWith("tree_e_01") -> SelectionMarker(9.4f, 7.0f, 1.15f)
    id.startsWith("tree_e_02") -> SelectionMarker(11.0f, 2.0f, 1.20f)
    id.startsWith("tree_e_03") -> SelectionMarker(9.6f, -4.3f, 1.10f)
    id.startsWith("tree_e_04") -> SelectionMarker(11.7f, -10.4f, 1.25f)
    id.startsWith("bench_w_01") -> SelectionMarker(-4.7f, 2.7f, 1.05f)
    id.startsWith("bench_e_01") -> SelectionMarker(4.7f, 2.7f, 1.05f)
    id.startsWith("bench_w_02") -> SelectionMarker(-4.9f, -4.5f, 1.05f)
    id.startsWith("bench_e_02") -> SelectionMarker(4.9f, -4.5f, 1.05f)
    else -> null
}

private data class SelectionMarker(val x: Float, val z: Float, val radius: Float)
private data class Paver(val x: Float, val z: Float, val yaw: Float)
private data class Shrub(val x: Float, val z: Float, val radius: Float)
private data class TreePlacement(val id: String, val x: Float, val z: Float, val scale: Float, val style: Int)
private data class Mound(
    val x: Float,
    val z: Float,
    val radius: Float,
    val scaleX: Float,
    val scaleY: Float,
    val scaleZ: Float,
)
