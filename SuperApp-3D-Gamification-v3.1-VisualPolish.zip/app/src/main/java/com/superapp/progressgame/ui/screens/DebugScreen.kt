package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.debug.createDebugSnapshot
import com.superapp.progressgame.ui.theme.DeepSurface

@Composable
fun DebugScreen(
    progress: PlayerProgress,
    preferences: FoundationPreferences,
    onBack: () -> Unit,
) {
    val snapshot = createDebugSnapshot()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Developer Status", color = Color.White, fontSize = 27.sp)
        Text(
            "این صفحه فقط برای بررسی پایهٔ فنی پروژه است و بخشی از تجربهٔ اصلی بازی نیست.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 12.sp,
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSurface, RoundedCornerShape(22.dp))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            DebugRow("Build", snapshot.buildType)
            DebugRow("App ID", snapshot.appId)
            DebugRow("Version", snapshot.appVersion)
            DebugRow("Save schema", snapshot.saveSchema.toString())
            DebugRow("World schema", snapshot.worldSchema.toString())
            DebugRow("Renderer", snapshot.renderer)
            DebugRow("Foundation flags", snapshot.enabledFoundationFlags.toString())
            DebugRow("Active region", progress.activeRegionId)
            DebugRow("Camera preset", preferences.cameraPresetId)
            DebugRow("Selected object", preferences.selectedObjectId ?: "—")
            DebugRow("Level / XP / Coin", "${progress.level} / ${progress.xp} / ${progress.coins}")
        }
        Button(onClick = onBack) { Text("برگشت") }
    }
}

@Composable
private fun DebugRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(value, color = Color.White, fontSize = 12.sp)
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
    }
}
