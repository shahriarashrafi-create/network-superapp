from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]

required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradlew",
    "gradle/wrapper/gradle-wrapper.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/superapp/progressgame/MainActivity.kt",
    "app/src/main/java/com/superapp/progressgame/ui/GameFoundationApp.kt",
    "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt",
    "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt",
    "app/src/main/java/com/superapp/progressgame/engine/camera/CameraPreset.kt",
    "app/src/main/java/com/superapp/progressgame/world/WorldObjectCatalog.kt",
    "app/src/main/assets/models/README.txt",
    "app/src/main/assets/materials/README.txt",
    "app/src/main/assets/textures/README.txt",
    "app/src/main/assets/environments/README.txt",
    "app/src/main/assets/definitions/README.txt",
    "keystore/superapp.jks",
]

errors = []
for item in required:
    if not (root / item).is_file():
        errors.append(f"missing: {item}")

build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
root_build = (root / "build.gradle.kts").read_text(encoding="utf-8")
manifest_path = root / "app/src/main/AndroidManifest.xml"
manifest = manifest_path.read_text(encoding="utf-8")
gradlew = (root / "gradlew").read_text(encoding="utf-8")
wrapper = (root / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
world_shell = (root / "app/src/main/java/com/superapp/progressgame/ui/screens/WorldShellScreen.kt").read_text(encoding="utf-8")
scene = (root / "app/src/main/java/com/superapp/progressgame/engine/scene/StarterWorldScene.kt").read_text(encoding="utf-8")
app_config = (root / "app/src/main/java/com/superapp/progressgame/core/config/AppConfig.kt").read_text(encoding="utf-8")

checks = {
    "applicationId": 'applicationId = "com.superapp.progressgame"' in build,
    "versionCode 8": bool(re.search(r"versionCode\s*=\s*8\b", build)),
    "versionName V3.1": 'versionName = "3.1.0-visual-polish"' in build,
    "compileSdk 36": bool(re.search(r"compileSdk\s*=\s*36\b", build)),
    "targetSdk 36": bool(re.search(r"targetSdk\s*=\s*36\b", build)),
    "stable signing": 'signingConfigs.getByName("stable")' in build,
    "SceneView 4.32": 'io.github.sceneview:sceneview:4.32.0' in build,
    "AGP 8.13.2": 'com.android.application") version "8.13.2"' in root_build,
    "Kotlin 2.4.10": 'org.jetbrains.kotlin.android") version "2.4.10"' in root_build,
    "Compose compiler plugin": 'org.jetbrains.kotlin.plugin.compose") version "2.4.10"' in root_build,
    "Gradle launcher 8.13": 'GRADLE_VERSION="8.13"' in gradlew,
    "Gradle wrapper 8.13": 'gradle-8.13-bin.zip' in wrapper,
    "landscape": 'android:screenOrientation="landscape"' in manifest,
    "hardware accelerated": 'android:hardwareAccelerated="true"' in manifest,
    "real SceneView": 'SceneView(' in world_shell,
    "real camera manipulator": 'rememberCameraManipulator(' in world_shell,
    "real hit gestures": 'rememberOnGestureListener(' in world_shell,
    "transparent scene surface": 'SurfaceType.TextureSurface' in world_shell and 'isOpaque = false' in world_shell,
    "procedural 3D terrain": 'name = "terrain_main"' in scene,
    "procedural mansion": 'mansion_main_body' in scene,
    "procedural fountain": 'fountain_main_base' in scene,
    "procedural trees": 'tree_w_01' in scene and 'tree_e_03' in scene,
    "save schema 2": 'SAVE_SCHEMA_VERSION = 2' in app_config,
    "world schema 2": 'WORLD_SCHEMA_VERSION = 2' in app_config,
}

for name, ok in checks.items():
    if not ok:
        errors.append(f"check failed: {name}")

try:
    ET.parse(manifest_path)
except Exception as exc:
    errors.append(f"AndroidManifest.xml invalid: {exc}")

# Catch the exact V1 compile regression class of problem: internal Compose layout imports.
for kt in root.rglob("*.kt"):
    text = kt.read_text(encoding="utf-8")
    if "androidx.compose.foundation.layout.RowColumnParentData" in text:
        errors.append(f"forbidden internal Compose API import: {kt.relative_to(root)}")

# Lightweight delimiter sanity. This is not a Kotlin compiler, but catches accidental truncation.
def strip_strings_and_comments(source: str) -> str:
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.S)
    source = re.sub(r'//.*', '', source)
    source = re.sub(r'""".*?"""', '""', source, flags=re.S)
    source = re.sub(r'"(?:\\.|[^"\\])*"', '""', source)
    source = re.sub(r"'(?:\\.|[^'\\])*'", "''", source)
    return source

for kt in root.rglob("*.kt"):
    src = strip_strings_and_comments(kt.read_text(encoding="utf-8"))
    for opener, closer in [("(", ")"), ("{", "}"), ("[", "]")]:
        if src.count(opener) != src.count(closer):
            errors.append(
                f"delimiter mismatch {opener}{closer}: {kt.relative_to(root)} "
                f"({src.count(opener)} != {src.count(closer)})"
            )

# No giant painted world/background assets: V2 world must be runtime geometry.
large_raster_assets = []
for p in (root / "app/src/main").rglob("*"):
    if p.is_file() and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"} and p.stat().st_size > 1_000_000:
        large_raster_assets.append(p)
if large_raster_assets:
    errors.append(
        "unexpected large raster world assets: "
        + ", ".join(str(p.relative_to(root)) for p in large_raster_assets)
    )

if errors:
    print("PROJECT VERIFY: FAILED")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("PROJECT VERIFY: OK")
print("Package: com.superapp.progressgame")
print("Version code: 8")
print("Version name: 3.1.0-visual-polish")
print("Renderer: SceneView 4.32.0 / Google Filament")
print("Gradle: 8.13 | AGP: 8.13.2 | Kotlin: 2.4.10 | compileSdk: 36")
print("Project files:", sum(1 for p in root.rglob("*") if p.is_file()))
