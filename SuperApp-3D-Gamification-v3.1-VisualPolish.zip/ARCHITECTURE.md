# Version 2 — Real 3D Core Architecture

```text
app
└── com.superapp.progressgame
    ├── MainActivity
    ├── core
    │   ├── config
    │   │   ├── AppConfig
    │   │   └── FeatureFlags
    │   ├── model
    │   │   └── PlayerProgress
    │   ├── storage
    │   │   ├── FoundationPreferences
    │   │   ├── ProgressRepository
    │   │   └── LocalProgressRepository
    │   └── di
    │       └── AppContainer
    ├── debug
    │   └── DebugSnapshot
    ├── engine
    │   ├── camera
    │   │   └── CameraPreset
    │   └── scene
    │       ├── RendererStats
    │       └── StarterWorldScene
    ├── world
    │   └── WorldObjectCatalog
    └── ui
        ├── GameFoundationApp
        ├── components
        │   └── GameHud
        ├── screens
        │   ├── BootScreen
        │   ├── GatewayScreen
        │   ├── WorldShellScreen
        │   ├── SettingsScreen
        │   └── DebugScreen
        └── theme
```

## Rendering stack

```text
Compose Screen / HUD
        ↓
WorldShellScreen
        ↓
SceneView
        ↓
Google Filament
        ↓
StarterWorldScene (procedural X/Y/Z scene graph)
```

`MainActivity` هیچ Tree یا Mansion نمی‌سازد. محتوای World از UI جدا است و Renderer نیز به Regionهای آینده وابسته نشده است.

## Camera flow

```text
CameraPreset state
        ↓
rememberCameraManipulator
        ↓
Orbit / Pan / Zoom
        ↓
Tap / Double Tap hit-test
        ↓
WorldObjectCatalog.normalize
        ↓
Selected Object + Focus Preset
```

## Stable object identity

نمونه‌ها:

- `fountain_main`
- `mansion_main`
- `entrance_gate`
- `tree_w_01`
- `tree_e_03`
- `bench_w_01`
- `bench_e_01`

Meshهای تشکیل‌دهنده می‌توانند suffix داشته باشند اما در Interaction به ID پایدار والد Normalized می‌شوند.

## Asset pipeline

```text
app/src/main/assets/
├── models/
├── materials/
├── textures/
├── environments/
└── definitions/
```

V2 برای کاهش وابستگی اولیه از Procedural Geometry استفاده می‌کند. GLB/PBR asset library در V4 روی همین pipeline اضافه می‌شود.
