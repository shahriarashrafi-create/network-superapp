# QA Report — Version 2.1 Real 3D Core — Kotlin DSL Build Fix

## Static validation

- Project root layout for supplied ZIP workflow: PASS
- Package identity preserved: PASS (`com.superapp.progressgame`)
- Version code increased: PASS (`6`)
- Stable signing config preserved: PASS
- Keystore present: PASS
- Landscape manifest: PASS
- Hardware acceleration: PASS
- Immersive system bars: PASS
- Save schema: PASS (`2`)
- World schema: PASS (`2`)
- SceneView dependency: PASS (`4.32.0`)
- Google Filament supplied transitively by SceneView: PASS by dependency design
- compileSdk / targetSdk: PASS (`36 / 36`)
- Gradle launcher / wrapper property aligned: PASS (`8.13`)
- AGP: PASS (`8.13.2`)
- Kotlin + Compose compiler plugin: PASS (`2.4.10`)
- Kotlin JVM target migrated from deprecated `kotlinOptions.jvmTarget` string syntax to `compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }`: PASS
- Real `SceneView` present: PASS
- Real Camera Manipulator present: PASS
- Tap / Double Tap hit-test callbacks present: PASS
- Terrain / Mansion / Fountain / Tree geometry present: PASS
- Stable object IDs present: PASS
- Debug overlay present: PASS
- Asset pipeline folders present: PASS
- XML well-formedness: PASS
- Kotlin delimiter sanity: PASS
- V1 internal Compose `weight` regression guard: PASS
- No large painted world/background raster: PASS

## Important build note

The local sandbox used to assemble this ZIP has no external Maven/Gradle network access, therefore it cannot perform the first dependency download for SceneView/Filament and cannot be the authoritative `assembleDebug` runner. The supplied GitHub Actions workflow performs that build in a networked Ubuntu runner.

If GitHub reports any dependency/API compilation error, use that exact log as the next validation source before adding V3 features.
