package com.superapp.progressgame.world

data class WorldObjectDefinition(
    val id: String,
    val category: String,
    val cameraFocusable: Boolean = true,
)

object WorldObjectCatalog {
    val objects = listOf(
        WorldObjectDefinition("fountain_main", "landmark"),
        WorldObjectDefinition("mansion_main", "building"),
        WorldObjectDefinition("entrance_gate", "architecture"),
        WorldObjectDefinition("tree_w_01", "nature"),
        WorldObjectDefinition("tree_w_02", "nature"),
        WorldObjectDefinition("tree_w_03", "nature"),
        WorldObjectDefinition("tree_e_01", "nature"),
        WorldObjectDefinition("tree_e_02", "nature"),
        WorldObjectDefinition("tree_e_03", "nature"),
        WorldObjectDefinition("bench_w_01", "prop"),
        WorldObjectDefinition("bench_e_01", "prop"),
    )

    fun normalize(rawName: String?): String? {
        if (rawName.isNullOrBlank()) return null
        return when {
            rawName.startsWith("fountain") -> "fountain_main"
            rawName.startsWith("mansion") -> "mansion_main"
            rawName.startsWith("entrance") -> "entrance_gate"
            rawName.startsWith("tree_w_01") -> "tree_w_01"
            rawName.startsWith("tree_w_02") -> "tree_w_02"
            rawName.startsWith("tree_w_03") -> "tree_w_03"
            rawName.startsWith("tree_e_01") -> "tree_e_01"
            rawName.startsWith("tree_e_02") -> "tree_e_02"
            rawName.startsWith("tree_e_03") -> "tree_e_03"
            rawName.startsWith("bench_w") -> "bench_w_01"
            rawName.startsWith("bench_e") -> "bench_e_01"
            else -> rawName.takeIf { candidate -> objects.any { it.id == candidate } }
        }
    }
}
