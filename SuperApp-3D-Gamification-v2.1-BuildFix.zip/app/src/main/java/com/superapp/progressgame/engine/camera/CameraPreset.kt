package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position

data class CameraPreset(
    val id: String,
    val target: Position,
    val orbitRadius: Float,
)

object CameraPresets {
    val Overview = CameraPreset(
        id = "overview",
        target = Position(x = 0f, y = 1.0f, z = -1.0f),
        orbitRadius = 16.5f,
    )

    val Fountain = CameraPreset(
        id = "fountain_main",
        target = Position(x = 0f, y = 0.9f, z = -1.2f),
        orbitRadius = 6.0f,
    )

    val Mansion = CameraPreset(
        id = "mansion_main",
        target = Position(x = 0f, y = 1.9f, z = -7.2f),
        orbitRadius = 8.2f,
    )

    val Entrance = CameraPreset(
        id = "entrance_gate",
        target = Position(x = 0f, y = 1.0f, z = 6.1f),
        orbitRadius = 6.8f,
    )

    val GardenWest = CameraPreset(
        id = "garden_west",
        target = Position(x = -4.8f, y = 1.0f, z = -0.8f),
        orbitRadius = 6.5f,
    )

    val GardenEast = CameraPreset(
        id = "garden_east",
        target = Position(x = 4.8f, y = 1.0f, z = -0.8f),
        orbitRadius = 6.5f,
    )

    fun forObject(objectId: String?): CameraPreset = when {
        objectId == null -> Overview
        objectId.startsWith("fountain") -> Fountain
        objectId.startsWith("mansion") -> Mansion
        objectId.startsWith("entrance") -> Entrance
        objectId.startsWith("tree_w") || objectId.startsWith("bench_w") -> GardenWest
        objectId.startsWith("tree_e") || objectId.startsWith("bench_e") -> GardenEast
        else -> Overview
    }

    fun byId(id: String?): CameraPreset = when (id) {
        Fountain.id -> Fountain
        Mansion.id -> Mansion
        Entrance.id -> Entrance
        GardenWest.id -> GardenWest
        GardenEast.id -> GardenEast
        else -> Overview
    }
}
