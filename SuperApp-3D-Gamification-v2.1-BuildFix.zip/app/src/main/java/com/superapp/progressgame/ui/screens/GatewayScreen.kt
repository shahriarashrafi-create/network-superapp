package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.PrimaryBlue
import com.superapp.progressgame.ui.theme.SuccessGreen

@Composable
fun GatewayScreen(
    progress: PlayerProgress,
    onEnterWorld: () -> Unit,
    onSettings: () -> Unit,
    onDebug: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF06101C),
                        Color(0xFF0A2237),
                        Color(0xFF0C2E42),
                        Color(0xFF07121F),
                    )
                )
            )
            .padding(horizontal = 34.dp, vertical = 24.dp),
    ) {
        // Small atmospheric shapes. They are UI decoration only; the game world itself is 3D.
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(270.dp)
                .background(Color(0xFF4D7FFF).copy(alpha = 0.055f), CircleShape)
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(185.dp)
                .background(Color(0xFF5FE1E6).copy(alpha = 0.035f), CircleShape)
        )

        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(
                modifier = Modifier.weight(0.62f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.Start,
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(AccentCyan.copy(alpha = 0.13f), RoundedCornerShape(11.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            Icons.Rounded.Explore,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                    Text(
                        text = "PROGRESS WORLD",
                        color = AccentCyan.copy(alpha = 0.95f),
                        fontSize = 10.sp,
                        letterSpacing = 1.2.sp,
                    )
                }

                Text(
                    text = "دنیای تو با اقدام‌هایت ساخته می‌شود",
                    color = Color.White,
                    fontSize = 30.sp,
                    lineHeight = 39.sp,
                )
                Text(
                    text = "وارد جهان سه‌بعدی شو، محیط را آزادانه ببین و روی نقاط مهم تمرکز کن.",
                    color = Color(0xFFB1C2D5),
                    fontSize = 13.sp,
                    lineHeight = 22.sp,
                )

                Spacer(Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onEnterWorld,
                        modifier = Modifier.height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        shape = RoundedCornerShape(15.dp),
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("ورود به دنیا", fontSize = 13.sp)
                    }

                    IconButton(
                        onClick = onSettings,
                        modifier = Modifier
                            .size(46.dp)
                            .background(DeepSurface.copy(alpha = 0.72f), RoundedCornerShape(15.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(15.dp)),
                    ) {
                        Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات", tint = Color.White)
                    }

                    IconButton(
                        onClick = onDebug,
                        modifier = Modifier
                            .size(46.dp)
                            .background(DeepSurface.copy(alpha = 0.72f), RoundedCornerShape(15.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(15.dp)),
                    ) {
                        Icon(Icons.Rounded.BugReport, contentDescription = "اطلاعات توسعه", tint = Color.White)
                    }
                }
            }

            PlayerCard(
                progress = progress,
                modifier = Modifier.weight(0.30f),
            )
        }
    }
}

@Composable
private fun PlayerCard(progress: PlayerProgress, modifier: Modifier = Modifier) {
    val xpProgress = (progress.xp % 100) / 100f

    Column(
        modifier = modifier
            .background(DeepSurface.copy(alpha = 0.74f), RoundedCornerShape(24.dp))
            .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(24.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("LEVEL ${progress.level}", color = Color.White, fontSize = 23.sp)
        LinearProgressIndicator(
            progress = { xpProgress },
            modifier = Modifier.fillMaxWidth().height(5.dp),
            color = PrimaryBlue,
            trackColor = Color.White.copy(alpha = 0.10f),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("${progress.xp} XP", color = Color(0xFFB9C8DA), fontSize = 10.sp)
            Text("◉ ${progress.coins}", color = SuccessGreen, fontSize = 12.sp)
        }
        Text(
            text = "جهان آغازین آماده است",
            color = AccentCyan.copy(alpha = 0.9f),
            fontSize = 10.sp,
        )
    }
}
