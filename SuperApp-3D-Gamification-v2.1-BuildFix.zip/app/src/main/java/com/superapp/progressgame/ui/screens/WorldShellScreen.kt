package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.engine.camera.CameraPresets
import com.superapp.progressgame.engine.scene.FrameStatsSampler
import com.superapp.progressgame.engine.scene.RendererStats
import com.superapp.progressgame.engine.scene.StarterWorldScene
import com.superapp.progressgame.ui.components.GameHud
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.PrimaryBlue
import com.superapp.progressgame.world.WorldObjectCatalog
import io.github.sceneview.SceneView
import io.github.sceneview.SurfaceType
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberFillLightNode
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberOnGestureListener

@Composable
fun WorldShellScreen(
    progress: PlayerProgress,
    preferences: FoundationPreferences,
    onBack: () -> Unit,
    onSettings: () -> Unit,
) {
    val engine = rememberEngine()
    val cameraNode = rememberCameraNode(engine)
    var selectedObjectId by remember { mutableStateOf(preferences.selectedObjectId) }
    var cameraPreset by remember { mutableStateOf(CameraPresets.byId(preferences.cameraPresetId)) }
    var stats by remember { mutableStateOf(RendererStats(selectedObjectId = selectedObjectId)) }
    val sampler = remember { FrameStatsSampler() }

    val cameraManipulator = rememberCameraManipulator(
        orbitRadius = cameraPreset.orbitRadius,
        targetPosition = cameraPreset.target,
    )

    fun selectObject(rawName: String?, focus: Boolean) {
        val objectId = WorldObjectCatalog.normalize(rawName)
        selectedObjectId = objectId
        preferences.selectedObjectId = objectId
        if (focus && objectId != null) {
            cameraPreset = CameraPresets.forObject(objectId)
            preferences.cameraPresetId = cameraPreset.id
        }
    }

    fun resetCamera() {
        selectedObjectId = null
        preferences.selectedObjectId = null
        cameraPreset = CameraPresets.Overview
        preferences.cameraPresetId = CameraPresets.Overview.id
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF152A3C), Color(0xFF0C1A27), Color(0xFF071018))
                )
            )
    ) {
        SceneView(
            modifier = Modifier.fillMaxSize(),
            surfaceType = SurfaceType.TextureSurface,
            isOpaque = false,
            engine = engine,
            cameraNode = cameraNode,
            cameraManipulator = cameraManipulator,
            autoCenterContent = false,
            mainLightNode = rememberMainLightNode(engine) {
                intensity = 105_000f
            },
            fillLightNode = rememberFillLightNode(engine) {
                intensity = 28_000f
            },
            onGestureListener = rememberOnGestureListener(
                onSingleTapConfirmed = { _, node ->
                    selectObject(node?.name, focus = false)
                },
                onDoubleTap = { _, node ->
                    selectObject(node?.name, focus = true)
                },
            ),
            onFrame = { frameTimeNanos ->
                sampler.sample(
                    frameTimeNanos = frameTimeNanos,
                    cameraPosition = cameraNode.worldPosition,
                    selectedObjectId = selectedObjectId,
                    cameraPresetId = cameraPreset.id,
                )?.let { stats = it }
            },
        ) {
            StarterWorldScene(selectedObjectId = selectedObjectId)
        }

        GameHud(
            progress = progress,
            onSettings = onSettings,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .background(DeepSurface.copy(alpha = 0.78f), RoundedCornerShape(14.dp)),
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "برگشت", tint = Color.White)
            }
            IconButton(
                onClick = ::resetCamera,
                modifier = Modifier
                    .size(44.dp)
                    .background(DeepSurface.copy(alpha = 0.78f), RoundedCornerShape(14.dp)),
            ) {
                Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "نمای کلی", tint = Color.White)
            }
        }

        FloatingActionButton(
            onClick = {
                selectedObjectId = "fountain_main"
                preferences.selectedObjectId = selectedObjectId
                cameraPreset = CameraPresets.Fountain
                preferences.cameraPresetId = cameraPreset.id
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 14.dp)
                .size(48.dp),
            containerColor = PrimaryBlue,
            contentColor = Color.White,
        ) {
            Icon(Icons.Rounded.MyLocation, contentDescription = "هدف مأموریت")
        }

        Text(
            text = "یک انگشت: چرخش  •  دو انگشت: جابه‌جایی  •  Pinch: زوم  •  دوبار لمس: فوکوس",
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .background(Color.Black.copy(alpha = 0.36f), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            color = Color.White.copy(alpha = 0.70f),
            fontSize = 8.sp,
        )

        if (preferences.debugOverlayEnabled) {
            Debug3DOverlay(
                stats = stats,
                modifier = Modifier.align(Alignment.CenterEnd).padding(14.dp),
            )
        }
    }
}

@Composable
private fun Debug3DOverlay(stats: RendererStats, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.58f), RoundedCornerShape(12.dp))
            .padding(horizontal = 11.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Text("3D DEBUG", color = AccentCyan, fontSize = 9.sp)
        Text("FPS ${stats.fps}", color = Color.White, fontSize = 8.sp)
        Text("Objects ${stats.objectCount}", color = Color.White, fontSize = 8.sp)
        Text("Triangles ≈ ${stats.estimatedTriangles}", color = Color.White, fontSize = 8.sp)
        Text(
            "Camera %.1f / %.1f / %.1f".format(
                stats.cameraPosition.x,
                stats.cameraPosition.y,
                stats.cameraPosition.z,
            ),
            color = Color.White,
            fontSize = 8.sp,
        )
        Text("Preset ${stats.cameraPresetId}", color = Color.White, fontSize = 8.sp)
        Text("Hit ${stats.selectedObjectId ?: "—"}", color = Color.White, fontSize = 8.sp)
    }
}
