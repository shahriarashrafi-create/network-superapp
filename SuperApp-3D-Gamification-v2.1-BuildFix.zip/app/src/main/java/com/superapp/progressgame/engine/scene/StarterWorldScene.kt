package com.superapp.progressgame.engine.scene

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import io.github.sceneview.SceneScope
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.math.Size

@Composable
fun SceneScope.StarterWorldScene(selectedObjectId: String?) {
    val grass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5B815C), metallic = 0f, roughness = 0.92f)
    }
    val grassDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3C684B), metallic = 0f, roughness = 0.96f)
    }
    val stone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFB6B3AA), metallic = 0f, roughness = 0.78f)
    }
    val stoneDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF747A7D), metallic = 0f, roughness = 0.72f)
    }
    val warmStone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFD7C8AE), metallic = 0f, roughness = 0.74f)
    }
    val wood = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF78513A), metallic = 0f, roughness = 0.82f)
    }
    val trunk = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5A3B2A), metallic = 0f, roughness = 0.95f)
    }
    val leaf = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF2F7045), metallic = 0f, roughness = 0.9f)
    }
    val leafLight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF52935D), metallic = 0f, roughness = 0.88f)
    }
    val metal = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3E4854), metallic = 0.8f, roughness = 0.28f)
    }
    val glass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF4D8FB0), metallic = 0.15f, roughness = 0.12f)
    }
    val water = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3D9FC0), metallic = 0.05f, roughness = 0.08f)
    }
    val whiteWall = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFE8E3D9), metallic = 0f, roughness = 0.64f)
    }
    val accentWall = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFAFA9A0), metallic = 0f, roughness = 0.68f)
    }
    val highlight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF64D8FF), metallic = 0.15f, roughness = 0.16f)
    }
    val lampGlow = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFFFFE2A2))
    }

    // Terrain: real geometry in X/Y/Z, not a painted background.
    CubeNode(
        size = Size(x = 22f, y = 0.42f, z = 22f),
        center = Position(x = 0f, y = -0.21f, z = 0f),
        materialInstance = grass,
        position = Position(x = 0f, y = 0f, z = -1.2f),
        apply = { name = "terrain_main"; isTouchable = false }
    )

    // Gentle raised landscape sections make the starter scene visibly volumetric.
    SphereNode(
        radius = 3.7f,
        materialInstance = grassDark,
        position = Position(x = -7.4f, y = -3.1f, z = -4.0f),
        scale = Scale(x = 1.55f, y = 0.32f, z = 1.15f),
        apply = { name = "terrain_hill_w"; isTouchable = false }
    )
    SphereNode(
        radius = 3.4f,
        materialInstance = grassDark,
        position = Position(x = 7.2f, y = -3.0f, z = -3.2f),
        scale = Scale(x = 1.4f, y = 0.30f, z = 1.2f),
        apply = { name = "terrain_hill_e"; isTouchable = false }
    )

    // Curved-feeling approach path built from individual 3D pavers.
    val path = listOf(
        Triple(0.0f, 6.7f, 0f), Triple(-0.15f, 5.7f, -3f), Triple(-0.35f, 4.7f, -7f),
        Triple(-0.45f, 3.7f, -9f), Triple(-0.35f, 2.7f, -6f), Triple(-0.15f, 1.7f, -3f),
        Triple(0.0f, 0.75f, 0f), Triple(0.05f, -0.35f, 2f), Triple(0.0f, -2.4f, 0f),
        Triple(0.0f, -3.45f, 0f), Triple(0.0f, -4.5f, 0f), Triple(0.0f, -5.55f, 0f),
    )
    path.forEachIndexed { index, (x, z, yaw) ->
        CubeNode(
            size = Size(x = 1.85f, y = 0.10f, z = 0.86f),
            materialInstance = if (index % 2 == 0) stone else warmStone,
            position = Position(x = x, y = 0.05f, z = z),
            rotation = Rotation(y = yaw),
            apply = { name = "path_${index.toString().padStart(2, '0')}"; isTouchable = false }
        )
    }

    // Entrance gate.
    Node(position = Position(x = 0f, y = 0f, z = 7.65f)) {
        val gateMaterial = if (selectedObjectId == "entrance_gate") highlight else warmStone
        CubeNode(
            size = Size(x = 0.55f, y = 2.6f, z = 0.65f),
            materialInstance = gateMaterial,
            position = Position(x = -2.0f, y = 1.3f, z = 0f),
            apply = { name = "entrance_gate_left" }
        )
        CubeNode(
            size = Size(x = 0.55f, y = 2.6f, z = 0.65f),
            materialInstance = gateMaterial,
            position = Position(x = 2.0f, y = 1.3f, z = 0f),
            apply = { name = "entrance_gate_right" }
        )
        CubeNode(
            size = Size(x = 4.55f, y = 0.35f, z = 0.65f),
            materialInstance = gateMaterial,
            position = Position(x = 0f, y = 2.55f, z = 0f),
            apply = { name = "entrance_gate_top" }
        )
    }

    // Main fountain landmark.
    Node(position = Position(x = 0f, y = 0f, z = -1.2f)) {
        val fountainMaterial = if (selectedObjectId == "fountain_main") highlight else stone
        CylinderNode(
            radius = 1.85f,
            height = 0.34f,
            materialInstance = fountainMaterial,
            position = Position(y = 0.17f),
            apply = { name = "fountain_main_base" }
        )
        CylinderNode(
            radius = 1.48f,
            height = 0.12f,
            materialInstance = water,
            position = Position(y = 0.39f),
            apply = { name = "fountain_main_water" }
        )
        CylinderNode(
            radius = 0.26f,
            height = 1.45f,
            materialInstance = fountainMaterial,
            position = Position(y = 1.05f),
            apply = { name = "fountain_main_column" }
        )
        CylinderNode(
            radius = 0.84f,
            height = 0.18f,
            materialInstance = fountainMaterial,
            position = Position(y = 1.48f),
            apply = { name = "fountain_main_bowl" }
        )
        SphereNode(
            radius = 0.22f,
            materialInstance = water,
            position = Position(y = 2.05f),
            apply = { name = "fountain_main_spray" }
        )
    }

    // Modern starter mansion: every piece is true geometry so orbiting reveals all sides.
    Node(position = Position(x = 0f, y = 0f, z = -7.5f)) {
        val mansionWall = if (selectedObjectId == "mansion_main") highlight else whiteWall
        CubeNode(
            size = Size(x = 8.7f, y = 2.6f, z = 3.2f),
            materialInstance = mansionWall,
            position = Position(x = 0f, y = 1.3f, z = 0f),
            apply = { name = "mansion_main_body" }
        )
        CubeNode(
            size = Size(x = 3.2f, y = 1.8f, z = 1.15f),
            materialInstance = accentWall,
            position = Position(x = -2.2f, y = 3.25f, z = 0.35f),
            apply = { name = "mansion_main_upper" }
        )
        CubeNode(
            size = Size(x = 9.25f, y = 0.22f, z = 3.65f),
            materialInstance = stoneDark,
            position = Position(x = 0f, y = 2.72f, z = 0f),
            apply = { name = "mansion_main_roof" }
        )
        CubeNode(
            size = Size(x = 1.1f, y = 2.05f, z = 0.08f),
            materialInstance = metal,
            position = Position(x = 0f, y = 1.05f, z = 1.64f),
            apply = { name = "mansion_main_door" }
        )
        listOf(-3.2f, -1.65f, 1.65f, 3.2f).forEachIndexed { index, x ->
            CubeNode(
                size = Size(x = 1.05f, y = 1.3f, z = 0.07f),
                materialInstance = glass,
                position = Position(x = x, y = 1.42f, z = 1.65f),
                apply = { name = "mansion_main_window_$index" }
            )
        }
        CubeNode(
            size = Size(x = 4.4f, y = 0.16f, z = 1.4f),
            materialInstance = warmStone,
            position = Position(x = 0f, y = 0.08f, z = 2.25f),
            apply = { name = "mansion_main_terrace" }
        )
    }

    // Reusable tree definitions with stable IDs.
    val trees = listOf(
        TreePlacement("tree_w_01", -5.5f, -0.2f, 1.15f, false),
        TreePlacement("tree_w_02", -7.2f, -3.5f, 1.35f, true),
        TreePlacement("tree_w_03", -5.9f, -6.2f, 1.05f, false),
        TreePlacement("tree_e_01", 5.3f, 0.15f, 1.25f, true),
        TreePlacement("tree_e_02", 7.0f, -3.2f, 1.1f, false),
        TreePlacement("tree_e_03", 5.8f, -6.0f, 1.3f, true),
    )
    trees.forEach { tree ->
        Node(position = Position(x = tree.x, y = 0f, z = tree.z), scale = Scale(tree.scale)) {
            val treeLeaf = if (selectedObjectId == tree.id) highlight else if (tree.lightLeaves) leafLight else leaf
            CylinderNode(
                radius = 0.23f,
                height = 2.25f,
                materialInstance = trunk,
                position = Position(y = 1.12f),
                apply = { name = "${tree.id}_trunk" }
            )
            ConeNode(
                radius = 1.15f,
                height = 2.65f,
                materialInstance = treeLeaf,
                position = Position(y = 2.65f),
                apply = { name = "${tree.id}_crown_a" }
            )
            ConeNode(
                radius = 0.85f,
                height = 2.1f,
                materialInstance = treeLeaf,
                position = Position(y = 3.55f),
                apply = { name = "${tree.id}_crown_b" }
            )
        }
    }

    // Benches.
    renderBench("bench_w_01", -3.5f, 1.4f, 23f, selectedObjectId == "bench_w_01", wood, metal, highlight)
    renderBench("bench_e_01", 3.5f, 1.35f, -23f, selectedObjectId == "bench_e_01", wood, metal, highlight)

    // Garden plants around the landmark.
    listOf(-2.8f, -2.25f, 2.25f, 2.8f).forEachIndexed { index, x ->
        SphereNode(
            radius = 0.48f,
            materialInstance = if (index % 2 == 0) leaf else leafLight,
            position = Position(x = x, y = 0.34f, z = -1.4f),
            scale = Scale(x = 1.2f, y = 0.72f, z = 1.0f),
            apply = { name = "plant_${index}"; isTouchable = false }
        )
    }

    // Lamps along the main approach.
    listOf(
        Pair(-2.7f, 4.8f), Pair(2.55f, 4.4f), Pair(-2.45f, 1.55f), Pair(2.45f, 1.5f),
        Pair(-2.6f, -3.6f), Pair(2.6f, -3.65f)
    ).forEachIndexed { index, (x, z) ->
        Node(position = Position(x = x, y = 0f, z = z)) {
            CylinderNode(
                radius = 0.08f,
                height = 1.85f,
                materialInstance = metal,
                position = Position(y = 0.92f),
                apply = { name = "lamp_${index}_post"; isTouchable = false }
            )
            SphereNode(
                radius = 0.18f,
                materialInstance = lampGlow,
                position = Position(y = 1.9f),
                apply = { name = "lamp_${index}_glow"; isTouchable = false }
            )
        }
    }
}

@Composable
private fun SceneScope.renderBench(
    id: String,
    x: Float,
    z: Float,
    yaw: Float,
    selected: Boolean,
    wood: com.google.android.filament.MaterialInstance,
    metal: com.google.android.filament.MaterialInstance,
    highlight: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z), rotation = Rotation(y = yaw)) {
        val seatMaterial = if (selected) highlight else wood
        CubeNode(
            size = Size(x = 1.65f, y = 0.14f, z = 0.55f),
            materialInstance = seatMaterial,
            position = Position(y = 0.55f),
            apply = { name = "${id}_seat" }
        )
        CubeNode(
            size = Size(x = 1.65f, y = 0.65f, z = 0.12f),
            materialInstance = seatMaterial,
            position = Position(y = 0.92f, z = -0.22f),
            apply = { name = "${id}_back" }
        )
        listOf(-0.62f, 0.62f).forEachIndexed { index, legX ->
            CubeNode(
                size = Size(x = 0.10f, y = 0.55f, z = 0.10f),
                materialInstance = metal,
                position = Position(x = legX, y = 0.27f),
                apply = { name = "${id}_leg_$index" }
            )
        }
    }
}

private data class TreePlacement(
    val id: String,
    val x: Float,
    val z: Float,
    val scale: Float,
    val lightLeaves: Boolean,
)
