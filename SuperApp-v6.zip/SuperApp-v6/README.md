# Super App v6

Android Super App prototype - Kotlin + Jetpack Compose.

## Build
- Version name: 1.4.0
- Version code: 6
- Same applicationId and signing key as previous builds
- Offline/local-first for this phase

## Home v6
- Polished Legacy-inspired gamified Home
- Correct header layout: notification left, user/profile right
- Refined Level / XP / Coin / Streak strip
- More compact Next Action hero
- Code-drawn goal path / flag illustration (no raster image)
- XP + Coin reward chips
- Compact reward chest with code-drawn chest asset
- 30 Home shortcuts in 5 horizontal pages, 6 per page
- Right-edge continuation fade + page dots
- All 30 shortcut cards route to their destination/placeholder
- Header notification/profile and reward chest are also linked
- No photo/background image assets added
