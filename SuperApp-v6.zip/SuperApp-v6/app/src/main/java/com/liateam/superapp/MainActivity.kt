package com.liateam.superapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.model.AppSection
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.TaskStatus
import com.liateam.superapp.ui.model.initialTasks
import com.liateam.superapp.ui.screens.ActionsScreen
import com.liateam.superapp.ui.screens.HomeScreen
import com.liateam.superapp.ui.screens.PlaceholderScreen
import com.liateam.superapp.ui.screens.ProgressScreen
import com.liateam.superapp.ui.theme.SuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SuperAppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SuperAppRoot()
                }
            }
        }
    }
}

@Composable
private fun SuperAppRoot() {
    var section by remember { mutableStateOf(AppSection.HOME) }
    var homeDestination by remember { mutableStateOf<HomeDestination?>(null) }
    val tasks = remember { mutableStateListOf<AppTask>().apply { addAll(initialTasks()) } }

    fun updateTask(id: Int, status: TaskStatus) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index >= 0) tasks[index] = tasks[index].copy(status = status)
    }

    fun openDestination(destination: HomeDestination) {
        homeDestination = null
        when (destination) {
            HomeDestination.PROGRESS -> section = AppSection.PROGRESS
            HomeDestination.NETWORK -> section = AppSection.NETWORK
            HomeDestination.ACTIONS -> section = AppSection.ACTIONS
            else -> {
                section = AppSection.HOME
                homeDestination = destination
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SuperColors.Background,
        bottomBar = {
            MainBottomBar(
                section = section,
                onSelect = {
                    homeDestination = null
                    section = it
                }
            )
        }
    ) { innerPadding ->
        val destination = homeDestination
        if (destination != null) {
            PlaceholderScreen(
                contentPadding = innerPadding,
                title = destination.title,
                subtitle = destination.subtitle,
                onBack = {
                    homeDestination = null
                    section = AppSection.HOME
                }
            )
        } else {
            when (section) {
                AppSection.HOME -> HomeScreen(
                    contentPadding = innerPadding,
                    tasks = tasks,
                    onOpenActions = { section = AppSection.ACTIONS },
                    onOpenDestination = ::openDestination
                )

                AppSection.ACTIONS -> ActionsScreen(
                    contentPadding = innerPadding,
                    tasks = tasks,
                    onTaskStatus = ::updateTask,
                    onOpenProgress = { section = AppSection.PROGRESS }
                )

                AppSection.PROGRESS -> ProgressScreen(
                    contentPadding = innerPadding,
                    onBack = { section = AppSection.HOME }
                )

                AppSection.NETWORK -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "شبکه من",
                    subtitle = "درختواره، اعضای سازمان و Profile 360 از این بخش باز می‌شوند."
                )

                AppSection.MESSAGES -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "پیام‌ها",
                    subtitle = "Messenger، گروه‌ها و کانال‌های تیمی در این بخش قرار می‌گیرند."
                )

                AppSection.MORE -> PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = "بیشتر",
                    subtitle = "تمام ابزارهای کم‌استفاده‌تر و Shortcutهای قابل Pin از اینجا در دسترس خواهند بود."
                )
            }
        }
    }
}

@Composable
private fun MainBottomBar(
    section: AppSection,
    onSelect: (AppSection) -> Unit
) {
    val items = listOf(
        Triple(AppSection.HOME, "خانه", Icons.Outlined.Home),
        Triple(AppSection.ACTIONS, "اقدام‌ها", Icons.Outlined.TaskAlt),
        Triple(AppSection.NETWORK, "شبکه من", Icons.Outlined.Groups),
        Triple(AppSection.MESSAGES, "پیام‌ها", Icons.Outlined.ChatBubbleOutline),
        Triple(AppSection.MORE, "بیشتر", Icons.Outlined.MoreHoriz)
    )

    NavigationBar(
        modifier = Modifier.height(68.dp),
        containerColor = Color.White,
        tonalElevation = androidx.compose.ui.unit.Dp.Unspecified
    ) {
        items.forEach { (target, label, icon) ->
            val selected = when (section) {
                AppSection.PROGRESS -> target == AppSection.ACTIONS
                else -> section == target
            }
            NavigationBarItem(
                selected = selected,
                onClick = { onSelect(target) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = SuperColors.Blue,
                    selectedTextColor = SuperColors.Blue,
                    indicatorColor = SuperColors.BlueSoft,
                    unselectedIconColor = SuperColors.TextSecondary,
                    unselectedTextColor = SuperColors.TextSecondary
                )
            )
        }
    }
}
