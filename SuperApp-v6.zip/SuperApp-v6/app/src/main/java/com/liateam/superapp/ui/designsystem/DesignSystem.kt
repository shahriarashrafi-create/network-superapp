package com.liateam.superapp.ui.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object SuperColors {
    val Blue = Color(0xFF1677F0)
    val BlueStrong = Color(0xFF0867E8)
    val BlueDeep = Color(0xFF0C55C8)
    val BlueSoft = Color(0xFFEAF4FF)
    val BlueSoft2 = Color(0xFFF5F9FF)
    val Sky = Color(0xFF69B7FF)

    val Navy = Color(0xFF0B1F44)
    val Text = Color(0xFF111D35)
    val TextSecondary = Color(0xFF6E7B93)
    val Border = Color(0xFFE5EDF7)
    val BorderBlue = Color(0xFFCDE3FA)
    val Background = Color(0xFFF7FAFE)
    val Surface = Color.White

    val Green = Color(0xFF13A36D)
    val GreenSoft = Color(0xFFE9F9F2)
    val Red = Color(0xFFE33E52)
    val RedSoft = Color(0xFFFFECEF)
    val Orange = Color(0xFFF2A51A)
    val OrangeSoft = Color(0xFFFFF6DF)
    val Purple = Color(0xFF7257E8)
    val PurpleSoft = Color(0xFFF2EEFF)
    val Gold = Color(0xFFF1B632)
    val GoldBright = Color(0xFFFFC83D)
    val GoldDeep = Color(0xFFCB8611)
    val GoldSoft = Color(0xFFFFF7DE)
    val NeutralSoft = Color(0xFFF1F4F8)
}

object SuperDimens {
    val ScreenPadding = 16.dp
    val CardRadius = 24.dp
    val SmallRadius = 17.dp
    val PillRadius = 999.dp
}

object SuperShapes {
    val Card = RoundedCornerShape(SuperDimens.CardRadius)
    val Small = RoundedCornerShape(SuperDimens.SmallRadius)
    val Pill = RoundedCornerShape(SuperDimens.PillRadius)
}
