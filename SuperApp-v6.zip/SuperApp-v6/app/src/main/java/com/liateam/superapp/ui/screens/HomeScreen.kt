package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.homeDestinations

private data class ShortcutVisual(
    val icon: ImageVector,
    val accent: Color,
    val accent2: Color,
    val soft: Color
)

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val nextAction = tasks.firstOrNull { it.status.name == "TODO" } ?: tasks.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFFBFDFF), Color(0xFFF5FAFF), SuperColors.Background)
                )
            )
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 5.dp,
                bottom = contentPadding.calculateBottomPadding() + 4.dp
            )
    ) {
        HomeHeader(
            onNotifications = { onOpenDestination(HomeDestination.NOTIFICATIONS) },
            onProfile = { onOpenDestination(HomeDestination.PROFILE) }
        )
        Spacer(Modifier.height(5.dp))
        StatusStrip()
        Spacer(Modifier.height(7.dp))

        NextActionHero(
            modifier = Modifier.weight(0.95f),
            task = nextAction,
            onStart = onOpenActions
        )

        Spacer(Modifier.height(7.dp))
        RewardStrip(onClick = { onOpenDestination(HomeDestination.REWARD_STORE) })
        Spacer(Modifier.height(7.dp))

        ShortcutPager(
            modifier = Modifier.weight(1.50f),
            onOpenDestination = onOpenDestination
        )
    }
}

@Composable
private fun HomeHeader(
    onNotifications: () -> Unit,
    onProfile: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier = Modifier.fillMaxWidth().height(49.dp)) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(42.dp)
                    .shadow(5.dp, SuperShapes.Small, clip = false)
                    .background(Color.White, SuperShapes.Small),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onNotifications, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.NotificationsNone,
                        contentDescription = "اعلان‌ها",
                        tint = SuperColors.Navy,
                        modifier = Modifier.size(23.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(10.dp)
                        .background(SuperColors.Red, CircleShape)
                        .border(2.dp, Color.White, CircleShape)
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "سلام، شهریار",
                        color = SuperColors.Text,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        lineHeight = 24.sp
                    )
                    Text(
                        "امروز روی قدم بعدی تمرکز کن",
                        color = SuperColors.TextSecondary,
                        fontSize = 9.6.sp,
                        lineHeight = 12.sp
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(46.dp)
                    .shadow(4.dp, CircleShape, clip = false)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFFF4F9FF), Color(0xFFD9EDFF))
                        ),
                        CircleShape
                    )
                    .border(2.dp, SuperColors.Gold.copy(alpha = 0.68f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onProfile, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.Person,
                        contentDescription = "پروفایل",
                        tint = SuperColors.Blue,
                        modifier = Modifier.size(27.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(16.dp)
                        .background(SuperColors.Gold, CircleShape)
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("♛", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatusStrip() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .shadow(5.dp, SuperShapes.Small, clip = false),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.98f)),
        shape = SuperShapes.Small,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatWithSymbol(
                    modifier = Modifier.weight(0.82f),
                    symbol = "♛",
                    value = "سطح ۳",
                    label = "مسیر لیدر",
                    accent = SuperColors.Gold
                )
                Hairline()
                Column(modifier = Modifier.weight(1.50f)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("240 / 500 XP", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                        Text("XP", color = SuperColors.TextSecondary, fontSize = 9.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    LinearProgressIndicator(
                        progress = { 0.48f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = Color(0xFFE3ECF7)
                    )
                }
                Hairline()
                StatWithSymbol(
                    modifier = Modifier.weight(0.72f),
                    symbol = "●",
                    value = "۶۹۵",
                    label = "سکه",
                    accent = SuperColors.Gold
                )
                Hairline()
                StatWithSymbol(
                    modifier = Modifier.weight(0.82f),
                    symbol = "◆",
                    value = "۷",
                    label = "روز متوالی",
                    accent = SuperColors.Orange
                )
            }
        }
    }
}

@Composable
private fun StatWithSymbol(modifier: Modifier = Modifier, symbol: String, value: String, label: String, accent: Color) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Box(
            modifier = Modifier.size(22.dp).background(accent.copy(alpha = 0.13f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(symbol, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(3.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(value, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 11.3.sp, maxLines = 1)
                Text(label, color = accent, fontSize = 7.2.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

@Composable
private fun Hairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 7.dp)
            .width(1.dp)
            .height(29.dp)
            .background(SuperColors.Border)
    )
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(7.dp, SuperShapes.Card, clip = false),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFFF8FCFF), Color(0xFFEAF5FF), Color(0xFFE3F1FF))
                    )
                )
                .border(1.dp, SuperColors.BorderBlue, SuperShapes.Card)
                .padding(horizontal = 14.dp, vertical = 11.dp)
        ) {
            val compact = maxHeight < 158.dp
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1.28f), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(31.dp).background(Color.White.copy(alpha = 0.90f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text("قدم بعدی", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 11.3.sp)
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(
                        task.title,
                        color = SuperColors.Text,
                        fontWeight = FontWeight.Black,
                        fontSize = if (compact) 20.sp else 22.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        "امروز یک مخاطب جدید را دعوت کن.",
                        color = SuperColors.TextSecondary,
                        fontSize = 9.8.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(if (compact) 5.dp else 7.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = onStart,
                            modifier = Modifier.weight(1f).height(if (compact) 37.dp else 40.dp),
                            shape = SuperShapes.Small,
                            contentPadding = PaddingValues(horizontal = 11.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                        ) {
                            Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("شروع", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                        }
                        Spacer(Modifier.width(6.dp))
                        RewardChip("+${task.points} XP  •  +2 Coin", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    }
                }
                Spacer(Modifier.width(8.dp))
                GoalPathIllustration(modifier = Modifier.weight(0.64f).fillMaxHeight())
            }
        }
    }
}

@Composable
private fun RewardChip(text: String, accent: Color, soft: Color) {
    Box(
        modifier = Modifier.background(soft, SuperShapes.Pill).padding(horizontal = 8.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 9.3.sp, maxLines = 1)
    }
}

@Composable
private fun GoalPathIllustration(modifier: Modifier) {
    Canvas(modifier = modifier.padding(2.dp)) {
        val w = size.width
        val h = size.height

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFFFFF), Color(0x00FFFFFF)),
                center = Offset(w * 0.58f, h * 0.48f),
                radius = minOf(w, h) * 0.58f
            ),
            radius = minOf(w, h) * 0.52f,
            center = Offset(w * 0.58f, h * 0.48f)
        )

        fun cube(cx: Float, cy: Float, s: Float, top: Color, left: Color, right: Color) {
            val topPath = Path().apply {
                moveTo(cx, cy - s * 0.48f)
                lineTo(cx + s * 0.55f, cy - s * 0.19f)
                lineTo(cx, cy + s * 0.10f)
                lineTo(cx - s * 0.55f, cy - s * 0.19f)
                close()
            }
            val leftPath = Path().apply {
                moveTo(cx - s * 0.55f, cy - s * 0.19f)
                lineTo(cx, cy + s * 0.10f)
                lineTo(cx, cy + s * 0.68f)
                lineTo(cx - s * 0.55f, cy + s * 0.38f)
                close()
            }
            val rightPath = Path().apply {
                moveTo(cx + s * 0.55f, cy - s * 0.19f)
                lineTo(cx, cy + s * 0.10f)
                lineTo(cx, cy + s * 0.68f)
                lineTo(cx + s * 0.55f, cy + s * 0.38f)
                close()
            }
            drawPath(topPath, top)
            drawPath(leftPath, left)
            drawPath(rightPath, right)
        }

        cube(w * 0.20f, h * 0.68f, w * 0.24f, Color(0xFFFFFFFF), Color(0xFFD9E9F9), Color(0xFFEAF4FC))
        cube(w * 0.43f, h * 0.58f, w * 0.26f, Color(0xFF60A9FB), Color(0xFF0D6DE7), Color(0xFF3B8EEF))
        cube(w * 0.67f, h * 0.47f, w * 0.29f, Color(0xFFFFFFFF), Color(0xFFDDEBF8), Color(0xFFF1F7FC))
        cube(w * 0.82f, h * 0.29f, w * 0.34f, Color(0xFFFFD36B), Color(0xFFF0A91D), Color(0xFFFFBF35))

        val arrow = Path().apply {
            moveTo(w * 0.18f, h * 0.45f)
            cubicTo(w * 0.35f, h * 0.43f, w * 0.50f, h * 0.34f, w * 0.64f, h * 0.23f)
        }
        drawPath(arrow, SuperColors.Blue, style = Stroke(width = 7f, cap = StrokeCap.Round))
        val arrowHead = Path().apply {
            moveTo(w * 0.61f, h * 0.18f)
            lineTo(w * 0.72f, h * 0.20f)
            lineTo(w * 0.67f, h * 0.30f)
            close()
        }
        drawPath(arrowHead, SuperColors.Blue)

        val poleX = w * 0.82f
        val poleTop = h * 0.04f
        val poleBottom = h * 0.24f
        drawLine(SuperColors.GoldDeep, Offset(poleX, poleBottom), Offset(poleX, poleTop), strokeWidth = 5f, cap = StrokeCap.Round)
        val flag = Path().apply {
            moveTo(poleX + 2f, poleTop + 3f)
            lineTo(w * 0.96f, poleTop + h * 0.04f)
            lineTo(poleX + 2f, poleTop + h * 0.095f)
            close()
        }
        drawPath(flag, brush = Brush.linearGradient(listOf(SuperColors.GoldBright, Color(0xFFF09F17))))

        drawCircle(Color(0xFFF4B82F), radius = 4.5f, center = Offset(w * 0.32f, h * 0.18f))
        drawCircle(Color(0xFF7EBBFA), radius = 3.8f, center = Offset(w * 0.54f, h * 0.12f))
    }
}

@Composable
private fun RewardStrip(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .shadow(4.dp, SuperShapes.Small, clip = false),
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBF1)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0xFFFFE2A0), SuperShapes.Small)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RewardChestAsset(modifier = Modifier.size(45.dp))
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("صندوق پاداش", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 13.2.sp)
                Text("هر ۳ ساعت یک پاداش جدید", color = SuperColors.TextSecondary, fontSize = 8.7.sp)
            }
            Box(
                modifier = Modifier.background(Color.White.copy(alpha = 0.92f), SuperShapes.Pill).padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text("02:15:36", color = SuperColors.Text, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(6.dp))
            Box(modifier = Modifier.size(30.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Text("‹", color = SuperColors.Blue, fontSize = 20.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun RewardChestAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val bodyTop = h * 0.40f
        val bodyBottom = h * 0.83f

        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFCCF53), Color(0xFFE89A18))),
            topLeft = Offset(w * 0.10f, bodyTop),
            size = Size(w * 0.80f, bodyBottom - bodyTop),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFF5BA6F8), Color(0xFF126DCE))),
            topLeft = Offset(w * 0.08f, h * 0.17f),
            size = Size(w * 0.84f, h * 0.35f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(11f, 11f)
        )
        drawLine(Color(0xFFFFE7A1), Offset(w * 0.17f, h * 0.48f), Offset(w * 0.83f, h * 0.48f), strokeWidth = 3f)
        drawRoundRect(
            Color(0xFFFFE8A6),
            topLeft = Offset(w * 0.42f, h * 0.43f),
            size = Size(w * 0.16f, h * 0.24f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f, 5f)
        )
        drawCircle(Color(0xFFF4B62F), radius = w * 0.055f, center = Offset(w * 0.50f, h * 0.57f))
        drawCircle(Color(0xFFFFD761), radius = w * 0.055f, center = Offset(w * 0.10f, h * 0.80f))
        drawCircle(Color(0xFFFFD761), radius = w * 0.045f, center = Offset(w * 0.88f, h * 0.77f))
    }
}

@Composable
private fun ShortcutPager(
    modifier: Modifier,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val pages = remember { homeDestinations().chunked(6) }
    val pagerState = rememberPagerState(pageCount = { pages.size })

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.83f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val pageWidth = maxWidth - 18.dp

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    pageSize = PageSize.Fixed(pageWidth),
                    pageSpacing = 8.dp,
                    contentPadding = PaddingValues(start = 0.dp, end = 18.dp),
                    beyondViewportPageCount = 1
                ) { page ->
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ShortcutPage(
                            destinations = pages[page],
                            currentPage = page,
                            pageCount = pages.size,
                            onOpenDestination = onOpenDestination
                        )
                    }
                }
            }

            if (pagerState.currentPage < pages.lastIndex) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .width(20.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, SuperColors.BlueSoft.copy(alpha = 0.82f))
                            )
                        )
                )
            }
        }
    }
}

@Composable
private fun ShortcutPage(
    destinations: List<HomeDestination>,
    currentPage: Int,
    pageCount: Int,
    onOpenDestination: (HomeDestination) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().height(22.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("دسترسی سریع", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 13.2.sp)
            Spacer(Modifier.weight(1f))
            Text("برای بیشتر بکش", color = SuperColors.Blue.copy(alpha = 0.68f), fontSize = 8.5.sp, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(4.dp))

        val top = destinations.take(3)
        val bottom = destinations.drop(3)
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            top.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bottom.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
            repeat(3 - bottom.size) { Spacer(Modifier.weight(1f)) }
        }
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth().height(10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(pageCount) { index ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (index == currentPage) 8.dp else 5.5.dp)
                        .background(if (index == currentPage) SuperColors.Blue else Color(0xFFD5E1EE), CircleShape)
                )
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    modifier: Modifier,
    destination: HomeDestination,
    onClick: () -> Unit
) {
    val visual = shortcutVisual(destination)
    Card(
        modifier = modifier.shadow(2.dp, SuperShapes.Small, clip = false),
        onClick = onClick,
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, SuperColors.Border, SuperShapes.Small)
                .padding(horizontal = 5.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            ShortcutAsset(visual = visual)
            Spacer(Modifier.height(3.dp))
            Text(
                destination.title,
                color = SuperColors.Text,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp,
                maxLines = 1,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ShortcutAsset(visual: ShortcutVisual) {
    Box(
        modifier = Modifier
            .size(width = 58.dp, height = 48.dp)
            .clip(SuperShapes.Small)
            .background(
                Brush.linearGradient(
                    listOf(visual.soft, Color.White)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(visual.accent.copy(alpha = 0.10f), radius = size.minDimension * 0.30f, center = Offset(size.width * 0.73f, size.height * 0.32f))
            drawCircle(visual.accent2.copy(alpha = 0.12f), radius = size.minDimension * 0.17f, center = Offset(size.width * 0.19f, size.height * 0.72f))
            drawRoundRect(
                color = visual.accent.copy(alpha = 0.13f),
                topLeft = Offset(size.width * 0.17f, size.height * 0.67f),
                size = Size(size.width * 0.67f, size.height * 0.16f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(9f, 9f)
            )
        }
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(Color.White.copy(alpha = 0.96f), CircleShape)
                .border(1.dp, visual.accent.copy(alpha = 0.16f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(22.dp))
        }
    }
}

private fun shortcutVisual(destination: HomeDestination): ShortcutVisual = when (destination) {
    HomeDestination.PROGRESS -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.Sky, SuperColors.BlueSoft)
    HomeDestination.NETWORK -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, Color(0xFF6CD4A7), SuperColors.GreenSoft)
    HomeDestination.ACADEMY -> ShortcutVisual(Icons.Outlined.School, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.MY_WEEK -> ShortcutVisual(Icons.Outlined.CalendarMonth, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.ACTIONS -> ShortcutVisual(Icons.Outlined.TaskAlt, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.CUSTOMERS -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Orange, SuperColors.Gold, SuperColors.OrangeSoft)
    HomeDestination.LEADER_CENTER -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.GoldDeep, SuperColors.Gold, SuperColors.GoldSoft)
    HomeDestination.GOALS -> ShortcutVisual(Icons.Outlined.TrackChanges, SuperColors.Red, SuperColors.Orange, SuperColors.RedSoft)
    HomeDestination.RANK_REWARDS -> ShortcutVisual(Icons.Outlined.EmojiEvents, SuperColors.GoldDeep, SuperColors.GoldBright, SuperColors.GoldSoft)
    HomeDestination.EVENTS -> ShortcutVisual(Icons.Outlined.Event, SuperColors.Red, SuperColors.Purple, SuperColors.RedSoft)
    HomeDestination.LIBRARY -> ShortcutVisual(Icons.Outlined.MenuBook, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.SALES -> ShortcutVisual(Icons.Outlined.ShoppingCart, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.REPORTS -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.PERSONAL_STORE -> ShortcutVisual(Icons.Outlined.Storefront, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.PROFILE -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.SETTINGS -> ShortcutVisual(Icons.Outlined.Settings, SuperColors.TextSecondary, SuperColors.Blue, SuperColors.NeutralSoft)
    HomeDestination.SEARCH -> ShortcutVisual(Icons.Outlined.Search, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.NOTIFICATIONS -> ShortcutVisual(Icons.Outlined.NotificationsNone, SuperColors.Red, SuperColors.Gold, SuperColors.RedSoft)
    HomeDestination.FOCUS -> ShortcutVisual(Icons.Outlined.Timer, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TREE -> ShortcutVisual(Icons.Outlined.AccountTree, SuperColors.Green, SuperColors.Blue, SuperColors.GreenSoft)
    HomeDestination.PROFILE_360 -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.GROUPS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Orange, SuperColors.Green, SuperColors.OrangeSoft)
    HomeDestination.CHANNELS -> ShortcutVisual(Icons.Outlined.ChatBubbleOutline, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TEAM_MEMBERS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.DREAM_BOARD -> ShortcutVisual(Icons.Outlined.Flag, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.ACHIEVEMENTS -> ShortcutVisual(Icons.Outlined.WorkspacePremium, SuperColors.GoldDeep, SuperColors.Purple, SuperColors.GoldSoft)
    HomeDestination.LEADERBOARD -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.REWARD_STORE -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.Orange, SuperColors.Gold, SuperColors.OrangeSoft)
    HomeDestination.WEBSITE -> ShortcutVisual(Icons.Outlined.Language, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.ORDERS -> ShortcutVisual(Icons.Outlined.ReceiptLong, SuperColors.Green, SuperColors.Orange, SuperColors.GreenSoft)
}
