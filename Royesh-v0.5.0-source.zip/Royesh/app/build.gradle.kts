import java.util.zip.ZipFile

plugins { id("com.android.application"); kotlin("android") }

// Keep the installed v0.1 development signature. Never silently replace its key.
val signingKey = rootProject.file("signing/royesh-development.jks")
if (!signingKey.exists()) {
    val workspace = System.getenv("GITHUB_WORKSPACE")?.let(::File)
    val archives = workspace?.walkTopDown()?.filter { it.isFile && it.extension.equals("zip", true) && ".git" !in it.toPath().map { p -> p.toString() } }?.toList().orEmpty()
    val keys = archives.mapNotNull { archive ->
        runCatching { ZipFile(archive).use { zip ->
            val entry = zip.entries().asSequence().firstOrNull { it.name.endsWith("signing/royesh-development.jks") && it.size in 1..20000 }
            entry?.let { zip.getInputStream(it).use { stream -> stream.readBytes() } }
        } }.getOrNull()
    }
    if (keys.isNotEmpty()) {
        check(keys.all { it.contentEquals(keys.first()) }) { "Different Royesh development keys found. Keep the original v0.1 ZIP only." }
        signingKey.parentFile.mkdirs(); signingKey.writeBytes(keys.first())
    }
}
val hasOriginalKey = signingKey.exists()
val selectedKey = if (hasOriginalKey) signingKey else rootProject.file("signing/royesh-preview.jks")
check(selectedKey.exists()) { "Bundled preview keystore missing; download the complete v0.2.1 ZIP." }
logger.lifecycle(if (hasOriginalKey) "Royesh: original signing key found; building upgrade." else "Royesh: original key unavailable; building separate preview app. Original installation is preserved.")

android {
    namespace = "ir.royesh.app"
    compileSdk = 35
    defaultConfig {
        applicationId = if (hasOriginalKey) "ir.royesh.app" else "ir.royesh.app.preview"
        manifestPlaceholders["appLabel"] = if (hasOriginalKey) "رویش" else "رویش آزمایشی"
        minSdk = 26; targetSdk = 35; versionCode = 6; versionName = "0.5.0"
    }
    signingConfigs { getByName("debug") { storeFile = selectedKey; storePassword = "android"; keyAlias = "royesh-development"; keyPassword = "android" } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.15" }
}
dependencies {
    implementation(project(":core"))
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
