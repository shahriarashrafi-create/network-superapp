package ir.royesh.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.royesh.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate

private fun roleName(role: String) = when (role) { "HEAD" -> "مدیر اصلی"; "ADMIN" -> "ادمین"; "LEADER" -> "لیدر"; else -> "عضو" }
@Composable fun OrganizationScreen(state: AppState, client: CloudClient, busy: Boolean, setBusy: (Boolean) -> Unit, save: (AppState) -> Boolean, account: () -> Unit) {
    var data by remember { mutableStateOf<JSONObject?>(null) }; var status by remember { mutableStateOf("") }
    var orgName by remember { mutableStateOf("") }; var invite by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }
    var display by remember { mutableStateOf(state.profile.name) }; var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<JSONObject?>(null) }; var expanded by remember { mutableStateOf(setOf<String>()) }
    var scale by remember { mutableFloatStateOf(1f) }
    val scope = rememberCoroutineScope()
    fun request(path: String, body: JSONObject? = null) {
        if (busy) return
        setBusy(true); status = "در حال ارتباط…"
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { runCatching { client.request(path, if (body == null) "GET" else "POST", body) } }
                result.onSuccess { response ->
                    if (response.has("code")) { invite = response.getString("code"); status = "دعوت یک‌بارمصرف تا ۷ روز معتبر است؛ عضو جدید زیرمجموعهٔ خودت قرار می‌گیرد." }
                    else { data = response; status = "اطلاعات سازمان دریافت شد."; val nodes = response.optJSONArray("members"); if (nodes != null) expanded = (0 until nodes.length()).map { nodes.getJSONObject(it) }.filter { it.isNull("sponsor_id") }.map { it.getString("user_id") }.toSet() }
                }.onFailure { status = it.message ?: "ارتباط برقرار نشد" }
            } finally { setBusy(false) }
        }
    }
    Text("سازمان و درختواره", style = MaterialTheme.typography.headlineSmall)
    val logged = runCatching { client.session != null }.getOrDefault(false)
    if (!logged) { Text("برای ساخت یا پیوستن به سازمان واقعی، ابتدا وارد حساب شو."); Button(onClick = account) { Text("رفتن به حساب") }; return }
    Button(enabled = !busy, onClick = { request("/organization") }) { Text("دریافت / تازه‌سازی سازمان") }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (status.isNotBlank()) Text(status)
    val current = data
    if (current == null) { Text("اطلاعات سازمان فقط از سرور خوانده می‌شود؛ دکمهٔ دریافت را بزن."); return }
    if (current.isNull("organization")) {
        Panel("ورود به سازمان · گام ۱") {
            Field(display, { display = it }, "نام نمایشی در سازمان")
            Field(orgName, { orgName = it }, "نام سازمان جدید")
            Button(enabled = !busy && display.isNotBlank() && orgName.isNotBlank(), onClick = { request("/organization/create", JSONObject().put("name", orgName).put("display_name", display)) }) { Text("ساخت سازمان و مدیر اصلی شدن") }
        }
        Panel("دعوت از اسپانسر داری؟") {
            Field(code, { code = it }, "کد دعوت خصوصی")
            Button(enabled = !busy && code.isNotBlank() && display.isNotBlank(), onClick = { request("/organization/join", JSONObject().put("code", code.trim()).put("display_name", display)) }) { Text("پیوستن با اسپانسر مشخص") }
        }
        return
    }
    val me = current.getJSONObject("me"); val array = current.getJSONArray("members")
    val nodes = (0 until array.length()).map { array.getJSONObject(it) }
    val myId = me.getString("user_id"); val myRole = me.getString("role")
    val sponsor = if (me.isNull("sponsor_id")) null else nodes.firstOrNull { it.getString("user_id") == me.getString("sponsor_id") }
    Panel(current.getJSONObject("organization").getString("name")) {
        Text("نقش تو: ${roleName(myRole)} · ${nodes.size} عضو")
        Text("اسپانسر: ${sponsor?.getString("name") ?: "ریشهٔ سازمان"}")
        Text("هر حساب یک عضویت دارد؛ اسپانسر با دعوت تعیین می‌شود و در این نسخه جابه‌جایی شاخه وجود ندارد.", style = MaterialTheme.typography.bodySmall)
    }
    val startId = "org-start-$myId"
    Panel("شروع سازمانی · گام ۲") {
        Text(if (sponsor == null) "اولین عضو را با دعوت خودت وارد کن." else "با اسپانسرت هماهنگ کن و یک اقدام حمایتی انجام بده.")
        Button(enabled = !busy && state.tasks.none { it.id == startId }, onClick = {
            save(state.copy(tasks = state.tasks + Task(id = startId, title = if (sponsor == null) "دعوت اولین عضو سازمان" else "هماهنگی شروع با ${sponsor.getString("name")}", due = LocalDate.now().toString(), priority = 2)))
        }) { Text(if (state.tasks.any { it.id == startId }) "مأموریت در مرکز اقدام ثبت شده" else "ثبت اولین مأموریت در مرکز اقدام") }
    }
    Button(enabled = !busy, onClick = { request("/organization/invite", JSONObject()) }) { Text("ساخت دعوت برای زیرمجموعهٔ خودم") }
    if (invite.isNotBlank()) Panel("کد دعوت؛ خصوصی ارسال کن") { SelectionContainer { Text(invite) } }
    Field(search, { search = it }, "جست‌وجوی نام اعضا")
    Text("بزرگ‌نمایی درختواره")
    Slider(scale, { scale = it }, valueRange = 0.8f..1.5f)
    val byId = nodes.associateBy { it.getString("user_id") }
    val children = nodes.groupBy { if (it.isNull("sponsor_id")) "" else it.getString("sponsor_id") }
    fun depth(node: JSONObject): Int {
        var p = node; var d = 0; val visited = mutableSetOf<String>()
        while (!p.isNull("sponsor_id") && d < 100 && visited.add(p.getString("user_id"))) { p = byId[p.getString("sponsor_id")] ?: break; d++ }
        return d
    }
    fun visible(node: JSONObject): Boolean {
        var p = node; val visited = mutableSetOf<String>()
        while (!p.isNull("sponsor_id") && visited.add(p.getString("user_id"))) {
            val id = p.getString("sponsor_id"); if (id !in expanded) return false; p = byId[id] ?: return false
        }; return true
    }
    // Sort by ancestry so every sponsor stays next to their branch.
    fun path(node: JSONObject): String { var p = node; val names = mutableListOf<String>(); val visited = mutableSetOf<String>(); while (visited.add(p.getString("user_id"))) { names.add(p.getString("name") + p.getString("user_id")); if (p.isNull("sponsor_id")) break; p = byId[p.getString("sponsor_id")] ?: break }; return names.reversed().joinToString("/") }
    nodes.sortedBy(::path).filter { if (search.isNotBlank()) it.getString("name").contains(search, true) else visible(it) }.forEach { node ->
        val id = node.getString("user_id"); val d = depth(node)
        Column(Modifier.padding(start = (d.coerceAtMost(6) * 12 * scale).dp)) {
            Panel(node.getString("name") + if (id == myId) " · شما" else "") {
                Text("${roleName(node.getString("role"))} · عمق $d · ${children[id]?.size ?: 0} زیرمجموعهٔ مستقیم", fontSize = (14 * scale).sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!children[id].isNullOrEmpty()) TextButton(onClick = { expanded = if (id in expanded) expanded - id else expanded + id }) { Text(if (id in expanded) "بستن شاخه" else "باز کردن شاخه") }
                    TextButton(onClick = { selected = node }) { Text("پروفایل عضو") }
                }
            }
        }
    }
    selected?.let { member ->
        val targetRole = member.getString("role"); val id = member.getString("user_id")
        Form(member.getString("name"), true, { selected = null }, { selected = null }, saveLabel = "بستن") {
            Text("نقش: ${roleName(targetRole)}")
            Text("اسپانسر: ${if (member.isNull("sponsor_id")) "ریشه" else byId[member.getString("sponsor_id")]?.getString("name") ?: "نامشخص"}")
            Text("زیرمجموعهٔ مستقیم: ${children[id]?.size ?: 0}")
            if (myRole in listOf("HEAD", "ADMIN") && targetRole != "HEAD" && id != myId && (myRole == "HEAD" || targetRole != "ADMIN")) {
                Text("مدیریت نقش؛ رتبهٔ فروش نیست")
                listOf("USER", "LEADER", "ADMIN").filter { myRole == "HEAD" || it != "ADMIN" }.forEach { role ->
                    OutlinedButton(enabled = !busy && role != targetRole, onClick = { selected = null; request("/organization/role", JSONObject().put("user_id", id).put("role", role)) }) { Text("تغییر به ${roleName(role)}") }
                }
            }
        }
    }
}
