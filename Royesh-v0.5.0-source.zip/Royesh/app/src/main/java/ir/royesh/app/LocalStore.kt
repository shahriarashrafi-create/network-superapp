package ir.royesh.app

import android.content.Context
import ir.royesh.core.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("royesh-v1", Context.MODE_PRIVATE)
    fun load(): AppState = prefs.getString("state", null)?.let(::decode) ?: AppState()
    fun save(state: AppState) { check(prefs.edit().putString("state", encode(state)).commit()) }
    fun encode(s: AppState): String = StateCodec.encode(s)
    fun decode(raw: String): AppState = StateCodec.decode(raw)
}

object StateCodec {
    fun encode(s: AppState): String = JSONObject().apply {
        put("schema", 3); put("profile", JSONObject().put("name", s.profile.name).put("dailyGoal", s.profile.dailyGoal))
        put("customers", JSONArray().apply { s.customers.forEach { c -> put(JSONObject().put("id", c.id).put("name", c.name).put("phone", c.phone).put("need", c.need)) } })
        put("products", JSONArray().apply { s.products.forEach { p -> put(JSONObject().put("id", p.id).put("name", p.name).put("price", p.price).put("pv", p.pv).put("active", p.active)) } })
        put("orders", JSONArray().apply { s.orders.forEach { o -> put(JSONObject().put("id", o.id).put("customerId", o.customerId).put("created", o.created).put("status", o.status.name).put("completedAt", o.completedAt ?: JSONObject.NULL).put("source", o.source).put("lines", JSONArray().apply { o.lines.forEach { l -> put(JSONObject().put("productId", l.productId).put("name", l.name).put("price", l.price).put("pv", l.pv).put("quantity", l.quantity)) } })) } })
        put("salesGoals", JSONArray().apply { s.salesGoals.forEach { put(JSONObject().put("month", it.month).put("amount", it.amount)) } })
        put("people", JSONArray().apply { s.people.forEach { p -> put(JSONObject().put("id", p.id).put("name", p.name).put("phone", p.phone).put("stage", p.stage.name)) } })
        put("tasks", JSONArray().apply { s.tasks.forEach { t -> put(JSONObject().put("id", t.id).put("title", t.title).put("personId", t.personId ?: JSONObject.NULL).put("customerId", t.customerId ?: JSONObject.NULL).put("due", t.due).put("priority", t.priority).put("done", t.done)) } })
        put("actions", JSONArray().apply { s.actions.forEach { a -> put(JSONObject().put("id", a.id).put("taskId", a.taskId).put("personId", a.personId ?: JSONObject.NULL).put("title", a.title).put("result", a.result).put("occurredAt", a.occurredAt).put("xp", a.xp)) } })
        put("blocks", JSONArray().apply { s.blocks.forEach { b -> put(JSONObject().put("id", b.id).put("title", b.title).put("date", b.date).put("hour", b.hour).put("minutes", b.minutes).put("weekly", b.weekly).put("actuals", JSONObject(b.actuals))) } })
        put("goals", JSONArray().apply { s.goals.forEach { g -> put(JSONObject().put("month", g.month).put("target", g.target)) } })
        s.focus?.let { put("focus", JSONObject().put("taskId", it.taskId).put("startedAt", it.startedAt).put("endsAt", it.endsAt)) }
    }.toString(2)
    fun decode(raw: String): AppState {
        require(raw.toByteArray().size <= 2_000_000)
        val j = JSONObject(raw); val schema = j.getInt("schema"); require(schema in 1..3)
        fun rows(key: String): List<JSONObject> {
            val a = if ((schema == 1 && key in listOf("blocks", "goals")) || (schema < 3 && key in listOf("customers", "products", "orders", "salesGoals"))) JSONArray() else j.getJSONArray(key)
            return (0 until a.length()).map(a::getJSONObject)
        }
        fun JSONObject.person(): String? = if (isNull("personId")) null else getString("personId")
        val p = j.getJSONObject("profile")
        val s = AppState(Profile(p.getString("name"), p.getInt("dailyGoal")),
            rows("people").map { Person(it.getString("id"), it.getString("name"), it.getString("phone"), Stage.valueOf(it.getString("stage"))) },
            rows("tasks").map { Task(it.getString("id"), it.getString("title"), it.person(), it.getString("due"), it.getInt("priority"), it.getBoolean("done"), if (it.isNull("customerId")) null else it.getString("customerId")) },
            rows("actions").map { Action(it.getString("id"), it.getString("taskId"), it.person(), it.getString("title"), it.getString("result"), it.getString("occurredAt"), it.getInt("xp")) },
            rows("blocks").map { b -> val a = b.getJSONObject("actuals"); TimeBlock(b.getString("id"), b.getString("title"), b.getString("date"), b.getInt("hour"), b.getInt("minutes"), b.getBoolean("weekly"), a.keys().asSequence().associateWith { a.getInt(it) }) },
            rows("goals").map { MonthlyGoal(it.getString("month"), it.getInt("target")) },
            j.optJSONObject("focus")?.let { FocusSession(it.getString("taskId"), it.getLong("startedAt"), it.getLong("endsAt")) },
            rows("customers").map { Customer(it.getString("id"), it.getString("name"), it.getString("phone"), it.getString("need")) },
            rows("products").map { Product(it.getString("id"), it.getString("name"), it.getLong("price"), it.getInt("pv"), it.getBoolean("active")) },
            rows("orders").map { o -> val a = o.getJSONArray("lines"); SaleOrder(o.getString("id"), o.getString("customerId"), (0 until a.length()).map { i -> val l = a.getJSONObject(i); OrderLine(l.getString("productId"), l.getString("name"), l.getLong("price"), l.getInt("pv"), l.getInt("quantity")) }, o.getString("created"), OrderStatus.valueOf(o.getString("status")), o.getString("source"), if (o.isNull("completedAt")) null else o.getString("completedAt")) },
            rows("salesGoals").map { SalesGoal(it.getString("month"), it.getLong("amount")) })
        require(s.profile.dailyGoal in 1..10)
        require(s.people.map { it.id }.distinct().size == s.people.size)
        require(s.tasks.map { it.id }.distinct().size == s.tasks.size)
        require(s.actions.map { it.taskId }.distinct().size == s.actions.size)
        s.tasks.forEach { LocalDate.parse(it.due); require(it.title.isNotBlank()); require(it.personId == null || s.people.any { p -> p.id == it.personId }) }
        s.actions.forEach { require(it.xp == 10 && it.result.isNotBlank()); java.time.LocalDateTime.parse(it.occurredAt); require(s.tasks.any { t -> t.id == it.taskId && t.done }) }
        s.blocks.forEach { b -> LocalDate.parse(b.date); require(b.hour in 0..23 && b.minutes in 15..240 && b.hour * 60 + b.minutes <= 1440 && b.title.isNotBlank()); b.actuals.forEach { (d, m) -> LocalDate.parse(d); require(m in 0..1440) } }
        s.goals.forEach { java.time.YearMonth.parse(it.month); require(it.target in 1..10000) }
        s.focus?.let { require(s.tasks.any { t -> t.id == it.taskId }); require(it.endsAt > it.startedAt && it.endsAt - it.startedAt <= 120 * 60000) }
        require(s.customers.map { it.id }.distinct().size == s.customers.size && s.orders.map { it.id }.distinct().size == s.orders.size && s.products.map { it.id }.distinct().size == s.products.size)
        s.customers.forEach { require(it.name.isNotBlank()) }
        s.products.forEach { require(it.name.isNotBlank() && it.price in 0..1_000_000_000_000L && it.pv in 0..1_000_000) }
        s.tasks.forEach { require(it.customerId == null || s.customers.any { c -> c.id == it.customerId }) }
        s.orders.forEach { o -> java.time.LocalDateTime.parse(o.created); o.completedAt?.let { java.time.LocalDateTime.parse(it) }; require(s.customers.any { it.id == o.customerId } && o.lines.size in 1..100); o.lines.forEach { require(it.quantity in 1..999 && it.price in 0..1_000_000_000_000L && it.pv in 0..1_000_000 && it.name.isNotBlank()) } }
        s.salesGoals.forEach { java.time.YearMonth.parse(it.month); require(it.amount in 1..1_000_000_000_000_000L) }
        return s
    }
}
