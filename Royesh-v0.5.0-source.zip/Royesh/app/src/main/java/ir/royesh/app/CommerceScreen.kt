package ir.royesh.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.royesh.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.*
import java.util.UUID

private fun money(value: Long) = String.format(java.util.Locale.US, "%,d", value) + " تومان"
@Composable fun CommerceScreen(state: AppState, client: CloudClient, busy: Boolean, setBusy: (Boolean) -> Unit, save: (AppState) -> Boolean, account: () -> Unit) {
    var section by remember { mutableIntStateOf(0) }; var search by remember { mutableStateOf("") }
    var editCustomer by remember { mutableStateOf<Customer?>(null) }; var customerForm by remember { mutableStateOf(false) }
    var editProduct by remember { mutableStateOf<Product?>(null) }; var productForm by remember { mutableStateOf(false) }
    var orderForm by remember { mutableStateOf(false) }; var cart by remember { mutableStateOf(mapOf<String, Int>()) }
    var status by remember { mutableStateOf("") }; var storeUrl by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("فروشگاه ${state.profile.name}") }
    val scope = rememberCoroutineScope()
    fun job(work: () -> JSONObject, done: (JSONObject) -> Unit) {
        if (busy) return
        setBusy(true); status = "در حال ارتباط…"
        scope.launch { try {
            val result = withContext(Dispatchers.IO) { runCatching(work) }
            // Local imports are allowed only once the network operation ends.
            setBusy(false)
            result.onSuccess { response -> runCatching { done(response) }.onFailure { status = it.message ?: "خطا" } }.onFailure { status = it.message ?: "ارتباط برقرار نشد" }
        } finally { setBusy(false) } }
    }
    Text("مشتری و فروش", style = MaterialTheme.typography.headlineSmall)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("مشتریان", "محصولات", "فروش", "فروشگاه").forEachIndexed { i, s -> FilterChip(section == i, { section = i }, enabled = !busy, label = { Text(s) }) } }
    val month = YearMonth.now().toString()
    when (section) {
        0 -> {
            Field(search, { search = it }, "جست‌وجوی مشتری؛ جدا از لیست مخاطبان")
            Button(onClick = { editCustomer = null; customerForm = true }) { Text("+ مشتری جدید") }
            if (state.customers.isEmpty()) Text("مشتری را با نیازش ثبت کن؛ مشتری و مخاطب شبکه‌سازی دو پروندهٔ جدا دارند.")
            state.customers.filter { it.name.contains(search, true) || it.phone.contains(search) }.forEach { c ->
                val purchases = state.orders.filter { it.customerId == c.id && it.status == OrderStatus.COMPLETED }
                val follow = state.tasks.filter { it.customerId == c.id && !it.done }.minByOrNull { it.due }
                Panel(c.name) {
                    Text(c.phone); if (c.need.isNotBlank()) Text("نیاز و یادداشت: ${c.need}")
                    Text("${purchases.size} خرید تأییدشده · ${money(purchases.sumOf { it.total })}")
                    if (purchases.size >= 2) Text("مشتری با خرید تکراری", color = Lime)
                    Text(if (follow == null) "پیگیری باز ندارد" else "اقدام بعدی: ${follow.title} · ${faDate(follow.due)}")
                    TextButton(onClick = { save(state.copy(tasks = state.tasks + Task(title = "پیگیری مشتری ${c.name}", due = LocalDate.now().plusDays(1).toString(), customerId = c.id))) }) { Text("ساخت پیگیری فردا در مرکز اقدام") }
                    TextButton(onClick = { editCustomer = c; customerForm = true }) { Text("ویرایش پرونده") }
                    purchases.takeLast(3).reversed().forEach { Text("${faDate(it.created.take(10))} · ${it.lines.joinToString { l -> l.name }} · ${money(it.total)}") }
                }
            }
        }
        1 -> {
            Button(onClick = { editProduct = null; productForm = true }) { Text("+ محصول جدید") }
            if (state.products.isEmpty()) Text("نام، قیمت به تومان و PV محصولات خودت را ثبت کن.")
            state.products.forEach { p -> Panel(p.name) {
                Text("${money(p.price)} · ${p.pv} PV · ${if (p.active) "فعال" else "بایگانی"}")
                TextButton(onClick = { editProduct = p; productForm = true }) { Text("ویرایش محصول") }
                TextButton(onClick = { save(state.copy(products = state.products.map { if (it.id == p.id) it.copy(active = !it.active) else it })) }) { Text(if (p.active) "بایگانی" else "فعال‌سازی") }
            } }
        }
        2 -> {
            val sales = state.monthSales(month); val confirmed = state.orders.filter { it.status == OrderStatus.COMPLETED && (it.completedAt ?: it.created).startsWith(month) }
            Panel("فروش ماه جاری") {
                Text(money(sales)); Text("PV: ${confirmed.sumOf { it.pv }} · ${confirmed.map { it.customerId }.distinct().size} مشتری خریدار این ماه")
                Text("فقط سفارش تأییدشدهٔ دستی محاسبه می‌شود؛ PV بر اساس مقدار واردشدهٔ محصول است و GPV رسمی محاسبه نمی‌شود.", style = MaterialTheme.typography.bodySmall)
            }
            var target by remember(state.salesGoals) { mutableStateOf(state.salesGoals.firstOrNull { it.month == month }?.amount?.toString() ?: "") }
            Field(target, { target = it.filter(Char::isDigit).take(16) }, "هدف فروش این ماه؛ تومان")
            Button(enabled = (target.toLongOrNull() ?: 0) in 1..1_000_000_000_000_000L, onClick = { save(state.copy(salesGoals = state.salesGoals.filterNot { it.month == month } + SalesGoal(month, target.toLong()))) }) { Text("ذخیرهٔ هدف فروش") }
            state.salesGoals.firstOrNull { it.month == month }?.let { g -> Panel("پیشرفت ${money(g.amount)}") { LinearProgressIndicator(progress = { (sales.toDouble() / g.amount).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth()) } }
            Text("دورهٔ این هدف ماه میلادی است.", style = MaterialTheme.typography.bodySmall)
            Button(enabled = state.customers.isNotEmpty() && state.products.any { it.active }, onClick = { cart = emptyMap(); orderForm = true }) { Text("+ ثبت سفارش") }
            if (state.customers.isEmpty() || state.products.none { it.active }) Text("برای سفارش، حداقل یک مشتری و محصول فعال بساز.")
            state.orders.reversed().forEach { o -> Panel("سفارش ${o.id.take(8)} · ${o.status.label}") {
                Text(state.customers.firstOrNull { it.id == o.customerId }?.name ?: "مشتری")
                o.lines.forEach { Text("${it.quantity} × ${it.name} · ${money(it.price)}") }
                Text("جمع: ${money(o.total)} · ${o.pv} PV · ${if (o.source == "web") "فروشگاه وب" else "محلی"}")
                if (o.status == OrderStatus.REGISTERED) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { save(state.changeOrder(o.id, OrderStatus.COMPLETED)) }) { Text("تأیید فروش دستی") }
                    TextButton(onClick = { save(state.changeOrder(o.id, OrderStatus.CANCELLED)) }) { Text("لغو") }
                }
            } }
        }
        3 -> {
            Text("ویترین شخصی تو", style = MaterialTheme.typography.titleLarge)
            state.products.filter { it.active }.forEach { p -> Panel(p.name) {
                Text(money(p.price)); Text("در سبد: ${cart[p.id] ?: 0}")
                Button(onClick = { cart = cart + (p.id to ((cart[p.id] ?: 0) + 1).coerceAtMost(999)) }) { Text("افزودن به سبد") }
            } }
            if (cart.isNotEmpty()) {
                Text("سبد: ${cart.values.sum()} عدد")
                Button(enabled = state.customers.isNotEmpty(), onClick = { orderForm = true }) { Text("ثبت سفارش سبد برای مشتری") }
                TextButton(onClick = { cart = emptyMap() }) { Text("خالی‌کردن سبد") }
                if (state.customers.isEmpty()) Text("ابتدا مشتری را در بخش مشتریان ثبت کن.")
            }
            HorizontalDivider(); Text("انتشار فروشگاه واقعی روی سرور", style = MaterialTheme.typography.titleMedium)
            Text("صفحهٔ عمومی، درخواست سفارش و شمارهٔ تماس می‌گیرد؛ درگاه پرداخت یا موجودی متصل ندارد.")
            val logged = runCatching { client.session != null }.getOrDefault(false)
            if (!logged) Button(onClick = account) { Text("ورود برای انتشار فروشگاه") } else {
                Field(title, { title = it }, "عنوان فروشگاه")
                Button(enabled = !busy && title.isNotBlank(), onClick = {
                    val products = JSONArray().apply { state.products.filter { it.active }.forEach { p -> put(JSONObject().put("id", p.id).put("name", p.name).put("price", p.price).put("pv", p.pv)) } }
                    val body = JSONObject().put("title", title).put("seller", state.profile.name).put("products", products)
                    job({ client.request("/store/publish", "POST", body) }) { response -> storeUrl = client.server + "/s/" + response.getString("slug"); status = "ویترین به حساب خودت و شناسهٔ معرف سرور متصل شد." }
                }) { Text("انتشار / به‌روزرسانی ویترین") }
                TextButton(enabled = !busy, onClick = { job({ client.request("/store") }) { r -> storeUrl = if (r.isNull("store")) "" else client.server + "/s/" + r.getJSONObject("store").getString("slug"); status = if (storeUrl.isBlank()) "هنوز فروشگاهی منتشر نکرده‌ای" else "لینک فروشگاه دریافت شد." } }) { Text("دریافت لینک فروشگاه من") }
                if (storeUrl.isNotBlank()) Panel("لینک عمومی؛ کپی و ارسال کن") { SelectionContainer { Text(storeUrl) } }
                Button(enabled = !busy, onClick = { job({ client.request("/store/orders") }) { response ->
                    val a = response.getJSONArray("orders"); var updated = state; var count = 0
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i); if (updated.orders.any { it.id == o.getString("id") }) continue
                        val phone = o.getString("phone")
                        fun normalized(s: String) = s.filter(Char::isDigit).map { Character.getNumericValue(it).toString() }.joinToString("")
                        val customer = updated.customers.firstOrNull { normalized(it.phone).isNotBlank() && normalized(it.phone) == normalized(phone) } ?: Customer(name = o.getString("name"), phone = phone)
                        if (updated.customers.none { it.id == customer.id }) updated = updated.copy(customers = updated.customers + customer)
                        val items = o.getJSONArray("lines")
                        val lines = (0 until items.length()).map { n -> val l = items.getJSONObject(n); OrderLine(l.getString("id"), l.getString("name"), l.getLong("price"), l.getInt("pv"), l.getInt("quantity")) }
                        val date = LocalDateTime.parse(o.getString("created")).atOffset(ZoneOffset.UTC).atZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().toString()
                        updated = updated.copy(orders = updated.orders + SaleOrder(id = o.getString("id"), customerId = customer.id, lines = lines, created = date, source = "web")); count++
                    }
                    if (save(updated)) status = "$count سفارش تازه دریافت شد؛ تا تأیید دستی، فروش محسوب نمی‌شوند."
                } }) { Text("دریافت سفارش‌های وب؛ بدون ثبت تکراری") }
            }
        }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (status.isNotBlank()) Text(status)
    if (customerForm) {
        val old = editCustomer; var name by remember { mutableStateOf(old?.name ?: "") }; var phone by remember { mutableStateOf(old?.phone ?: "") }; var need by remember { mutableStateOf(old?.need ?: "") }
        Form(if (old == null) "مشتری جدید" else "پروندهٔ مشتری", name.isNotBlank(), {
            val c = Customer(old?.id ?: UUID.randomUUID().toString(), name.trim(), phone.trim(), need.trim())
            if (save(state.copy(customers = if (old == null) state.customers + c else state.customers.map { if (it.id == c.id) c else it }))) customerForm = false
        }, { customerForm = false }) { Field(name, { name = it }, "نام مشتری"); Field(phone, { phone = it }, "شماره تماس"); Field(need, { need = it }, "نیاز و یادداشت") }
    }
    if (productForm) {
        val old = editProduct; var name by remember { mutableStateOf(old?.name ?: "") }; var price by remember { mutableStateOf(old?.price?.toString() ?: "") }; var pv by remember { mutableStateOf(old?.pv?.toString() ?: "0") }
        Form(if (old == null) "محصول جدید" else "ویرایش محصول", name.isNotBlank() && (price.toLongOrNull() ?: -1) in 0..1_000_000_000_000L && (pv.toIntOrNull() ?: -1) in 0..1_000_000, {
            val p = Product(old?.id ?: UUID.randomUUID().toString(), name.trim(), price.toLong(), pv.toInt(), old?.active ?: true)
            if (save(state.copy(products = if (old == null) state.products + p else state.products.map { if (it.id == p.id) p else it }))) productForm = false
        }, { productForm = false }) { Field(name, { name = it }, "نام محصول"); Field(price, { price = it.filter(Char::isDigit).take(13) }, "قیمت؛ تومان"); Field(pv, { pv = it.filter(Char::isDigit).take(7) }, "PV هر عدد"); Text("تغییر قیمت، سفارش‌های قبلی را تغییر نمی‌دهد.") }
    }
    if (orderForm) {
        var customerId by remember { mutableStateOf(state.customers.firstOrNull()?.id) }
        Form("ثبت سفارش؛ بدون پرداخت آنلاین", customerId != null && cart.isNotEmpty() && cart.all { it.value in 1..999 && state.products.any { p -> p.id == it.key && p.active } }, {
            if (save(state.placeOrder(customerId!!, cart, LocalDateTime.now().toString()))) { orderForm = false; cart = emptyMap(); section = 2 }
        }, { orderForm = false }) {
            Text("مشتری را انتخاب کن")
            state.customers.forEach { c -> FilterChip(customerId == c.id, { customerId = c.id }, label = { Text(c.name) }) }
            state.products.filter { it.active }.forEach { p ->
                var value by remember(p.id) { mutableStateOf((cart[p.id] ?: 0).toString()) }
                Field(value, { raw -> value = raw.filter(Char::isDigit).take(3); val q = value.toIntOrNull() ?: 0; cart = if (q == 0) cart - p.id else cart + (p.id to q) }, "تعداد ${p.name} · ${money(p.price)}")
            }
            Text("ابتدا سفارش ثبت می‌شود؛ پس از انجام فروش آن را دستی تأیید کن.")
        }
    }
}
