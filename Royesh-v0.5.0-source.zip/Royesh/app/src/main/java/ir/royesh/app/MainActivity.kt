package ir.royesh.app

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.royesh.core.*
import java.time.LocalDate
import java.time.LocalDateTime

val Lime = Color(0xFFCEEF79)
val Navy = Color(0xFF101E2C)
class MainActivity : ComponentActivity() {
    private lateinit var store: LocalStore
    private lateinit var cloud: CloudClient
    private var cloudBusy by mutableStateOf(false)
    private var state by mutableStateOf(AppState())
    private var broken by mutableStateOf(false)
    private var restore by mutableStateOf<AppState?>(null)
    private val export = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { contentResolver.openOutputStream(uri)!!.use { it.write(store.encode(state).toByteArray()) } }.onFailure { toast("ذخیرهٔ فایل انجام نشد") }.onSuccess { toast("پشتیبان ذخیره شد") }
    }
    private val importBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = contentResolver.openInputStream(uri)!!.use { stream ->
                val out = java.io.ByteArrayOutputStream(); val buffer = ByteArray(4096)
                while (true) { val n = stream.read(buffer); if (n < 0) break; out.write(buffer, 0, n); require(out.size() <= 2_000_000) }
                out.toString("UTF-8")
            }; store.decode(raw)
        }.onSuccess { restore = it }.onFailure { toast("فایل معتبر نیست یا بیش از ۲ مگابایت است") }
    }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { allowed ->
        getSharedPreferences("reminders", MODE_PRIVATE).edit().putBoolean("enabled", allowed).commit()
        ReminderReceiver.schedule(this); toast(if (allowed) "یادآوری فعال شد" else "اجازهٔ اعلان داده نشد")
    }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun save(value: AppState): Boolean {
        if (cloudBusy) { toast("تا پایان ارتباط صبر کن"); return false }
        return runCatching { store.save(value); state = value }.onFailure { toast("ذخیره‌سازی انجام نشد؛ دوباره تلاش کن") }.isSuccess
    }
    private fun replace(value: AppState): Boolean {
        if (cloudBusy) return false
        val safe = getSharedPreferences("restore-point", MODE_PRIVATE).edit().putString("state", store.encode(state)).commit()
        return safe && save(value)
    }
    private fun pick(date: String, changed: (String) -> Unit) {
        val d = LocalDate.parse(date)
        DatePickerDialog(this, { _, y, m, day -> changed(LocalDate.of(y, m + 1, day).toString()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); store = LocalStore(this); cloud = CloudClient(this)
        runCatching { store.load() }.onSuccess { state = it }.onFailure { broken = true }
        ReminderReceiver.schedule(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Lime, onPrimary = Navy, background = Navy, surface = Color(0xFF1B2D3C))) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                if (broken) Surface(Modifier.fillMaxSize()) { Column(Modifier.padding(24.dp)) { Text("اطلاعات ذخیره‌شده قابل خواندن نیست؛ برای جلوگیری از بازنویسی، ورود متوقف شد. دادهٔ برنامه را پاک نکن.") } } else App()
            }
        } }
    }
    @Composable private fun App() {
        var tab by remember { mutableIntStateOf(0) }; var dialog by remember { mutableStateOf("") }
        var person by remember { mutableStateOf<Person?>(null) }; var task by remember { mutableStateOf<Task?>(null) }
        val today = LocalDate.now().toString()
        Scaffold(containerColor = Navy, bottomBar = { NavigationBar(containerColor = Color(0xFF152534)) {
            listOf("خانه", "اقدام‌ها", "مخاطبان", "رشد", "برنامه").forEachIndexed { i, title -> NavigationBarItem(enabled = !cloudBusy, selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂", "✓", "◎", "✦", "▦")[i], fontSize = 24.sp) }, label = { Text(title) }) }
        } }) { padding -> Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("رویش", color = Lime, style = MaterialTheme.typography.headlineMedium); Text("قدم‌های کوچک، رشد ماندگار") }
                TextButton(enabled = !cloudBusy, onClick = { dialog = "profile" }) { Text("پروفایل") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(enabled = !cloudBusy, onClick = { tab = 5 }) { Text("حساب و ابر") }
                TextButton(enabled = !cloudBusy, onClick = { tab = 6 }) { Text("سازمان و درختواره") }
                TextButton(enabled = !cloudBusy, onClick = { tab = 7 }) { Text("مشتری و فروشگاه") }
            }
            when (tab) {
                0 -> {
                    Text("سلام ${state.profile.name} 🌱", style = MaterialTheme.typography.headlineSmall)
                    Text("امروز برای رشدت یک قدم بردار.")
                    Panel("اقدام بعدی تو") { val next = state.nextTask()
                        if (next == null) { Text("اولین قدم را خودت انتخاب کن."); Button(onClick = { person = null; dialog = "task" }) { Text("+ ساخت اولین اقدام") } }
                        else { Text(next.title, style = MaterialTheme.typography.titleLarge); Text("${faDate(next.due)} · ${taskSubject(next)}"); Button(onClick = { task = next }) { Text("ثبت نتیجهٔ اقدام") } }
                    }
                    val done = state.todayCount(today)
                    Panel("هدف امروز · $done از ${state.profile.dailyGoal}") {
                        LinearProgressIndicator(progress = { (done.toFloat() / state.profile.dailyGoal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Text(if (done >= state.profile.dailyGoal) "هدف امروز کامل شد؛ قدم‌های تو ارزشمندند!" else "هر نتیجه، یک قدم در مسیر رشد توست.")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { person = null; dialog = "task" }) { Text("+ اقدام") }; OutlinedButton(onClick = { dialog = "person" }) { Text("+ مخاطب") } }
                    val blocks = state.blocks.filter { Planning.occurs(it, LocalDate.now()) }
                    Panel("برنامهٔ امروز") { Text("${blocks.size} بلوک · ${blocks.sumOf { it.minutes }} دقیقه برنامه"); TextButton(onClick = { tab = 4 }) { Text("باز کردن برنامه و تمرکز") } }
                    Panel("گزارش کوتاه") { Text("${state.people.size} مخاطب · ${state.tasks.count { !it.done }} اقدام باز"); Text("${state.tasks.count { !it.done && it.due < today }} اقدام عقب‌افتاده") }
                    if (state.actions.isNotEmpty()) Panel("آخرین نتیجه‌ها") { state.actions.takeLast(3).reversed().forEach { Text("${it.title}\n${it.result}"); HorizontalDivider() } }
                }
                1 -> {
                    var filter by remember { mutableIntStateOf(0) }
                    Text("مرکز اقدام", style = MaterialTheme.typography.headlineSmall)
                    Button(onClick = { person = null; dialog = "task" }) { Text("+ اقدام جدید") }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("باز", "امروز", "انجام‌شده").forEachIndexed { i, s -> FilterChip(filter == i, { filter = i }, label = { Text(s) }) } }
                    val tasks = state.tasks.filter { when (filter) { 1 -> !it.done && it.due <= today; 2 -> it.done; else -> !it.done } }.sortedWith(compareBy<Task> { it.due }.thenByDescending { it.priority })
                    if (tasks.isEmpty()) Text("اینجا فعلاً اقدامی نیست؛ یک قدم کوچک تعریف کن.")
                    tasks.forEach { t -> Panel(t.title) { Text("${taskSubject(t)} · ${faDate(t.due)}" + if (t.priority == 2) " · مهم" else "")
                        if (!t.done) Button(onClick = { task = t }) { Text("ثبت نتیجه") } else Text(state.actions.firstOrNull { it.taskId == t.id }?.result ?: "انجام‌شده", color = Lime)
                    } }
                }
                2 -> {
                    var search by remember { mutableStateOf("") }
                    Text("مخاطبان من", style = MaterialTheme.typography.headlineSmall)
                    Field(search, { search = it }, "جست‌وجوی نام یا شماره")
                    Button(onClick = { dialog = "person" }) { Text("+ مخاطب جدید") }
                    if (state.people.isEmpty()) Text("اولین مخاطبت را اضافه کن و پیگیری را به اقدام تبدیل کن.")
                    state.people.filter { it.name.contains(search, true) || it.phone.contains(search) }.forEach { p -> Panel(p.name) { Text("${p.stage.label} · ${p.phone}"); TextButton(onClick = { person = p; dialog = "detail" }) { Text("پرونده و پیگیری") } } }
                }
                3 -> {
                    Text("مسیر رویش تو", style = MaterialTheme.typography.headlineSmall)
                    Panel("سطح ${state.level} · ${state.xp} XP") { LinearProgressIndicator(progress = { (state.xp % 100) / 100f }, modifier = Modifier.fillMaxWidth()); Text("هر ۱۰۰ امتیاز یک سطح رشد شخصی"); Text("امتیاز خوداظهاری و آزمایشی است؛ رتبهٔ رسمی سازمان نیست.", style = MaterialTheme.typography.bodySmall) }
                    val streak = Planning.streak(state.actions, LocalDate.now())
                    Panel("برج ثبات") { Text("$streak روز زنجیرهٔ فعال"); Text("نقطه‌های بعدی: ۳، ۷، ۱۴ و ۳۰ روز") }
                    listOf("اولین ارتباط" to state.people.isNotEmpty(), "اولین قدم ثبت‌شده" to state.actions.isNotEmpty(), "ده اقدام نتیجه‌دار" to (state.actions.size >= 10), "سه روز استمرار" to (streak >= 3)).forEach { (title, earned) -> Panel((if (earned) "✦ " else "○ ") + title) { Text(if (earned) "به مجموعهٔ تو اضافه شد" else "با فعالیت باز می‌شود") } }
                }
                4 -> PlanningScreen(state, { save(it) }, { task = it })
                5 -> AccountScreen(state, cloud, store, cloudBusy, { cloudBusy = it }, ::replace, { replace(AppState(profile = state.profile)) })
                6 -> OrganizationScreen(state, cloud, cloudBusy, { cloudBusy = it }, { save(it) }, { tab = 5 })
                7 -> CommerceScreen(state, cloud, cloudBusy, { cloudBusy = it }, { save(it) }, { tab = 5 })
            }
            TextButton(enabled = !cloudBusy, onClick = { dialog = "reminders" }) { Text("تنظیم یادآوری روزانه") }
            Text("رویش ۰.۵ · سازمان، مشتری و فروش", style = MaterialTheme.typography.bodySmall)
        } }
        if (state.profile.name.isBlank() || dialog == "profile") {
            val first = state.profile.name.isBlank(); var name by remember { mutableStateOf(state.profile.name) }; var goal by remember { mutableIntStateOf(state.profile.dailyGoal) }
            Form(if (first) "به رویش خوش آمدی" else "پروفایل و هدف روزانه", name.isNotBlank(), { if (save(state.copy(profile = Profile(name.trim(), goal)))) dialog = "" }, { dialog = "" }, !first) {
                Field(name, { name = it }, "نام تو"); Text("هدف روزانه: $goal اقدام"); Slider(goal.toFloat(), { goal = it.toInt() }, valueRange = 1f..10f, steps = 8)
                Text("شروع کوچک بهتر از برنامهٔ سنگین است.")
                if (!first) {
                    TextButton(onClick = { export.launch("royesh-backup-${LocalDate.now()}.json") }) { Text("خروجی پشتیبان JSON") }
                    TextButton(onClick = { dialog = ""; importBackup.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }) { Text("بازیابی از فایل JSON") }
                    TextButton(onClick = {
                        val raw = getSharedPreferences("restore-point", MODE_PRIVATE).getString("state", null)
                        if (raw == null) toast("هنوز نقطهٔ بازیابی نداری") else runCatching { store.decode(raw) }.onSuccess { dialog = ""; restore = it }.onFailure { toast("نقطهٔ بازیابی معتبر نیست") }
                    }) { Text("بازگشت به قبل از آخرین بازیابی") }
                }
            }
        }
        if (dialog == "person") {
            var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
            Form("مخاطب جدید", name.isNotBlank(), { if (save(state.copy(people = state.people + Person(name = name.trim(), phone = phone.trim())))) dialog = "" }, { dialog = "" }) { Field(name, { name = it }, "نام مخاطب"); Field(phone, { phone = it }, "شماره تماس (اختیاری)") }
        }
        if (dialog == "detail" && person != null) {
            val p = state.people.first { it.id == person!!.id }
            Form(p.name, true, { dialog = "task" }, { dialog = ""; person = null }, saveLabel = "ساخت پیگیری") {
                Text(p.phone); Stage.entries.forEach { stage -> FilterChip(p.stage == stage, { save(state.copy(people = state.people.map { if (it.id == p.id) it.copy(stage = stage) else it })) }, label = { Text(stage.label) }) }
                state.actions.filter { it.personId == p.id }.takeLast(5).reversed().forEach { Text("${it.title}: ${it.result}") }
            }
        }
        if (dialog == "task") {
            var title by remember { mutableStateOf("") }; var due by remember { mutableStateOf(today) }; var important by remember { mutableStateOf(false) }; var personId by remember { mutableStateOf(person?.id) }
            Form("اقدام جدید", title.isNotBlank(), { if (save(state.copy(tasks = state.tasks + Task(title = title.trim(), personId = personId, due = due, priority = if (important) 2 else 1)))) { dialog = ""; person = null } }, { dialog = ""; person = null }) {
                Field(title, { title = it }, "چه کاری انجام می‌دهی؟"); TextButton(onClick = { pick(due) { due = it } }) { Text("موعد: ${faDate(due)}") }
                Row { Checkbox(important, { important = it }); Text("اولویت بالا") }
                FilterChip(personId == null, { personId = null }, label = { Text("اقدام شخصی") })
                state.people.forEach { p -> FilterChip(personId == p.id, { personId = p.id }, label = { Text(p.name) }) }
            }
        }
        task?.let { t ->
            var result by remember(t.id) { mutableStateOf("") }; var next by remember(t.id) { mutableStateOf("") }; var due by remember(t.id) { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
            Form("نتیجهٔ ${t.title}", result.isNotBlank(), { if (save(state.complete(t.id, result, LocalDateTime.now().toString(), next, due))) task = null }, { task = null }) {
                Field(result, { result = it }, "چه نتیجه‌ای گرفتی؟"); Field(next, { next = it }, "پیگیری بعدی (اختیاری)")
                if (next.isNotBlank()) TextButton(onClick = { pick(due) { due = it } }) { Text("موعد پیگیری: ${faDate(due)}") }
                Text("۱۰ امتیاز محلی؛ هر اقدام فقط یک بار.")
            }
        }
        if (dialog == "reminders") {
            val prefs = getSharedPreferences("reminders", MODE_PRIVATE); var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }; var hour by remember { mutableStateOf(prefs.getInt("hour", 9).toString()) }
            Form("یادآوری روزانه", (hour.toIntOrNull() ?: -1) in 0..23, {
                prefs.edit().putBoolean("enabled", enabled).putInt("hour", hour.toInt()).commit()
                if (enabled && android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) permission.launch(android.Manifest.permission.POST_NOTIFICATIONS) else ReminderReceiver.schedule(this)
                dialog = ""
            }, { dialog = "" }) { Row { Switch(enabled, { enabled = it }); Text("یادآوری روزانه") }; Field(hour, { hour = it.filter(Char::isDigit).take(2) }, "ساعت محلی؛ ۰ تا ۲۳"); Text("زمان تحویل تقریبی است و به محدودیت باتری گوشی بستگی دارد.") }
        }
        restore?.let { incoming -> AlertDialog(onDismissRequest = { restore = null }, title = { Text("جایگزینی اطلاعات از پشتیبان؟") }, text = { Text("${incoming.people.size} مخاطب و ${incoming.tasks.size} اقدام جایگزین اطلاعات فعلی می‌شود. نسخهٔ قبل در نقطهٔ بازیابی محلی حفظ می‌شود.") }, confirmButton = { TextButton(onClick = {
            val safe = getSharedPreferences("restore-point", MODE_PRIVATE).edit().putString("state", store.encode(state)).commit()
            if (safe && save(incoming)) { restore = null; person = null; task = null; dialog = ""; tab = 0 }
        }) { Text("بازیابی و جایگزینی") } }, dismissButton = { TextButton(onClick = { restore = null }) { Text("انصراف") } }) }
    }
    private fun personName(id: String?) = state.people.firstOrNull { it.id == id }?.name ?: "اقدام شخصی"
    private fun taskSubject(task: Task) = state.customers.firstOrNull { it.id == task.customerId }?.let { "مشتری: ${it.name}" } ?: personName(task.personId)
}
@Composable fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2D3C))) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(title, color = Lime, style = MaterialTheme.typography.titleMedium); content() } }
}
@Composable fun Field(value: String, change: (String) -> Unit, label: String) { OutlinedTextField(value, change, label = { Text(label) }, modifier = Modifier.fillMaxWidth()) }
@Composable fun Form(title: String, valid: Boolean, save: () -> Unit, dismiss: () -> Unit, dismissible: Boolean = true, saveLabel: String = "ذخیره", content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(onDismissRequest = { if (dismissible) dismiss() }, title = { Text(title) }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }, confirmButton = { TextButton(onClick = save, enabled = valid) { Text(saveLabel) } }, dismissButton = { if (dismissible) TextButton(onClick = dismiss) { Text("انصراف") } })
}
