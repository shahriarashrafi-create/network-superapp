package ir.royesh.app
import ir.royesh.core.*
import org.junit.Assert.*
import org.junit.Test

class StateCodecTest {
    @Test fun firstVersionBackupMigratesWithoutLosingResults() {
        val raw = """{"schema":1,"profile":{"name":"شهریار","dailyGoal":3},"people":[{"id":"p","name":"دوست","phone":"0912","stage":"NEW"}],"tasks":[{"id":"t","title":"تماس","personId":"p","due":"2026-10-18","priority":1,"done":true}],"actions":[{"id":"a","taskId":"t","personId":"p","title":"تماس","result":"انجام شد","occurredAt":"2026-10-18T12:00:00","xp":10}]}"""
        val migrated = StateCodec.decode(raw)
        assertEquals("شهریار", migrated.profile.name); assertEquals(10, migrated.xp); assertEquals("p", migrated.tasks.first().personId)
        assertTrue(migrated.customers.isEmpty()); assertEquals(migrated, StateCodec.decode(StateCodec.encode(migrated)))
    }
    @Test fun secondVersionPlanningMigrates() {
        val raw = """{"schema":2,"profile":{"name":"نام","dailyGoal":3},"people":[],"tasks":[],"actions":[],"blocks":[{"id":"b","title":"برنامه","date":"2026-10-18","hour":9,"minutes":60,"weekly":true,"actuals":{"2026-10-18":40}}],"goals":[{"month":"2026-10","target":30}]}"""
        val s = StateCodec.decode(raw)
        assertEquals(40, s.blocks.first().actuals["2026-10-18"]); assertEquals(30, s.goals.first().target); assertTrue(s.products.isEmpty())
    }
    @Test fun commerceAndCustomerTaskRoundTrip() {
        val s = AppState(profile = Profile("نام", 3), customers = listOf(Customer("c", "مشتری", "0912", "نیاز")), products = listOf(Product("p", "محصول", 150000, 3)), salesGoals = listOf(SalesGoal("2026-10", 1000000)), tasks = listOf(Task(id = "t", title = "پیگیری", due = "2026-10-18", customerId = "c")))
            .placeOrder("c", mapOf("p" to 2), "2026-10-18T12:00:00")
        assertEquals(s, StateCodec.decode(StateCodec.encode(s)))
    }
    @Test(expected = IllegalArgumentException::class) fun orphanCustomerTaskRejected() {
        val s = AppState(tasks = listOf(Task(title = "پیگیری", due = "2026-10-18", customerId = "missing")))
        StateCodec.decode(StateCodec.encode(s))
    }
}
