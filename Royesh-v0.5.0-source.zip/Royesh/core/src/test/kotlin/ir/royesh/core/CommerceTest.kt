package ir.royesh.core
import org.junit.Assert.*
import org.junit.Test

class CommerceTest {
    private val base = AppState(customers = listOf(Customer(id = "c", name = "مشتری")), products = listOf(Product("p", "محصول", 150000, 5)))
    @Test fun orderKeepsPriceAndPvSnapshot() {
        val s = base.placeOrder("c", mapOf("p" to 2), "2026-10-18T12:00:00")
        val edited = s.copy(products = listOf(base.products.first().copy(price = 999999, pv = 20)))
        assertEquals(300000L, edited.orders.first().total); assertEquals(10L, edited.orders.first().pv)
    }
    @Test fun onlyConfirmedSalesCount() {
        val s = base.placeOrder("c", mapOf("p" to 2), "2026-10-18T12:00:00")
        assertEquals(0L, s.monthSales("2026-10"))
        assertEquals(300000L, s.changeOrder(s.orders.first().id, OrderStatus.COMPLETED, "2026-10-18T13:00:00").monthSales("2026-10"))
        assertEquals(0L, s.changeOrder(s.orders.first().id, OrderStatus.CANCELLED).monthSales("2026-10"))
    }
    @Test(expected = IllegalArgumentException::class) fun finalOrderCannotBeReconfirmed() {
        val s = base.placeOrder("c", mapOf("p" to 1), "2026-10-18T12:00:00"); val id = s.orders.first().id
        s.changeOrder(id, OrderStatus.COMPLETED).changeOrder(id, OrderStatus.COMPLETED)
    }
    @Test(expected = IllegalArgumentException::class) fun zeroQuantityRejected() { base.placeOrder("c", mapOf("p" to 0), "2026-10-18T12:00:00") }
    @Test(expected = IllegalArgumentException::class) fun prospectCannotBeUsedAsCustomer() {
        base.copy(people = listOf(Person(id = "prospect", name = "مخاطب"))).placeOrder("prospect", mapOf("p" to 1), "2026-10-18T12:00:00")
    }
    @Test fun followupKeepsCustomerLink() {
        val s = base.copy(tasks = listOf(Task(id = "t", title = "تماس", due = "2026-10-18", customerId = "c")))
            .complete("t", "پیگیری شود", "2026-10-18T12:00:00", "تماس بعدی", "2026-10-19")
        assertEquals("c", s.tasks.last().customerId)
    }
    @Test fun decimalFreeMoneyIsExact() {
        val s = base.copy(products = listOf(Product("p", "محصول", 1000000000000, 1))).placeOrder("c", mapOf("p" to 999), "2026-10-18T12:00:00")
        assertEquals(999000000000000L, s.orders.first().total)
    }
    @Test fun saleBelongsToConfirmationMonth() {
        val s = base.placeOrder("c", mapOf("p" to 1), "2026-09-30T12:00:00")
        val confirmed = s.changeOrder(s.orders.first().id, OrderStatus.COMPLETED, "2026-10-01T12:00:00")
        assertEquals(0L, confirmed.monthSales("2026-09")); assertEquals(150000L, confirmed.monthSales("2026-10"))
    }

}
