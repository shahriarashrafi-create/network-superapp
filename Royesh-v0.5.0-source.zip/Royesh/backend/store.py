import html
import json
import re
import secrets
import time
import uuid
from urllib.parse import parse_qs

class StoreError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

def init(db):
    db.executescript('''
    CREATE TABLE IF NOT EXISTS stores(owner TEXT PRIMARY KEY,slug TEXT UNIQUE,title TEXT,seller TEXT,catalog TEXT);
    CREATE TABLE IF NOT EXISTS web_orders(id TEXT PRIMARY KEY,owner TEXT,name TEXT,phone TEXT,lines TEXT,created TEXT);
    CREATE INDEX IF NOT EXISTS web_orders_owner ON web_orders(owner);
    ''')

def catalog(value):
    if not isinstance(value, list) or len(value) > 500: raise StoreError(400, 'Invalid catalog')
    result = []
    for p in value:
        if not isinstance(p, dict): raise StoreError(400, 'Invalid product')
        if not isinstance(p.get('id'), str) or not 1 <= len(p['id']) <= 100 or not isinstance(p.get('name'), str) or not 1 <= len(p['name']) <= 150: raise StoreError(400, 'Invalid product name')
        if type(p.get('price')) is not int or not 0 <= p['price'] <= 10**12 or type(p.get('pv')) is not int or not 0 <= p['pv'] <= 10**6: raise StoreError(400, 'Invalid price or PV')
        result.append({'id': p['id'], 'name': p['name'], 'price': p['price'], 'pv': p['pv']})
    if len({p['id'] for p in result}) != len(result): raise StoreError(400, 'Duplicate products')
    return result

def handle(db, uid, path, method, body):
    if path == '/store/publish' and method == 'POST':
        title, seller = body.get('title', ''), body.get('seller', '')
        if not isinstance(title, str) or not title.strip() or len(title) > 120 or not isinstance(seller, str) or not seller.strip() or len(seller) > 100: raise StoreError(400, 'Invalid store title')
        products = catalog(body.get('products'))
        db.execute('BEGIN IMMEDIATE')
        old = db.execute('SELECT slug FROM stores WHERE owner=?', (uid,)).fetchone()
        slug = old['slug'] if old else 'r-' + secrets.token_hex(6)
        db.execute('INSERT INTO stores VALUES(?,?,?,?,?) ON CONFLICT(owner) DO UPDATE SET title=excluded.title,seller=excluded.seller,catalog=excluded.catalog', (uid, slug, title.strip(), seller.strip(), json.dumps(products, ensure_ascii=False)))
        return 200, {'slug': slug, 'referral': uid, 'products': len(products)}
    if path == '/store' and method == 'GET':
        row = db.execute('SELECT slug,title FROM stores WHERE owner=?', (uid,)).fetchone()
        return 200, {'store': dict(row) if row else None}
    if path == '/store/orders' and method == 'GET':
        rows = db.execute('SELECT * FROM web_orders WHERE owner=? ORDER BY created DESC LIMIT 500', (uid,)).fetchall()
        return 200, {'orders': [{'id': r['id'], 'name': r['name'], 'phone': r['phone'], 'lines': json.loads(r['lines']), 'created': r['created']} for r in rows]}
    raise StoreError(404, 'Not found')

def public(db, path, method, raw=b''):
    match = re.fullmatch(r'/s/(r-[a-f0-9]{12})(/order)?', path)
    if not match: raise StoreError(404, 'Store not found')
    row = db.execute('SELECT * FROM stores WHERE slug=?', (match[1],)).fetchone()
    if not row: raise StoreError(404, 'Store not found')
    products = json.loads(row['catalog'])
    notice = ''
    if method == 'POST' and match[2]:
        try:
            form = parse_qs(raw.decode('utf-8'), max_num_fields=10)
            get = lambda key: form.get(key, [''])[0].strip()
            name, phone = get('name'), get('phone')
            quantity = int(get('quantity'))
            product = next((p for p in products if p['id'] == get('product')), None)
            if not 1 <= len(name) <= 100 or not 7 <= len(phone) <= 24 or not all(c.isdigit() or c in '+ -()' for c in phone) or not 1 <= quantity <= 99 or not product: raise ValueError()
        except (ValueError, UnicodeError): raise StoreError(400, 'Invalid order form')
        lines = [dict(product, quantity=quantity)]
        created = time.strftime('%Y-%m-%dT%H:%M:%S', time.gmtime())
        db.execute('INSERT INTO web_orders VALUES(?,?,?,?,?,?)', (str(uuid.uuid4()), row['owner'], name, phone, json.dumps(lines, ensure_ascii=False), created))
        notice = '<p class="notice">درخواست سفارش ثبت شد؛ فروشنده برای هماهنگی با شما تماس می‌گیرد. پرداختی انجام نشده است.</p>'
    elif method != 'GET' or match[2]: raise StoreError(405, 'Method not allowed')
    esc = lambda value: html.escape(str(value), quote=True)
    cards = []
    for p in products:
        cards.append(f'''<article><h2>{esc(p['name'])}</h2><p>{p['price']:,} تومان</p><form method="post" action="/s/{row['slug']}/order"><input type="hidden" name="product" value="{esc(p['id'])}"><label>تعداد<input name="quantity" type="number" min="1" max="99" value="1" required></label><label>نام شما<input name="name" maxlength="100" required autocomplete="name"></label><label>شماره تماس<input name="phone" type="tel" minlength="7" maxlength="24" required autocomplete="tel"></label><p>با ارسال، نام و شمارهٔ شما برای هماهنگی این سفارش در اختیار فروشنده قرار می‌گیرد.</p><button>ثبت درخواست سفارش</button></form></article>''')
    return f'''<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(row['title'])}</title><style>body{{font-family:Tahoma,sans-serif;background:#101e2c;color:#eee;max-width:680px;margin:auto;padding:24px}}article{{background:#1b2d3c;border-radius:20px;padding:24px;margin:20px 0}}label{{display:block;margin:12px 0}}input{{display:block;padding:12px;box-sizing:border-box;width:100%;border-radius:8px}}button{{padding:14px;border:0;border-radius:20px;background:#ceef79}}h1,.notice{{color:#ceef79}}p{{line-height:1.8}}</style><h1>{esc(row['title'])}</h1><p>فروشنده: {esc(row['seller'])}</p><p>این صفحه درخواست سفارش ثبت می‌کند؛ درگاه پرداخت یا تأیید موجودی ندارد.</p>{notice}{''.join(cards) or '<p>هنوز محصولی منتشر نشده است.</p>'}<footer>رویش · شناسهٔ معرف فروشنده: {esc(row['owner'])}</footer></html>'''
