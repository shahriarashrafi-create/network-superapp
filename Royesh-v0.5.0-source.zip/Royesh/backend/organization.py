import secrets
import sqlite3
import time

class OrgError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

def init(db):
    db.executescript('''
    CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY,name TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS members(user_id TEXT PRIMARY KEY,org_id TEXT NOT NULL,sponsor_id TEXT,name TEXT NOT NULL,role TEXT NOT NULL,joined INTEGER NOT NULL);
    CREATE INDEX IF NOT EXISTS members_org ON members(org_id);
    CREATE TABLE IF NOT EXISTS invitations(code TEXT PRIMARY KEY,org_id TEXT,sponsor_id TEXT,expires INTEGER,used INTEGER DEFAULT 0);
    ''')

def member(db, uid): return db.execute('SELECT * FROM members WHERE user_id=?', (uid,)).fetchone()

def view(db, uid):
    me = member(db, uid)
    if not me: return {'organization': None}
    org = db.execute('SELECT * FROM organizations WHERE id=?', (me['org_id'],)).fetchone()
    rows = db.execute('SELECT user_id,sponsor_id,name,role,joined FROM members WHERE org_id=? ORDER BY joined,user_id', (me['org_id'],)).fetchall()
    return {'organization': dict(org), 'me': dict(me), 'members': [dict(r) for r in rows]}

def text(value, maximum=100):
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > maximum: raise OrgError(400, 'Invalid name')
    return value.strip()

def handle(db, uid, path, method, body):
    if path == '/organization' and method == 'GET': return 200, view(db, uid)
    if method != 'POST': raise OrgError(405, 'POST required')
    # Transaction serializes joining and role changes, including concurrent invitations.
    db.execute('BEGIN IMMEDIATE')
    me = member(db, uid)
    if path == '/organization/create':
        if me: raise OrgError(409, 'Already a member')
        name, display = text(body.get('name')), text(body.get('display_name'))
        org = secrets.token_hex(12)
        db.execute('INSERT INTO organizations VALUES(?,?)', (org, name))
        db.execute('INSERT INTO members VALUES(?,?,NULL,?,?,?)', (uid, org, display, 'HEAD', int(time.time())))
        return 201, view(db, uid)
    if path == '/organization/join':
        if me: raise OrgError(409, 'Already a member')
        code = text(body.get('code'), 100)
        invite = db.execute('SELECT * FROM invitations WHERE code=? AND used=0 AND expires>?', (code, int(time.time()))).fetchone()
        if not invite: raise OrgError(400, 'Invalid or expired invitation')
        sponsor = member(db, invite['sponsor_id'])
        if not sponsor or sponsor['org_id'] != invite['org_id']: raise OrgError(400, 'Invalid sponsor')
        db.execute('INSERT INTO members VALUES(?,?,?,?,?,?)', (uid, invite['org_id'], invite['sponsor_id'], text(body.get('display_name')), 'USER', int(time.time())))
        db.execute('UPDATE invitations SET used=1 WHERE code=?', (code,))
        return 201, view(db, uid)
    if not me: raise OrgError(403, 'Organization membership required')
    if path == '/organization/invite':
        # Invitations always place a new member under the authenticated sponsor.
        code = secrets.token_urlsafe(12)
        expires = int(time.time()) + 7 * 86400
        db.execute('INSERT INTO invitations VALUES(?,?,?,?,0)', (code, me['org_id'], uid, expires))
        return 201, {'code': code, 'expires': expires, 'sponsor_id': uid}
    if path == '/organization/role':
        target = member(db, body.get('user_id', '')); role = body.get('role')
        if me['role'] not in ('HEAD', 'ADMIN'): raise OrgError(403, 'Role management forbidden')
        if not target or target['org_id'] != me['org_id']: raise OrgError(404, 'Member not found')
        if target['role'] == 'HEAD' or target['user_id'] == uid: raise OrgError(403, 'Cannot change the head or your own role')
        if role not in ('USER', 'LEADER', 'ADMIN'): raise OrgError(400, 'Invalid role')
        if me['role'] == 'ADMIN' and (target['role'] == 'ADMIN' or role == 'ADMIN'): raise OrgError(403, 'Only head manages admins')
        db.execute('UPDATE members SET role=? WHERE user_id=?', (role, target['user_id']))
        return 200, view(db, uid)
    raise OrgError(404, 'Not found')
