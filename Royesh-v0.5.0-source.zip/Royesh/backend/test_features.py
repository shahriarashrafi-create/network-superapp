import concurrent.futures
import http.client
import json
import os
import tempfile
import threading
import unittest
from urllib.parse import urlencode
import server
import test_server

class FeaturesTest(unittest.TestCase):
    call = test_server.ApiTest.call
    new = test_server.ApiTest.new
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(); server.DB = os.path.join(cls.temp.name, 'features.sqlite3'); server.init()
        cls.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        threading.Thread(target=cls.http.serve_forever, daemon=True).start()
    @classmethod
    def tearDownClass(cls): cls.http.shutdown(); cls.http.server_close(); cls.temp.cleanup()
    def setUp(self): server.attempts.clear()
    def org(self, user, name='تیم رویش'):
        status, result = self.call('/organization/create', 'POST', {'name': name, 'display_name': user['email'].split('@')[0]}, user['token'])
        self.assertEqual(201, status); return result
    def invite(self, user): return self.call('/organization/invite', 'POST', {}, user['token'])[1]['code']
    def join(self, user, code): return self.call('/organization/join', 'POST', {'code': code, 'display_name': 'عضو تازه', 'role': 'HEAD'}, user['token'])
    def public(self, path, body=None):
        c = http.client.HTTPConnection('127.0.0.1', self.http.server_port, timeout=10)
        c.request('POST' if body is not None else 'GET', path, urlencode(body) if body is not None else None, {'Content-Type': 'application/x-www-form-urlencoded'})
        r = c.getresponse(); result = r.status, r.read().decode(); c.close(); return result
    def test_join_uses_authenticated_sponsor_and_ignores_claimed_role(self):
        a, b = self.new('org-head'), self.new('org-child'); self.org(a)
        status, joined = self.join(b, self.invite(a)); self.assertEqual(201, status)
        self.assertEqual(a['user_id'], joined['me']['sponsor_id']); self.assertEqual('USER', joined['me']['role'])
        self.assertEqual(2, len(joined['members'])); self.assertNotIn('email', joined['members'][0])
        self.assertEqual(409, self.call('/organization/create', 'POST', {'name': 'دوم', 'display_name': 'نام'}, b['token'])[0])
        self.assertEqual(403, self.call('/organization/role', 'POST', {'user_id': a['user_id'], 'role': 'ADMIN'}, b['token'])[0])
    def test_roles_cannot_escalate_or_cross_organization(self):
        h, admin, member, outsider = [self.new('role-' + n) for n in ('head', 'admin', 'user', 'outside')]
        self.org(h); self.join(admin, self.invite(h)); self.join(member, self.invite(h)); self.org(outsider, 'دیگر')
        self.assertEqual(200, self.call('/organization/role', 'POST', {'user_id': admin['user_id'], 'role': 'ADMIN'}, h['token'])[0])
        self.assertEqual(200, self.call('/organization/role', 'POST', {'user_id': member['user_id'], 'role': 'LEADER'}, admin['token'])[0])
        self.assertEqual(403, self.call('/organization/role', 'POST', {'user_id': member['user_id'], 'role': 'ADMIN'}, admin['token'])[0])
        self.assertEqual(403, self.call('/organization/role', 'POST', {'user_id': h['user_id'], 'role': 'USER'}, admin['token'])[0])
        self.assertEqual(404, self.call('/organization/role', 'POST', {'user_id': outsider['user_id'], 'role': 'USER'}, h['token'])[0])
    def test_invitation_replay_and_expiry(self):
        a, b, c = [self.new('invite-' + n) for n in ('a', 'b', 'c')]; self.org(a)
        code = self.invite(a); self.assertEqual(201, self.join(b, code)[0]); self.assertEqual(400, self.join(c, code)[0])
        expired = self.invite(a)
        with server.connect() as db: db.execute('UPDATE invitations SET expires=0 WHERE code=?', (expired,))
        self.assertEqual(400, self.join(c, expired)[0])
    def test_one_invite_cannot_be_consumed_concurrently(self):
        a, b, c = [self.new('concurrent-invite-' + n) for n in ('a', 'b', 'c')]; self.org(a); code = self.invite(a)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results = list(pool.map(lambda user: self.join(user, code)[0], (b, c)))
        self.assertEqual([201, 400], sorted(results))
    def test_public_store_escapes_text_and_uses_server_price(self):
        seller, other = self.new('store-seller'), self.new('store-other')
        product = {'id': 'p1', 'name': '<script>alert(1)</script>', 'price': 500, 'pv': 4}
        status, published = self.call('/store/publish', 'POST', {'title': 'فروشگاه', 'seller': 'نام', 'products': [product]}, seller['token'])
        self.assertEqual(200, status); path = '/s/' + published['slug']
        status, page = self.public(path); self.assertEqual(200, status); self.assertNotIn('<script>', page); self.assertIn('&lt;script&gt;', page)
        status, _ = self.public(path + '/order', {'product': 'p1', 'quantity': 2, 'name': 'مشتری', 'phone': '09123456789', 'price': 1, 'owner': other['user_id']})
        self.assertEqual(200, status)
        rows = self.call('/store/orders', token=seller['token'])[1]['orders']; self.assertEqual(1, len(rows)); self.assertEqual(500, rows[0]['lines'][0]['price'])
        self.assertEqual([], self.call('/store/orders', token=other['token'])[1]['orders'])
        self.assertEqual(400, self.public(path + '/order', {'product': 'p1', 'quantity': 0, 'name': 'مشتری', 'phone': '09123456789'})[0])
    def test_store_slug_is_stable_and_private_endpoints_require_login(self):
        user = self.new('slug'); body = {'title': 'نام', 'seller': 'فرد', 'products': []}
        first = self.call('/store/publish', 'POST', body, user['token'])[1]
        second = self.call('/store/publish', 'POST', dict(body, title='نام تازه'), user['token'])[1]
        self.assertEqual(first['slug'], second['slug']); self.assertEqual(user['user_id'], first['referral'])
        self.assertEqual(401, self.call('/store/orders')[0]); self.assertEqual(401, self.call('/organization')[0])
    def test_new_snapshot_schema_round_trips(self):
        user = self.new('schema-three')
        data = dict(test_server.ApiTest.snapshot(self) if hasattr(test_server.ApiTest, 'snapshot') else {'schema': 2, 'profile': {'name': 'علی', 'dailyGoal': 3}, 'people': [], 'tasks': [], 'actions': [], 'blocks': [], 'goals': []})
        data.update(schema=3, customers=[], products=[], orders=[], salesGoals=[])
        self.assertEqual(200, self.call('/snapshot', 'PUT', {'version': 0, 'data': data}, user['token'])[0])
        self.assertEqual(data, self.call('/snapshot', token=user['token'])[1]['data'])

if __name__ == '__main__': unittest.main()
