# V26 Validation

کنترل‌های انجام‌شده روی این نسخه:

- XMLهای `app/src/main/res` با parser استاندارد XML بررسی شدند و همگی معتبرند.
- تمام `R.string.*`های Kotlin با `strings.xml` تطبیق داده شدند و reference گمشده وجود ندارد.
- `GamificationRules`، `ProgressStage` و `ProgressStageFactory` با Kotlin compiler محلی با موفقیت compile شدند.
- قوانین جدید Combo/XP/Coin به فایل pure منتقل و Unit Test برای reward پایه، فعال‌شدن Combo در موفقیت سوم، ×1.5، milestone صندوق پنجم و XP level target اضافه شد.
- migration مسیر برای payload فاقد `category` حفظ شده است؛ category جدید با fallback از number/title ساخته می‌شود.
- کد مسیر عمودی قدیمی که بعد از طراحی نواری بدون مصرف بود حذف شد؛ `StageStatusBadge` به فایل مستقل منتقل شد.
- اسکن `TODO` / `FIXME` / `NotImplementedError` روی سورس اصلی انجام شد.
- Workflow موجود همچنان `:app:testDebugUnitTest` و `:app:assembleDebug` را در GitHub Actions اجرا می‌کند.

## محدودیت محیط تولید ZIP

Full Android Gradle build در این محیط اجرا نشد، چون `gradle-wrapper.jar` و Gradle/Android dependency cache محلی وجود ندارد و bootstrap شبکه‌ای Gradle در این runtime در دسترس نیست. `gradlew` و GitHub Actions پروژه عمداً حفظ شده‌اند تا build کامل در CI انجام شود.
