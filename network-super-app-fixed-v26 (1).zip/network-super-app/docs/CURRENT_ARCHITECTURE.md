# Current Architecture — V26

V26 ادامه Clean Rebuild نسخه V25 است و هدر سراسری، Gamification و Progress strips را به ساختار فعلی اضافه می‌کند.

## App shell

- `MainActivity`: initialization اولیه `ProgressPathStore` سپس `GamificationStore` قبل از اولین Composition.
- `AppRoot`: مالک destination، Bottom Navigation، route جزئیات کار، Rewards و Settings.
- `SharedFixedHeader`: یک نمونه ثابت از Home Header برای صفحات اصلی و Mission Detail.

## Home

- `HomeUiState` و `HomeDefaults`: داده‌های محتوایی Home.
- `HomeScreen`: محتوای Home بدون هدر؛ هدر در AppRoot ثابت نگه داشته می‌شود.
- `HomeHeader`: Profile + adaptive name + Builder/Chest + Coin/Combo/Settings + XP.
- `HomeActions`, `HomeSections`: کارت‌ها و سکشن‌های Home.

## Gamification

- `GamificationRules`: محاسبات خالص XP/Coin/Combo/Chest milestone.
- `GamificationStore`: state مشترک و persistent برای Coin، XP، Combo و صندوق‌ها.
- `RewardChestScreen`: تنها محل Claim صندوق‌ها.

### قوانین اصلی

1. هر Stage فقط یک‌بار reward مستقیم می‌دهد.
2. reward پایه: 20 XP / 4 Coin.
3. موفقیت سوم متوالی Combo را فعال می‌کند؛ reward از همان نقطه ×1.5 است.
4. Fail، Combo را reset می‌کند.
5. هر 5 موفقیت جدید یک Task Chest می‌دهد.
6. Three-hour Chest بعد از Claim تا 3 ساعت قفل می‌شود.
7. بازکردن صندوق فقط در `RewardChestScreen` ممکن است.

## Progress domain/state

- `ProgressStage.kt`: Stage/Mission status و `ProgressCategory`.
- `MissionRules.kt`: قوانین خالص اجرای کار.
- `ProgressPathRules.kt`: ترتیب، rollback و invariant مسیر.
- `ProgressStageFactory.kt`: defaults و checklist ids.
- `ProgressPathPersistence.kt`: JSON + migration + category fallback.
- `ProgressPathStore.kt`: source of truth مسیر و اتصال تکمیل/شکست به Gamification.

## Progress UI

`ProgressPathScreen` پنج سکشن مستقل Home-like دارد:

- کارهای شخصی
- کارهای فروش
- کارهای شبکه‌سازی
- کارهای حمایتی
- کارهای حامی

هر سکشن افقی scroll می‌شود و جاده زیگ‌زاگی همان سکشن با Canvas رسم می‌شود. Badge وضعیت در `ProgressStageBadge.kt` مستقل شده و کد مسیر عمودی قدیمی حذف شده است.

## Persistence invariants

- id/number مثبت و یکتا.
- شماره‌ها بعد mutation پیوسته می‌شوند.
- رفتار Current/Upcoming و rollback نسخه V25 حفظ شده است.
- payload قدیمی بدون category نیز قابل خواندن است.
- Gamification state در SharedPreferences مستقل `gamification_v1` نگهداری می‌شود.

## Header invariants

- سمت راست: Profile سپس ناحیه نام با عرض ثابت؛ فونت نام تا جا شدن کامل کوچک می‌شود.
- زیر نام: Builder سمت راست و Chest سمت چپ، داخل همان عرض نام.
- سمت چپ: Coin، Combo، Settings؛ ابعاد فشرده برای عرض موبایل.
- Coin count زیر Asset سکه نمایش داده می‌شود.
- Header مستقل از scroll محتوای صفحه است.
