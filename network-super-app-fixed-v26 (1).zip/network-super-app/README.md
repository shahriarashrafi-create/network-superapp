# Network Super App — V26

پروتوتایپ Android سوپر اپ نتورک مارکتینگ با Kotlin، Jetpack Compose و Material 3.

V26 روی پایه Clean Rebuild نسخه V25 ساخته شده و تغییرات جدید هدر سراسری، Progress Path نواری، Coin/XP/Combo و Reward Chests را به همان معماری مسئولیت‌محور اضافه می‌کند.

## تکنولوژی

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Jetpack Compose / Material 3
- Min SDK 26 / Target SDK 35
- Java 17

## Build

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

GitHub Actions همین دو task را اجرا می‌کند و APK debug را به‌عنوان artifact تحویل می‌دهد.

## ساختار اصلی

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
└── ui/
    ├── components/
    ├── navigation/
    ├── home/
    ├── gamification/
    │   ├── GamificationRules.kt
    │   ├── GamificationStore.kt
    │   └── RewardChestScreen.kt
    ├── progress/
    │   ├── ProgressStage.kt
    │   ├── ProgressStageBadge.kt
    │   ├── MissionRules.kt
    │   ├── ProgressPathRules.kt
    │   ├── ProgressStageFactory.kt
    │   ├── ProgressPathPersistence.kt
    │   ├── ProgressPathStore.kt
    │   ├── ProgressPathScreen.kt
    │   ├── ProgressPathDialogs.kt
    │   ├── MissionDetailScreen.kt
    │   ├── MissionDetailContent.kt
    │   └── MissionDialogs.kt
    └── theme/
```

## گیمیفیکیشن

- Task reward پایه: `20 XP + 4 Coin`
- Combo پس از 3 موفقیت متوالی فعال می‌شود.
- Combo فعال: `XP ×1.5` و `Coin ×1.5`
- Fail زنجیره Combo را صفر می‌کند.
- هر stage فقط یک‌بار می‌تواند XP/Coin بدهد.
- هر 5 موفقیت جدید یک Task Chest می‌دهد.
- Three-hour Chest بعد از Claim هر 3 ساعت دوباره آماده می‌شود.
- همه صندوق‌ها فقط از `RewardChestScreen` Claim می‌شوند.

## سازگاری داده

Progress payload نسخه V24/V25 همچنان خوانده می‌شود. `category` به داده مرحله اضافه شده ولی decoder برای payloadهای قدیمی فاقد category، دسته را از اطلاعات موجود بازیابی می‌کند. کلیدهای قبلی مسیر پیشرفت حذف نشده‌اند.

## Visual baseline

`docs/home-reference.png` مبنای Home است. هدر مشترک V26 و Progress strips همگی با Compose/Canvas ساخته شده‌اند و برای ظاهر اصلی به تصویر پس‌زمینه وابسته نیستند.
