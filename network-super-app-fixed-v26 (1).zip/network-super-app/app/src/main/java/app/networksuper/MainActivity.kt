package app.networksuper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.networksuper.ui.navigation.AppRoot
import app.networksuper.ui.gamification.GamificationStore
import app.networksuper.ui.progress.ProgressPathStore
import app.networksuper.ui.theme.NetworkSuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load persisted app state before the first composition to avoid showing defaults for a frame.
        ProgressPathStore.initialize(applicationContext)
        GamificationStore.initialize(applicationContext)

        setContent {
            NetworkSuperAppTheme {
                AppRoot()
            }
        }
    }
}
