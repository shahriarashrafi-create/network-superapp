package app.networksuper.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.networksuper.R
import app.networksuper.ui.gamification.GamificationStore
import app.networksuper.ui.theme.*
import kotlinx.coroutines.delay

/**
 * Shared compact header used by Home, Progress and the other main destinations.
 * It intentionally owns no scroll state so AppRoot can keep it fixed above page content.
 */
@Composable
internal fun HomeHeader(
    state: HomeUiState,
    modifier: Modifier = Modifier,
    onOpenRewards: () -> Unit = {},
    onOpenSettings: () -> Unit = {}
) {
    val game = GamificationStore.state
    val xpTarget = GamificationStore.xpTarget()
    val xpStart = GamificationStore.xpLevelStart()
    var nowMillis by remember(game.nextThreeHourChestAtMillis) {
        mutableLongStateOf(System.currentTimeMillis())
    }
    LaunchedEffect(game.nextThreeHourChestAtMillis) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(30_000L)
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(21.dp))
            .background(Color.White.copy(alpha = 0.78f))
    ) {
        HeaderWaveBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Left side: Coin + Combo + Settings only. All three are deliberately compact.
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CoinHeaderItem(coins = game.coins)
                        ComboHeaderItem(
                            count = game.comboCount,
                            active = GamificationStore.comboActive()
                        )
                        SettingsHeaderItem(onClick = onOpenSettings)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ProfileArea(
                            userName = state.userName,
                            rankName = state.rankName,
                            chestCount = GamificationStore.availableChestCount(nowMillis),
                            onOpenRewards = onOpenRewards
                        )
                    }
                }
            }

            XpProgressRow(
                current = game.totalXp,
                levelStart = xpStart,
                target = xpTarget
            )
        }
    }
}

@Composable
private fun ProfileArea(
    userName: String,
    rankName: String,
    chestCount: Int,
    onOpenRewards: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ProfileAvatar()
        Column(
            modifier = Modifier.width(120.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AdaptiveNameText(
                userName = userName,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(3.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                RankBadge(
                    rankName = rankName,
                    modifier = Modifier.weight(1f)
                )
                MiniChestButton(
                    availableCount = chestCount,
                    onClick = onOpenRewards
                )
            }
        }
    }
}


@Composable
private fun AdaptiveNameText(userName: String, modifier: Modifier = Modifier) {
    val preferred = when {
        userName.length <= 9 -> 18f
        userName.length <= 14 -> 16f
        userName.length <= 20 -> 14f
        userName.length <= 26 -> 12f
        else -> 10f
    }
    var fittedSize by remember(userName) { mutableFloatStateOf(preferred) }

    Text(
        text = userName,
        modifier = modifier,
        color = Navy,
        fontSize = fittedSize.sp,
        lineHeight = fittedSize.sp,
        fontWeight = FontWeight.Black,
        textAlign = TextAlign.Center,
        maxLines = 1,
        softWrap = false,
        onTextLayout = { result ->
            if (result.didOverflowWidth && fittedSize > 8f) {
                fittedSize = (fittedSize - 0.5f).coerceAtLeast(8f)
            }
        }
    )
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val wave1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.38f)
            cubicTo(w * 0.75f, h * 0.16f, w * 0.58f, h * 0.48f, w * 0.38f, h * 0.31f)
            cubicTo(w * 0.20f, h * 0.17f, w * 0.10f, h * 0.38f, 0f, h * 0.22f)
            close()
        }
        drawPath(
            path = wave1,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = 0.34f),
                    Color(0xFF8CCBFF).copy(alpha = 0.18f),
                    Color.Transparent
                )
            )
        )

        val wave2 = Path().apply {
            moveTo(0f, h * 0.08f)
            cubicTo(w * 0.18f, h * 0.30f, w * 0.32f, h * 0.04f, w * 0.48f, h * 0.18f)
            cubicTo(w * 0.66f, h * 0.34f, w * 0.80f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.52f)
            cubicTo(w * 0.80f, h * 0.35f, w * 0.63f, h * 0.56f, w * 0.45f, h * 0.40f)
            cubicTo(w * 0.24f, h * 0.24f, w * 0.12f, h * 0.47f, 0f, h * 0.33f)
            close()
        }
        drawPath(path = wave2, color = Color.White.copy(alpha = 0.28f))
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(43.dp)
            .shadow(5.dp, CircleShape, ambientColor = PrimaryBlue.copy(alpha = 0.14f), spotColor = PrimaryBlue.copy(alpha = 0.18f))
            .clip(CircleShape)
            .background(Color(0xFFE9F5FF))
            .border(1.5.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(37.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))))
                .border(2.dp, RewardGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Person,
                contentDescription = stringResource(R.string.profile),
                tint = Color.White,
                modifier = Modifier.size(23.dp)
            )
        }
    }
}

@Composable
private fun RankBadge(rankName: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(11.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1E63), Color(0xFF17368B))))
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(11.dp))
            .padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(13.dp)
        )
        Spacer(Modifier.width(3.dp))
        Text(
            text = rankName,
            color = Color.White,
            fontSize = 10.sp,
            lineHeight = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1
        )
    }
}

@Composable
private fun MiniChestButton(availableCount: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .shadow(2.dp, RoundedCornerShape(10.dp))
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.94f))
            .border(1.dp, RewardGold.copy(alpha = 0.26f), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        RewardGiftAsset(Modifier.size(21.dp))
        if (availableCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 2.dp, y = (-2).dp)
                    .size(12.dp)
                    .background(Color(0xFFFF4057), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = availableCount.coerceAtMost(9).toString(),
                    color = Color.White,
                    fontSize = 7.sp,
                    lineHeight = 7.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun CoinHeaderItem(coins: Int) {
    CompactHeaderAction(
        icon = {
            Box(modifier = Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Rounded.Star,
                    contentDescription = "سکه",
                    tint = RewardGold,
                    modifier = Modifier.size(27.dp)
                )
                Box(
                    modifier = Modifier
                        .size(13.dp)
                        .background(Color(0xFFFFD85C), CircleShape)
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("C", color = Color(0xFF9A6700), fontSize = 7.sp, fontWeight = FontWeight.Black)
                }
            }
        },
        bottomText = coins.toString()
    )
}

@Composable
private fun ComboHeaderItem(count: Int, active: Boolean) {
    CompactHeaderAction(
        icon = {
            Box(modifier = Modifier.size(28.dp), contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Rounded.Whatshot,
                    contentDescription = stringResource(R.string.combo),
                    tint = if (active) Color(0xFFFF5D1A) else Color(0xFFFF9A57),
                    modifier = Modifier.size(25.dp)
                )
                if (active) {
                    Text(
                        text = "×1.5",
                        modifier = Modifier.align(Alignment.BottomCenter),
                        color = Navy,
                        fontSize = 6.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        },
        bottomText = count.toString()
    )
}

@Composable
private fun SettingsHeaderItem(onClick: () -> Unit) {
    CompactHeaderAction(
        modifier = Modifier.clickable(onClick = onClick),
        icon = {
            Icon(
                Icons.Rounded.Settings,
                contentDescription = "تنظیمات",
                tint = PrimaryBlueDark,
                modifier = Modifier.size(23.dp)
            )
        },
        bottomText = ""
    )
}

@Composable
private fun CompactHeaderAction(
    icon: @Composable BoxScope.() -> Unit,
    bottomText: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.width(34.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.78f))
                .border(1.dp, Color.White.copy(alpha = 0.92f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
            content = icon
        )
        if (bottomText.isNotEmpty()) {
            Text(
                text = bottomText,
                color = Navy,
                fontSize = 9.sp,
                lineHeight = 9.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun RewardGiftAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFD348), Color(0xFFF09A16))),
            topLeft = Offset(w * 0.15f, h * 0.38f),
            size = Size(w * 0.70f, h * 0.45f),
            cornerRadius = CornerRadius(w * 0.09f, w * 0.09f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE676), Color(0xFFFFB51A))),
            topLeft = Offset(w * 0.11f, h * 0.31f),
            size = Size(w * 0.78f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )
        drawRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.44f, h * 0.31f),
            size = Size(w * 0.12f, h * 0.52f)
        )
        drawRoundRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.30f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = Color(0xFFFF6671),
            topLeft = Offset(w * 0.50f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawLine(
            color = Color.White.copy(alpha = 0.65f),
            start = Offset(w * 0.18f, h * 0.35f),
            end = Offset(w * 0.35f, h * 0.35f),
            strokeWidth = 1.4f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun XpProgressRow(current: Int, levelStart: Int, target: Int) {
    val denominator = (target - levelStart).coerceAtLeast(1)
    val progress = ((current - levelStart).toFloat() / denominator.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(17.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.White.copy(alpha = 0.72f))
                .padding(horizontal = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "$current XP",
                color = PrimaryBlue,
                fontSize = 8.sp,
                lineHeight = 8.sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFDCE8F7))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)))
                )
            }
            Text(
                text = target.toString(),
                color = Muted,
                fontSize = 8.sp,
                lineHeight = 8.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
