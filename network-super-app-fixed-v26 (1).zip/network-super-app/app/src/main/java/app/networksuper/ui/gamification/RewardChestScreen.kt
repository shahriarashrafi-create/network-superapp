package app.networksuper.ui.gamification

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.LockClock
import androidx.compose.material.icons.rounded.Redeem
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.networksuper.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun RewardChestScreen(modifier: Modifier = Modifier) {
    val state = GamificationStore.state
    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var lastReward by remember { mutableStateOf<ChestReward?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(1000L)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SoftBlue,
                border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.15f))
            ) {
                Text(
                    text = "${GamificationStore.availableChestCount(nowMillis)} آماده",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    color = PrimaryBlue,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Text(
                text = "صندوق‌ها",
                color = Navy,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black
            )
        }

        lastReward?.let { reward ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SuccessGreen.copy(alpha = 0.09f),
                border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.22f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = SuccessGreen)
                    Text(
                        text = "پاداش دریافت شد: ${reward.label}",
                        color = Navy,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        ChestCard(
            title = "صندوق ۳ ساعته",
            subtitle = if (GamificationStore.isThreeHourChestReady(nowMillis)) {
                "آماده باز کردن"
            } else {
                "زمان باقی‌مانده ${formatRemaining(GamificationStore.threeHourChestRemainingMillis(nowMillis))}"
            },
            ready = GamificationStore.isThreeHourChestReady(nowMillis),
            icon = if (GamificationStore.isThreeHourChestReady(nowMillis)) Icons.Rounded.Redeem else Icons.Rounded.Schedule,
            onOpen = { lastReward = GamificationStore.claimThreeHourChest(nowMillis) }
        )

        ChestCard(
            title = "صندوق پاداش کارها",
            subtitle = if (state.unclaimedTaskChests > 0) {
                "${state.unclaimedTaskChests} صندوق آماده داری"
            } else {
                "هر ۵ کار موفق یک صندوق می‌گیری"
            },
            ready = state.unclaimedTaskChests > 0,
            icon = if (state.unclaimedTaskChests > 0) Icons.Rounded.Redeem else Icons.Rounded.LockClock,
            onOpen = { lastReward = GamificationStore.claimTaskChest() }
        )

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceOutline)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Text("قانون صندوق‌ها", color = Navy, fontWeight = FontWeight.Black)
                Text(
                    text = "همه صندوق‌ها فقط در همین صفحه باز می‌شوند. صندوق دوره‌ای هر ۳ ساعت دوباره آماده می‌شود و صندوق کارها با پیشرفت واقعی به‌دست می‌آید.",
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Right
                )
            }
        }
    }
}

@Composable
private fun ChestCard(
    title: String,
    subtitle: String,
    ready: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(
            if (ready) 1.4.dp else 1.dp,
            if (ready) RewardGold.copy(alpha = 0.45f) else SurfaceOutline
        ),
        shadowElevation = if (ready) 3.dp else 0.dp
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        if (ready) Brush.linearGradient(listOf(Color(0xFFFFF3C7), Color(0xFFFFD872)))
                        else Brush.linearGradient(listOf(Color(0xFFF2F5F9), Color(0xFFE6EBF2)))
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (ready) Color(0xFFCA8B00) else Muted,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Navy, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = if (ready) PrimaryBlue else Muted, style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = onOpen,
                enabled = ready,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                contentPadding = PaddingValues(horizontal = 13.dp, vertical = 8.dp)
            ) {
                Text("باز کردن", fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
        }
    }
}

private fun formatRemaining(millis: Long): String {
    val totalSeconds = (millis / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return "%02d:%02d:%02d".format(hours, minutes, seconds)
}
