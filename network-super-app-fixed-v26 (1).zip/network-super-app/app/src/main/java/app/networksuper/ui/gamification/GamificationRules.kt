package app.networksuper.ui.gamification

import kotlin.math.roundToInt

/** Pure reward math. Kept outside persistence/UI so it can be unit-tested deterministically. */
internal object GamificationRules {
    const val BASE_TASK_COINS = 4
    const val BASE_TASK_XP = 20
    const val COMBO_START = 3
    const val TASKS_PER_CHEST = 5
    const val XP_LEVEL_STEP = 3000

    fun taskReward(currentCombo: Int, currentSuccessCount: Int): ComputedTaskReward {
        val newCombo = currentCombo.coerceAtLeast(0) + 1
        val multiplier = if (newCombo >= COMBO_START) 1.5f else 1f
        val newSuccessCount = currentSuccessCount.coerceAtLeast(0) + 1
        return ComputedTaskReward(
            coins = (BASE_TASK_COINS * multiplier).roundToInt(),
            xp = (BASE_TASK_XP * multiplier).roundToInt(),
            comboCount = newCombo,
            multiplier = multiplier,
            successCount = newSuccessCount,
            chestEarned = newSuccessCount % TASKS_PER_CHEST == 0
        )
    }

    fun xpTarget(totalXp: Int): Int {
        val safeXp = totalXp.coerceAtLeast(0)
        return ((safeXp / XP_LEVEL_STEP) + 1) * XP_LEVEL_STEP
    }

    fun xpLevelStart(totalXp: Int): Int =
        (totalXp.coerceAtLeast(0) / XP_LEVEL_STEP) * XP_LEVEL_STEP
}

internal data class ComputedTaskReward(
    val coins: Int,
    val xp: Int,
    val comboCount: Int,
    val multiplier: Float,
    val successCount: Int,
    val chestEarned: Boolean
)
