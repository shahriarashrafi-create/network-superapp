package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.ui.theme.*

private data class CategoryVisual(
    val category: ProgressCategory,
    val title: String,
    val icon: ImageVector,
    val accent: Color
)

private val ProgressCategories = listOf(
    CategoryVisual(ProgressCategory.PERSONAL, "کارهای شخصی", Icons.Rounded.Person, AccentPurple),
    CategoryVisual(ProgressCategory.SALES, "کارهای فروش", Icons.Rounded.ShoppingBag, SuccessGreen),
    CategoryVisual(ProgressCategory.NETWORKING, "کارهای شبکه‌سازی", Icons.Rounded.AccountTree, PrimaryBlue),
    CategoryVisual(ProgressCategory.SUPPORT, "کارهای حمایتی", Icons.Rounded.Groups, WarningOrange),
    CategoryVisual(ProgressCategory.SPONSOR, "کارهای حامی", Icons.Rounded.WorkspacePremium, Color(0xFF7A64E8))
)

/**
 * Home-like progress page: five horizontally scrollable strips. The cards keep their existing
 * visual language; each strip adds a code-drawn zig-zag street behind the cards.
 */
@Composable
fun ProgressPathContent(
    modifier: Modifier = Modifier,
    onOpenMission: (Long) -> Unit = {}
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 7.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            ProgressCategories.forEach { visual ->
                val items = ProgressPathStore.stages
                    .filter { it.category == visual.category }
                    .sortedBy { it.number }

                ProgressCategorySection(
                    visual = visual,
                    stages = items,
                    onStageClick = onOpenMission
                )
            }
            Spacer(Modifier.height(54.dp))
        }

        Surface(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(AbsoluteAlignment.BottomRight)
                .padding(14.dp)
                .size(42.dp)
                .shadow(5.dp, CircleShape),
            shape = CircleShape,
            color = PrimaryBlue,
            border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = "افزودن کارت",
                    tint = Color.White,
                    modifier = Modifier.size(23.dp)
                )
            }
        }
    }

    if (showAddDialog) {
        StageEditorDialog(
            editingStage = null,
            onDismiss = { showAddDialog = false },
            onSave = { title, position ->
                ProgressPathStore.addStage(title, position)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun ProgressCategorySection(
    visual: CategoryVisual,
    stages: List<ProgressStage>,
    onStageClick: (Long) -> Unit
) {
    val completed = stages.count { it.status == StageStatus.COMPLETED }
    val total = stages.size

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(186.dp),
        shape = RoundedCornerShape(23.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 1.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 10.dp, bottom = 7.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = visual.accent.copy(alpha = 0.09f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, visual.accent.copy(alpha = 0.16f))
                ) {
                    Text(
                        text = "$completed/$total",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        color = visual.accent,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Text(
                        text = visual.title,
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(11.dp))
                            .background(visual.accent.copy(alpha = 0.10f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = visual.icon,
                            contentDescription = null,
                            tint = visual.accent,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(4.dp))

            if (stages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "هنوز کاری در این مسیر ثبت نشده",
                        color = Muted,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                CategoryRoadScroller(
                    stages = stages,
                    accent = visual.accent,
                    onStageClick = onStageClick,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun CategoryRoadScroller(
    stages: List<ProgressStage>,
    accent: Color,
    onStageClick: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
            val viewportWidth = maxWidth
            val cardWidth = 126.dp
            val step = 142.dp
            val startPadding = 18.dp
            val calculated = (startPadding.value * 2f + step.value * (stages.size - 1).coerceAtLeast(0) + cardWidth.value).dp
            val contentWidth = if (calculated < viewportWidth) viewportWidth else calculated
            val hScroll = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .horizontalScroll(hScroll)
            ) {
                Box(
                    modifier = Modifier
                        .width(contentWidth)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFFF9FCFF), accent.copy(alpha = 0.025f), Color(0xFFF8FBFF))
                            )
                        )
                ) {
                    HorizontalZigZagRoad(
                        count = stages.size,
                        accent = accent,
                        startPaddingPx = startPadding,
                        step = step,
                        cardWidth = cardWidth,
                        modifier = Modifier.matchParentSize()
                    )

                    stages.forEachIndexed { index, stage ->
                        val high = index % 2 == 0
                        ProgressRoadCard(
                            stage = stage,
                            accentHint = accent,
                            onClick = { onStageClick(stage.id) },
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset(
                                    x = (startPadding.value + step.value * index).dp,
                                    y = if (high) 8.dp else 61.dp
                                )
                                .width(cardWidth)
                                .height(62.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HorizontalZigZagRoad(
    count: Int,
    accent: Color,
    startPaddingPx: androidx.compose.ui.unit.Dp,
    step: androidx.compose.ui.unit.Dp,
    cardWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (count <= 0) return@Canvas
        val startX = startPaddingPx.toPx() + cardWidth.toPx() / 2f
        val highY = 54.dp.toPx()
        val lowY = 108.dp.toPx()
        val points = List(count) { index ->
            Offset(startX + step.toPx() * index, if (index % 2 == 0) highY else lowY)
        }

        val path = Path().apply {
            moveTo(points.first().x - 46.dp.toPx(), points.first().y)
            lineTo(points.first().x, points.first().y)
            for (i in 0 until points.lastIndex) {
                val p0 = points[i]
                val p1 = points[i + 1]
                val middleX = (p0.x + p1.x) / 2f
                cubicTo(middleX, p0.y, middleX, p1.y, p1.x, p1.y)
            }
            lineTo(points.last().x + 48.dp.toPx(), points.last().y)
        }

        // Asphalt edge, street body and dashed center line are all code-drawn assets.
        drawPath(
            path = path,
            color = Color.White.copy(alpha = 0.98f),
            style = Stroke(width = 34.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = path,
            color = Color(0xFFB9C5D2).copy(alpha = 0.48f),
            style = Stroke(width = 29.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = path,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFF7D8B99).copy(alpha = 0.78f),
                    Color(0xFF657584).copy(alpha = 0.84f),
                    accent.copy(alpha = 0.46f)
                )
            ),
            style = Stroke(width = 23.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = path,
            color = Color.White.copy(alpha = 0.92f),
            style = Stroke(
                width = 2.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 8.dp.toPx()))
            )
        )
    }
}

@Composable
private fun ProgressRoadCard(
    stage: ProgressStage,
    accentHint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val statusAccent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.FAILED -> FailRed
        StageStatus.UPCOMING -> accentHint
    }

    Box(modifier = modifier) {
        Surface(
            onClick = onClick,
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(17.dp),
            color = Color.White.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.92f else 0.99f),
            border = androidx.compose.foundation.BorderStroke(
                if (current) 1.8.dp else 1.dp,
                statusAccent.copy(alpha = if (current) 0.80f else 0.25f)
            ),
            shadowElevation = if (current) 5.dp else 2.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stage.title,
                    color = Navy.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.78f else 1f),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        StageStatusBadge(
            stage = stage,
            compact = true,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-5).dp, y = (-7).dp)
        )
    }
}
