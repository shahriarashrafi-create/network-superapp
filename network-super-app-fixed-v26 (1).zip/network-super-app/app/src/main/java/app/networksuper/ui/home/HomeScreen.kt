package app.networksuper.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.progress.ProgressPathStore

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    uiState: HomeUiState = HomeDefaults.state,
    onOpenMission: (Long) -> Unit = {}
) {
    val currentStage = ProgressPathStore.currentStage()
    val nextActionTitle = currentStage?.title ?: stringResource(R.string.next_step_missing)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        NextActionCard(
            nextActionTitle = nextActionTitle,
            onStart = { currentStage?.let { onOpenMission(it.id) } },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.29f)
        )
        TodaySection(
            title = uiState.todayTitle,
            dateLabel = uiState.todayDateLabel,
            scheduleItems = uiState.scheduleItems,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.355f)
        )
        ProgressSection(
            onStageClick = onOpenMission,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.355f)
        )
    }
}
