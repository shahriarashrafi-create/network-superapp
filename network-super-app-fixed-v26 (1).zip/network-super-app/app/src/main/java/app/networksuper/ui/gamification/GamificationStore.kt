package app.networksuper.ui.gamification

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.networksuper.ui.progress.ProgressPathStore

/**
 * Central, persistent gamification engine.
 *
 * Rewards are intentionally independent from screen code so Home, Progress and Reward Chest
 * always show the same XP/Coin/Combo state. A stage can only grant its completion reward once.
 */
object GamificationStore {
    private const val PREFS_NAME = "gamification_v1"
    private const val KEY_COINS = "coins"
    private const val KEY_XP = "xp"
    private const val KEY_COMBO = "combo"
    private const val KEY_REWARDED_STAGE_IDS = "rewarded_stage_ids"
    private const val KEY_UNCLAIMED_TASK_CHESTS = "unclaimed_task_chests"
    private const val KEY_NEXT_THREE_HOUR_CHEST_AT = "next_three_hour_chest_at"
    private const val KEY_CHEST_OPEN_COUNT = "chest_open_count"
    private const val KEY_SUCCESS_COUNT = "success_count"

    private const val DEFAULT_COINS = 86
    private const val DEFAULT_XP = 2480
    const val THREE_HOURS_MILLIS: Long = 3L * 60L * 60L * 1000L

    private var prefs: SharedPreferences? = null
    private var initialized = false

    var state by mutableStateOf(GamificationState())
        private set

    fun initialize(context: Context) {
        if (initialized) return
        val storage = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = storage

        val hasPersistedState = storage.contains(KEY_COINS) || storage.contains(KEY_XP)
        val alreadyCompletedIds = ProgressPathStore.stages
            .filter { it.status == app.networksuper.ui.progress.StageStatus.COMPLETED }
            .map { it.id }
            .toSet()

        val rewardedIds = if (storage.contains(KEY_REWARDED_STAGE_IDS)) {
            storage.getStringSet(KEY_REWARDED_STAGE_IDS, emptySet())
                .orEmpty()
                .mapNotNull { it.toLongOrNull() }
                .toSet()
        } else {
            // Existing completed cards are treated as historical progress so updating the app does
            // not retroactively pay them again.
            alreadyCompletedIds
        }

        state = GamificationState(
            coins = storage.getInt(KEY_COINS, DEFAULT_COINS),
            totalXp = storage.getInt(KEY_XP, DEFAULT_XP),
            comboCount = storage.getInt(KEY_COMBO, 0).coerceAtLeast(0),
            rewardedStageIds = rewardedIds,
            unclaimedTaskChests = storage.getInt(KEY_UNCLAIMED_TASK_CHESTS, 0).coerceAtLeast(0),
            nextThreeHourChestAtMillis = storage.getLong(KEY_NEXT_THREE_HOUR_CHEST_AT, 0L).coerceAtLeast(0L),
            chestOpenCount = storage.getInt(KEY_CHEST_OPEN_COUNT, 0).coerceAtLeast(0),
            successCount = storage.getInt(KEY_SUCCESS_COUNT, 0).coerceAtLeast(0)
        )

        if (!hasPersistedState || !storage.contains(KEY_REWARDED_STAGE_IDS)) persist()
        initialized = true
    }

    /**
     * Called only after a task passes its required checklist and is completed.
     * Combo activates on the third consecutive successful task and then multiplies both rewards
     * by 1.5. Duplicate completion of the same card never grants XP/Coin twice.
     */
    fun onTaskCompleted(stageId: Long): TaskRewardReceipt? {
        if (stageId in state.rewardedStageIds) return null

        val reward = GamificationRules.taskReward(
            currentCombo = state.comboCount,
            currentSuccessCount = state.successCount
        )

        state = state.copy(
            coins = state.coins + reward.coins,
            totalXp = state.totalXp + reward.xp,
            comboCount = reward.comboCount,
            rewardedStageIds = state.rewardedStageIds + stageId,
            unclaimedTaskChests = state.unclaimedTaskChests + if (reward.chestEarned) 1 else 0,
            successCount = reward.successCount
        )
        persist()

        return TaskRewardReceipt(
            coins = reward.coins,
            xp = reward.xp,
            comboCount = reward.comboCount,
            multiplier = reward.multiplier,
            chestEarned = reward.chestEarned
        )
    }

    /** A failed task breaks the consecutive-success combo. */
    fun onTaskFailed() {
        if (state.comboCount == 0) return
        state = state.copy(comboCount = 0)
        persist()
    }

    fun comboActive(): Boolean = state.comboCount >= GamificationRules.COMBO_START

    fun xpTarget(): Int = GamificationRules.xpTarget(state.totalXp)

    fun xpLevelStart(): Int = GamificationRules.xpLevelStart(state.totalXp)

    fun isThreeHourChestReady(nowMillis: Long = System.currentTimeMillis()): Boolean =
        state.nextThreeHourChestAtMillis == 0L || nowMillis >= state.nextThreeHourChestAtMillis

    fun availableChestCount(nowMillis: Long = System.currentTimeMillis()): Int =
        state.unclaimedTaskChests + if (isThreeHourChestReady(nowMillis)) 1 else 0

    fun threeHourChestRemainingMillis(nowMillis: Long = System.currentTimeMillis()): Long =
        (state.nextThreeHourChestAtMillis - nowMillis).coerceAtLeast(0L)

    /** All earned task chests are opened only from RewardChestScreen. */
    fun claimTaskChest(): ChestReward? {
        if (state.unclaimedTaskChests <= 0) return null
        val reward = rewardForOpenIndex(state.chestOpenCount, earned = true)
        applyChestReward(
            reward = reward,
            nextState = state.copy(
                unclaimedTaskChests = state.unclaimedTaskChests - 1,
                chestOpenCount = state.chestOpenCount + 1
            )
        )
        return reward
    }

    /** Free chest can be claimed once every three hours and only from RewardChestScreen. */
    fun claimThreeHourChest(nowMillis: Long = System.currentTimeMillis()): ChestReward? {
        if (!isThreeHourChestReady(nowMillis)) return null
        val reward = rewardForOpenIndex(state.chestOpenCount, earned = false)
        applyChestReward(
            reward = reward,
            nextState = state.copy(
                nextThreeHourChestAtMillis = nowMillis + THREE_HOURS_MILLIS,
                chestOpenCount = state.chestOpenCount + 1
            )
        )
        return reward
    }

    private fun applyChestReward(reward: ChestReward, nextState: GamificationState) {
        state = nextState.copy(
            coins = nextState.coins + reward.coins,
            totalXp = nextState.totalXp + reward.xp
        )
        persist()
    }

    /**
     * Stable rotating reward pool: no network dependency and no re-roll by reopening the screen.
     * Earned chests are slightly stronger than the free 3-hour chest.
     */
    private fun rewardForOpenIndex(openIndex: Int, earned: Boolean): ChestReward {
        val bucket = Math.floorMod(openIndex, 6)
        return if (earned) {
            when (bucket) {
                0 -> ChestReward(coins = 20, xp = 60, label = "۲۰ سکه + ۶۰ XP")
                1 -> ChestReward(coins = 35, xp = 0, label = "۳۵ سکه")
                2 -> ChestReward(coins = 12, xp = 120, label = "۱۲ سکه + ۱۲۰ XP")
                3 -> ChestReward(coins = 50, xp = 50, label = "۵۰ سکه + ۵۰ XP")
                4 -> ChestReward(coins = 18, xp = 160, label = "۱۸ سکه + ۱۶۰ XP")
                else -> ChestReward(coins = 65, xp = 80, label = "۶۵ سکه + ۸۰ XP")
            }
        } else {
            when (bucket) {
                0 -> ChestReward(coins = 8, xp = 30, label = "۸ سکه + ۳۰ XP")
                1 -> ChestReward(coins = 12, xp = 20, label = "۱۲ سکه + ۲۰ XP")
                2 -> ChestReward(coins = 6, xp = 50, label = "۶ سکه + ۵۰ XP")
                3 -> ChestReward(coins = 15, xp = 25, label = "۱۵ سکه + ۲۵ XP")
                4 -> ChestReward(coins = 10, xp = 45, label = "۱۰ سکه + ۴۵ XP")
                else -> ChestReward(coins = 18, xp = 30, label = "۱۸ سکه + ۳۰ XP")
            }
        }
    }

    private fun persist() {
        val storage = prefs ?: return
        storage.edit()
            .putInt(KEY_COINS, state.coins)
            .putInt(KEY_XP, state.totalXp)
            .putInt(KEY_COMBO, state.comboCount)
            .putStringSet(KEY_REWARDED_STAGE_IDS, state.rewardedStageIds.map(Long::toString).toMutableSet())
            .putInt(KEY_UNCLAIMED_TASK_CHESTS, state.unclaimedTaskChests)
            .putLong(KEY_NEXT_THREE_HOUR_CHEST_AT, state.nextThreeHourChestAtMillis)
            .putInt(KEY_CHEST_OPEN_COUNT, state.chestOpenCount)
            .putInt(KEY_SUCCESS_COUNT, state.successCount)
            .apply()
    }
}

data class GamificationState(
    val coins: Int = 86,
    val totalXp: Int = 2480,
    val comboCount: Int = 0,
    val rewardedStageIds: Set<Long> = emptySet(),
    val unclaimedTaskChests: Int = 0,
    val nextThreeHourChestAtMillis: Long = 0L,
    val chestOpenCount: Int = 0,
    val successCount: Int = 0
)

data class TaskRewardReceipt(
    val coins: Int,
    val xp: Int,
    val comboCount: Int,
    val multiplier: Float,
    val chestEarned: Boolean
)

data class ChestReward(
    val coins: Int,
    val xp: Int,
    val label: String
)
