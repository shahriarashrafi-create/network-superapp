package app.networksuper.ui.progress

enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

enum class MissionStatus { NOT_STARTED, ACTIVE, EXPIRED, COMPLETED, FAILED }

enum class ProgressCategory {
    PERSONAL,
    SALES,
    NETWORKING,
    SUPPORT,
    SPONSOR;

    companion object {
        fun fromLegacy(number: Int, title: String): ProgressCategory {
            val normalized = title.trim()
            return when {
                normalized.contains("مشتری") || normalized.contains("فروش") || normalized.contains("مالی") -> SALES
                normalized.contains("ارتباط") || normalized.contains("معرفی") || normalized.contains("شبکه") -> NETWORKING
                normalized.contains("یادگیری") || normalized.contains("مهارت") || normalized.contains("حمایت") -> SUPPORT
                normalized.contains("رهبری") || normalized.contains("حامی") || normalized.contains("تیم") -> SPONSOR
                else -> entries[Math.floorMod(number - 1, entries.size)]
            }
        }
    }
}

data class MissionChecklistItem(
    val id: Long,
    val text: String,
    val required: Boolean,
    val checked: Boolean = false
)

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus,
    val category: ProgressCategory = ProgressCategory.PERSONAL,
    /** Legacy persisted field kept only so existing payloads remain fully compatible. */
    val description: String = "",
    val missionStatus: MissionStatus = status.defaultMissionStatus(),
    val durationMinutes: Int = DEFAULT_MISSION_DURATION_MINUTES,
    val startedAtMillis: Long? = null,
    val endAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val attemptCount: Int = 0,
    val note: String = "",
    /** Autosaved working copy. Null means there is no unsaved draft. */
    val noteDraft: String? = null,
    val checklist: List<MissionChecklistItem> = emptyList()
) {
    companion object {
        const val DEFAULT_MISSION_DURATION_MINUTES = 15
    }
}

private fun StageStatus.defaultMissionStatus(): MissionStatus = when (this) {
    StageStatus.COMPLETED -> MissionStatus.COMPLETED
    StageStatus.FAILED -> MissionStatus.FAILED
    StageStatus.CURRENT, StageStatus.UPCOMING -> MissionStatus.NOT_STARTED
}
