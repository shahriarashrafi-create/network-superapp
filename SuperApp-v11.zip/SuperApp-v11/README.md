# Super App — v1.9.0 / Build 11

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## Build 11 highlights
- Home remains action-first while shortcut cards now expose small live metrics (progress, follow-ups, today actions, weekly growth, etc.).
- Status strip is more balanced: one XP bar + percentage, refined Level/Coin/Combo presentation and compact time/action context.
- Level bottom sheet now adds today/week/daily-average XP, clickable previous/current/next levels, clearer reward/unlock chips and consistent XP ordering.
- Full Level Path is more statistical with trend, KPI chips, previous/current/future state and tap-to-inspect rewards/unlocks.
- Coin is softer and more premium; Coin sheet adds today/week/spend KPIs and time-scoped recent transactions.
- Wallet adds day/week/month/spend KPIs, weekly trend visualization, receive/spend filters, transaction ranges and empty-state handling.
- Reward Store adds balance, purchasable count, purchase history and monthly spend summary.
- Combo sheet differentiates inactive/active states and adds current state, best combo and earned XP summary.
- Notification Center is denser and more useful: unread/action summary, filter counts, unread surface treatment, standardized CTAs and Persian copy.
- Reward strip now shows a small daily reward statistic without becoming a dashboard.
- Bottom navigation is slightly shorter, quieter and more floating.
- Shadows/borders/spacing were softened for a cleaner Legacy-inspired premium look.

## Visual policy
No decorative bitmap/background images are used. UI is built with Compose, Canvas, shapes, gradients, vector/material icons and code-generated assets.

## App identity
- applicationId: `com.liateam.superapp`
- versionCode: `11`
- versionName: `1.9.0`
- existing signing keystore preserved for in-place updates.
