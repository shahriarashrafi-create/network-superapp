package com.liateam.superapp

import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppSection
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.TaskStatus
import com.liateam.superapp.ui.model.initialTasks
import com.liateam.superapp.ui.screens.ActionsScreen
import com.liateam.superapp.ui.screens.HomeScreen
import com.liateam.superapp.ui.screens.LevelPathScreen
import com.liateam.superapp.ui.screens.NotificationsScreen
import com.liateam.superapp.ui.screens.PlaceholderScreen
import com.liateam.superapp.ui.screens.ProfileScreen
import com.liateam.superapp.ui.screens.ProgressScreen
import com.liateam.superapp.ui.screens.RewardStoreScreen
import com.liateam.superapp.ui.screens.WalletScreen
import com.liateam.superapp.ui.theme.SuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SuperAppTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SuperAppRoot()
                }
            }
        }
    }
}

@Composable
private fun SuperAppRoot() {
    var section by remember { mutableStateOf(AppSection.HOME) }
    val destinationStack = remember { mutableStateListOf<HomeDestination>() }
    val tasks = remember { mutableStateListOf<AppTask>().apply { addAll(initialTasks()) } }
    val stateHolder = rememberSaveableStateHolder()
    val context = LocalContext.current
    val activity = context as? ComponentActivity
    var lastHomeBackAt by remember { mutableLongStateOf(0L) }

    val destination = destinationStack.lastOrNull()

    fun updateTask(id: Int, status: TaskStatus) {
        val index = tasks.indexOfFirst { it.id == id }
        if (index >= 0) tasks[index] = tasks[index].copy(status = status)
    }

    fun openDestination(target: HomeDestination) {
        when (target) {
            HomeDestination.PROGRESS -> {
                destinationStack.clear()
                section = AppSection.PROGRESS
            }
            HomeDestination.NETWORK -> {
                destinationStack.clear()
                section = AppSection.NETWORK
            }
            HomeDestination.ACTIONS -> {
                destinationStack.clear()
                section = AppSection.ACTIONS
            }
            else -> destinationStack.add(target)
        }
    }

    fun navigateBack() {
        when {
            destinationStack.isNotEmpty() -> destinationStack.removeAt(destinationStack.lastIndex)
            section != AppSection.HOME -> section = AppSection.HOME
            else -> {
                val now = SystemClock.elapsedRealtime()
                if (now - lastHomeBackAt <= 2200L) {
                    activity?.finish()
                } else {
                    lastHomeBackAt = now
                    Toast.makeText(context, "برای خروج دوباره بزنید", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    BackHandler(enabled = true) { navigateBack() }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SuperColors.Background,
        bottomBar = {
            if (destination == null) {
                MainBottomBar(
                    section = section,
                    onSelect = {
                        destinationStack.clear()
                        section = it
                    }
                )
            }
        }
    ) { innerPadding ->
        when (destination) {
            HomeDestination.PROFILE -> stateHolder.SaveableStateProvider("dest_profile") {
                ProfileScreen(
                    contentPadding = innerPadding,
                    onBack = ::navigateBack,
                    onOpenDestination = ::openDestination
                )
            }

            HomeDestination.NOTIFICATIONS -> stateHolder.SaveableStateProvider("dest_notifications") {
                NotificationsScreen(
                    contentPadding = innerPadding,
                    onBack = ::navigateBack,
                    onOpenDestination = ::openDestination
                )
            }

            HomeDestination.LEVEL_PATH -> stateHolder.SaveableStateProvider("dest_level_path") {
                LevelPathScreen(contentPadding = innerPadding, onBack = ::navigateBack)
            }

            HomeDestination.WALLET -> stateHolder.SaveableStateProvider("dest_wallet") {
                WalletScreen(contentPadding = innerPadding, onBack = ::navigateBack)
            }

            HomeDestination.REWARD_STORE -> stateHolder.SaveableStateProvider("dest_reward_store") {
                RewardStoreScreen(contentPadding = innerPadding, onBack = ::navigateBack)
            }

            null -> when (section) {
                AppSection.HOME -> stateHolder.SaveableStateProvider("section_home") {
                    HomeScreen(
                        contentPadding = innerPadding,
                        tasks = tasks,
                        onOpenActions = { section = AppSection.ACTIONS },
                        onOpenDestination = ::openDestination
                    )
                }

                AppSection.ACTIONS -> stateHolder.SaveableStateProvider("section_actions") {
                    ActionsScreen(
                        contentPadding = innerPadding,
                        tasks = tasks,
                        onTaskStatus = ::updateTask,
                        onOpenProgress = { section = AppSection.PROGRESS }
                    )
                }

                AppSection.PROGRESS -> stateHolder.SaveableStateProvider("section_progress") {
                    ProgressScreen(contentPadding = innerPadding, onBack = ::navigateBack)
                }

                AppSection.NETWORK -> stateHolder.SaveableStateProvider("section_network") {
                    PlaceholderScreen(
                        contentPadding = innerPadding,
                        title = "شبکه من",
                        subtitle = "درختواره، اعضای سازمان و Profile 360 از این بخش باز می‌شوند."
                    )
                }

                AppSection.MESSAGES -> stateHolder.SaveableStateProvider("section_messages") {
                    PlaceholderScreen(
                        contentPadding = innerPadding,
                        title = "پیام‌ها",
                        subtitle = "Messenger، گروه‌ها و کانال‌های تیمی در این بخش قرار می‌گیرند."
                    )
                }

                AppSection.MORE -> stateHolder.SaveableStateProvider("section_more") {
                    PlaceholderScreen(
                        contentPadding = innerPadding,
                        title = "بیشتر",
                        subtitle = "تمام ابزارهای کم‌استفاده‌تر و Shortcutهای قابل Pin از اینجا در دسترس خواهند بود."
                    )
                }
            }

            else -> stateHolder.SaveableStateProvider("dest_${destination.name}") {
                PlaceholderScreen(
                    contentPadding = innerPadding,
                    title = destination.title,
                    subtitle = destination.subtitle,
                    onBack = ::navigateBack
                )
            }
        }
    }
}

private data class BottomItem(
    val section: AppSection,
    val label: String,
    val icon: ImageVector
)

@Composable
private fun MainBottomBar(
    section: AppSection,
    onSelect: (AppSection) -> Unit
) {
    val items = listOf(
        BottomItem(AppSection.HOME, "خانه", Icons.Outlined.Home),
        BottomItem(AppSection.ACTIONS, "اقدام‌ها", Icons.Outlined.TaskAlt),
        BottomItem(AppSection.NETWORK, "شبکه من", Icons.Outlined.Groups),
        BottomItem(AppSection.MESSAGES, "پیام‌ها", Icons.Outlined.ChatBubbleOutline),
        BottomItem(AppSection.MORE, "بیشتر", Icons.Outlined.MoreHoriz)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 3.dp)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .shadow(2.dp, RoundedCornerShape(18.dp), clip = false),
            shape = RoundedCornerShape(18.dp),
            color = Color.White,
            tonalElevation = 0.dp,
            shadowElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 5.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                items.forEach { item ->
                    val selected = when (section) {
                        AppSection.PROGRESS -> item.section == AppSection.ACTIONS
                        else -> section == item.section
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelect(item.section) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .height(24.dp)
                                .background(if (selected) SuperColors.BlueSoft else Color.Transparent, SuperShapes.Pill)
                                .padding(horizontal = if (selected) 11.dp else 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                item.icon,
                                contentDescription = item.label,
                                tint = if (selected) SuperColors.Blue else Color(0xFF53657D),
                                modifier = Modifier.size(17.dp)
                            )
                        }
                        Text(
                            item.label,
                            color = if (selected) SuperColors.Blue else Color(0xFF64748A),
                            fontWeight = if (selected) FontWeight.Black else FontWeight.Medium,
                            fontSize = 7.9.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
