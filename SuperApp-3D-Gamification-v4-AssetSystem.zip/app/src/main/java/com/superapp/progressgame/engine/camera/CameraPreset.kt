package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position

data class CameraPreset(
    val id: String,
    val target: Position,
    val orbitRadius: Float,
    val minRadius: Float,
    val maxRadius: Float,
)

object CameraPresets {
    val Overview = CameraPreset(
        id = "overview",
        target = Position(x = 0f, y = 1.25f, z = -2.0f),
        orbitRadius = 17.0f,
        minRadius = 10.5f,
        maxRadius = 22.0f,
    )

    val Fountain = CameraPreset(
        id = "fountain_main",
        target = Position(x = 0f, y = 1.0f, z = -1.2f),
        orbitRadius = 6.6f,
        minRadius = 4.6f,
        maxRadius = 10.0f,
    )

    val Mansion = CameraPreset(
        id = "mansion_main",
        target = Position(x = 0f, y = 2.0f, z = -8.6f),
        orbitRadius = 9.2f,
        minRadius = 7.0f,
        maxRadius = 15.0f,
    )

    val Entrance = CameraPreset(
        id = "entrance_gate",
        target = Position(x = 0f, y = 1.25f, z = 10.5f),
        orbitRadius = 6.6f,
        minRadius = 4.8f,
        maxRadius = 9.5f,
    )

    val GardenWest = CameraPreset(
        id = "garden_west",
        target = Position(x = -6.0f, y = 1.1f, z = -0.8f),
        orbitRadius = 7.2f,
        minRadius = 5.0f,
        maxRadius = 12.0f,
    )

    val GardenEast = CameraPreset(
        id = "garden_east",
        target = Position(x = 6.0f, y = 1.1f, z = -0.8f),
        orbitRadius = 7.2f,
        minRadius = 5.0f,
        maxRadius = 12.0f,
    )

    fun forObject(objectId: String?): CameraPreset = when {
        objectId == null -> Overview
        objectId.startsWith("fountain") -> Fountain
        objectId.startsWith("mansion") -> Mansion
        objectId.startsWith("entrance") -> Entrance
        objectId.startsWith("tree_w") || objectId.startsWith("bench_w") || objectId.startsWith("plant_0") -> GardenWest
        objectId.startsWith("tree_e") || objectId.startsWith("bench_e") -> GardenEast
        objectId.startsWith("lamp_") -> Overview
        else -> Overview
    }

    fun byId(id: String?): CameraPreset = when (id) {
        Fountain.id -> Fountain
        Mansion.id -> Mansion
        Entrance.id -> Entrance
        GardenWest.id -> GardenWest
        GardenEast.id -> GardenEast
        else -> Overview
    }
}
