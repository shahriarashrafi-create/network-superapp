package com.superapp.progressgame.world

import com.superapp.progressgame.assets.AssetCatalog
import com.superapp.progressgame.assets.StarterEstateLayout

data class WorldObjectDefinition(
    val id: String,
    val assetId: String,
    val category: String,
    val displayName: String,
    val cameraFocusable: Boolean = true,
)

object WorldObjectCatalog {
    val objects: List<WorldObjectDefinition> = StarterEstateLayout.allInteractive.map { instance ->
        val asset = AssetCatalog.require(instance.assetId)
        WorldObjectDefinition(
            id = instance.instanceId,
            assetId = instance.assetId,
            category = asset.category.name.lowercase(),
            displayName = asset.displayName,
            cameraFocusable = asset.focusable,
        )
    }

    private val ids = objects.map { it.id }.toSet()

    fun normalize(rawName: String?): String? {
        if (rawName.isNullOrBlank()) return null
        val direct = rawName.takeIf(ids::contains)
        if (direct != null) return direct

        return when {
            rawName.startsWith("fountain_main") -> "fountain_main"
            rawName.startsWith("mansion_main") -> "mansion_main"
            rawName.startsWith("entrance_gate") -> "entrance_gate"
            rawName.startsWith("tree_w_01") -> "tree_w_01"
            rawName.startsWith("tree_w_02") -> "tree_w_02"
            rawName.startsWith("tree_w_03") -> "tree_w_03"
            rawName.startsWith("tree_w_04") -> "tree_w_04"
            rawName.startsWith("tree_e_01") -> "tree_e_01"
            rawName.startsWith("tree_e_02") -> "tree_e_02"
            rawName.startsWith("tree_e_03") -> "tree_e_03"
            rawName.startsWith("tree_e_04") -> "tree_e_04"
            rawName.startsWith("bench_w_01") -> "bench_w_01"
            rawName.startsWith("bench_w_02") -> "bench_w_02"
            rawName.startsWith("bench_e_01") -> "bench_e_01"
            rawName.startsWith("bench_e_02") -> "bench_e_02"
            rawName.startsWith("plant_01") -> "plant_01"
            rawName.startsWith("plant_02") -> "plant_02"
            rawName.startsWith("plant_03") -> "plant_03"
            rawName.startsWith("plant_04") -> "plant_04"
            rawName.startsWith("plant_05") -> "plant_05"
            rawName.startsWith("plant_06") -> "plant_06"
            rawName.startsWith("lamp_01") -> "lamp_01"
            rawName.startsWith("lamp_02") -> "lamp_02"
            rawName.startsWith("lamp_03") -> "lamp_03"
            rawName.startsWith("lamp_04") -> "lamp_04"
            rawName.startsWith("lamp_05") -> "lamp_05"
            rawName.startsWith("lamp_06") -> "lamp_06"
            rawName.startsWith("lamp_07") -> "lamp_07"
            rawName.startsWith("lamp_08") -> "lamp_08"
            else -> null
        }
    }

    fun definition(id: String?): WorldObjectDefinition? = objects.firstOrNull { it.id == id }
}
