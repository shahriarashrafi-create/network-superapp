package com.liateam.superapp.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

private enum class PathState { DONE, CURRENT, AVAILABLE, LOCKED, FAILED }

private data class PathStep(
    val title: String,
    val subtitle: String,
    val rewardXp: Int,
    val rewardCoin: Int,
    val state: PathState,
    val asset: StageAssetType,
    val unlockCondition: String = "مرحله قبلی را کامل کن",
    val progressText: String? = null,
    val duration: String = "۵ دقیقه"
)

private enum class StageAssetType {
    MINDSET, CONNECTION, INVITE, PRODUCT, FOLLOW_UP, CUSTOMER, TEAM, LEADERSHIP
}

private val pathSteps = listOf(
    PathStep("آشنایی و ذهنیت", "پایه‌های شروع حرفه‌ای", 30, 3, PathState.DONE, StageAssetType.MINDSET, duration = "۸ دقیقه"),
    PathStep("ارتباط‌سازی", "ساخت لیست و شروع گفت‌وگو", 40, 4, PathState.DONE, StageAssetType.CONNECTION, duration = "۱۲ دقیقه"),
    PathStep("دعوت یک نفر", "گفت‌وگوی کوتاه با یک مخاطب جدید", 20, 2, PathState.CURRENT, StageAssetType.INVITE, progressText = "۱ از ۳ زیرکار"),
    PathStep("معرفی محصول", "معرفی ساده و درست محصول", 25, 3, PathState.LOCKED, StageAssetType.PRODUCT, "مرحله دعوت را کامل کن"),
    PathStep("پیگیری حرفه‌ای", "Follow-up با اقدام بعدی روشن", 25, 3, PathState.LOCKED, StageAssetType.FOLLOW_UP, "معرفی محصول را کامل کن"),
    PathStep("اولین مشتری", "ثبت اولین خرید موفق", 40, 5, PathState.LOCKED, StageAssetType.CUSTOMER, "پیگیری حرفه‌ای را کامل کن"),
    PathStep("ساخت تیم", "ثبت عضو و شروع مسیر حمایتی", 50, 6, PathState.LOCKED, StageAssetType.TEAM, "اولین مشتری را ثبت کن"),
    PathStep("تکثیر و رهبری", "کمک به تیم برای تکرار مسیر", 70, 8, PathState.LOCKED, StageAssetType.LEADERSHIP, "ساخت تیم را کامل کن")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onStartCurrent: () -> Unit = {}
) {
    var selected by remember { mutableStateOf<PathStep?>(null) }
    var mapMode by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF9FBFE))
    ) {
        CalmProgressBackground()

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 8.dp,
                // Scaffold already contributes the navigation-bar height; this extra spacing keeps total safe space above 120dp on the target layout.
                bottom = contentPadding.calculateBottomPadding() + 36.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ProgressHeader(onBack) }
            item { ProgressSummary() }
            item { CurrentMissionCard(onStartCurrent) }
            item { ProgressModeSwitch(mapMode = mapMode, onMapMode = { mapMode = it }) }

            if (mapMode) {
                pathSteps.forEachIndexed { index, step ->
                    val previousState = when {
                        index == 0 -> null
                        index == 4 -> PathState.LOCKED // the reward checkpoint sits between 4 and 5
                        else -> pathSteps[index - 1].state
                    }
                    val nextState = when {
                        index == 3 -> PathState.LOCKED // reward checkpoint
                        index == pathSteps.lastIndex -> PathState.LOCKED // final reward
                        else -> pathSteps[index + 1].state
                    }
                    val nextFraction = when {
                        index == 3 || index == pathSteps.lastIndex -> 0.50f
                        else -> stageNodeFraction(index + 1)
                    }

                    item(key = "journey_step_$index") {
                        GameMapStageRow(
                            index = index,
                            step = step,
                            previousState = previousState,
                            nextState = nextState,
                            nextFraction = nextFraction,
                            onClick = { selected = step }
                        )
                    }

                    if (index == 3) {
                        item(key = "mid_reward") {
                            RewardIslandRow(
                                title = "جایزه میانی",
                                subtitle = "+۵۰ سکه • نشان مسیر",
                                nextFraction = stageNodeFraction(4),
                                unlocked = false,
                                final = false
                            )
                        }
                    }
                }

                item(key = "final_reward") {
                    RewardIslandRow(
                        title = "فتح مسیر پایه",
                        subtitle = "+۱۰۰۰ سکه • نشان ویژه • مسیر بعدی",
                        nextFraction = null,
                        unlocked = false,
                        final = true
                    )
                }
            } else {
                pathSteps.forEachIndexed { index, step ->
                    item(key = "list_step_$index") {
                        CompactListStep(
                            index = index,
                            step = step,
                            onClick = { selected = step },
                            onStart = if (step.state == PathState.CURRENT) onStartCurrent else null
                        )
                    }
                }
            }
        }
    }

    selected?.let { step ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
        ) {
            PathStepSheet(
                step = step,
                onClose = { selected = null },
                onStart = {
                    selected = null
                    onStartCurrent()
                }
            )
        }
    }
}

@Composable
private fun CalmProgressBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
            color = SuperColors.Blue.copy(alpha = 0.035f),
            radius = size.width * 0.34f,
            center = Offset(size.width * 0.91f, size.height * 0.12f)
        )
        drawCircle(
            color = SuperColors.Green.copy(alpha = 0.027f),
            radius = size.width * 0.29f,
            center = Offset(size.width * 0.04f, size.height * 0.67f)
        )
    }
}

@Composable
private fun ProgressHeader(onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(54.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("مسیر پیشرفت", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text("مسیر رشدت را مرحله به مرحله فتح کن", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
        }
    }
}

@Composable
private fun ProgressSummary() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 13.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryStat("۳ از ۸", "مرحله فعلی", SuperColors.Blue, Modifier.weight(1f))
                SummaryStat("۳۸٪", "پیشرفت مسیر", SuperColors.Green, Modifier.weight(1f))
                SummaryStat("+۱۸۰", "XP این هفته", SuperColors.Purple, Modifier.weight(1f))
            }
            Spacer(Modifier.height(11.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .background(Color(0xFFE8EEF7), CircleShape)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(0.38f)
                        .height(7.dp)
                        .background(
                            Brush.horizontalGradient(listOf(SuperColors.Sky, SuperColors.Blue)),
                            CircleShape
                        )
                )
            }
        }
    }
}

@Composable
private fun SummaryStat(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Spacer(Modifier.height(2.dp))
        Text(label, color = SuperColors.TextSecondary, fontSize = 7.7.sp, maxLines = 1)
    }
}

@Composable
private fun CurrentMissionCard(onStart: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(21.dp), clip = false)
            .border(1.2.dp, SuperColors.Blue.copy(alpha = 0.42f), RoundedCornerShape(21.dp)),
        shape = RoundedCornerShape(21.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F8FF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                JourneyAsset(
                    asset = StageAssetType.INVITE,
                    state = PathState.CURRENT,
                    number = 3,
                    size = 62.dp
                )
                Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
                    Text("مرحله ۳ از ۸", color = SuperColors.BlueDeep, fontWeight = FontWeight.Black, fontSize = 8.8.sp)
                    Text("دعوت یک نفر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 17.sp)
                    Text("یک گفت‌وگوی کوتاه با یک مخاطب جدید", color = SuperColors.TextSecondary, fontSize = 8.8.sp, maxLines = 1)
                }
                Button(
                    onClick = onStart,
                    modifier = Modifier.height(40.dp),
                    contentPadding = PaddingValues(horizontal = 13.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("ادامه", fontSize = 9.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("۱ از ۳ زیرکار", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 8.4.sp)
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SmallPathChip("+۲۰ XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallPathChip("+۲ سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
                }
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { 0.34f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = Color(0xFFDCE9F8)
            )
        }
    }
}

@Composable
private fun ProgressModeSwitch(mapMode: Boolean, onMapMode: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("مسیر اصلی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))
        Surface(color = Color.White, shape = SuperShapes.Pill, shadowElevation = 1.dp) {
            Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                ModePill("مسیر", selected = mapMode, onClick = { onMapMode(true) })
                ModePill("لیست", selected = !mapMode, onClick = { onMapMode(false) })
            }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        color = if (selected) SuperColors.BlueSoft else Color.Transparent,
        shape = SuperShapes.Pill
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            color = if (selected) SuperColors.Blue else SuperColors.TextSecondary,
            fontSize = 8.8.sp,
            fontWeight = FontWeight.Black
        )
    }
}

private fun stageNodeFraction(index: Int): Float = if (index % 2 == 0) 0.70f else 0.30f

@Composable
private fun GameMapStageRow(
    index: Int,
    step: PathStep,
    previousState: PathState?,
    nextState: PathState?,
    nextFraction: Float,
    onClick: () -> Unit
) {
    val nodeFraction = stageNodeFraction(index)
    val rowHeight = if (step.state == PathState.CURRENT) 132.dp else 116.dp
    val nodeSize = if (step.state == PathState.CURRENT) 74.dp else 66.dp
    val nodeCenterY = if (step.state == PathState.CURRENT) 48.dp else 43.dp

    BoxWithConstraints(
        modifier = Modifier.fillMaxWidth().height(rowHeight)
    ) {
        val nodeLeft = (maxWidth * nodeFraction) - (nodeSize / 2)
        val nodeTop = nodeCenterY - (nodeSize / 2)
        val labelWidth = 132.dp
        val labelX = if (nodeFraction > 0.5f) {
            nodeLeft - labelWidth - 12.dp
        } else {
            nodeLeft + nodeSize + 12.dp
        }
        val labelTop = nodeCenterY - 27.dp

        Canvas(modifier = Modifier.fillMaxSize()) {
            val x = size.width * nodeFraction
            val centerY = nodeCenterY.toPx()

            if (previousState != null) {
                val incoming = Path().apply {
                    moveTo(x, 0f)
                    cubicTo(x, centerY * 0.35f, x, centerY * 0.65f, x, centerY)
                }
                drawMapSegment(
                    path = incoming,
                    from = previousState,
                    to = step.state
                )
            }

            if (index <= pathSteps.lastIndex) {
                val nextX = size.width * nextFraction
                val outgoing = Path().apply {
                    moveTo(x, centerY)
                    cubicTo(
                        x,
                        centerY + (size.height - centerY) * 0.42f,
                        nextX,
                        centerY + (size.height - centerY) * 0.58f,
                        nextX,
                        size.height
                    )
                }
                drawMapSegment(
                    path = outgoing,
                    from = step.state,
                    to = nextState
                )
            }
        }

        JourneyAsset(
            asset = step.asset,
            state = step.state,
            number = index + 1,
            size = nodeSize,
            modifier = Modifier
                .absoluteOffset(x = nodeLeft, y = nodeTop)
                .clickable(onClick = onClick)
        )

        StageMapLabel(
            index = index,
            step = step,
            modifier = Modifier
                .width(labelWidth)
                .absoluteOffset(x = labelX, y = labelTop)
                .clickable(onClick = onClick)
        )
    }
}

private fun DrawScope.drawMapSegment(path: Path, from: PathState?, to: PathState?) {
    val completed = from == PathState.DONE && to == PathState.DONE
    val enteringCurrent = from == PathState.DONE && to == PathState.CURRENT
    val failed = from == PathState.FAILED || to == PathState.FAILED

    val color = when {
        failed -> SuperColors.Red
        completed -> SuperColors.Green
        enteringCurrent -> SuperColors.Blue
        else -> Color(0xFFB9C5D3)
    }
    val dashed = !(completed || enteringCurrent || failed)

    drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = 5.dp.toPx(),
            cap = StrokeCap.Round,
            pathEffect = if (dashed) {
                PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx()))
            } else null
        )
    )
}

@Composable
private fun StageMapLabel(index: Int, step: PathStep, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = if (step.state == PathState.CURRENT) Color(0xFFF5F9FF) else Color.White.copy(alpha = 0.92f),
        shape = RoundedCornerShape(14.dp),
        border = if (step.state == PathState.CURRENT) BorderStroke(1.dp, SuperColors.Blue.copy(alpha = 0.30f)) else null,
        shadowElevation = if (step.state == PathState.CURRENT) 1.5.dp else 0.dp
    ) {
        Column(Modifier.padding(horizontal = 9.dp, vertical = 8.dp)) {
            Text(
                "${toPersianDigits(index + 1)}  ${step.title}",
                color = if (step.state == PathState.LOCKED) Color(0xFF5F6E82) else SuperColors.Navy,
                fontWeight = FontWeight.Black,
                fontSize = 10.3.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                pathLabel(step.state),
                color = pathAccent(step.state),
                fontWeight = FontWeight.Bold,
                fontSize = 7.2.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun JourneyAsset(
    asset: StageAssetType,
    state: PathState,
    number: Int,
    size: Dp,
    modifier: Modifier = Modifier
) {
    val accent = pathAccent(state)
    val outer = when (state) {
        PathState.DONE -> SuperColors.GreenSoft
        PathState.CURRENT -> Color(0xFFDDEEFF)
        PathState.AVAILABLE -> Color(0xFFF2F7FF)
        PathState.FAILED -> SuperColors.RedSoft
        PathState.LOCKED -> Color(0xFFF0F3F7)
    }
    val inner = when (state) {
        PathState.LOCKED -> Color(0xFFD7DEE7)
        PathState.AVAILABLE -> Color.White
        else -> Color.White
    }

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        if (state == PathState.CURRENT) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(SuperColors.Blue.copy(alpha = 0.10f), CircleShape)
                    .border(1.dp, SuperColors.Blue.copy(alpha = 0.16f), CircleShape)
            )
        } else {
            Box(Modifier.fillMaxSize().background(outer, CircleShape))
        }

        Box(
            Modifier
                .size(size * 0.76f)
                .background(inner, CircleShape)
                .border(
                    width = if (state == PathState.CURRENT) 2.dp else 1.dp,
                    color = if (state == PathState.LOCKED) Color(0xFFD0D8E2) else accent.copy(alpha = 0.34f),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (state == PathState.LOCKED) {
                StageAssetDrawing(asset = asset, color = Color(0xFF9AA7B7), modifier = Modifier.size(size * 0.44f))
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .size(size * 0.29f)
                        .background(Color(0xFFA6B1BF), CircleShape)
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.15f))
                }
            } else {
                StageAssetDrawing(asset = asset, color = accent, modifier = Modifier.size(size * 0.44f))
                StatusBadge(state = state, number = number, size = size * 0.29f)
            }
        }
    }
}

@Composable
private fun BoxScope.StatusBadge(state: PathState, number: Int, size: Dp) {
    val badgeColor = when (state) {
        PathState.DONE -> SuperColors.Green
        PathState.CURRENT -> SuperColors.Blue
        PathState.AVAILABLE -> SuperColors.Sky
        PathState.FAILED -> SuperColors.Red
        PathState.LOCKED -> Color(0xFFA6B1BF)
    }
    Box(
        Modifier
            .align(Alignment.BottomEnd)
            .size(size)
            .background(badgeColor, CircleShape)
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        when (state) {
            PathState.DONE -> Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.62f))
            PathState.FAILED -> Icon(Icons.Outlined.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.62f))
            else -> Text(toPersianDigits(number), color = Color.White, fontWeight = FontWeight.Black, fontSize = 7.sp)
        }
    }
}

@Composable
private fun StageAssetDrawing(asset: StageAssetType, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        when (asset) {
            StageAssetType.MINDSET -> drawMindsetAsset(color)
            StageAssetType.CONNECTION -> drawConnectionAsset(color)
            StageAssetType.INVITE -> drawInviteAsset(color)
            StageAssetType.PRODUCT -> drawProductAsset(color)
            StageAssetType.FOLLOW_UP -> drawFollowUpAsset(color)
            StageAssetType.CUSTOMER -> drawCustomerAsset(color)
            StageAssetType.TEAM -> drawTeamAsset(color)
            StageAssetType.LEADERSHIP -> drawLeadershipAsset(color)
        }
    }
}

private fun DrawScope.drawMindsetAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawCircle(color.copy(alpha = 0.13f), radius = w * 0.34f, center = Offset(w * 0.50f, h * 0.43f))
    drawCircle(color, radius = w * 0.25f, center = Offset(w * 0.50f, h * 0.40f), style = Stroke(width = w * 0.09f))
    drawLine(color, Offset(w * 0.39f, h * 0.67f), Offset(w * 0.61f, h * 0.67f), strokeWidth = w * 0.09f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * 0.42f, h * 0.79f), Offset(w * 0.58f, h * 0.79f), strokeWidth = w * 0.075f, cap = StrokeCap.Round)
    drawLine(color.copy(alpha = 0.55f), Offset(w * 0.50f, h * 0.04f), Offset(w * 0.50f, h * 0.14f), strokeWidth = w * 0.055f, cap = StrokeCap.Round)
    drawLine(color.copy(alpha = 0.55f), Offset(w * 0.16f, h * 0.24f), Offset(w * 0.25f, h * 0.29f), strokeWidth = w * 0.055f, cap = StrokeCap.Round)
    drawLine(color.copy(alpha = 0.55f), Offset(w * 0.75f, h * 0.29f), Offset(w * 0.84f, h * 0.24f), strokeWidth = w * 0.055f, cap = StrokeCap.Round)
}

private fun DrawScope.drawConnectionAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawLine(color.copy(alpha = 0.45f), Offset(w * 0.33f, h * 0.43f), Offset(w * 0.67f, h * 0.43f), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
    drawCircle(color, radius = w * 0.15f, center = Offset(w * 0.30f, h * 0.34f))
    drawCircle(color, radius = w * 0.15f, center = Offset(w * 0.70f, h * 0.34f))
    drawArc(color = color, startAngle = 195f, sweepAngle = 150f, useCenter = false, topLeft = Offset(w * 0.10f, h * 0.43f), size = Size(w * 0.40f, h * 0.42f), style = Stroke(width = w * 0.10f, cap = StrokeCap.Round))
    drawArc(color = color, startAngle = 195f, sweepAngle = 150f, useCenter = false, topLeft = Offset(w * 0.50f, h * 0.43f), size = Size(w * 0.40f, h * 0.42f), style = Stroke(width = w * 0.10f, cap = StrokeCap.Round))
}

private fun DrawScope.drawInviteAsset(color: Color) {
    val w = size.width
    val h = size.height
    val plane = Path().apply {
        moveTo(w * 0.10f, h * 0.48f)
        lineTo(w * 0.89f, h * 0.13f)
        lineTo(w * 0.66f, h * 0.87f)
        lineTo(w * 0.48f, h * 0.59f)
        close()
    }
    drawPath(plane, color = color.copy(alpha = 0.16f))
    drawPath(plane, color = color, style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))
    drawLine(color, Offset(w * 0.48f, h * 0.59f), Offset(w * 0.88f, h * 0.14f), strokeWidth = w * 0.06f, cap = StrokeCap.Round)
}

private fun DrawScope.drawProductAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawRoundRect(color.copy(alpha = 0.13f), topLeft = Offset(w * 0.16f, h * 0.29f), size = Size(w * 0.68f, h * 0.56f), cornerRadius = CornerRadius(w * 0.08f))
    drawRoundRect(color = color, topLeft = Offset(w * 0.16f, h * 0.29f), size = Size(w * 0.68f, h * 0.56f), cornerRadius = CornerRadius(w * 0.08f), style = Stroke(width = w * 0.07f))
    drawLine(color, Offset(w * 0.50f, h * 0.30f), Offset(w * 0.50f, h * 0.84f), strokeWidth = w * 0.06f)
    drawLine(color, Offset(w * 0.17f, h * 0.48f), Offset(w * 0.83f, h * 0.48f), strokeWidth = w * 0.06f)
    drawArc(color, 190f, 160f, false, Offset(w * 0.23f, h * 0.08f), Size(w * 0.30f, h * 0.30f), style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))
    drawArc(color, 190f, 160f, false, Offset(w * 0.47f, h * 0.08f), Size(w * 0.30f, h * 0.30f), style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))
}

private fun DrawScope.drawFollowUpAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawArc(color = color, startAngle = 30f, sweepAngle = 285f, useCenter = false, topLeft = Offset(w * 0.15f, h * 0.15f), size = Size(w * 0.70f, h * 0.70f), style = Stroke(width = w * 0.09f, cap = StrokeCap.Round))
    val arrow = Path().apply {
        moveTo(w * 0.75f, h * 0.15f)
        lineTo(w * 0.91f, h * 0.18f)
        lineTo(w * 0.81f, h * 0.31f)
        close()
    }
    drawPath(arrow, color)
    drawCircle(color.copy(alpha = 0.13f), radius = w * 0.12f, center = Offset(w * 0.50f, h * 0.50f))
}

private fun DrawScope.drawCustomerAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawRoundRect(color.copy(alpha = 0.13f), topLeft = Offset(w * 0.20f, h * 0.29f), size = Size(w * 0.60f, h * 0.57f), cornerRadius = CornerRadius(w * 0.08f))
    drawRoundRect(color = color, topLeft = Offset(w * 0.20f, h * 0.29f), size = Size(w * 0.60f, h * 0.57f), cornerRadius = CornerRadius(w * 0.08f), style = Stroke(width = w * 0.07f))
    drawArc(color = color, startAngle = 180f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w * 0.34f, h * 0.13f), size = Size(w * 0.32f, h * 0.34f), style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))
    drawLine(color, Offset(w * 0.38f, h * 0.58f), Offset(w * 0.47f, h * 0.68f), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * 0.47f, h * 0.68f), Offset(w * 0.66f, h * 0.49f), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
}

private fun DrawScope.drawTeamAsset(color: Color) {
    val w = size.width
    val h = size.height
    drawCircle(color, radius = w * 0.13f, center = Offset(w * 0.50f, h * 0.28f))
    drawCircle(color.copy(alpha = 0.88f), radius = w * 0.11f, center = Offset(w * 0.25f, h * 0.39f))
    drawCircle(color.copy(alpha = 0.88f), radius = w * 0.11f, center = Offset(w * 0.75f, h * 0.39f))
    drawArc(color = color, startAngle = 195f, sweepAngle = 150f, useCenter = false, topLeft = Offset(w * 0.28f, h * 0.39f), size = Size(w * 0.44f, h * 0.44f), style = Stroke(width = w * 0.10f, cap = StrokeCap.Round))
    drawArc(color = color.copy(alpha = 0.88f), startAngle = 195f, sweepAngle = 150f, useCenter = false, topLeft = Offset(w * 0.06f, h * 0.49f), size = Size(w * 0.35f, h * 0.34f), style = Stroke(width = w * 0.08f, cap = StrokeCap.Round))
    drawArc(color = color.copy(alpha = 0.88f), startAngle = 195f, sweepAngle = 150f, useCenter = false, topLeft = Offset(w * 0.59f, h * 0.49f), size = Size(w * 0.35f, h * 0.34f), style = Stroke(width = w * 0.08f, cap = StrokeCap.Round))
}

private fun DrawScope.drawLeadershipAsset(color: Color) {
    val w = size.width
    val h = size.height
    val crown = Path().apply {
        moveTo(w * 0.16f, h * 0.67f)
        lineTo(w * 0.10f, h * 0.28f)
        lineTo(w * 0.36f, h * 0.48f)
        lineTo(w * 0.50f, h * 0.17f)
        lineTo(w * 0.64f, h * 0.48f)
        lineTo(w * 0.90f, h * 0.28f)
        lineTo(w * 0.84f, h * 0.67f)
        close()
    }
    drawPath(crown, color.copy(alpha = 0.15f))
    drawPath(crown, color, style = Stroke(width = w * 0.07f, cap = StrokeCap.Round))
    drawRoundRect(color, topLeft = Offset(w * 0.18f, h * 0.70f), size = Size(w * 0.64f, h * 0.12f), cornerRadius = CornerRadius(w * 0.05f))
    repeat(3) { i ->
        drawCircle(Color.White, radius = w * 0.035f, center = Offset(w * (0.36f + i * 0.14f), h * 0.74f))
    }
}

@Composable
private fun RewardIslandRow(
    title: String,
    subtitle: String,
    nextFraction: Float?,
    unlocked: Boolean,
    final: Boolean
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (final) 158.dp else 148.dp)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val centerX = size.width * 0.50f
            val centerY = 54.dp.toPx()
            val gray = Color(0xFFB9C5D3)

            drawLine(
                color = gray,
                start = Offset(centerX, 0f),
                end = Offset(centerX, centerY),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx()))
            )

            if (nextFraction != null) {
                val nextX = size.width * nextFraction
                val outgoing = Path().apply {
                    moveTo(centerX, centerY)
                    cubicTo(centerX, size.height * 0.68f, nextX, size.height * 0.78f, nextX, size.height)
                }
                drawPath(
                    path = outgoing,
                    color = gray,
                    style = Stroke(
                        width = 5.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx()))
                    )
                )
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 13.dp)
                .alpha(if (unlocked) 1f else 0.82f),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(if (final) 86.dp else 78.dp)) {
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(SuperColors.GoldSoft, Color(0xFFFFFAEA)),
                        center = Offset(size.width * 0.50f, size.height * 0.58f),
                        radius = size.width * 0.62f
                    ),
                    topLeft = Offset(size.width * 0.05f, size.height * 0.12f),
                    size = Size(size.width * 0.90f, size.height * 0.76f)
                )
            }
            TreasureAsset(size = if (final) 58.dp else 52.dp, locked = !unlocked)
        }

        Surface(
            modifier = Modifier
                .width(if (final) 230.dp else 190.dp)
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp),
            color = Color.White.copy(alpha = 0.96f),
            shape = RoundedCornerShape(14.dp),
            shadowElevation = 1.dp
        ) {
            Column(
                Modifier.padding(horizontal = 11.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.8.sp)
                Text(subtitle, color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 7.3.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun TreasureAsset(size: Dp, locked: Boolean) {
    val main = if (locked) Color(0xFFD5A13B) else SuperColors.GoldDeep
    val light = if (locked) Color(0xFFFFE7A2) else SuperColors.GoldBright
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(light, main)),
                topLeft = Offset(w * 0.10f, h * 0.39f),
                size = Size(w * 0.80f, h * 0.43f),
                cornerRadius = CornerRadius(w * 0.08f)
            )
            drawArc(
                color = main,
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(w * 0.12f, h * 0.14f),
                size = Size(w * 0.76f, h * 0.50f),
                style = Stroke(width = w * 0.09f, cap = StrokeCap.Round)
            )
            drawLine(Color.White.copy(alpha = 0.85f), Offset(w * 0.13f, h * 0.52f), Offset(w * 0.87f, h * 0.52f), strokeWidth = w * 0.055f)
            drawRoundRect(Color.White.copy(alpha = 0.92f), Offset(w * 0.43f, h * 0.50f), Size(w * 0.14f, h * 0.22f), CornerRadius(w * 0.035f))
        }
        if (locked) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .size(size * 0.33f)
                    .background(Color.White, CircleShape)
                    .border(1.dp, Color(0xFFE2E6EC), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color(0xFF8794A5), modifier = Modifier.size(size * 0.19f))
            }
        }
    }
}

@Composable
private fun CompactListStep(index: Int, step: PathStep, onClick: () -> Unit, onStart: (() -> Unit)?) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = pathBackground(step.state)),
        border = if (step.state == PathState.CURRENT) BorderStroke(1.dp, SuperColors.Blue.copy(alpha = 0.32f)) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 2.dp else 0.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            JourneyAsset(step.asset, step.state, index + 1, 48.dp)
            Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                Text("${toPersianDigits(index + 1)}. ${step.title}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 7.8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (onStart != null) {
                Button(
                    onClick = onStart,
                    modifier = Modifier.height(32.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("ادامه", fontSize = 8.sp, fontWeight = FontWeight.Black) }
            } else {
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun SmallPathChip(text: String, color: Color, background: Color) {
    Box(Modifier.background(background, SuperShapes.Pill).padding(horizontal = 7.dp, vertical = 3.dp)) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 7.2.sp)
    }
}

@Composable
private fun PathStepSheet(step: PathStep, onClose: () -> Unit, onStart: () -> Unit) {
    val index = pathSteps.indexOf(step).coerceAtLeast(0)
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 30.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            JourneyAsset(step.asset, step.state, index + 1, 62.dp)
            Column(Modifier.weight(1f).padding(horizontal = 11.dp)) {
                Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 9.3.sp)
            }
        }

        Spacer(Modifier.height(11.dp))
        Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallPathChip("+${toPersianDigits(step.rewardXp)} XP", SuperColors.Blue, SuperColors.BlueSoft)
            SmallPathChip("+${toPersianDigits(step.rewardCoin)} سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
            SmallPathChip(step.duration, SuperColors.Purple, SuperColors.PurpleSoft)
        }

        if (step.progressText != null) {
            Spacer(Modifier.height(12.dp))
            Text(step.progressText, color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { 0.34f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.BlueSoft
            )
        }

        if (step.state == PathState.LOCKED) {
            Spacer(Modifier.height(12.dp))
            Surface(color = Color(0xFFF5F7FA), shape = RoundedCornerShape(13.dp)) {
                Text(
                    "شرط باز شدن: ${step.unlockCondition}",
                    modifier = Modifier.padding(11.dp),
                    color = SuperColors.TextSecondary,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(Modifier.height(15.dp))
        when (step.state) {
            PathState.CURRENT -> {
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("شروع / ادامه", fontWeight = FontWeight.Black) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction("انجام شد", SuperColors.Green, Modifier.weight(1f), onClose)
                    QuickAction("بعداً", SuperColors.Blue, Modifier.weight(1f), onClose)
                    QuickAction("ناموفق", SuperColors.Red, Modifier.weight(1f), onClose)
                }
            }
            PathState.FAILED -> OutlinedButton(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Outlined.Refresh, contentDescription = null, tint = SuperColors.Red)
                Spacer(Modifier.width(5.dp))
                Text("Reset و تلاش دوباره", color = SuperColors.Red, fontWeight = FontWeight.Bold)
            }
            else -> OutlinedButton(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("بستن", color = SuperColors.Blue, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(11.dp)
    ) {
        Text(
            label,
            modifier = Modifier.padding(vertical = 8.dp),
            color = color,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
    }
}

private fun pathAccent(state: PathState): Color = when (state) {
    PathState.DONE -> SuperColors.Green
    PathState.CURRENT -> SuperColors.Blue
    PathState.AVAILABLE -> SuperColors.Sky
    PathState.LOCKED -> Color(0xFF8B98AA)
    PathState.FAILED -> SuperColors.Red
}

private fun pathBackground(state: PathState): Color = when (state) {
    PathState.DONE -> Color(0xFFF1FBF6)
    PathState.CURRENT -> Color(0xFFF3F8FF)
    PathState.AVAILABLE -> Color.White
    PathState.LOCKED -> Color(0xFFFBFCFE)
    PathState.FAILED -> Color(0xFFFFF3F3)
}

private fun pathLabel(state: PathState): String = when (state) {
    PathState.DONE -> "تکمیل شد"
    PathState.CURRENT -> "مرحله من"
    PathState.AVAILABLE -> "آماده"
    PathState.LOCKED -> "قفل"
    PathState.FAILED -> "ناموفق"
}

private fun toPersianDigits(value: Int): String = value.toString().map { digit ->
    when (digit) {
        '0' -> '۰'
        '1' -> '۱'
        '2' -> '۲'
        '3' -> '۳'
        '4' -> '۴'
        '5' -> '۵'
        '6' -> '۶'
        '7' -> '۷'
        '8' -> '۸'
        '9' -> '۹'
        else -> digit
    }
}.joinToString("")
