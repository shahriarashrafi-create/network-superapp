package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import kotlinx.coroutines.launch

private enum class PathState { DONE, FAILED, CURRENT, LOCKED }

private data class PathStep(
    val title: String,
    val subtitle: String,
    val rewardXp: Int,
    val rewardCoin: Int,
    val state: PathState,
    val unlockCondition: String = "مرحله قبلی را کامل کن",
    val progressText: String? = null,
    val duration: String = "۵ دقیقه",
    val nextTitle: String? = null
)

private val pathSteps = listOf(
    PathStep("آشنایی و ذهنیت", "پایه‌های شروع حرفه‌ای", 30, 3, PathState.DONE, duration = "۸ دقیقه"),
    PathStep("ارتباط‌سازی", "ساخت لیست و شروع گفت‌وگو", 40, 4, PathState.DONE, duration = "۱۲ دقیقه"),
    PathStep("دعوت یک نفر", "گفت‌وگوی کوتاه با یک مخاطب جدید", 20, 2, PathState.CURRENT, progressText = "۱ از ۳ زیرکار", nextTitle = "معرفی محصول"),
    PathStep("معرفی محصول", "معرفی ساده و درست محصول", 25, 3, PathState.LOCKED, "مرحله دعوت را کامل کن", nextTitle = "پیگیری حرفه‌ای"),
    PathStep("پیگیری حرفه‌ای", "Follow-up با اقدام بعدی روشن", 25, 3, PathState.LOCKED, "معرفی محصول را کامل کن"),
    PathStep("اولین مشتری", "ثبت اولین خرید موفق", 40, 5, PathState.LOCKED, "پیگیری حرفه‌ای را کامل کن"),
    PathStep("ساخت تیم", "ثبت عضو و شروع مسیر حمایتی", 50, 6, PathState.LOCKED, "اولین مشتری را ثبت کن"),
    PathStep("تکثیر و رهبری", "کمک به تیم برای تکرار مسیر", 70, 8, PathState.LOCKED, "ساخت تیم را کامل کن")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onStartCurrent: () -> Unit = {}
) {
    var selected by remember { mutableStateOf<PathStep?>(null) }
    var mapMode by remember { mutableStateOf(true) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val currentIndex = pathSteps.indexOfFirst { it.state == PathState.CURRENT }.coerceAtLeast(0)

    // Keep the header visible for early stages; deeper paths auto-position on the active stage.
    LaunchedEffect(Unit) {
        if (currentIndex >= 4) listState.scrollToItem(3 + currentIndex, 18)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7FAFE))
    ) {
        ProgressBackdrop()

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 6.dp,
                bottom = contentPadding.calculateBottomPadding() + 26.dp
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { ProgressHeader(onBack = onBack) }
            item { ProgressSummary() }
            item { ProgressModeSwitch(mapMode = mapMode, onMapMode = { mapMode = it }) }

            if (mapMode) {
                pathSteps.forEachIndexed { index, step ->
                    item(key = "journey_$index") {
                        JourneyStage(
                            index = index,
                            step = step,
                            onClick = { selected = step },
                            onStart = if (step.state == PathState.CURRENT) onStartCurrent else null
                        )
                    }
                    if (index == 3) {
                        item(key = "mid_reward") {
                            RewardMilestone(
                                title = "جایزه میانی",
                                subtitle = "با تکمیل مرحله ۴",
                                reward = "+۵۰ سکه • نشان مسیر",
                                progress = 0.75f,
                                final = false
                            )
                        }
                    }
                }
                item {
                    RewardMilestone(
                        title = "جایزه نهایی",
                        subtitle = "پایان مسیر اصلی",
                        reward = "Badge + Reward + باز شدن مسیر بعدی",
                        progress = 0.38f,
                        final = true
                    )
                }
            } else {
                pathSteps.forEachIndexed { index, step ->
                    item(key = "list_$index") {
                        CompactListStep(
                            index = index,
                            step = step,
                            onClick = { selected = step },
                            onStart = if (step.state == PathState.CURRENT) onStartCurrent else null
                        )
                    }
                }
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(
                    end = SuperDimens.ScreenPadding,
                    bottom = contentPadding.calculateBottomPadding() + 10.dp
                )
                .clickable {
                    scope.launch {
                        // Header + summary + mode switch occupy three list items.
                        listState.animateScrollToItem(3 + currentIndex, 18)
                    }
                },
            color = Color.White.copy(alpha = 0.97f),
            shape = SuperShapes.Pill,
            shadowElevation = 3.dp
        ) {
            Text(
                "مرحله من",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                color = SuperColors.Blue,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp
            )
        }
    }

    selected?.let { step ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
        ) {
            PathStepSheet(
                step = step,
                onClose = { selected = null },
                onStart = {
                    selected = null
                    onStartCurrent()
                }
            )
        }
    }
}

@Composable
private fun ProgressBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val grid = 38.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            drawLine(Color(0xFF7FA8CB).copy(alpha = 0.035f), Offset(x, 0f), Offset(x, size.height), 1f)
            x += grid
        }
        var y = 0f
        while (y <= size.height) {
            drawLine(Color(0xFF7FA8CB).copy(alpha = 0.035f), Offset(0f, y), Offset(size.width, y), 1f)
            y += grid
        }
        drawCircle(Color(0xFF6DB6FF).copy(alpha = 0.055f), size.width * 0.28f, Offset(size.width * 0.95f, size.height * 0.14f))
        drawCircle(Color(0xFF36C995).copy(alpha = 0.04f), size.width * 0.23f, Offset(size.width * 0.05f, size.height * 0.64f))
    }
}

@Composable
private fun ProgressHeader(onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("مسیر پیشرفت", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 23.sp)
            Text("قدم‌ها، وضعیت مسیر و جایزه بعدی", color = SuperColors.TextSecondary, fontSize = 9.3.sp)
        }
    }
}

@Composable
private fun ProgressSummary() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                MiniPathStat("3 / 8", "مرحله", SuperColors.Blue, Modifier.weight(1f))
                MiniPathStat("38٪", "مسیر", SuperColors.Green, Modifier.weight(1f))
                MiniPathStat("+180", "XP هفته", SuperColors.GoldDeep, Modifier.weight(1f))
                MiniPathStat("1", "تا جایزه", SuperColors.Purple, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { 0.38f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = Color(0xFFE3EDF7)
            )
        }
    }
}

@Composable
private fun MiniPathStat(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 12.5.sp)
        Text(label, color = SuperColors.TextSecondary, fontSize = 7.1.sp, maxLines = 1)
    }
}

@Composable
private fun ProgressModeSwitch(mapMode: Boolean, onMapMode: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("مسیر اصلی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 14.5.sp)
        Spacer(Modifier.weight(1f))
        Surface(color = Color.White, shape = SuperShapes.Pill, shadowElevation = 1.dp) {
            Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                ModePill("مسیر", selected = mapMode, onClick = { onMapMode(true) })
                ModePill("لیست", selected = !mapMode, onClick = { onMapMode(false) })
            }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        color = if (selected) SuperColors.BlueSoft else Color.Transparent,
        shape = SuperShapes.Pill
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
            color = if (selected) SuperColors.Blue else SuperColors.TextSecondary,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun JourneyStage(
    index: Int,
    step: PathStep,
    onClick: () -> Unit,
    onStart: (() -> Unit)?
) {
    val cardOnRight = index % 2 == 0
    val height = if (step.state == PathState.CURRENT) 132.dp else 116.dp

    Box(Modifier.fillMaxWidth().height(height)) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val topY = 0f
            val midY = size.height / 2f
            val bottomY = size.height
            val segmentColor = when (step.state) {
                PathState.DONE -> SuperColors.Green
                PathState.CURRENT -> SuperColors.Blue
                PathState.FAILED -> SuperColors.Red
                PathState.LOCKED -> Color(0xFFB7C2CE)
            }
            val dashed = step.state == PathState.LOCKED
            if (index > 0) {
                val topPath = Path().apply {
                    moveTo(cx, topY)
                    lineTo(cx, midY - 23.dp.toPx())
                }
                drawPath(
                    topPath,
                    color = if (step.state == PathState.LOCKED) Color(0xFFB7C2CE) else segmentColor,
                    style = Stroke(
                        width = 5.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx())) else null
                    )
                )
            }
            if (index < pathSteps.lastIndex) {
                val next = pathSteps[index + 1]
                val nextLocked = next.state == PathState.LOCKED
                val bottomPath = Path().apply {
                    moveTo(cx, midY + 23.dp.toPx())
                    lineTo(cx, bottomY)
                }
                drawPath(
                    bottomPath,
                    color = when {
                        step.state == PathState.DONE && next.state == PathState.DONE -> SuperColors.Green
                        step.state == PathState.DONE && next.state == PathState.CURRENT -> SuperColors.Blue
                        step.state == PathState.CURRENT -> SuperColors.Blue
                        else -> Color(0xFFB7C2CE)
                    },
                    style = Stroke(
                        width = 5.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = if (nextLocked) PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx())) else null
                    )
                )
            }

            // Small scenery, intentionally sparse and code-drawn.
            val decoX = if (cardOnRight) size.width * 0.14f else size.width * 0.86f
            drawCircle(pathAccent(step.state).copy(alpha = 0.08f), 18.dp.toPx(), Offset(decoX, midY + 18.dp.toPx()))
            drawCircle(Color.White.copy(alpha = 0.8f), 5.dp.toPx(), Offset(decoX + 15.dp.toPx(), midY - 12.dp.toPx()))
        }

        JourneyStepCard(
            modifier = Modifier
                .align(if (cardOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                .fillMaxWidth(if (step.state == PathState.CURRENT) 0.46f else 0.43f),
            index = index,
            step = step,
            onClick = onClick,
            onStart = onStart
        )

        JourneyNode(
            modifier = Modifier.align(Alignment.Center),
            state = step.state,
            number = index + 1
        )
    }
}

@Composable
private fun JourneyNode(modifier: Modifier, state: PathState, number: Int) {
    val outerColor = when (state) {
        PathState.DONE -> SuperColors.GreenSoft
        PathState.CURRENT -> SuperColors.GoldSoft
        PathState.FAILED -> SuperColors.RedSoft
        PathState.LOCKED -> Color(0xFFE9EEF4)
    }
    val innerColor = when (state) {
        PathState.DONE -> SuperColors.Green
        PathState.CURRENT -> SuperColors.Blue
        PathState.FAILED -> SuperColors.Red
        PathState.LOCKED -> Color(0xFF9EAABA)
    }

    Box(
        modifier = modifier.size(if (state == PathState.CURRENT) 54.dp else 46.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().background(outerColor, CircleShape))
        Box(
            Modifier
                .size(if (state == PathState.CURRENT) 38.dp else 32.dp)
                .background(innerColor, CircleShape)
                .border(2.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                PathState.DONE -> Icon(Icons.Outlined.Check, null, tint = Color.White, modifier = Modifier.size(19.dp))
                PathState.FAILED -> Icon(Icons.Outlined.Close, null, tint = Color.White, modifier = Modifier.size(19.dp))
                PathState.LOCKED -> Icon(Icons.Outlined.Lock, null, tint = Color.White, modifier = Modifier.size(15.dp))
                PathState.CURRENT -> Text(number.toString(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun JourneyStepCard(
    modifier: Modifier,
    index: Int,
    step: PathStep,
    onClick: () -> Unit,
    onStart: (() -> Unit)?
) {
    val accent = pathAccent(step.state)
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .then(
                if (step.state == PathState.CURRENT) Modifier.border(1.4.dp, SuperColors.Blue.copy(alpha = 0.70f), RoundedCornerShape(18.dp))
                else Modifier
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = pathBackground(step.state)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 3.dp else 0.5.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = if (step.state == PathState.CURRENT) 10.dp else 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StageAsset(index = index, state = step.state, assetSize = 32.dp)
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("${index + 1}. ${step.title}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 7.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            if (step.state == PathState.CURRENT && step.progressText != null) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(step.progressText, color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 7.2.sp)
                    Spacer(Modifier.weight(1f))
                    Text(step.duration, color = SuperColors.TextSecondary, fontSize = 7.sp)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { 0.34f },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = Color(0xFFDDEAF7)
                )
            }

            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                    SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallPathChip("+${step.rewardCoin}", SuperColors.GoldDeep, SuperColors.GoldSoft)
                }
                if (onStart != null) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.height(29.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                    ) {
                        Icon(Icons.Outlined.PlayArrow, null, modifier = Modifier.size(13.dp))
                        Text("شروع", fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                    }
                } else {
                    Text(pathLabel(step.state), color = accent, fontWeight = FontWeight.Black, fontSize = 7.2.sp)
                }
            }

            if (step.state == PathState.LOCKED) {
                Spacer(Modifier.height(4.dp))
                Text(step.unlockCondition, color = Color(0xFF95A3B4), fontSize = 6.7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun StageAsset(index: Int, state: PathState, assetSize: androidx.compose.ui.unit.Dp) {
    val accent = when (index % 4) {
        0 -> SuperColors.Green
        1 -> SuperColors.Blue
        2 -> SuperColors.Purple
        else -> SuperColors.Orange
    }
    Box(
        modifier = Modifier
            .size(assetSize)
            .background(pathBackground(state), CircleShape)
            .border(1.dp, accent.copy(alpha = 0.18f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(assetSize * 0.62f)) {
            val c = size.minDimension / 2f
            when (index % 4) {
                0 -> {
                    drawCircle(accent.copy(alpha = 0.18f), c * 0.95f, Offset(c, c))
                    drawCircle(accent, c * 0.42f, Offset(c, c))
                    drawLine(Color.White, Offset(c, c * 0.72f), Offset(c, c * 1.28f), 2.5f, StrokeCap.Round)
                }
                1 -> {
                    drawCircle(accent.copy(alpha = 0.16f), c * 0.95f, Offset(c, c))
                    drawCircle(accent, c * 0.28f, Offset(c * 0.70f, c))
                    drawCircle(accent, c * 0.28f, Offset(c * 1.30f, c))
                    drawLine(accent, Offset(c * 0.92f, c), Offset(c * 1.08f, c), 3f, StrokeCap.Round)
                }
                2 -> {
                    val p = Path().apply {
                        moveTo(c * 0.28f, c * 0.58f)
                        lineTo(c * 1.55f, c * 0.35f)
                        lineTo(c * 1.16f, c * 1.62f)
                        lineTo(c * 0.86f, c * 1.05f)
                        close()
                    }
                    drawPath(p, accent)
                }
                else -> {
                    drawRoundRect(accent, Offset(c * 0.30f, c * 0.58f), Size(c * 1.40f, c * 0.86f), CornerRadius(5f, 5f))
                    drawLine(Color.White, Offset(c * 0.54f, c * 0.88f), Offset(c * 1.48f, c * 0.88f), 2.2f, StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
private fun RewardMilestone(
    title: String,
    subtitle: String,
    reward: String,
    progress: Float,
    final: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (final) Color(0xFFFFF0BC) else Color(0xFFFFF8E1)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (final) 2.dp else 0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (final) Icons.Outlined.Flag else Icons.Outlined.Star, null, tint = SuperColors.GoldDeep, modifier = Modifier.size(24.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.6.sp)
                Text(subtitle, color = SuperColors.TextSecondary, fontSize = 7.7.sp)
                Text(reward, color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 7.7.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color = SuperColors.Gold,
                    trackColor = Color.White
                )
            }
        }
    }
}

@Composable
private fun CompactListStep(index: Int, step: PathStep, onClick: () -> Unit, onStart: (() -> Unit)?) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = pathBackground(step.state)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 2.dp else 0.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            StageAsset(index, step.state, 36.dp)
            Column(Modifier.weight(1f).padding(horizontal = 8.dp), horizontalAlignment = Alignment.End) {
                Text("${index + 1}. ${step.title}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 7.8.sp, maxLines = 1)
            }
            if (onStart != null) {
                Button(
                    onClick = onStart,
                    modifier = Modifier.height(32.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("شروع", fontSize = 8.sp, fontWeight = FontWeight.Black) }
            } else {
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun SmallPathChip(text: String, color: Color, background: Color) {
    Box(Modifier.background(background, SuperShapes.Pill).padding(horizontal = 6.dp, vertical = 3.dp)) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 7.1.sp)
    }
}

@Composable
private fun PathStepSheet(step: PathStep, onClose: () -> Unit, onStart: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            JourneyNode(Modifier, step.state, pathSteps.indexOf(step) + 1)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
            SmallPathChip("+${step.rewardCoin} سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
            SmallPathChip(step.duration, SuperColors.Purple, SuperColors.PurpleSoft)
        }

        if (step.progressText != null) {
            Spacer(Modifier.height(10.dp))
            Text(step.progressText, color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(
                progress = { 0.34f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.BlueSoft
            )
        }

        if (step.state == PathState.LOCKED) {
            Spacer(Modifier.height(10.dp))
            Surface(color = SuperColors.BlueSoft2, shape = RoundedCornerShape(13.dp)) {
                Text("شرط باز شدن: ${step.unlockCondition}", modifier = Modifier.padding(10.dp), color = SuperColors.TextSecondary, fontSize = 9.sp)
            }
        }

        step.nextTitle?.let {
            Spacer(Modifier.height(9.dp))
            Text("بعد از این: $it", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
        }

        Spacer(Modifier.height(13.dp))
        when (step.state) {
            PathState.CURRENT -> {
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth().height(43.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("شروع / ادامه", fontWeight = FontWeight.Black) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction("انجام شد", SuperColors.Green, Modifier.weight(1f), onClose)
                    QuickAction("بعداً", SuperColors.Blue, Modifier.weight(1f), onClose)
                    QuickAction("ناموفق", SuperColors.Red, Modifier.weight(1f), onClose)
                }
            }
            PathState.FAILED -> OutlinedButton(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth().height(43.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Outlined.Refresh, null, tint = SuperColors.Red)
                Spacer(Modifier.width(5.dp))
                Text("Reset و تلاش دوباره", color = SuperColors.Red, fontWeight = FontWeight.Bold)
            }
            else -> OutlinedButton(
                onClick = onClose,
                modifier = Modifier.fillMaxWidth().height(43.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("بستن", color = SuperColors.Blue, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun QuickAction(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(11.dp)
    ) {
        Text(label, modifier = Modifier.padding(vertical = 8.dp), color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
    }
}

private fun pathAccent(state: PathState): Color = when (state) {
    PathState.DONE -> SuperColors.Green
    PathState.FAILED -> SuperColors.Red
    PathState.CURRENT -> SuperColors.Blue
    PathState.LOCKED -> Color(0xFF97A4B3)
}

private fun pathBackground(state: PathState): Color = when (state) {
    PathState.DONE -> Color(0xFFF0FBF6)
    PathState.FAILED -> Color(0xFFFFF2F2)
    PathState.CURRENT -> Color(0xFFF1F8FF)
    PathState.LOCKED -> Color.White.copy(alpha = 0.94f)
}

private fun pathLabel(state: PathState): String = when (state) {
    PathState.DONE -> "تکمیل شد"
    PathState.FAILED -> "ناموفق"
    PathState.CURRENT -> "مرحله فعال"
    PathState.LOCKED -> "قفل"
}
