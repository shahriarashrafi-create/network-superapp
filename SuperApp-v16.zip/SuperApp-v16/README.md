# SuperApp v12

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## v12 focus
- Home Next Action opens a real task flow.
- Task details with subtasks, CRM deep-link entry, time presets and rewards.
- Full-screen Focus Mode with countdown, pause, optional music affordance and finish flow.
- Result sheet: Done / Later / Fail.
- Completion state with XP, Coin and Combo feedback, then Next Action.
- Progress Path redesigned as a vertical zigzag-like staged journey with stats, Done/Fail/Current/Locked states, rewards and step details.
- Current path step can launch directly into the task flow.
- Existing Home, Profile, Notifications, Level, Coin, Combo, Wallet, Reward Store and 30-link pager are retained.
- UI remains code/vector/canvas based; no decorative bitmap background is used.

Application ID and signing configuration are intentionally preserved for in-place APK updates.

## v2.3.0 / Build 15
- Home redesigned as a spacious gamified hub: compact mission card + adjacent reward chest widget.
- Six shortcut cards replaced by minimal orb launchers while retaining 30 destinations across five pages.
- Stronger Blue/Navy/Gold contrast, slim status strip, code-only Canvas/Vector assets, and no decorative bitmap backgrounds.


## Build 15
- Home gamified journey path rendered entirely with Compose Canvas.
- Shortcut hub tightened and anchored closer to bottom navigation.
- No bitmap/photo decorative assets added.


## v2.3.0 / Build 15
- Home polish: حذف 48٪، XP یکپارچه، مسیر Home جمع‌وجورتر، Shortcutهای فشرده‌تر و نزدیک‌تر به Bottom Nav.
- Progress Path rebuilt as a gamified zigzag journey with state-colored route, current node, locked nodes, milestones, rewards, map/list modes and step bottom sheets.
- All decorative visuals remain Compose/Canvas/Vector based; no raster background image was added.

## v16 - Progress Journey rebuild
- Rebuilt Progress Path from scratch as a clean game-map journey.
- Added custom code-drawn stage assets for all eight stages.
- Replaced oversized map cards with compact stage labels + tappable asset nodes.
- Fixed path continuity between rows and checkpoint transitions.
- Added distinct completed/current/available/locked/failed visual states.
- Added mid-path treasure checkpoint and Persian final reward checkpoint.
- Simplified summary to current stage / route progress / weekly XP.
- Removed next-step explanatory text from the current mission card and details.
- Preserved Map/List views with a cleaner compact list.
- Added extra bottom safe area so journey content never sits under bottom navigation.
- Preserved applicationId and existing signing key/config so this build can update the previous installed app.
