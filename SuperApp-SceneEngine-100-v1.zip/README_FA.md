# Super App Scene Engine 100

پروژه جدید مسیر پیشرفت گیمیفای‌شده، از صفر و بدون هیچ بک‌گراند تصویری بزرگ طراحی شده است.

## ایده اصلی
کل محیط بازی با کد و داده ساخته می‌شود:

`Terrain → Path → Walls → Buildings → Objects → Trees → Effects → Fog → UI`

هیچ فایل PNG/JPG/WebP/SVG برای Scene استفاده نشده است. Regionها از Data + Asset Definition + Renderer تشکیل می‌شوند.

## چیزهایی که در این نسخه پیاده‌سازی شده
- Scene Engine دوبعدی/2.5D کدمحور
- 100 Region آماده و Data-Driven
- 500 مأموریت پیش‌فرض
- 15 Region Template
- 103 Asset Variant مشترک
- Assetهای قابل استفاده مجدد: درخت، نیمکت، بوته، فواره، چراغ، نرده، دروازه، استخر، مسیر، ساختمان، پل، آبشار، آلاچیق، میز، صندلی
- State برای Objectها: خام / معمولی / کامل / Premium
- تغییر State بعد از تکمیل مأموریت
- Depth sorting و Z-order
- Shadow و Highlight
- Camera Engine با Overview / Travel / Focus / Result / Next
- Pan و Pinch Zoom
- Focus روی Object مأموریت
- Fog کدمحور با Gradient و Cloud Blobs و Reveal تدریجی
- Atmosphere روز/شب
- Glow / Vignette-like focus / Light pulse
- Particle System
- Sparkle / Dust / Leaf / Splash / Reward / Coin Fly / XP Fly
- Water animation برای Fountain/Pool/Waterfall
- HUD کوچک و شناور
- Mission FAB کوچک پایین صفحه
- Mission Bar یک‌خطی
- Level / XP / Coin
- Reward بر اساس اهمیت Low / Medium / High
- Region Unlock
- World Overview برای 100 Region
- Mission Manager کامل
- World Builder داخلی
- افزودن/حذف/جابه‌جایی/Scale/State Object در Builder
- تغییر Template و Theme هر Region
- ذخیره Region سفارشی به JSON در Local Storage
- ذخیره XP، Coin، Level، Mission، Region و Object State
- Landscape + Fullscreen Immersive
- Culling برای Objectهای خارج View
- جداسازی Data / Storage / Renderer / UI / App Logic
- Stable signing key داخل پروژه برای نسخه‌های بعدی همین پایه

## فایل‌های Data
- `app/src/main/assets/data/regions.json` — 100 Region
- `app/src/main/assets/data/asset-catalog.json` — 103 Asset Variant
- `app/src/main/assets/data/templates.json` — 15 Template
- `app/src/main/assets/data/themes.json` — Themeها

## ساختار کد
- `js/gameData.js` — Asset Catalog، Templateها، Themeها، 100 Region
- `js/storage.js` — ذخیره‌سازی
- `js/sceneEngine.js` — Renderer، Camera، Fog، Asset Drawing، Particles
- `js/ui.js` — HUD، نوار مأموریت و UI helperها
- `js/app.js` — Progression، Mission، Region Unlock، Manager و World Builder

## Build با Workflow قبلی
فایل ZIP را مستقیم در Root Repository قرار بده.
Workflow قبلی شما ZIP را استخراج می‌کند، `settings.gradle` را پیدا می‌کند و با دستور زیر Build می‌کند:

`./gradlew assembleDebug`

نیاز به تغییر Workflow نیست.

## Signing
برای اینکه نسخه‌های بعدی که بر پایه همین پروژه ساخته می‌شوند قابلیت Update داشته باشند، کلید ثابت در مسیر زیر قرار گرفته:

`keystore/superapp.jks`

Signing config در `app/build.gradle` اعمال شده است. برای نسخه‌های بعدی همین فایل Keystore باید بدون تغییر حفظ شود.

## نکته مهم
این نسخه عمداً هیچ Scene Image ندارد. کیفیت ظاهری از Renderer، Assetهای کدمحور، State، نور، انیمیشن، Fog و Camera ساخته می‌شود؛ بنابراین افزایش Region از 5 به 100 یا بیشتر، وابسته به اضافه‌کردن عکس بزرگ جدید نیست.
