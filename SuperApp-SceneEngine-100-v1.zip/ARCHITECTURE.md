# Architecture

## Scene
هر Region شامل:
- themeId
- templateId
- terrain
- paths
- walls / water / indoor flags
- objects[]
- missions[]

هر Object شامل:
- id
- type
- variant
- x / y / z
- scale
- state
- missionStep

## Asset model
Assetها به‌صورت Drawing Function کدمحور هستند. یک Type می‌تواند Variantهای متعدد داشته باشد و همه Regionها همان Definition را reuse می‌کنند.

## Camera
- Overview
- Region Scene
- Focus Object
- Result Pull-back
- Region Complete Pull-back
- Next Region Travel

## Progression
Mission Complete:
1. ذخیره Done
2. تغییر Object State
3. Particle Effect
4. Coin Fly / XP Fly
5. Fog Reveal
6. Camera Pull-back
7. در صورت تکمیل Region: Unlock Region بعدی

## Scalability
World Overview برای 100 Region آماده است و معماری Region بر اساس Data است، نه تصویر. Regionهای بیشتر نیز با همان Schema قابل اضافه شدن هستند.
