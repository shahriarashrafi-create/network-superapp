(function(){
'use strict';
const $=id=>document.getElementById(String(id).replace(/^#/,''));
const fa=n=>Number(n||0).toLocaleString('fa-IR');
const importanceText=v=>v==='high'?'بالا':v==='low'?'کم':'متوسط';
let toastTimer=null;
const UI={
  $,fa,importanceText,
  setHud(progress,totalMissions,completedMissions){const per=500,level=Math.floor(progress.totalXp/per)+1,cur=progress.totalXp%per,pct=cur/per*100;$('#levelLabel').textContent=`سطح ${fa(level)}`;$('#xpLabel').textContent=`${fa(cur)} / ${fa(per)} XP`;$('#xpBar').style.width=`${pct}%`;$('#coinLabel').textContent=fa(progress.coins);$('#totalXpLabel').textContent=fa(progress.totalXp);$('#worldProgressLabel').textContent=`${fa(Math.round(completedMissions/Math.max(1,totalMissions)*100))}٪`;},
  setRegion(region){$('#regionTitle').textContent=`منطقه ${fa(region.id)}`;$('#regionSubtitle').textContent=region.subtitle||region.templateId;},
  setMission(mission,region,started){if(!mission){$('#missionFab').textContent='✓';$('#missionActionBtn').disabled=true;$('#missionTitle').textContent='این مسیر کامل شد';$('#missionMeta').textContent='همه مأموریت‌ها انجام شده‌اند';$('#rewardCoins').textContent='+۰';$('#rewardXp').textContent='+۰';$('#regionProgressBar').style.width='100%';$('#regionProgressLabel').textContent='کامل';return;}$('#missionFab').disabled=false;$('#missionFab').textContent=started?'✓':'▶';$('#missionTitle').textContent=mission.title;const obj=region.objects.find(o=>o.id===mission.targetId);$('#missionMeta').textContent=`اهمیت ${importanceText(mission.importance)} · ${(GameData.assetLabels[obj?.type]||obj?.type||'هدف')}`;$('#rewardCoins').textContent=`+${fa(mission.coins)}`;$('#rewardXp').textContent=`+${fa(mission.xp)}`;const done=region.missions.filter(m=>m.completed).length;$('#regionProgressBar').style.width=`${done/Math.max(1,region.missions.length)*100}%`;$('#regionProgressLabel').textContent=`${fa(done)} / ${fa(region.missions.length)}`;$('#missionActionBtn').disabled=false;$('#missionActionBtn').textContent=started?'انجام شد ✓':'شروع مأموریت';},
  toggleMissionStrip(open){$('#missionStrip').classList.toggle('collapsed',!open);$('#missionFab').classList.toggle('active',open);},
  showToast(text){const el=$('#toast');el.textContent=text;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),1800);},
  showReward(coins,xp){const el=$('#rewardBurst');el.innerHTML=`<span class="coin-dot">●</span> +${fa(coins)} &nbsp;&nbsp; <span class="xp-star">★</span> +${fa(xp)}`;el.classList.remove('show');void el.offsetWidth;el.classList.add('show');},
  openScreen(id){for(const s of document.querySelectorAll('.screen'))s.classList.remove('active');$(id).classList.add('active');},
  openGame(){this.openScreen('#gameRoot');},
  openModal(id){$(id).classList.remove('hidden');},closeModal(id){$(id).classList.add('hidden');},
  chipCenter(id){const r=$(id).getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2};}
};
window.GameUI=UI;
})();
