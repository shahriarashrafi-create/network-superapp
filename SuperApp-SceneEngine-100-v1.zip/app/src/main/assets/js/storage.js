(function(){
  'use strict';
  const KEYS={progress:'scene100.progress.v1',missions:'scene100.missions.v1',overrides:'scene100.overrides.v1',settings:'scene100.settings.v1'};
  const memoryStore={};
  function read(key,fallback){
    try{const raw=localStorage.getItem(key);if(raw!=null){const v=JSON.parse(raw);return v==null?fallback:v;}}
    catch(e){}
    try{return memoryStore[key]!=null?JSON.parse(memoryStore[key]):fallback}catch(e){return fallback}
  }
  function write(key,value){const raw=JSON.stringify(value);memoryStore[key]=raw;try{localStorage.setItem(key,raw)}catch(e){}}
  function remove(key){delete memoryStore[key];try{localStorage.removeItem(key)}catch(e){}}
  const StorageSystem={
    loadProgress(){return read(KEYS.progress,{coins:0,totalXp:0,currentRegion:1,startedMissionId:'',completed:{},objectStates:{}})},
    saveProgress(v){write(KEYS.progress,v)},
    loadMissionOverrides(){return read(KEYS.missions,{})},
    saveMissionOverrides(v){write(KEYS.missions,v)},
    loadRegionOverrides(){return read(KEYS.overrides,{})},
    saveRegionOverrides(v){write(KEYS.overrides,v)},
    loadSettings(){return read(KEYS.settings,{atmosphere:'day'})},
    saveSettings(v){write(KEYS.settings,v)},
    resetProgress(){remove(KEYS.progress)},
    resetAll(){Object.values(KEYS).forEach(remove)}
  };
  window.StorageSystem=StorageSystem;
})();
