(function(){
  'use strict';

  function mulberry32(seed){return function(){let t=seed+=0x6D2B79F5;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;}}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

  const assetCounts={tree:12,bench:8,plant:10,fountain:6,lamp:8,fence:6,gate:5,pool:6,path:8,building:10,bridge:4,waterfall:4,gazebo:5,table:5,chair:6};
  const assetLabels={tree:'درخت',bench:'نیمکت',plant:'گل و بوته',fountain:'فواره',lamp:'چراغ',fence:'نرده',gate:'دروازه',pool:'استخر',path:'مسیر',building:'ساختمان',bridge:'پل',waterfall:'آبشار',gazebo:'آلاچیق',table:'میز',chair:'صندلی'};
  const assetCatalog=[];
  Object.keys(assetCounts).forEach(type=>{
    for(let i=1;i<=assetCounts[type];i++) assetCatalog.push({id:`${type}_${String(i).padStart(2,'0')}`,type,variant:i,label:`${assetLabels[type]} ${i}`});
  });

  const themes=[
    {id:'royal_garden',name:'باغ سلطنتی',sky:'#bfe8ff',ground:'#6ebd67',ground2:'#4f9d55',stone:'#d9d0bd',accent:'#53bdf7',roof:'#335d78',wall:'#f0eadb',night:'#162844'},
    {id:'mediterranean',name:'مدیترانه‌ای',sky:'#c9eeff',ground:'#80be6c',ground2:'#61a65a',stone:'#e9d7bb',accent:'#54c1e9',roof:'#9a5f43',wall:'#fff0d4',night:'#20314f'},
    {id:'modern_lux',name:'مدرن لوکس',sky:'#d1f0ff',ground:'#78b884',ground2:'#5a9a70',stone:'#d7dde2',accent:'#48badf',roof:'#3b4652',wall:'#f0f3f4',night:'#162432'},
    {id:'forest_retreat',name:'اقامتگاه جنگلی',sky:'#c8e7db',ground:'#5fa45f',ground2:'#3f804d',stone:'#c7c0a7',accent:'#68b7ca',roof:'#5b4b3d',wall:'#e9dfc4',night:'#15271f'},
    {id:'water_palace',name:'قصر آبی',sky:'#c6edff',ground:'#77bda0',ground2:'#559985',stone:'#d7d5cc',accent:'#48c4f5',roof:'#496e86',wall:'#eef7f9',night:'#173447'},
    {id:'sunset_resort',name:'ریزورت غروب',sky:'#ffd8b0',ground:'#88b96c',ground2:'#678f54',stone:'#e5c7aa',accent:'#57b9d5',roof:'#8c5d47',wall:'#f7e2c8',night:'#34223d'},
    {id:'white_estate',name:'عمارت سفید',sky:'#d9f3ff',ground:'#7dbb73',ground2:'#5c9858',stone:'#e6e2da',accent:'#55bee8',roof:'#587087',wall:'#ffffff',night:'#1a2940'},
    {id:'beach_club',name:'کلاب ساحلی',sky:'#bfeaff',ground:'#8fc590',ground2:'#72aa79',stone:'#e8d3ae',accent:'#2ec8e9',roof:'#5c7b88',wall:'#f8f3e8',night:'#173448'}
  ];

  const templateNames=['Courtyard','Fountain Square','Garden','Pool','Mansion Entrance','Terrace','Lake','Waterfall','Forest','Luxury Lounge','Interior Hall','Office','Sport Area','Rooftop','Beach'];
  const templateFa=['حیاط مرکزی','میدان آب‌نما','باغ','استخر','ورودی عمارت','تراس','دریاچه','آبشار','جنگل','لانژ لوکس','سالن داخلی','دفتر کار','فضای ورزشی','روف‌تاپ','ساحل'];

  function o(id,type,variant,x,y,scale=1,state=0,z=0,missionStep=0,extra={}){
    return {id,type,variant,x,y,scale,state,z,missionStep,...extra};
  }

  const makers={
    'Courtyard':(r)=>({
      terrain:'grass',paths:[{style:1,points:[[80,600],[260,470],[500,350],[760,250],[930,120]],width:78}],walls:true,
      objects:[o('target1','gate',1,120,565,1.22,0,0,1),o('target2','fountain',2,470,355,1.05,0,0,2),o('target3','bench',1,330,430,.9,0,0,3),o('target4','lamp',3,690,280,.95,0,0,4),o('target5','building',2,840,150,1.15,0,0,5),o('tree1','tree',2,230,210,.95),o('tree2','tree',4,730,140,.9),o('plant1','plant',3,390,320,.8),o('plant2','plant',6,610,270,.8)]}),
    'Fountain Square':(r)=>({
      terrain:'stone',paths:[{style:3,points:[[90,570],[330,440],[500,350],[690,250],[900,130]],width:90}],walls:true,
      objects:[o('target1','fountain',3,500,350,1.2,0,0,1),o('target2','bench',4,350,400,.92,0,0,2),o('target3','bench',4,650,300,.92,0,0,3),o('target4','lamp',5,480,210,.95,0,0,4),o('target5','gazebo',2,810,190,1.05,0,0,5),o('tree1','tree',5,210,260,.85),o('tree2','tree',5,760,110,.85),o('plant1','plant',4,270,330,.72),o('plant2','plant',8,720,260,.72)]}),
    'Garden':(r)=>({
      terrain:'grass',paths:[{style:2,points:[[110,590],[240,470],[410,420],[560,300],[810,190],[930,110]],width:60}],walls:false,
      objects:[o('target1','bench',2,280,410,.95,0,0,1),o('target2','tree',7,420,310,1.05,0,0,2),o('target3','fountain',1,590,300,.88,0,0,3),o('target4','gazebo',4,770,190,1.05,0,0,4),o('target5','plant',10,540,210,1.12,0,0,5),o('tree1','tree',1,160,200,.88),o('tree2','tree',9,830,350,.86),o('plant1','plant',2,330,250,.78),o('plant2','plant',7,690,370,.8),o('lamp1','lamp',2,500,420,.82)]}),
    'Pool':(r)=>({
      terrain:'tile',paths:[{style:5,points:[[90,580],[250,500],[500,430],[780,300],[930,180]],width:72}],walls:true,
      objects:[o('target1','pool',2,500,335,1.28,0,0,1),o('target2','chair',2,340,310,.95,0,0,2),o('target3','chair',4,665,285,.95,0,0,3),o('target4','lamp',7,720,180,.9,0,0,4),o('target5','gazebo',5,825,140,1.08,0,0,5),o('plant1','plant',5,230,330,.8),o('plant2','plant',6,760,420,.8),o('tree1','tree',10,180,200,.85),o('table1','table',3,640,425,.9)]}),
    'Mansion Entrance':(r)=>({
      terrain:'grass',paths:[{style:6,points:[[80,600],[250,500],[500,385],[720,270],[915,150]],width:88}],walls:true,
      objects:[o('target1','gate',4,150,550,1.22,0,0,1),o('target2','lamp',2,330,455,1,0,0,2),o('target3','fountain',5,510,365,1.0,0,0,3),o('target4','plant',4,690,255,.95,0,0,4),o('target5','building',6,850,135,1.22,0,0,5),o('tree1','tree',3,240,230,.9),o('tree2','tree',8,720,110,.86),o('fence1','fence',1,410,300,1),o('bench1','bench',3,580,270,.8)]}),
    'Terrace':(r)=>({
      terrain:'stone',paths:[{style:4,points:[[110,570],[300,450],[490,370],[700,270],[900,160]],width:72}],walls:true,
      objects:[o('target1','table',4,380,390,1,0,0,1),o('target2','chair',5,300,420,.9,0,0,2),o('target3','plant',9,560,320,.9,0,0,3),o('target4','lamp',6,690,230,.95,0,0,4),o('target5','gazebo',3,830,170,1.08,0,0,5),o('bench1','bench',7,620,390,.86),o('tree1','tree',11,190,240,.85),o('plant2','plant',2,760,320,.76)]}),
    'Lake':(r)=>({
      terrain:'grass',water:true,paths:[{style:2,points:[[80,600],[220,490],[380,430],[620,250],[900,140]],width:55}],walls:false,
      objects:[o('target1','bridge',1,430,370,1.15,0,0,1),o('target2','bench',5,260,390,.9,0,0,2),o('target3','lamp',1,590,250,.95,0,0,3),o('target4','tree',12,740,220,1.02,0,0,4),o('target5','gazebo',1,850,150,1.04,0,0,5),o('tree1','tree',4,180,220,.88),o('plant1','plant',8,650,400,.8),o('fountain1','fountain',6,510,320,.75)]}),
    'Waterfall':(r)=>({
      terrain:'rock',water:true,paths:[{style:7,points:[[90,590],[230,500],[380,420],[560,330],[780,220],[910,130]],width:58}],walls:false,
      objects:[o('target1','waterfall',2,700,190,1.18,0,0,1),o('target2','bridge',3,510,330,1.05,0,0,2),o('target3','bench',6,310,420,.9,0,0,3),o('target4','lamp',8,620,280,.9,0,0,4),o('target5','gazebo',2,820,150,1.02,0,0,5),o('tree1','tree',6,180,250,.9),o('tree2','tree',9,760,320,.9),o('plant1','plant',3,450,240,.76)]}),
    'Forest':(r)=>({
      terrain:'forest',paths:[{style:1,points:[[80,600],[200,510],[360,430],[550,330],[740,250],[910,150]],width:48}],walls:false,
      objects:[o('target1','tree',8,250,370,1.12,0,0,1),o('target2','bench',8,390,400,.92,0,0,2),o('target3','lamp',4,540,315,.9,0,0,3),o('target4','bridge',2,690,250,1.02,0,0,4),o('target5','gazebo',4,835,155,1.02,0,0,5),o('tree1','tree',1,140,220,.95),o('tree2','tree',2,470,180,.92),o('tree3','tree',3,760,360,.9),o('plant1','plant',6,580,430,.72)]}),
    'Luxury Lounge':(r)=>({
      terrain:'tile',paths:[{style:8,points:[[120,570],[320,450],[510,370],[700,270],[890,170]],width:74}],walls:true,
      objects:[o('target1','table',2,400,390,1.05,0,0,1),o('target2','chair',6,320,420,.92,0,0,2),o('target3','fountain',4,560,315,.85,0,0,3),o('target4','lamp',5,690,240,.96,0,0,4),o('target5','building',9,840,145,1.12,0,0,5),o('plant1','plant',10,250,300,.84),o('bench1','bench',2,630,390,.9),o('gazebo1','gazebo',5,760,270,.85)]}),
    'Interior Hall':(r)=>({
      terrain:'interior',paths:[{style:5,points:[[120,560],[310,455],[500,360],[700,250],[890,160]],width:82}],walls:true,indoor:true,
      objects:[o('target1','table',5,380,390,1,0,0,1),o('target2','chair',3,300,420,.9,0,0,2),o('target3','plant',1,540,315,.9,0,0,3),o('target4','lamp',8,690,240,.92,0,0,4),o('target5','building',10,830,150,1.12,0,0,5),o('bench1','bench',5,600,390,.88),o('plant2','plant',5,740,330,.8)]}),
    'Office':(r)=>({
      terrain:'interior',paths:[{style:4,points:[[140,560],[330,450],[500,360],[680,260],[870,160]],width:70}],walls:true,indoor:true,
      objects:[o('target1','table',1,420,390,1.08,0,0,1),o('target2','chair',1,330,420,.92,0,0,2),o('target3','plant',7,570,320,.88,0,0,3),o('target4','lamp',3,690,235,.9,0,0,4),o('target5','building',7,835,145,1.1,0,0,5),o('bench1','bench',6,620,390,.84),o('plant2','plant',9,250,310,.78)]}),
    'Sport Area':(r)=>({
      terrain:'sport',paths:[{style:6,points:[[90,590],[250,500],[430,410],[620,310],[820,210],[930,140]],width:66}],walls:true,
      objects:[o('target1','bench',3,280,420,.92,0,0,1),o('target2','lamp',6,430,345,.95,0,0,2),o('target3','fence',4,580,300,1.02,0,0,3),o('target4','plant',4,700,240,.9,0,0,4),o('target5','building',4,840,150,1.05,0,0,5),o('tree1','tree',6,170,230,.86),o('tree2','tree',10,780,350,.86)]}),
    'Rooftop':(r)=>({
      terrain:'rooftop',paths:[{style:8,points:[[120,560],[310,455],[500,360],[690,260],[870,165]],width:72}],walls:true,
      objects:[o('target1','table',3,380,390,1,0,0,1),o('target2','chair',2,300,420,.9,0,0,2),o('target3','plant',2,550,320,.92,0,0,3),o('target4','lamp',7,690,235,.95,0,0,4),o('target5','pool',5,810,170,1.02,0,0,5),o('gazebo1','gazebo',1,700,390,.86),o('plant2','plant',8,240,300,.78)]}),
    'Beach':(r)=>({
      terrain:'sand',water:true,paths:[{style:2,points:[[80,600],[220,500],[390,420],[570,320],[760,230],[920,140]],width:56}],walls:false,
      objects:[o('target1','chair',4,270,420,.98,0,0,1),o('target2','table',2,390,390,.95,0,0,2),o('target3','plant',5,540,315,.9,0,0,3),o('target4','lamp',2,680,240,.92,0,0,4),o('target5','gazebo',5,830,160,1.08,0,0,5),o('tree1','tree',12,180,230,.94),o('pool1','pool',6,680,380,.8)]})
  };

  const missionTitleBank=[
    ['شروع ارتباط‌سازی','ساخت لیست اولیه','پیگیری مخاطب‌ها','دعوت هدفمند','ثبت نتیجه روز'],
    ['گسترش ارتباط‌ها','تمرین معرفی کوتاه','پیگیری حرفه‌ای','ثبت اقدام بعدی','جمع‌بندی روز'],
    ['شناخت نیاز','معرفی ارزش','پاسخ به سؤال‌ها','پیگیری تصمیم','ثبت بازخورد'],
    ['همراهی عضو جدید','آموزش کوتاه','پیگیری تیمی','تکثیر عادت','هدف هفته'],
    ['برنامه رهبری','کوچینگ یک نفر','جلسه جمع‌بندی','بهبود سیستم','ثبت نقطه عطف']
  ];
  const importanceCycle=['medium','low','medium','high','medium'];
  const rewardPreset={low:{coins:40,xp:80},medium:{coins:60,xp:120},high:{coins:90,xp:180}};

  function clone(v){return JSON.parse(JSON.stringify(v));}
  function varyObject(obj,rng){
    const n=clone(obj); n.x=clamp(n.x+(rng()-.5)*34,50,950); n.y=clamp(n.y+(rng()-.5)*26,50,650); n.scale=clamp(n.scale*(.92+rng()*.16),.55,1.45); if(!String(n.id).startsWith('target')) n.variant=1+Math.floor(rng()*assetCounts[n.type]); return n;
  }

  function buildRegion(index){
    const tIndex=(index-1)%templateNames.length;
    const templateId=templateNames[tIndex];
    const rng=mulberry32(1187+index*977);
    const base=makers[templateId](rng);
    const theme=themes[(index-1)%themes.length];
    const objects=base.objects.map(x=>varyObject(x,rng));
    const titles=missionTitleBank[(index-1)%missionTitleBank.length];
    const missions=[1,2,3,4,5].map(step=>{
      const imp=importanceCycle[step-1],rw=rewardPreset[imp];
      return {id:`r${index}m${step}`,region:index,step,title:titles[step-1],description:`قدم ${step} از مسیر منطقه ${index} را انجام بده و تغییر محیط را ببین.`,importance:imp,coins:rw.coins+Math.floor((index-1)/10)*5,xp:rw.xp+Math.floor((index-1)/10)*10,targetId:`target${step}`,targetState:Math.min(3,step<3?2:3),completed:false};
    });
    return {id:index,name:`منطقه ${index}`,subtitle:templateFa[tIndex],templateId,themeId:theme.id,terrain:base.terrain,water:!!base.water,indoor:!!base.indoor,walls:!!base.walls,paths:clone(base.paths||[]),objects,missions};
  }

  const regions=Array.from({length:100},(_,i)=>buildRegion(i+1));

  window.GameData={assetCounts,assetLabels,assetCatalog,themes,templateNames,templateFa,makers,regions,rewardPreset,buildRegion,clone,mulberry32};
})();
