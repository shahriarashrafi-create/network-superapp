(function(){
'use strict';
const U=GameUI,$=U.$;
const deep=GameData.clone;

let progress=StorageSystem.loadProgress();
let missionOverrides=StorageSystem.loadMissionOverrides();
let regionOverrides=StorageSystem.loadRegionOverrides();
let settings=StorageSystem.loadSettings();
let regions=GameData.regions.map(deep);
let viewRegionId=progress.currentRegion||1;
let missionPanelOpen=false;
let builderEngine=null,builderWorking=null,builderSelectedId=null;

function applyOverrides(){
  regions=GameData.regions.map(deep);
  for(const region of regions){
    const ro=regionOverrides[region.id];
    if(ro) Object.assign(region,deep(ro));
    for(const m of region.missions){
      const ov=missionOverrides[m.id];
      if(ov) Object.assign(m,deep(ov));
      m.completed=!!progress.completed[m.id];
    }
    region.missions=region.missions.filter(m=>!missionOverrides[m.id]?.deleted);
    for(const o of region.objects){const key=`${region.id}:${o.id}`;if(progress.objectStates[key]!=null)o.state=progress.objectStates[key];}
  }
  for(const key of Object.keys(missionOverrides)){
    const m=missionOverrides[key];if(!m.custom||m.deleted)continue;const region=regions[m.region-1];if(region&&!region.missions.find(x=>x.id===m.id)){const copy=deep(m);copy.completed=!!progress.completed[copy.id];region.missions.push(copy);}
  }
  for(const region of regions)region.missions.sort((a,b)=>a.step-b.step);
}
applyOverrides();

const runtime={
  getCurrentRegion:()=>progress.currentRegion,
  isRegionComplete:(id)=>isRegionComplete(id),
  getActiveMission:()=>activeMission(),
  getRevealForRegion:(id)=>{const r=regions[id-1];if(!r)return{completed:[],ratio:0,activeId:null};const done=r.missions.filter(m=>m.completed);const active=id===progress.currentRegion?r.missions.find(m=>!m.completed):null;return{completed:done.map(m=>m.targetId),ratio:done.length/Math.max(1,r.missions.length),activeId:active?.targetId||null};}
};

const engine=new SceneEngine($('#gameCanvas'));
engine.setRuntime(runtime);engine.setAtmosphere(settings.atmosphere||'day');
engine.onRegionTap=id=>{if(id>progress.currentRegion){U.showToast(`منطقه ${U.fa(id)} هنوز زیر ابر است.`);engine.focusOverviewRegion(progress.currentRegion);return;}enterRegion(id,false);};
engine.onObjectTap=id=>{if(viewRegionId===progress.currentRegion){const m=activeMission();if(m&&m.targetId===id){missionPanelOpen=true;U.toggleMissionStrip(true);engine.focusObject(id,1.95,650);}}};

function getRegion(id){return regions[Math.max(1,Math.min(100,id))-1];}
function activeRegion(){return getRegion(progress.currentRegion);}
function activeMission(){return activeRegion()?.missions.find(m=>!m.completed)||null;}
function isRegionComplete(id){const r=getRegion(id);return !!r&&r.missions.length>0&&r.missions.every(m=>m.completed);}
function totalMissionCount(){return regions.reduce((n,r)=>n+r.missions.length,0);}
function completedMissionCount(){return Object.keys(progress.completed).filter(k=>progress.completed[k]).length;}
function saveProgress(){StorageSystem.saveProgress(progress);}
function levelInfo(){const per=500;return{level:Math.floor(progress.totalXp/per)+1,current:progress.totalXp%per,need:per};}
function currentObject(){const m=activeMission();return m?activeRegion().objects.find(o=>o.id===m.targetId):null;}

function updateUI(){U.setHud(progress,totalMissionCount(),completedMissionCount());const r=getRegion(viewRegionId);if(r)U.setRegion(r);const m=activeMission();U.setMission(m,activeRegion(),progress.startedMissionId===m?.id);if(engine.mode==='scene'&&viewRegionId===progress.currentRegion){const o=currentObject();if(o)o.missionActive=true;}for(const rgn of regions)for(const o of rgn.objects)if(viewRegionId!==progress.currentRegion||o.id!==m?.targetId)o.missionActive=false;}

function setMissionStrip(open){missionPanelOpen=open;U.toggleMissionStrip(open);}
function enterRegion(id,focusActive=true){viewRegionId=id;const r=getRegion(id);engine.setRegion(r);updateUI();if(focusActive&&id===progress.currentRegion){const m=activeMission();if(m)setTimeout(()=>engine.focusObject(m.targetId,1.78,760),80);}else setTimeout(()=>engine.fitScene(true),80);}
function goOverview(){setMissionStrip(false);viewRegionId=progress.currentRegion;engine.setOverview(progress.currentRegion,true);$('#regionTitle').textContent='نقشه مسیر';$('#regionSubtitle').textContent=`تا منطقه ${U.fa(progress.currentRegion)} باز شده`;}

$('#missionFab').addEventListener('click',()=>{
  const m=activeMission();if(!m){U.showToast('همه ۱۰۰ منطقه کامل شده‌اند!');return;}
  if(engine.mode==='overview'||viewRegionId!==progress.currentRegion){enterRegion(progress.currentRegion,false);setTimeout(()=>engine.focusObject(m.targetId,1.92,850),120);setMissionStrip(true);return;}
  setMissionStrip(!missionPanelOpen);if(missionPanelOpen)engine.focusObject(m.targetId,1.92,760);
});
$('#overviewBtn').addEventListener('click',goOverview);
$('#focusBtn').addEventListener('click',()=>{const m=activeMission();if(!m)return;if(engine.mode==='overview'||viewRegionId!==progress.currentRegion)enterRegion(progress.currentRegion,false);setMissionStrip(true);setTimeout(()=>engine.focusObject(m.targetId,1.98,760),80);});

$('#missionActionBtn').addEventListener('click',()=>{
  const m=activeMission();if(!m)return;
  if(progress.startedMissionId!==m.id){progress.startedMissionId=m.id;saveProgress();updateUI();engine.focusObject(m.targetId,2.05,650);U.showToast('مأموریت شروع شد؛ بعد از انجام کار، «انجام شد» را بزن.');return;}
  completeMission(m);
});

function completeMission(m){
  const r=activeRegion();const obj=r.objects.find(o=>o.id===m.targetId);if(!obj||m.completed)return;
  m.completed=true;progress.completed[m.id]=true;progress.startedMissionId='';progress.coins+=Number(m.coins)||0;progress.totalXp+=Number(m.xp)||0;obj.state=m.targetState??Math.min(3,(obj.state||0)+1);progress.objectStates[`${r.id}:${obj.id}`]=obj.state;saveProgress();
  engine.transitionObject(obj.id,obj.state);const p=engine.project(obj.x,obj.y,obj.z||0);if(obj.type==='tree')engine.addParticle('leaf',p.x,p.y-25,18,'#7cc45d');if(obj.type==='fountain'||obj.type==='pool'||obj.type==='waterfall')engine.addParticle('splash',p.x,p.y-10,18,'#78d7ff');
  engine.addCoinFly(obj.id,U.chipCenter('#coinChip'),'coin');engine.addCoinFly(obj.id,U.chipCenter('#xpChip'),'xp');U.showReward(m.coins,m.xp);updateUI();
  const done=isRegionComplete(r.id);
  if(done){if(r.id<100)progress.currentRegion=Math.max(progress.currentRegion,r.id+1);saveProgress();setTimeout(()=>{engine.focusRegionResult(850);setTimeout(()=>showRegionComplete(r.id),850);},550);}
  else{const next=activeMission();setTimeout(()=>{updateUI();if(next)engine.focusObject(next.targetId,1.86,850);},950);}
}

function showRegionComplete(id){$('#regionCompleteTitle').textContent=`منطقه ${U.fa(id)} کامل شد!`;$('#regionCompleteText').textContent=id<100?`منطقه ${U.fa(id+1)} برایت باز شد.`:'تمام ۱۰۰ منطقه مسیر را کامل کردی.';U.openModal('#regionCompleteModal');}
$('#continueRegionBtn').addEventListener('click',()=>{U.closeModal('#regionCompleteModal');const m=activeMission();if(m){enterRegion(progress.currentRegion,false);setTimeout(()=>engine.focusObject(m.targetId,1.86,850),150);}else goOverview();});

// Settings
$('#settingsBtn').addEventListener('click',()=>U.openModal('#settingsModal'));
$('#closeSettingsBtn').addEventListener('click',()=>U.closeModal('#settingsModal'));
$('#toggleAtmosphereBtn').addEventListener('click',()=>{settings.atmosphere=settings.atmosphere==='night'?'day':'night';StorageSystem.saveSettings(settings);engine.setAtmosphere(settings.atmosphere);if(builderEngine)builderEngine.setAtmosphere(settings.atmosphere);U.showToast(settings.atmosphere==='night'?'حالت شب فعال شد':'حالت روز فعال شد');});
$('#resetProgressBtn').addEventListener('click',()=>{if(!confirm('تمام XP، سکه و پیشرفت ۱۰۰ منطقه از ابتدا شروع شود؟'))return;StorageSystem.resetProgress();progress=StorageSystem.loadProgress();applyOverrides();viewRegionId=1;U.closeModal('#settingsModal');updateUI();goOverview();});

// Mission manager
function fillRegionSelect(select,selected=1){select.innerHTML=regions.map(r=>`<option value="${r.id}">منطقه ${U.fa(r.id)} — ${r.subtitle}</option>`).join('');select.value=String(selected);}
fillRegionSelect($('#managerRegionSelect'),progress.currentRegion);
function renderMissionList(regionId){const r=getRegion(regionId),list=$('#missionList');list.innerHTML='';for(const m of r.missions){const o=r.objects.find(x=>x.id===m.targetId);const row=document.createElement('div');row.className='mission-row'+(m.completed?' done':'');row.innerHTML=`<div class="row-icon">${m.completed?'✓':'◆'}</div><div class="row-copy"><b>${escapeHtml(m.title)}</b><small>مرحله ${U.fa(m.step)} · ${U.importanceText(m.importance)} · ${(GameData.assetLabels[o?.type]||o?.type||'هدف')} · ${U.fa(m.coins)} سکه · ${U.fa(m.xp)} XP</small></div><button class="edit-btn">ویرایش</button>`;row.querySelector('.edit-btn').addEventListener('click',()=>openMissionEditor(m));list.appendChild(row);}}
function escapeHtml(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
$('#openManagerBtn').addEventListener('click',()=>{U.closeModal('#settingsModal');U.openScreen('#managerScreen');fillRegionSelect($('#managerRegionSelect'),progress.currentRegion);renderMissionList(progress.currentRegion);});
$('#closeManagerBtn').addEventListener('click',()=>{U.openGame();updateUI();goOverview();});
$('#managerRegionSelect').addEventListener('change',e=>renderMissionList(Number(e.target.value)));
$('#addMissionBtn').addEventListener('click',()=>openMissionEditor(null,Number($('#managerRegionSelect').value)));

function populateMissionEditor(regionId,targetId=''){fillRegionSelect($('#editMissionRegion'),regionId);$('#editMissionStep').innerHTML=Array.from({length:10},(_,i)=>`<option value="${i+1}">مرحله ${U.fa(i+1)}</option>`).join('');const r=getRegion(regionId);$('#editMissionTarget').innerHTML=r.objects.map(o=>`<option value="${o.id}">${GameData.assetLabels[o.type]||o.type} · ${o.id}</option>`).join('');if(targetId&&r.objects.some(o=>o.id===targetId))$('#editMissionTarget').value=targetId;}
function openMissionEditor(m=null,regionId=progress.currentRegion){const rid=m?.region||regionId;populateMissionEditor(rid,m?.targetId);$('#missionModalTitle').textContent=m?'ویرایش مأموریت':'مأموریت جدید';$('#missionId').value=m?.id||'';$('#editMissionTitle').value=m?.title||'';$('#editMissionDescription').value=m?.description||'';$('#editMissionStep').value=String(m?.step||getRegion(rid).missions.length+1);$('#editMissionImportance').value=m?.importance||'medium';const rw=GameData.rewardPreset[m?.importance||'medium'];$('#editMissionCoins').value=m?.coins??rw.coins;$('#editMissionXp').value=m?.xp??rw.xp;$('#deleteMissionBtn').style.visibility=m?'visible':'hidden';U.openModal('#missionModal');}
$('#editMissionRegion').addEventListener('change',e=>populateMissionEditor(Number(e.target.value)));
$('#editMissionImportance').addEventListener('change',e=>{const rw=GameData.rewardPreset[e.target.value];$('#editMissionCoins').value=rw.coins;$('#editMissionXp').value=rw.xp;});
$('#cancelMissionBtn').addEventListener('click',()=>U.closeModal('#missionModal'));
$('#missionForm').addEventListener('submit',e=>{e.preventDefault();const id=$('#missionId').value||`custom_${Date.now()}`,region=Number($('#editMissionRegion').value),data={id,custom:(!$('#missionId').value)||!!missionOverrides[id]?.custom,region,step:Number($('#editMissionStep').value),title:$('#editMissionTitle').value.trim(),description:$('#editMissionDescription').value.trim(),targetId:$('#editMissionTarget').value,importance:$('#editMissionImportance').value,coins:Math.max(0,Number($('#editMissionCoins').value)||0),xp:Math.max(0,Number($('#editMissionXp').value)||0),targetState:3};const existing=getRegion(region).missions.find(m=>m.step===data.step&&m.id!==id);if(existing&&!confirm(`مرحله ${data.step} قبلاً استفاده شده. مأموریت جدید با همان شماره ذخیره شود؟`))return;missionOverrides[id]=data;StorageSystem.saveMissionOverrides(missionOverrides);applyOverrides();U.closeModal('#missionModal');fillRegionSelect($('#managerRegionSelect'),region);renderMissionList(region);});
$('#deleteMissionBtn').addEventListener('click',()=>{const id=$('#missionId').value;if(!id)return;const r=regions.find(r=>r.missions.some(m=>m.id===id));const m=r?.missions.find(m=>m.id===id);if(!confirm(`مأموریت «${m?.title||''}» حذف شود؟`))return;if(m?.custom)missionOverrides[id]={...m,deleted:true,custom:true};else missionOverrides[id]={...m,deleted:true};StorageSystem.saveMissionOverrides(missionOverrides);if(progress.completed[id])delete progress.completed[id];saveProgress();applyOverrides();if(r){regions[r.id-1].missions=regions[r.id-1].missions.filter(x=>x.id!==id);renderMissionList(r.id);}U.closeModal('#missionModal');});

// World Builder
function makeRegionFromTemplate(regionId,templateId,themeId){const idx=GameData.templateNames.indexOf(templateId),rng=GameData.mulberry32(5000+regionId*37+idx*101),base=GameData.makers[templateId](rng),old=getRegion(regionId);return{id:regionId,name:`منطقه ${regionId}`,subtitle:GameData.templateFa[idx],templateId,themeId:themeId||old.themeId,terrain:base.terrain,water:!!base.water,indoor:!!base.indoor,walls:!!base.walls,paths:deep(base.paths||[]),objects:deep(base.objects),missions:deep(old.missions)};}
function ensureBuilder(){if(builderEngine)return;builderEngine=new SceneEngine($('#builderCanvas'),{builder:true});builderEngine.setRuntime(runtime);builderEngine.setAtmosphere(settings.atmosphere||'day');builderEngine.onObjectTap=id=>{builderSelectedId=id;builderEngine.selectedObjectId=id;syncBuilderObjectControls();};builderEngine.onBuilderChange=o=>syncBuilderObjectControls(o);}
function loadBuilderRegion(id){ensureBuilder();builderWorking=deep(getRegion(id));builderSelectedId=null;builderEngine.setRegion(builderWorking);builderEngine.resize();fillBuilderSelectors();}
function fillBuilderSelectors(){fillRegionSelect($('#builderRegionSelect'),builderWorking.id);$('#builderTemplateSelect').innerHTML=GameData.templateNames.map((n,i)=>`<option value="${n}">${GameData.templateFa[i]}</option>`).join('');$('#builderTemplateSelect').value=builderWorking.templateId;$('#builderThemeSelect').innerHTML=GameData.themes.map(t=>`<option value="${t.id}">${t.name}</option>`).join('');$('#builderThemeSelect').value=builderWorking.themeId;$('#builderAssetType').innerHTML=Object.keys(GameData.assetCounts).map(t=>`<option value="${t}">${GameData.assetLabels[t]}</option>`).join('');fillVariantSelect();}
function fillVariantSelect(){const type=$('#builderAssetType').value||'tree';$('#builderAssetVariant').innerHTML=Array.from({length:GameData.assetCounts[type]},(_,i)=>`<option value="${i+1}">${GameData.assetLabels[type]} ${i+1}</option>`).join('');}
function syncBuilderObjectControls(o=null){o=o||builderWorking?.objects.find(x=>x.id===builderSelectedId);if(!o)return;$('#builderX').value=Math.round(o.x);$('#builderY').value=Math.round(o.y);$('#builderScale').value=Math.round((o.scale||1)*100);$('#builderState').value=String(o.state||0);}
$('#openBuilderBtn').addEventListener('click',()=>{U.closeModal('#settingsModal');U.openScreen('#builderScreen');setTimeout(()=>loadBuilderRegion(progress.currentRegion),60);});
$('#closeBuilderBtn').addEventListener('click',()=>{U.openGame();applyOverrides();updateUI();goOverview();});
$('#builderRegionSelect').addEventListener('change',e=>loadBuilderRegion(Number(e.target.value)));
$('#builderTemplateSelect').addEventListener('change',e=>{builderWorking=makeRegionFromTemplate(builderWorking.id,e.target.value,$('#builderThemeSelect').value);builderEngine.setRegion(builderWorking);builderSelectedId=null;});
$('#builderThemeSelect').addEventListener('change',e=>{builderWorking.themeId=e.target.value;builderEngine.setRegion(builderWorking);});
$('#builderAssetType').addEventListener('change',fillVariantSelect);
$('#builderAddAssetBtn').addEventListener('click',()=>{const type=$('#builderAssetType').value,variant=Number($('#builderAssetVariant').value),id=`customObj_${Date.now()}`;const o={id,type,variant,x:500,y:350,scale:1,state:0,z:0};builderWorking.objects.push(o);builderSelectedId=id;builderEngine.selectedObjectId=id;syncBuilderObjectControls(o);});
for(const [id,prop,conv] of [['#builderX','x',Number],['#builderY','y',Number],['#builderScale','scale',v=>Number(v)/100],['#builderState','state',Number]])$(id).addEventListener('input',e=>{const o=builderWorking?.objects.find(x=>x.id===builderSelectedId);if(!o)return;o[prop]=conv(e.target.value);});
$('#builderDeleteBtn').addEventListener('click',()=>{if(!builderSelectedId)return;builderWorking.objects=builderWorking.objects.filter(o=>o.id!==builderSelectedId);builderSelectedId=null;builderEngine.selectedObjectId=null;});
$('#builderResetBtn').addEventListener('click',()=>{if(!confirm('چیدمان این Region به Template برگردد؟'))return;builderWorking=makeRegionFromTemplate(builderWorking.id,builderWorking.templateId,builderWorking.themeId);builderEngine.setRegion(builderWorking);builderSelectedId=null;});
$('#builderSaveBtn').addEventListener('click',()=>{const save={id:builderWorking.id,name:builderWorking.name,subtitle:builderWorking.subtitle,templateId:builderWorking.templateId,themeId:builderWorking.themeId,terrain:builderWorking.terrain,water:builderWorking.water,indoor:builderWorking.indoor,walls:builderWorking.walls,paths:deep(builderWorking.paths),objects:deep(builderWorking.objects)};regionOverrides[builderWorking.id]=save;StorageSystem.saveRegionOverrides(regionOverrides);applyOverrides();builderWorking=deep(getRegion(builderWorking.id));builderEngine.setRegion(builderWorking);U.showToast(`Region ${builderWorking.id} ذخیره شد.`);});


// Initial state
engine.setOverview(progress.currentRegion,false);updateUI();$('#regionTitle').textContent='نقشه مسیر';$('#regionSubtitle').textContent=`تا منطقه ${U.fa(progress.currentRegion)} باز شده`;setMissionStrip(false);
})();
