# QA Report

## بررسی‌های انجام‌شده
- JavaScript syntax check با Node: PASS
- AndroidManifest XML parse: PASS
- JSON parse برای Regions / Assets / Templates / Themes: PASS
- بررسی همه IDهای UI و Referenceهای JS: PASS — هیچ ID گمشده‌ای وجود ندارد
- تعداد Region: 100
- تعداد مأموریت پیش‌فرض: 500
- تعداد Asset Variant: 103
- تعداد Template: 15
- تعداد فایل تصویر در پروژه: 0
- بررسی Keystore و Alias: PASS
- Browser smoke test با Chromium:
  - Load بدون Page Error: PASS
  - Mission FAB و Focus: PASS
  - Start Mission → Done: PASS
  - افزایش Coin از 0 به 60: PASS
  - افزایش XP از 0 به 120: PASS
  - Mission Manager و 5 مأموریت Region اول: PASS
  - World Builder باز می‌شود: PASS
  - Add Asset و Save Region: PASS

## Build محلی
در محیط ساخت این گفتگو دسترسی اینترنتی به `services.gradle.org` موجود نیست، بنابراین دانلود Gradle 8.9 و اجرای کامل Android Build محلی امکان‌پذیر نبود. پروژه برای همان Workflow GitHub شما تنظیم شده و Wrapper سفارشی همان الگوی قبلی را حفظ می‌کند.
