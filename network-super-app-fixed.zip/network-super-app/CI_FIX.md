# GitHub Actions build fix

The previous ZIP did not contain a `gradlew` launcher, so workflows that require
the Gradle wrapper stopped at **Prepare Gradle wrapper** with:

`ERROR: gradlew not found.`

This package adds:

- `gradlew` (CI-compatible launcher; executable)
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar` layout compatibility
- a GitHub Actions workflow that installs Gradle 8.9 and builds the debug APK

In CI, the launcher uses the Gradle version installed by `gradle/actions/setup-gradle`.
If Gradle is not installed, the Unix launcher can download Gradle 8.9 automatically.
