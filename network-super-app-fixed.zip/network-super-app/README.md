# Network Super App

پروتوتایپ اندروید صفحه Home برای سوپر اپ نتورک مارکتینگ، بر اساس تصمیم‌های طراحی نهایی این گفتگو.

## وضعیت فعلی

نسخه `0.1.0` شامل Home اولیه با Jetpack Compose است:

- هدر RTL با Profile، Rank، XP، Combo و Reward Chest
- کارت «قدم بعدی» با بک‌گراند هندسی کاملاً کدنویسی‌شده
- «امروز من» به شکل برنامه ساعت‌محور و اسکرول افقی RTL
- «مسیر پیشرفت» به شکل تسک‌های افقی با ترتیب کاربر
- Bottom Navigation گیمیفای‌شده
- تصویر مرجع طراحی در `docs/home-reference.png`
- مشخصات فارسی Home در `docs/HOME_SPEC_FA.md`

## تکنولوژی

- Kotlin
- Jetpack Compose
- Material 3
- RTL-first UI
- Min SDK 26 / Target SDK 35

## اجرا

پروژه را با Android Studio باز کنید و Gradle Sync را اجرا کنید. سپس ماژول `app` را روی Emulator یا دستگاه اندروید اجرا کنید.

> در این نسخه داده‌ها Mock هستند و هنوز Backend، احراز هویت و دیتابیس متصل نشده‌اند.

## ساختار

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
├── ui/home/HomeScreen.kt
└── ui/theme/

docs/
├── HOME_SPEC_FA.md
└── home-reference.png
```

## قدم بعدی پیشنهادی

پس از تأیید Home، مدل‌های داده و Navigation واقعی اضافه شوند و سپس صفحات «مسیر پیشرفت»، «لیست مشتریان»، «لیست شبکه‌سازی» و «بیشتر» به همین Design System پیاده‌سازی شوند.
