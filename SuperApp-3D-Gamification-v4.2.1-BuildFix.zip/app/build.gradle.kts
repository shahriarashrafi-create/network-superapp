plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}


kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

android {
    namespace = "com.superapp.progressgame"
    compileSdk = 36

    // SceneView/Filament ships native libraries. Keep 16 KB page alignment ready
    // for current Android/Play requirements while preserving the existing app identity.
    experimentalProperties["android.nativeLibraryAlignmentPageSize"] = "16k"

    defaultConfig {
        applicationId = "com.superapp.progressgame"
        minSdk = 26
        targetSdk = 36
        versionCode = 12
        versionName = "4.2.1-entrance-cinematic-buildfix"
    }

    signingConfigs {
        create("stable") {
            storeFile = rootProject.file("keystore/superapp.jks")
            storePassword = "superapp123"
            keyAlias = "superapp"
            keyPassword = "superapp123"
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("stable")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("stable")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    androidResources {
        noCompress += listOf("filamat", "ktx", "glb", "gltf")
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2026.06.01"))
    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Real-time 3D renderer: SceneView declarative layer + Google Filament runtime.
    implementation("io.github.sceneview:sceneview:4.32.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
