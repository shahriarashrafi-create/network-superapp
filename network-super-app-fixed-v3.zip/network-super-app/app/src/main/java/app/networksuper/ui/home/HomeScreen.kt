package app.networksuper.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.networksuper.ui.theme.*

private data class ScheduleItem(
    val time: String,
    val title: String,
    val icon: ImageVector,
    val accent: Color
)

private data class ProgressTask(
    val title: String,
    val icon: ImageVector,
    val accent: Color,
    val done: Boolean = false
)

private data class NavItem(
    val label: String,
    val icon: ImageVector
)

@Composable
fun HomeScreen() {
    var selectedNav by remember { mutableIntStateOf(0) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppBackground,
            bottomBar = {
                GameBottomNav(
                    selectedIndex = selectedNav,
                    onSelected = { selectedNav = it }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { HomeHeader() }
                item { NextActionCard() }
                item { TodaySection() }
                item { ProgressSection() }
                item { Spacer(Modifier.height(6.dp)) }
            }
        }
    }
}

@Composable
private fun HomeHeader() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HeaderAction(icon = Icons.Rounded.Whatshot, badge = "3", tint = WarningOrange)
                HeaderAction(icon = Icons.Rounded.Inventory2, showDot = true, tint = RewardGold)
            }

            Column(
                modifier = Modifier.widthIn(min = 130.dp, max = 190.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "2480 XP",
                    color = PrimaryBlue,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                )
                LinearProgressIndicator(
                    progress = { 0.62f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(9.dp)
                        .clip(CircleShape),
                    color = PrimaryBlue,
                    trackColor = Color(0xFFDDE9F9)
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF1597FF), Color(0xFF0D56CE))
                                )
                            )
                            .border(3.dp, RewardGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "سلام شهریار",
                            color = Navy,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Right
                        )
                        Spacer(Modifier.height(5.dp))
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Navy)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                Icons.Rounded.WorkspacePremium,
                                contentDescription = null,
                                tint = RewardGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Text("Builder", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderAction(
    icon: ImageVector,
    badge: String? = null,
    showDot: Boolean = false,
    tint: Color
) {
    Box(
        modifier = Modifier
            .size(52.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(27.dp))
        if (badge != null) {
            Text(
                text = badge,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 2.dp),
                color = Navy,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
            )
        }
        if (showDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(8.dp)
                    .background(Color(0xFFFF4057), CircleShape)
            )
        }
    }
}

@Composable
private fun NextActionCard() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp)
                .shadow(14.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF0767E9), Color(0xFF1F91FF), Color(0xFFF8FBFF))
                    )
                )
        ) {
            GeometricQuestArt(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.52f)
                    .align(Alignment.CenterStart)
            )

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxWidth(0.56f)
                        .padding(end = 22.dp, start = 12.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Rounded.TrackChanges,
                            contentDescription = null,
                            tint = Color(0xFFFF4B3E),
                            modifier = Modifier.size(34.dp)
                        )
                        Text(
                            "قدم بعدی",
                            color = Navy,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(Modifier.height(22.dp))

                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = Color.White.copy(alpha = 0.96f),
                        shadowElevation = 4.dp
                    ) {
                        Text(
                            text = "پیگیری با علی رضایی",
                            modifier = Modifier.fillMaxWidth().padding(18.dp),
                            textAlign = TextAlign.Right,
                            color = Navy,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Button(
                        onClick = { },
                        modifier = Modifier.fillMaxWidth().height(58.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("شروع", fontSize = 21.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }
    }
}

@Composable
private fun GeometricQuestArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        for (i in 0..5) {
            val x = w * (0.08f + i * 0.16f)
            drawLine(
                color = Color.White.copy(alpha = 0.13f),
                start = Offset(x, 0f),
                end = Offset(x - h * 0.25f, h),
                strokeWidth = 2f
            )
        }

        val path = Path().apply {
            moveTo(w * 0.08f, h * 0.78f)
            cubicTo(w * 0.22f, h * 0.70f, w * 0.26f, h * 0.49f, w * 0.42f, h * 0.56f)
            cubicTo(w * 0.58f, h * 0.64f, w * 0.62f, h * 0.33f, w * 0.84f, h * 0.25f)
        }
        drawPath(
            path = path,
            color = Color(0xFFFFD35A),
            style = Stroke(width = 7f, cap = StrokeCap.Round)
        )

        listOf(
            Offset(w * 0.10f, h * 0.77f),
            Offset(w * 0.40f, h * 0.56f),
            Offset(w * 0.62f, h * 0.46f),
            Offset(w * 0.84f, h * 0.25f)
        ).forEach { p ->
            drawCircle(Color.White, radius = 13f, center = p)
            drawCircle(Color(0xFFFFD35A), radius = 13f, center = p, style = Stroke(width = 5f))
        }

        for (i in 0..3) {
            val left = w * (0.10f + i * 0.20f)
            val top = h * (0.12f + (i % 2) * 0.18f)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.11f),
                topLeft = Offset(left, top),
                size = Size(w * 0.22f, w * 0.22f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f),
                style = Stroke(width = 3f)
            )
        }
    }
}

@Composable
private fun TodaySection() {
    val scheduleItems = listOf(
        ScheduleItem("10:00", "تماس", Icons.Rounded.Call, SuccessGreen),
        ScheduleItem("15:00", "جلسه معرفی", Icons.Rounded.Groups, PrimaryBlue),
        ScheduleItem("18:00", "جلسه تیم", Icons.Rounded.Group, WarningOrange),
        ScheduleItem("21:00", "پیگیری", Icons.Rounded.Assignment, AccentPurple)
    )

    HomeSectionCard {
        SectionHeader(
            title = "امروز من",
            rightIcon = Icons.Rounded.CheckCircle,
            rightIconTint = SuccessGreen,
            leftContent = {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(SoftBlue)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, tint = PrimaryBlue)
                    Text("دوشنبه ۲۳ مهر", color = Navy, fontWeight = FontWeight.Bold)
                }
            }
        )

        Spacer(Modifier.height(14.dp))

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LazyRow(
                reverseLayout = true,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(scheduleItems) { item ->
                    ScheduleCard(item)
                }
            }
        }
    }
}

@Composable
private fun ScheduleCard(item: ScheduleItem) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = Modifier.width(150.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = item.accent.copy(alpha = 0.07f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, item.accent.copy(alpha = 0.17f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(item.time, color = item.accent, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Spacer(Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(item.accent.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(item.icon, contentDescription = null, tint = item.accent, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text(item.title, color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { if (item.time == "10:00") 1f else 0.42f },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                    color = item.accent,
                    trackColor = item.accent.copy(alpha = 0.16f)
                )
            }
        }
    }
}

@Composable
private fun ProgressSection() {
    val taskItems = listOf(
        ProgressTask("مرتب کردن اتاق", Icons.Rounded.Hotel, SuccessGreen, true),
        ProgressTask("روتین صبح", Icons.Rounded.WbSunny, WarningOrange),
        ProgressTask("نرمش روزانه", Icons.Rounded.FitnessCenter, PrimaryBlue),
        ProgressTask("هدف بلندمدت", Icons.Rounded.Flag, AccentPurple)
    )

    HomeSectionCard {
        SectionHeader(
            title = "مسیر پیشرفت",
            rightIcon = Icons.Rounded.EmojiEvents,
            rightIconTint = RewardGold,
            leftContent = {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SoftBlue
                ) {
                    Text(
                        "مرحله ۶ از ۱۲",
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        color = PrimaryBlueDark,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        )

        Spacer(Modifier.height(14.dp))

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LazyRow(
                reverseLayout = true,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(taskItems) { task ->
                    ProgressTaskCard(task)
                }
            }
        }
    }
}

@Composable
private fun ProgressTaskCard(task: ProgressTask) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = Modifier.width(160.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = task.accent.copy(alpha = 0.06f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, task.accent.copy(alpha = 0.15f))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Icon(
                        if (task.done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (task.done) SuccessGreen else Muted.copy(alpha = 0.45f)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .background(task.accent.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(task.icon, contentDescription = null, tint = task.accent, modifier = Modifier.size(31.dp))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    task.title,
                    color = Navy,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { if (task.done) 1f else 0.35f },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                    color = task.accent,
                    trackColor = task.accent.copy(alpha = 0.16f)
                )
            }
        }
    }
}

@Composable
private fun HomeSectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
private fun SectionHeader(
    title: String,
    rightIcon: ImageVector,
    rightIconTint: Color,
    leftContent: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            leftContent()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(rightIcon, contentDescription = null, tint = rightIconTint, modifier = Modifier.size(28.dp))
                    Text(title, color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun GameBottomNav(selectedIndex: Int, onSelected: (Int) -> Unit) {
    val navItems = listOf(
        NavItem("خانه", Icons.Rounded.Home),
        NavItem("مسیر پیشرفت", Icons.Rounded.TrendingUp),
        NavItem("لیست مشتریان", Icons.Rounded.Groups),
        NavItem("لیست شبکه‌سازی", Icons.Rounded.AccountTree),
        NavItem("بیشتر", Icons.Rounded.MoreHoriz)
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 14.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val active = index == selectedIndex
                Surface(
                    onClick = { onSelected(index) },
                    shape = RoundedCornerShape(20.dp),
                    color = if (active) SoftBlue else Color.Transparent,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.5.dp,
                        PrimaryBlue.copy(alpha = 0.25f)
                    ) else null,
                    shadowElevation = if (active) 7.dp else 0.dp
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            item.icon,
                            contentDescription = item.label,
                            tint = if (active) PrimaryBlue else Muted,
                            modifier = Modifier.size(if (active) 28.dp else 24.dp)
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            item.label,
                            color = if (active) PrimaryBlue else Muted,
                            fontSize = 11.sp,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
