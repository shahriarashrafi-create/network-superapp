package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.networksuper.ui.theme.*

private val stageSpacing = 184.dp
private val stageCardHeight = 94.dp
private val worldTopPadding = 66.dp

@Composable
fun ProgressPathContent(modifier: Modifier = Modifier) {
    val stages = ProgressPathStore.stages
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    var actionStageId by remember { mutableStateOf<Long?>(null) }
    var editStageId by remember { mutableStateOf<Long?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var deleteStageId by remember { mutableStateOf<Long?>(null) }

    val currentIndex = stages.indexOfFirst { it.status == StageStatus.CURRENT }.coerceAtLeast(0)

    LaunchedEffect(currentIndex, stages.size) {
        val target = with(density) {
            (worldTopPadding + stageSpacing * currentIndex.toFloat() - 165.dp).toPx().toInt()
        }.coerceAtLeast(0)
        scrollState.animateScrollTo(target)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        ProgressPathHeader()
        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFFF7FBFF))
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            ) {
                val availableWidth = maxWidth
                val worldHeight = worldTopPadding * 2f +
                    stageSpacing * (stages.size.coerceAtLeast(1) - 1).toFloat() +
                    stageCardHeight + 70.dp
                val cardWidth = availableWidth * 0.61f

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(worldHeight)
                ) {
                    ProgressWorldBackdrop(Modifier.matchParentSize())
                    ProgressRoad(
                        modifier = Modifier.matchParentSize(),
                        count = stages.size
                    )

                    stages.forEachIndexed { index, stage ->
                        val isCardOnRight = index % 2 == 0
                        val cardTop = worldTopPadding + stageSpacing * index.toFloat()

                        StageCard(
                            stage = stage,
                            onClick = { actionStageId = stage.id },
                            modifier = Modifier
                                .align(if (isCardOnRight) Alignment.TopEnd else Alignment.TopStart)
                                .offset(
                                    x = if (isCardOnRight) (-10).dp else 10.dp,
                                    y = cardTop
                                )
                                .width(cardWidth)
                                .height(stageCardHeight)
                        )
                    }
                }
            }

            Canvas(Modifier.matchParentSize()) {
                val fadeHeight = 22.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color(0xFFF7FBFF),
                        1f to Color.Transparent,
                        startY = 0f,
                        endY = fadeHeight
                    ),
                    size = Size(size.width, fadeHeight)
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        1f to Color(0xFFF7FBFF),
                        startY = size.height - fadeHeight,
                        endY = size.height
                    ),
                    topLeft = Offset(0f, size.height - fadeHeight),
                    size = Size(size.width, fadeHeight)
                )
            }

            Surface(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .align(AbsoluteAlignment.BottomRight)
                    .padding(14.dp)
                    .size(44.dp)
                    .shadow(6.dp, CircleShape),
                shape = CircleShape,
                color = PrimaryBlue,
                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "افزودن کارت",
                        tint = Color.White,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }

    actionStageId?.let { id ->
        ProgressPathStore.stages.firstOrNull { it.id == id }?.let { stage ->
            StageActionsDialog(
                stage = stage,
                onDismiss = { actionStageId = null },
                onEdit = {
                    actionStageId = null
                    editStageId = stage.id
                },
                onMakeCurrent = {
                    ProgressPathStore.setCurrent(stage.id)
                    actionStageId = null
                },
                onCompleted = {
                    ProgressPathStore.markCompleted(stage.id)
                    actionStageId = null
                },
                onFailed = {
                    ProgressPathStore.markFailed(stage.id)
                    actionStageId = null
                },
                onDelete = {
                    actionStageId = null
                    deleteStageId = stage.id
                }
            )
        } ?: run { actionStageId = null }
    }

    editStageId?.let { id ->
        ProgressPathStore.stages.firstOrNull { it.id == id }?.let { stage ->
            StageEditorDialog(
                editingStage = stage,
                onDismiss = { editStageId = null },
                onSave = { title, number ->
                    ProgressPathStore.editStage(stage.id, title, number)
                    editStageId = null
                }
            )
        } ?: run { editStageId = null }
    }

    if (showAddDialog) {
        StageEditorDialog(
            editingStage = null,
            onDismiss = { showAddDialog = false },
            onSave = { title, number ->
                ProgressPathStore.addStage(title, number)
                showAddDialog = false
            }
        )
    }

    deleteStageId?.let { id ->
        ProgressPathStore.stages.firstOrNull { it.id == id }?.let { stage ->
            DeleteStageDialog(
                stage = stage,
                onDismiss = { deleteStageId = null },
                onConfirm = {
                    ProgressPathStore.deleteStage(stage.id)
                    deleteStageId = null
                }
            )
        } ?: run { deleteStageId = null }
    }
}

@Composable
private fun ProgressPathHeader() {
    val stages = ProgressPathStore.stages
    val current = ProgressPathStore.currentStage()
    val ordinal = ProgressPathStore.currentOrdinal()
    val total = stages.size.coerceAtLeast(1)
    val progress = (ordinal.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val percent = (progress * 100).toInt()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                4.dp,
                RoundedCornerShape(26.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.07f),
                spotColor = PrimaryBlue.copy(alpha = 0.08f)
            ),
        shape = RoundedCornerShape(26.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEAF2FC))
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = SoftBlue,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.20f))
                ) {
                    Text(
                        text = if (current != null) "مرحله ${current.number} از ${stages.size}" else "بدون مرحله فعلی",
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = PrimaryBlueDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "مسیر پیشرفت",
                        color = Navy,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .shadow(5.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color.White, Color(0xFFFFF2C8))))
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EmojiEvents,
                            contentDescription = null,
                            tint = RewardGold,
                            modifier = Modifier.size(31.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(12.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDDEAF9))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF29B8EF), Color(0xFF0E6FFF))
                                )
                            )
                    )
                }

                Text(
                    text = "$percent%",
                    color = PrimaryBlue,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun ProgressWorldBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFF9FCFF), Color(0xFFF1F8FF), Color(0xFFF8FBFF))
            )
        )

        fun mountain(baseY: Float, x: Float, width: Float, height: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(x, baseY)
                lineTo(x + width * 0.50f, baseY - height)
                lineTo(x + width, baseY)
                close()
            }
            drawPath(p, Color(0xFFB8D9F6).copy(alpha = alpha))
        }

        val band = 330.dp.toPx()
        var y = 250.dp.toPx()
        var row = 0
        while (y < h + band) {
            val shift = if (row % 2 == 0) 0f else w * 0.12f
            mountain(y, -w * 0.08f + shift, w * 0.60f, 115.dp.toPx(), 0.23f)
            mountain(y + 16.dp.toPx(), w * 0.40f + shift, w * 0.56f, 95.dp.toPx(), 0.16f)

            drawCircle(
                color = Color.White.copy(alpha = 0.88f),
                radius = 22.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.78f else 0.20f, y - 120.dp.toPx())
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.82f),
                radius = 16.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.83f else 0.25f, y - 118.dp.toPx())
            )

            val treeX = w * if (row % 2 == 0) 0.12f else 0.86f
            drawRoundRect(
                color = Color(0xFF8BC2D9).copy(alpha = 0.30f),
                topLeft = Offset(treeX - 2.dp.toPx(), y - 70.dp.toPx()),
                size = Size(4.dp.toPx(), 31.dp.toPx()),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            val tree = Path().apply {
                moveTo(treeX, y - 118.dp.toPx())
                lineTo(treeX - 15.dp.toPx(), y - 68.dp.toPx())
                lineTo(treeX + 15.dp.toPx(), y - 68.dp.toPx())
                close()
            }
            drawPath(tree, Color(0xFF64BCD3).copy(alpha = 0.30f))

            y += band
            row++
        }
    }
}

@Composable
private fun ProgressRoad(count: Int, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (count <= 0) return@Canvas

        val nodeYs = List(count) { index ->
            (worldTopPadding + stageSpacing * index.toFloat() + stageCardHeight / 2f).toPx()
        }
        val nodeXs = List(count) { index ->
            size.width * if (index % 2 == 0) 0.36f else 0.64f
        }

        val roadPath = Path().apply {
            moveTo(nodeXs.first(), nodeYs.first() - 82.dp.toPx())
            lineTo(nodeXs.first(), nodeYs.first())
            for (i in 0 until count - 1) {
                val x0 = nodeXs[i]
                val y0 = nodeYs[i]
                val x1 = nodeXs[i + 1]
                val y1 = nodeYs[i + 1]
                val midY = (y0 + y1) / 2f
                cubicTo(x0, midY, x1, midY, x1, y1)
            }
            lineTo(nodeXs.last(), nodeYs.last() + 84.dp.toPx())
        }

        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.95f),
            style = Stroke(width = 54.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color(0xFF8BCBFF).copy(alpha = 0.22f),
            style = Stroke(width = 48.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFF7EC5FF), Color(0xFF4AA4FA), Color(0xFF8ACBFF))
            ),
            style = Stroke(width = 38.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.94f),
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(13.dp.toPx(), 13.dp.toPx()))
            )
        )
    }
}

@Composable
private fun StageCard(
    stage: ProgressStage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val completed = stage.status == StageStatus.COMPLETED
    val failed = stage.status == StageStatus.FAILED
    val accent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.FAILED -> FailRed
        StageStatus.UPCOMING -> PrimaryBlue
    }
    val contentAlpha = if (stage.status == StageStatus.UPCOMING) 0.72f else 1f

    Box(modifier = modifier) {
        Surface(
            onClick = onClick,
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    if (current) 9.dp else 3.dp,
                    RoundedCornerShape(23.dp),
                    ambientColor = accent.copy(alpha = if (current) 0.18f else 0.06f),
                    spotColor = accent.copy(alpha = if (current) 0.20f else 0.08f)
                ),
            shape = RoundedCornerShape(23.dp),
            color = Color.White.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.82f else 0.98f),
            border = androidx.compose.foundation.BorderStroke(
                if (current) 2.dp else 1.dp,
                when {
                    current -> PrimaryBlue
                    completed -> SuccessGreen.copy(alpha = 0.22f)
                    failed -> FailRed.copy(alpha = 0.24f)
                    else -> PrimaryBlue.copy(alpha = 0.13f)
                }
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stage.title,
                    color = Navy.copy(alpha = contentAlpha),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        StageStatusBadge(
            stage = stage,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-9).dp, y = (-12).dp)
        )
    }
}

@Composable
fun StageStatusBadge(
    stage: ProgressStage,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    when (stage.status) {
        StageStatus.CURRENT -> {
            Surface(
                modifier = modifier,
                shape = RoundedCornerShape(14.dp),
                color = PrimaryBlue,
                shadowElevation = if (compact) 1.dp else 3.dp
            ) {
                Text(
                    text = "مرحله فعلی",
                    modifier = Modifier.padding(
                        horizontal = if (compact) 8.dp else 12.dp,
                        vertical = if (compact) 4.dp else 6.dp
                    ),
                    color = Color.White,
                    fontSize = if (compact) 9.sp else 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }

        StageStatus.COMPLETED -> StatusCircle(
            icon = Icons.Rounded.Check,
            color = SuccessGreen,
            description = "انجام شده",
            modifier = modifier,
            compact = compact
        )

        StageStatus.FAILED -> StatusCircle(
            icon = Icons.Rounded.Close,
            color = FailRed,
            description = "انجام نشده",
            modifier = modifier,
            compact = compact
        )

        StageStatus.UPCOMING -> {
            val size = if (compact) 29.dp else 36.dp
            Surface(
                modifier = modifier.size(size),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = if (compact) 1.dp else 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFB9C7DA))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = stage.number.toString(),
                        color = Navy.copy(alpha = 0.78f),
                        fontSize = if (compact) 11.sp else 13.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusCircle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    description: String,
    modifier: Modifier,
    compact: Boolean
) {
    val size = if (compact) 29.dp else 36.dp
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = color,
        shadowElevation = if (compact) 1.dp else 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = Color.White,
                modifier = Modifier.size(if (compact) 18.dp else 21.dp)
            )
        }
    }
}

@Composable
private fun StageActionsDialog(
    stage: ProgressStage,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onMakeCurrent: () -> Unit,
    onCompleted: () -> Unit,
    onFailed: () -> Unit,
    onDelete: () -> Unit
) {
    ProgressDialogShell(onDismiss = onDismiss) {
        Text(
            text = stage.title,
            modifier = Modifier.fillMaxWidth(),
            color = Navy,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "مرحله ${stage.number}",
            modifier = Modifier.fillMaxWidth(),
            color = Muted,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DialogActionButton(
                text = "ویرایش",
                icon = Icons.Rounded.Edit,
                color = AccentPurple,
                onClick = onEdit,
                modifier = Modifier.weight(1f)
            )
            DialogActionButton(
                text = "مرحله فعلی",
                icon = Icons.Rounded.NearMe,
                color = PrimaryBlue,
                onClick = onMakeCurrent,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DialogActionButton(
                text = "انجام شد",
                icon = Icons.Rounded.Check,
                color = SuccessGreen,
                onClick = onCompleted,
                modifier = Modifier.weight(1f)
            )
            DialogActionButton(
                text = "انجام نشد",
                icon = Icons.Rounded.Close,
                color = FailRed,
                onClick = onFailed,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(10.dp))
        TextButton(
            onClick = onDelete,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed)
            Spacer(Modifier.width(5.dp))
            Text("حذف کارت", color = FailRed, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DialogActionButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.10f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(6.dp))
            Text(text, color = color, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun StageEditorDialog(
    editingStage: ProgressStage?,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit
) {
    var title by remember(editingStage?.id) { mutableStateOf(editingStage?.title.orEmpty()) }
    var numberText by remember(editingStage?.id) {
        mutableStateOf(editingStage?.number?.toString() ?: ((ProgressPathStore.stages.maxOfOrNull { it.number } ?: 0) + 1).toString())
    }
    val number = numberText.toIntOrNull()
    val duplicate = number != null && !ProgressPathStore.numberIsAvailable(number, editingStage?.id)
    val valid = title.isNotBlank() && number != null && number > 0 && !duplicate

    ProgressDialogShell(onDismiss = onDismiss) {
        Text(
            text = if (editingStage == null) "افزودن کارت جدید" else "ویرایش کارت",
            modifier = Modifier.fillMaxWidth(),
            color = Navy,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        MiniRoadDecoration()
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("نام کارت") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryBlue,
                focusedLabelColor = PrimaryBlue
            )
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = numberText,
            onValueChange = { value -> numberText = value.filter { it.isDigit() }.take(3) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("مرحله چندم؟") },
            supportingText = {
                if (duplicate) Text("این شماره مرحله قبلاً استفاده شده", color = FailRed)
                else Text("شماره هر مرحله باید یکتا باشد")
            },
            isError = duplicate,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryBlue,
                focusedLabelColor = PrimaryBlue
            )
        )
        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("انصراف")
            }
            Button(
                onClick = { if (valid) onSave(title.trim(), number!!) },
                enabled = valid,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(if (editingStage == null) "اضافه کردن" else "ذخیره", fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun MiniRoadDecoration() {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(30.dp)
    ) {
        val path = Path().apply {
            moveTo(size.width * 0.08f, size.height * 0.65f)
            cubicTo(
                size.width * 0.30f, 0f,
                size.width * 0.65f, size.height,
                size.width * 0.92f, size.height * 0.35f
            )
        }
        drawPath(path, Color(0xFFDDEBFA), style = Stroke(11.dp.toPx(), cap = StrokeCap.Round))
        drawPath(path, Color(0xFF69B7FB), style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(
            path,
            Color.White,
            style = Stroke(
                1.5.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 7.dp.toPx()))
            )
        )
    }
}

@Composable
private fun DeleteStageDialog(
    stage: ProgressStage,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White,
        title = {
            Text("حذف کارت؟", color = Navy, fontWeight = FontWeight.Black)
        },
        text = {
            Text("«${stage.title}» از مسیر پیشرفت حذف می‌شود.", color = Muted)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = FailRed),
                shape = RoundedCornerShape(14.dp)
            ) { Text("حذف") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
private fun ProgressDialogShell(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFFFBFDFF),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.18f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                content = content
            )
        }
    }
}
