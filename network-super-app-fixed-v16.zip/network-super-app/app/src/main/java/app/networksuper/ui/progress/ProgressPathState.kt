package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf

/** Shared source of truth for Progress Path and Home. */
enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus
)

object ProgressPathStore {
    private const val PREFS_NAME = "progress_path_v1"
    private const val KEY_STAGES = "stages"

    private val defaultStages = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    )

    val stages = mutableStateListOf<ProgressStage>().apply { addAll(defaultStages) }

    private var prefs: SharedPreferences? = null

    fun initialize(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val stored = prefs?.getString(KEY_STAGES, null)
        val parsed = stored?.let(::decodeStages).orEmpty()
        if (parsed.isNotEmpty()) {
            stages.clear()
            stages.addAll(parsed.sortedByDescending { it.number })
        } else {
            persist()
        }
    }

    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    fun currentOrdinal(): Int {
        val current = currentStage() ?: return 0
        val ascending = stages.sortedBy { it.number }
        return ascending.indexOfFirst { it.id == current.id }.let { if (it >= 0) it + 1 else 0 }
    }

    fun numberIsAvailable(number: Int, excludingId: Long? = null): Boolean =
        number > 0 && stages.none { it.number == number && it.id != excludingId }

    fun addStage(title: String, number: Int) {
        if (title.isBlank() || !numberIsAvailable(number)) return
        val nextId = (stages.maxOfOrNull { it.id } ?: 0L) + 1L
        stages.add(
            ProgressStage(
                id = nextId,
                number = number,
                title = title.trim(),
                status = StageStatus.UPCOMING
            )
        )
        sortAndPersist()
    }

    fun editStage(id: Long, title: String, number: Int) {
        if (title.isBlank() || !numberIsAvailable(number, id)) return
        val index = stages.indexOfFirst { it.id == id }
        if (index < 0) return
        stages[index] = stages[index].copy(title = title.trim(), number = number)
        sortAndPersist()
    }

    fun deleteStage(id: Long) {
        val target = stages.firstOrNull { it.id == id } ?: return
        val wasCurrent = target.status == StageStatus.CURRENT
        val previousNumber = target.number
        stages.removeAll { it.id == id }
        if (wasCurrent) promoteNextAfter(previousNumber)
        sortAndPersist()
    }

    fun setCurrent(id: Long) {
        val target = stages.firstOrNull { it.id == id } ?: return
        for (index in stages.indices) {
            val stage = stages[index]
            stages[index] = when {
                stage.id == target.id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        persist()
    }

    fun markCompleted(id: Long) = markResult(id, StageStatus.COMPLETED)

    fun markFailed(id: Long) = markResult(id, StageStatus.FAILED)

    private fun markResult(id: Long, result: StageStatus) {
        val target = stages.firstOrNull { it.id == id } ?: return
        val wasCurrent = target.status == StageStatus.CURRENT
        val previousNumber = target.number
        val index = stages.indexOfFirst { it.id == id }
        if (index >= 0) stages[index] = target.copy(status = result)
        if (wasCurrent) promoteNextAfter(previousNumber)
        sortAndPersist()
    }

    private fun promoteNextAfter(number: Int) {
        if (stages.any { it.status == StageStatus.CURRENT }) return
        val next = stages
            .filter { it.status == StageStatus.UPCOMING && it.number > number }
            .minByOrNull { it.number }
            ?: stages.filter { it.status == StageStatus.UPCOMING }.minByOrNull { it.number }
        if (next != null) {
            val index = stages.indexOfFirst { it.id == next.id }
            if (index >= 0) stages[index] = next.copy(status = StageStatus.CURRENT)
        }
    }

    private fun sortAndPersist() {
        val sorted = stages.sortedByDescending { it.number }
        stages.clear()
        stages.addAll(sorted)
        persist()
    }

    private fun persist() {
        prefs?.edit()?.putString(KEY_STAGES, encodeStages(stages))?.apply()
    }

    private fun encodeStages(items: List<ProgressStage>): String = items.joinToString("|") { stage ->
        val encodedTitle = Base64.encodeToString(stage.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        listOf(stage.id, stage.number, stage.status.name, encodedTitle).joinToString(",")
    }

    private fun decodeStages(raw: String): List<ProgressStage> = raw
        .split('|')
        .mapNotNull { token ->
            val parts = token.split(',', limit = 4)
            if (parts.size != 4) return@mapNotNull null
            runCatching {
                ProgressStage(
                    id = parts[0].toLong(),
                    number = parts[1].toInt(),
                    status = StageStatus.valueOf(parts[2]),
                    title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                )
            }.getOrNull()
        }
}
