# SuperApp 3D Gamification — Version 1 / Foundation

این ZIP ورژن اول پروژه مستقل گیمیفیکیشن سه‌بعدی است.

## هدف این نسخه

Foundation پایدار برای تمام نسخه‌های بعدی:

- Android Native
- Kotlin + Jetpack Compose
- Landscape Fullscreen / Immersive
- Package ثابت: `com.superapp.progressgame`
- Signing ثابت برای Update APK
- Version Code = 4
- Save Schema = 1
- World Schema = 1
- Local Progress Storage
- Graphics / Sound / Haptic / Debug preferences
- Splash / Gateway / World Shell / Settings / System Status
- HUD کوچک بازی
- ساختار جدا برای Core / Storage / Debug / UI
- Feature Flags برای موتورهای نسخه‌های بعدی
- آماده برای اتصال Renderer سه‌بعدی واقعی در Version 2

## نکته مهم

World Shell در V1 فقط یک نمای کدمحور برای تثبیت HUD و ساختار صفحه بازی است.
هیچ Renderer سه‌بعدی جعلی به عنوان موتور نهایی معرفی نشده است.
موتور 3D واقعی و Camera 3D در V2 اضافه می‌شوند.

## Build

Workflow موجود در Repository باید ZIP را Extract کند و دستور زیر را اجرا کند:

```bash
./gradlew assembleDebug --stacktrace --no-daemon
```

APK در مسیر استاندارد زیر تولید می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`
