# Version 01 — Foundation

## Included

1. Native Android project skeleton
2. Kotlin + Compose
3. Gradle / Java 17 compatibility
4. Landscape fullscreen shell
5. Code-only UI foundation
6. Game Gateway
7. World Shell
8. Compact HUD
9. Local player progress model
10. Persistent foundation preferences
11. Reset progress
12. Save/world schema versioning
13. Feature flags
14. Debug status screen
15. Stable package/signing contract
16. Separation points for V2 3D engine

## Explicitly deferred to V2

- Filament / SceneView renderer
- real XYZ camera
- 3D terrain
- PBR models/materials
- orbit/pan/pinch in 3D
- scene graph
