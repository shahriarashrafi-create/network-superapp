# APK Update Contract

Do not change these without an explicit migration decision:

- `applicationId = com.superapp.progressgame`
- stable signing keystore and alias
- save preference names and schema migration rules

Every future APK must use a strictly greater `versionCode`.
Save migrations must be non-destructive.
