# V1 Foundation Architecture

```text
app
└── com.superapp.progressgame
    ├── MainActivity
    ├── core
    │   ├── config
    │   │   ├── AppConfig
    │   │   └── FeatureFlags
    │   ├── model
    │   │   └── PlayerProgress
    │   ├── storage
    │   │   ├── FoundationPreferences
    │   │   ├── ProgressRepository
    │   │   └── LocalProgressRepository
    │   └── di
    │       └── AppContainer
    ├── debug
    │   └── DebugSnapshot
    └── ui
        ├── GameFoundationApp
        ├── components
        │   └── GameHud
        ├── screens
        │   ├── BootScreen
        │   ├── GatewayScreen
        │   ├── WorldShellScreen
        │   ├── SettingsScreen
        │   └── DebugScreen
        └── theme
```

## V2 insertion points

Version 2 must add the real 3D renderer without rewriting the foundation:

- `engine/scene`
- `engine/camera`
- `engine/render`
- `world/terrain`
- `world/objects`
- `assets/3d`

The V1 Compose HUD stays above the renderer layer.
