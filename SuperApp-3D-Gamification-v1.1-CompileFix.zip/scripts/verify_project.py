from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradlew",
    "gradle/wrapper/gradle-wrapper.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/superapp/progressgame/MainActivity.kt",
    "keystore/superapp.jks",
]

errors = []
for item in required:
    if not (root / item).is_file():
        errors.append(f"missing: {item}")

build = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")

checks = {
    "applicationId": 'applicationId = "com.superapp.progressgame"' in build,
    "versionCode": bool(re.search(r"versionCode\s*=\s*4\b", build)),
    "stable signing": 'signingConfigs.getByName("stable")' in build,
    "landscape": 'android:screenOrientation="landscape"' in manifest,
}

for name, ok in checks.items():
    if not ok:
        errors.append(f"check failed: {name}")

large_assets = [p for p in root.rglob("*") if p.is_file() and p.stat().st_size > 5_000_000]
if large_assets:
    errors.append("unexpected files over 5 MB: " + ", ".join(str(p.relative_to(root)) for p in large_assets))

if errors:
    print("PROJECT VERIFY: FAILED")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("PROJECT VERIFY: OK")
print("Package: com.superapp.progressgame")
print("Version code: 4")
print("Foundation files:", sum(1 for p in root.rglob("*") if p.is_file()))
