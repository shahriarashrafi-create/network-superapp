# Version 1 foundation: no custom shrinking rules are required yet.
