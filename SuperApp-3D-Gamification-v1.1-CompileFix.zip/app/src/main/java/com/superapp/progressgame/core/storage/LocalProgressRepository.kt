package com.superapp.progressgame.core.storage

import android.content.Context
import com.superapp.progressgame.core.config.AppConfig
import com.superapp.progressgame.core.model.PlayerProgress

class LocalProgressRepository(context: Context) : ProgressRepository {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override fun load(): PlayerProgress = PlayerProgress(
        level = prefs.getInt(KEY_LEVEL, 1).coerceAtLeast(1),
        xp = prefs.getInt(KEY_XP, 0).coerceAtLeast(0),
        coins = prefs.getInt(KEY_COINS, 0).coerceAtLeast(0),
        activeRegionId = prefs.getString(KEY_REGION, AppConfig.DEFAULT_REGION_ID)
            ?: AppConfig.DEFAULT_REGION_ID,
        regionProgressPercent = prefs.getInt(KEY_REGION_PROGRESS, 0).coerceIn(0, 100),
    )

    override fun save(progress: PlayerProgress) {
        prefs.edit()
            .putInt(KEY_SCHEMA, AppConfig.SAVE_SCHEMA_VERSION)
            .putInt(KEY_LEVEL, progress.level)
            .putInt(KEY_XP, progress.xp)
            .putInt(KEY_COINS, progress.coins)
            .putString(KEY_REGION, progress.activeRegionId)
            .putInt(KEY_REGION_PROGRESS, progress.regionProgressPercent)
            .apply()
    }

    override fun reset(): PlayerProgress {
        val fresh = PlayerProgress()
        prefs.edit().clear().apply()
        save(fresh)
        return fresh
    }

    companion object {
        private const val PREFS_NAME = "progress_world_save"
        private const val KEY_SCHEMA = "save_schema"
        private const val KEY_LEVEL = "level"
        private const val KEY_XP = "xp"
        private const val KEY_COINS = "coins"
        private const val KEY_REGION = "active_region"
        private const val KEY_REGION_PROGRESS = "region_progress"
    }
}
