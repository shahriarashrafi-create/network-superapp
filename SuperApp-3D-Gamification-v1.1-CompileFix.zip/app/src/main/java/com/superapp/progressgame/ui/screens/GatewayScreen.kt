package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.DeepSurface
import com.superapp.progressgame.ui.theme.ElevatedSurface
import com.superapp.progressgame.ui.theme.PrimaryBlue

@Composable
fun GatewayScreen(
    progress: PlayerProgress,
    onEnterWorld: () -> Unit,
    onSettings: () -> Unit,
    onDebug: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF07111F), Color(0xFF0A2037), Color(0xFF07111F))
                )
            )
            .padding(horizontal = 34.dp, vertical = 24.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(
                modifier = Modifier.weight(0.52f),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("دنیای تو از اقدام‌ها ساخته می‌شود", color = Color.White, fontSize = 31.sp)
                Text(
                    "ورژن ۱، پایهٔ پایدار پروژهٔ سه‌بعدی است. از ورژن بعد موتور 3D واقعی روی همین اسکلت فعال می‌شود.",
                    color = Color(0xFFA9B8CE),
                    fontSize = 14.sp,
                    lineHeight = 23.sp,
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onEnterWorld,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("ورود به دنیا")
                    }
                    OutlinedButton(onClick = onSettings) {
                        Icon(Icons.Rounded.Settings, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("تنظیمات")
                    }
                    OutlinedButton(onClick = onDebug) {
                        Icon(Icons.Rounded.BugReport, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("وضعیت سیستم")
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(0.38f)
                    .background(DeepSurface.copy(alpha = 0.92f), RoundedCornerShape(26.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(26.dp))
                    .padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Foundation Status", color = AccentCyan, fontSize = 12.sp)
                Text("LEVEL ${progress.level}", color = Color.White, fontSize = 24.sp)
                FoundationMetric("XP", progress.xp.toString())
                FoundationMetric("COIN", progress.coins.toString())
                FoundationMetric("SAVE SCHEMA", "1")
                FoundationMetric("WORLD SCHEMA", "1")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ElevatedSurface, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Text("3D Renderer: آماده برای اتصال در V2", color = Color(0xFFA9B8CE), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun FoundationMetric(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(value, color = Color.White, fontSize = 14.sp)
        Text(label, color = Color(0xFF8194AE), fontSize = 11.sp)
    }
}
