package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.core.storage.GraphicsProfile
import com.superapp.progressgame.ui.theme.DeepSurface

@Composable
fun SettingsScreen(
    preferences: FoundationPreferences,
    onResetProgress: () -> Unit,
    onBack: () -> Unit,
) {
    var graphics by remember { mutableStateOf(preferences.graphicsProfile) }
    var sound by remember { mutableStateOf(preferences.soundEnabled) }
    var haptics by remember { mutableStateOf(preferences.hapticsEnabled) }
    var debug by remember { mutableStateOf(preferences.debugOverlayEnabled) }

    Column(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("تنظیمات پایه", color = Color.White, fontSize = 27.sp)
        Text("تنظیماتی که از همین نسخه ذخیره می‌شوند و در نسخه‌های بعدی گسترش پیدا می‌کنند.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)

        Column(
            modifier = Modifier.fillMaxWidth().background(DeepSurface, RoundedCornerShape(22.dp)).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp),
        ) {
            Text("پروفایل گرافیک", color = Color.White, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GraphicsProfile.entries.forEach { profile ->
                    FilterChip(
                        selected = graphics == profile,
                        onClick = {
                            graphics = profile
                            preferences.graphicsProfile = profile
                        },
                        label = { Text(profile.displayName()) },
                    )
                }
            }
            ToggleSetting("صدا", sound) {
                sound = it
                preferences.soundEnabled = it
            }
            ToggleSetting("هپتیک", haptics) {
                haptics = it
                preferences.hapticsEnabled = it
            }
            ToggleSetting("Debug Overlay", debug) {
                debug = it
                preferences.debugOverlayEnabled = it
            }
        }

        Spacer(Modifier.height(2.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onBack) { Text("ذخیره و برگشت") }
            OutlinedButton(onClick = onResetProgress) { Text("Reset Progress") }
        }
    }
}

@Composable
private fun ToggleSetting(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Switch(checked = checked, onCheckedChange = onCheckedChange)
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}

private fun GraphicsProfile.displayName(): String = when (this) {
    GraphicsProfile.AUTO -> "Auto"
    GraphicsProfile.PERFORMANCE -> "Performance"
    GraphicsProfile.QUALITY -> "Quality"
}
