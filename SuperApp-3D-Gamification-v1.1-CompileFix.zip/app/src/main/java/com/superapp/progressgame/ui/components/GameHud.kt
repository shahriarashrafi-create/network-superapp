package com.superapp.progressgame.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.ui.theme.ElevatedSurface
import com.superapp.progressgame.ui.theme.SuccessGreen

@Composable
fun GameHud(
    progress: PlayerProgress,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Row(
            modifier = Modifier
                .background(ElevatedSurface.copy(alpha = 0.88f), RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Lv ${progress.level}", color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.width(10.dp))
            LinearProgressIndicator(
                progress = { (progress.xp % 100) / 100f },
                modifier = Modifier.width(110.dp).height(5.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.12f),
            )
            Spacer(Modifier.width(8.dp))
            Text("${progress.xp} XP", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
        }

        Row(
            modifier = Modifier
                .background(ElevatedSurface.copy(alpha = 0.88f), RoundedCornerShape(18.dp))
                .padding(start = 6.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .background(SuccessGreen.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
                Text("◉ ${progress.coins}", color = SuccessGreen, fontSize = 13.sp)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات", tint = Color.White)
            }
        }
    }
}
