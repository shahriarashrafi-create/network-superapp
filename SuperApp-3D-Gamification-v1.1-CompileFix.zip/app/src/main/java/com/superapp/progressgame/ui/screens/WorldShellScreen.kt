package com.superapp.progressgame.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.superapp.progressgame.core.model.PlayerProgress
import com.superapp.progressgame.ui.components.GameHud
import com.superapp.progressgame.ui.theme.AccentCyan
import com.superapp.progressgame.ui.theme.ElevatedSurface
import com.superapp.progressgame.ui.theme.GridLine
import com.superapp.progressgame.ui.theme.PrimaryBlue

@Composable
fun WorldShellScreen(
    progress: PlayerProgress,
    debugOverlayEnabled: Boolean,
    onBack: () -> Unit,
    onSettings: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF07111F), Color(0xFF102B44), Color(0xFF081522))
                )
            )
    ) {
        PerspectiveFoundationGrid(Modifier.fillMaxSize())

        GameHud(
            progress = progress,
            onSettings = onSettings,
            modifier = Modifier.fillMaxWidth().padding(18.dp),
        )

        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.CenterStart).padding(16.dp)
                .background(ElevatedSurface.copy(alpha = 0.9f), RoundedCornerShape(16.dp)),
        ) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "برگشت", tint = Color.White)
        }

        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("FOUNDATION WORLD", color = Color.White, fontSize = 20.sp)
            Text("محل اتصال موتور سه‌بعدی واقعی در Version 2", color = Color(0xFFA9B8CE), fontSize = 12.sp)
        }

        FloatingActionButton(
            onClick = { },
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
            containerColor = PrimaryBlue,
            contentColor = Color.White,
        ) {
            Icon(Icons.Rounded.MyLocation, contentDescription = "ماموریت")
        }

        if (debugOverlayEnabled) {
            Column(
                modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                Text("DEBUG FOUNDATION", color = AccentCyan, fontSize = 10.sp)
                Text("Renderer: OFF (V2)", color = Color.White, fontSize = 10.sp)
                Text("Camera profile: overview", color = Color.White, fontSize = 10.sp)
                Text("Region: ${progress.activeRegionId}", color = Color.White, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun PerspectiveFoundationGrid(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val horizonY = size.height * 0.42f
        val vanish = Offset(size.width * 0.5f, horizonY)
        val bottomY = size.height

        repeat(17) { index ->
            val x = size.width * index / 16f
            drawLine(
                color = GridLine.copy(alpha = 0.65f),
                start = Offset(x, bottomY),
                end = vanish,
                strokeWidth = 1.2f,
            )
        }

        repeat(10) { index ->
            val t = index / 10f
            val eased = t * t
            val y = horizonY + (bottomY - horizonY) * eased
            val left = size.width * (0.5f - 0.5f * eased)
            val right = size.width * (0.5f + 0.5f * eased)
            drawLine(
                color = GridLine.copy(alpha = 0.56f),
                start = Offset(left, y),
                end = Offset(right, y),
                strokeWidth = 1.1f,
            )
        }

        val marker = Path().apply {
            moveTo(vanish.x, vanish.y - 32f)
            lineTo(vanish.x + 24f, vanish.y)
            lineTo(vanish.x, vanish.y + 32f)
            lineTo(vanish.x - 24f, vanish.y)
            close()
        }
        drawPath(marker, color = AccentCyan.copy(alpha = 0.75f), style = Stroke(width = 2f))
    }
}
