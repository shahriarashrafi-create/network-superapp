package com.superapp.progressgame.core.config

object AppConfig {
    const val APP_ID = "com.superapp.progressgame"
    const val FOUNDATION_VERSION = "1.0.0-foundation"
    const val SAVE_SCHEMA_VERSION = 1
    const val WORLD_SCHEMA_VERSION = 1
    const val DEFAULT_REGION_ID = "foundation_region"
    const val DEFAULT_CAMERA_PROFILE = "overview"
}
