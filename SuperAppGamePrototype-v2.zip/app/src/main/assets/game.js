(() => {
  'use strict';

  let WORLD_W = 1536;
  let WORLD_H = 864;
  const STORE = {
    missions: 'superapp.missions.v1',
    stats: 'superapp.stats.v1',
    started: 'superapp.started.v1'
  };

  const visualCatalog = [
    { key:'gate', name:'دروازه ورودی', icon:'🚪' },
    { key:'fountain', name:'فواره محوطه', icon:'⛲' },
    { key:'garden', name:'فضای سبز و درخت‌ها', icon:'🌳' },
    { key:'path', name:'مسیر و محوطه', icon:'🛣️' },
    { key:'villa', name:'ویلای اصلی', icon:'🏡' },
    { key:'terrace', name:'تراس و باغ', icon:'🌿' },
    { key:'interior', name:'فضای داخلی', icon:'🛋️' },
    { key:'pool', name:'استخر لوکس', icon:'🏊' },
    { key:'lounge', name:'لانژ و آتشدان', icon:'🔥' },
    { key:'dream', name:'ویلای رؤیایی', icon:'💎' }
  ];

  const zoneNames = [
    'ورودی و محوطه بیرونی',
    'حیاط و باغ',
    'فضای داخلی اصلی',
    'بخش لوکس و استخر',
    'ویلای کامل رؤیایی'
  ];

  // Coordinates are intentionally tied to the approved villa artwork.
  const stageAnchors = {
    1: [
      {x:120,y:100, visual:'gate'},
      {x:250,y:145, visual:'fountain'},
      {x:430,y:220, visual:'garden'},
      {x:635,y:182, visual:'path'},
      {x:760,y:95, visual:'villa'}
    ],
    2: [
      {x:575,y:300, visual:'garden'},
      {x:650,y:395, visual:'fountain'},
      {x:495,y:420, visual:'terrace'},
      {x:685,y:560, visual:'garden'},
      {x:755,y:515, visual:'path'}
    ],
    3: [
      {x:845,y:95, visual:'interior'},
      {x:930,y:125, visual:'interior'},
      {x:1025,y:110, visual:'interior'},
      {x:1110,y:170, visual:'terrace'},
      {x:845,y:235, visual:'villa'}
    ],
    4: [
      {x:1220,y:125, visual:'pool'},
      {x:1370,y:82, visual:'lounge'},
      {x:1280,y:235, visual:'terrace'},
      {x:1440,y:300, visual:'garden'},
      {x:1380,y:210, visual:'path'}
    ],
    5: [
      {x:1225,y:410, visual:'fountain'},
      {x:1320,y:520, visual:'garden'},
      {x:1160,y:650, visual:'terrace'},
      {x:1400,y:675, visual:'garden'},
      {x:1180,y:600, visual:'dream'}
    ]
  };

  const fogZones = {
    1: {x:0,y:0,w:820,h:300},
    2: {x:360,y:230,w:520,h:420},
    3: {x:620,y:0,w:560,h:270},
    4: {x:1040,y:0,w:496,h:320},
    5: {x:930,y:290,w:606,h:574}
  };

  const rewardPreset = {
    low: { coins:40, xp:80 },
    medium: { coins:60, xp:120 },
    high: { coins:90, xp:180 }
  };

  const defaultMissions = [
    {r:1,s:1,t:'شروع ارتباط‌سازی',d:'با ۳ نفر از لیستت تماس بگیر و یک گفت‌وگوی کوتاه شروع کن.',i:'medium',v:'gate'},
    {r:1,s:2,t:'ساخت لیست اولیه',d:'۱۰ مخاطب مناسب برای گفت‌وگوهای بعدی به لیستت اضافه کن.',i:'low',v:'fountain'},
    {r:1,s:3,t:'پیگیری مخاطب‌ها',d:'با ۲ نفری که قبلاً صحبت کرده‌ای یک پیگیری کوتاه انجام بده.',i:'medium',v:'garden'},
    {r:1,s:4,t:'دعوت به معرفی فرصت',d:'از یک مخاطب برای شنیدن معرفی کوتاه فرصت کاری دعوت کن.',i:'high',v:'path'},
    {r:1,s:5,t:'ثبت نتیجه روز',d:'نتیجه گفت‌وگوها و قدم بعد هر مخاطب را ثبت کن.',i:'low',v:'villa'},

    {r:2,s:1,t:'گسترش ارتباط‌ها',d:'۵ ارتباط تازه برای شبکه‌سازی ایجاد کن.',i:'medium',v:'garden'},
    {r:2,s:2,t:'تمرین معرفی کوتاه',d:'متن معرفی ۶۰ ثانیه‌ای خودت را یک بار تمرین و اصلاح کن.',i:'medium',v:'fountain'},
    {r:2,s:3,t:'دعوت هدفمند',d:'۲ دعوت هدفمند برای گفت‌وگوی جدی‌تر ارسال کن.',i:'high',v:'terrace'},
    {r:2,s:4,t:'پیگیری حرفه‌ای',d:'پیگیری‌ها را بر اساس علاقه و زمان مناسب اولویت‌بندی کن.',i:'medium',v:'garden'},
    {r:2,s:5,t:'جمع‌بندی ارتباط‌ها',d:'برای هر مخاطب قدم بعدی مشخص و زمان‌بندی کن.',i:'low',v:'path'},

    {r:3,s:1,t:'شناخت نیاز مشتری',d:'در یک گفت‌وگو سه سؤال برای شناخت نیاز واقعی مشتری بپرس.',i:'high',v:'interior'},
    {r:3,s:2,t:'معرفی محصول',d:'یک معرفی کوتاه و متناسب با نیاز مخاطب انجام بده.',i:'high',v:'interior'},
    {r:3,s:3,t:'پاسخ به سؤال‌ها',d:'سه سؤال رایج مشتری‌ها را آماده و پاسخ‌ها را مرور کن.',i:'medium',v:'interior'},
    {r:3,s:4,t:'پیگیری فروش',d:'یک پیگیری محترمانه برای تصمیم‌گیری مشتری انجام بده.',i:'medium',v:'terrace'},
    {r:3,s:5,t:'ثبت تجربه مشتری',d:'نتیجه و بازخورد مشتری را برای بهبود گفت‌وگوها ثبت کن.',i:'low',v:'villa'},

    {r:4,s:1,t:'شروع همراهی عضو جدید',d:'برای یک عضو جدید قدم اول مشخص و ساده تعریف کن.',i:'high',v:'pool'},
    {r:4,s:2,t:'آموزش کوتاه',d:'یک آموزش ۱۰ دقیقه‌ای درباره مهارت ارتباطی برگزار کن.',i:'medium',v:'lounge'},
    {r:4,s:3,t:'پیگیری تیمی',d:'با یک هم‌تیمی درباره پیشرفت و مانع فعلی گفت‌وگو کن.',i:'medium',v:'terrace'},
    {r:4,s:4,t:'تکثیر یک عادت',d:'یک رفتار ساده و قابل تکرار را به هم‌تیمی منتقل کن.',i:'high',v:'garden'},
    {r:4,s:5,t:'هدف هفته تیم',d:'یک هدف کوتاه و قابل اندازه‌گیری برای هفته تعیین کن.',i:'medium',v:'path'},

    {r:5,s:1,t:'برنامه رهبری هفته',d:'سه اولویت اصلی هفته را مشخص و زمان‌بندی کن.',i:'high',v:'villa'},
    {r:5,s:2,t:'کوچینگ یک نفر',d:'یک گفت‌وگوی کوچینگ کوتاه با تمرکز روی اقدام بعدی انجام بده.',i:'high',v:'terrace'},
    {r:5,s:3,t:'جلسه جمع‌بندی',d:'یک جلسه کوتاه برای مرور بردها و چالش‌ها برگزار کن.',i:'medium',v:'lounge'},
    {r:5,s:4,t:'بهبود سیستم',d:'یک بخش از فرایند پیگیری یا آموزش را ساده‌تر کن.',i:'medium',v:'garden'},
    {r:5,s:5,t:'ثبت نقطه عطف',d:'نتیجه مسیر را ثبت کن و هدف بعدی را برای خودت بنویس.',i:'high',v:'dream'}
  ].map((m, idx) => ({
    id: 'm' + (idx + 1), region:m.r, step:m.s, title:m.t, description:m.d,
    importance:m.i, visual:m.v, coins:rewardPreset[m.i].coins, xp:rewardPreset[m.i].xp,
    completed:false
  }));

  const $ = id => document.getElementById(id);
  const mapViewport = $('mapViewport');
  const mapWorld = $('mapWorld');
  const fogCanvas = $('fogCanvas');
  const fog = fogCanvas.getContext('2d');
  const markerLayer = $('markerLayer');
  const gameScreen = $('gameScreen');
  const managerScreen = $('managerScreen');
  const missionFab = $('missionFab');
  const missionCard = $('missionCard');

  let missions = loadMissions();
  let stats = loadStats();
  let startedMissionId = localStorage.getItem(STORE.started) || '';
  let transform = { scale:1, tx:0, ty:0 };
  let revealAnim = null;
  let pointers = new Map();
  let pinchStart = null;
  let lastPan = null;
  let userInteracting = false;
  let missionPanelOpen = false;

  function setWorldSize() {
    fogCanvas.width = WORLD_W;
    fogCanvas.height = WORLD_H;
    mapWorld.style.width = WORLD_W + 'px';
    mapWorld.style.height = WORLD_H + 'px';
    markerLayer.style.width = WORLD_W + 'px';
    markerLayer.style.height = WORLD_H + 'px';
    $('worldImage').style.width = WORLD_W + 'px';
    $('worldImage').style.height = WORLD_H + 'px';
  }

  function fa(n) {
    return Number(n || 0).toLocaleString('fa-IR');
  }

  function loadMissions() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE.missions));
      if (Array.isArray(raw) && raw.length) return raw;
    } catch(e) {}
    const copy = JSON.parse(JSON.stringify(defaultMissions));
    localStorage.setItem(STORE.missions, JSON.stringify(copy));
    return copy;
  }

  function loadStats() {
    try {
      const s = JSON.parse(localStorage.getItem(STORE.stats));
      if (s && Number.isFinite(s.totalXp)) return s;
    } catch(e) {}
    return {coins:0,totalXp:0};
  }

  function saveAll() {
    localStorage.setItem(STORE.missions, JSON.stringify(missions));
    localStorage.setItem(STORE.stats, JSON.stringify(stats));
    if (startedMissionId) localStorage.setItem(STORE.started, startedMissionId);
    else localStorage.removeItem(STORE.started);
  }

  function sortedMissions() {
    return [...missions].sort((a,b) => (a.region-b.region) || (a.step-b.step));
  }

  function activeMission() {
    return sortedMissions().find(m => !m.completed) || null;
  }

  function missionsInRegion(region) {
    return sortedMissions().filter(m => m.region === region);
  }

  function isRegionComplete(region) {
    const list = missionsInRegion(region);
    return list.length > 0 && list.every(m => m.completed);
  }

  function completedCount() { return missions.filter(m => m.completed).length; }

  function levelInfo() {
    const perLevel = 500;
    const level = Math.floor(stats.totalXp / perLevel) + 1;
    const current = stats.totalXp % perLevel;
    return { level, current, need:perLevel, pct:(current/perLevel)*100 };
  }

  function anchorFor(mission) {
    const list = stageAnchors[mission.region] || stageAnchors[1];
    const idx = Math.max(0, Math.min(list.length-1, mission.step-1));
    const base = list[idx];
    return { ...base, visual: mission.visual || base.visual };
  }

  function visualInfo(key) {
    return visualCatalog.find(v => v.key === key) || visualCatalog[0];
  }

  function importanceText(v) { return v === 'high' ? 'بالا' : v === 'low' ? 'کم' : 'متوسط'; }

  function updateHud() {
    const li = levelInfo();
    $('levelText').textContent = `سطح ${fa(li.level)}`;
    $('xpText').textContent = `${fa(li.current)} / ${fa(li.need)} XP`;
    $('xpBar').style.width = `${li.pct}%`;
    $('coinText').textContent = fa(stats.coins);
    $('totalXpText').textContent = fa(stats.totalXp);
    const total = Math.max(missions.length,1);
    $('progressText').textContent = `${fa(Math.round((completedCount()/total)*100))}٪`;
  }

  function updateMissionCard() {
    const m = activeMission();
    if (!m) {
      missionFab.textContent = '✓';
      missionFab.disabled = true;
      $('missionTitle').textContent = 'مسیر فعلی کامل شد!';
      $('missionDescription').textContent = 'همه مأموریت‌ها انجام شده‌اند. می‌توانی از مدیریت مأموریت‌ها مسیر تازه بسازی.';
      $('missionActionBtn').textContent = 'تکمیل شد';
      $('missionActionBtn').disabled = true;
      $('visualIcon').textContent = '🏆';
      $('visualName').textContent = 'ویلای رؤیایی';
      $('rewardCoins').textContent = '+۰';
      $('rewardXp').textContent = '+۰';
      $('stepProgressBar').style.width = '100%';
      $('stepProgressText').textContent = 'همه مناطق کامل شدند';
      return;
    }
    missionFab.disabled = false;
    missionFab.textContent = startedMissionId === m.id ? '✓' : '▶';
    const v = visualInfo(m.visual || anchorFor(m).visual);
    $('visualIcon').textContent = v.icon;
    $('visualName').textContent = `منطقه ${fa(m.region)} · ${v.name}`;
    $('missionTitle').textContent = m.title;
    $('missionDescription').textContent = m.description || 'این مأموریت را انجام بده و بخش بعدی ویلایت را آشکار کن.';
    const badge = $('importanceBadge');
    badge.className = `importance ${m.importance || 'medium'}`;
    badge.textContent = importanceText(m.importance);
    $('rewardCoins').textContent = `+${fa(m.coins)}`;
    $('rewardXp').textContent = `+${fa(m.xp)}`;
    const regionList = missionsInRegion(m.region);
    const done = regionList.filter(x=>x.completed).length;
    $('stepProgressBar').style.width = `${regionList.length ? (done/regionList.length)*100 : 0}%`;
    $('stepProgressText').textContent = `پیشرفت منطقه ${fa(done)} / ${fa(regionList.length)}`;
    $('missionActionBtn').textContent = startedMissionId === m.id ? 'انجام شد ✓' : 'شروع مأموریت';
  }

  function updateMarkers() {
    markerLayer.innerHTML = '';
    const active = activeMission();
    const currentRegion = active ? active.region : 6;
    sortedMissions().forEach(m => {
      const a = anchorFor(m);
      const v = visualInfo(m.visual || a.visual);
      const el = document.createElement('div');
      el.className = 'marker';
      el.style.left = a.x + 'px';
      el.style.top = a.y + 'px';
      el.dataset.id = m.id;
      if (m.completed) {
        el.classList.add('completed');
        el.textContent = '✓';
      } else if (active && active.id === m.id) {
        el.classList.add('active');
        el.textContent = v.icon;
      } else if (m.region > currentRegion || (m.region === currentRegion && m.step > active.step)) {
        el.classList.add('locked');
        el.textContent = '🔒';
      } else {
        el.textContent = v.icon;
      }
      markerLayer.appendChild(el);
    });
  }

  function seededCloudPoints(zone, region) {
    const pts=[];
    let seed = 1201 + region*991;
    const rand=()=>{ seed=(seed*9301+49297)%233280; return seed/233280; };
    const count = 22 + region*2;
    for(let i=0;i<count;i++) {
      pts.push({
        x: zone.x + rand()*zone.w,
        y: zone.y + rand()*zone.h,
        r: 75 + rand()*115,
        a: .30 + rand()*.25
      });
    }
    return pts;
  }

  const cloudCache = Object.fromEntries(Object.entries(fogZones).map(([r,z])=>[r,seededCloudPoints(z,+r)]));

  function drawCloudBlob(p) {
    const g = fog.createRadialGradient(p.x,p.y,p.r*.12,p.x,p.y,p.r);
    g.addColorStop(0,`rgba(245,249,251,${Math.min(.82,p.a+.25)})`);
    g.addColorStop(.5,`rgba(220,230,236,${p.a})`);
    g.addColorStop(1,'rgba(210,224,231,0)');
    fog.fillStyle=g;
    fog.beginPath();
    fog.arc(p.x,p.y,p.r,0,Math.PI*2);
    fog.fill();
  }

  function clearReveal(x,y,r) {
    fog.save();
    fog.globalCompositeOperation = 'destination-out';
    const g = fog.createRadialGradient(x,y,r*.2,x,y,r);
    g.addColorStop(0,'rgba(0,0,0,1)');
    g.addColorStop(.74,'rgba(0,0,0,.96)');
    g.addColorStop(1,'rgba(0,0,0,0)');
    fog.fillStyle=g;
    fog.beginPath(); fog.arc(x,y,r,0,Math.PI*2); fog.fill();
    fog.restore();
  }

  function drawFog() {
    fog.clearRect(0,0,WORLD_W,WORLD_H);
    const active = activeMission();
    const currentRegion = active ? active.region : 6;

    for (let region=1; region<=5; region++) {
      if (isRegionComplete(region)) continue;
      const locked = region > currentRegion;
      fog.save();
      fog.globalAlpha = locked ? .98 : .78;
      cloudCache[region].forEach(drawCloudBlob);
      fog.restore();

      const regionMissions = missionsInRegion(region);
      regionMissions.filter(m=>m.completed).forEach(m => {
        const a = anchorFor(m);
        let radius = 175;
        if (revealAnim && revealAnim.id === m.id) radius *= revealAnim.t;
        clearReveal(a.x,a.y,radius);
      });

      // The active objective peeks through the fog, creating anticipation.
      if (active && active.region === region) {
        const a = anchorFor(active);
        clearReveal(a.x,a.y,95);
      }
    }
  }

  function animateReveal(mission, done) {
    const started = performance.now();
    revealAnim = {id:mission.id,t:0};
    const tick = now => {
      const p = Math.min(1,(now-started)/1150);
      revealAnim.t = 1 - Math.pow(1-p,3);
      drawFog();
      if (p<1) requestAnimationFrame(tick);
      else { revealAnim=null; drawFog(); if(done) done(); }
    };
    requestAnimationFrame(tick);
  }

  function minScale() {
    return Math.max(mapViewport.clientWidth/WORLD_W, mapViewport.clientHeight/WORLD_H);
  }

  function clampTransform() {
    const min = minScale();
    transform.scale = Math.max(min, Math.min(min*2.5, transform.scale));
    const ww = WORLD_W*transform.scale;
    const wh = WORLD_H*transform.scale;
    const vw = mapViewport.clientWidth;
    const vh = mapViewport.clientHeight;
    if (ww <= vw) transform.tx = (vw-ww)/2;
    else transform.tx = Math.min(0, Math.max(vw-ww, transform.tx));
    if (wh <= vh) transform.ty = (vh-wh)/2;
    else transform.ty = Math.min(0, Math.max(vh-wh, transform.ty));
  }

  function applyTransform() {
    clampTransform();
    mapWorld.style.transform = `translate3d(${transform.tx}px,${transform.ty}px,0) scale(${transform.scale})`;
  }

  function setInitialTransform() {
    transform.scale = minScale()*1.04;
    transform.tx = (mapViewport.clientWidth-WORLD_W*transform.scale)/2;
    transform.ty = (mapViewport.clientHeight-WORLD_H*transform.scale)/2;
    applyTransform();
  }

  function animateCameraTo(x,y,zoomFactor=1.72,duration=920) {
    const targetScale = Math.min(minScale()*2.2, minScale()*zoomFactor);
    const targetTx = mapViewport.clientWidth/2 - x*targetScale;
    const targetTy = mapViewport.clientHeight/2 - y*targetScale;
    const start = {...transform};
    const t0 = performance.now();
    const ease = p => 1-Math.pow(1-p,3);
    const frame = now => {
      const p = Math.min(1,(now-t0)/duration), e=ease(p);
      transform.scale = start.scale + (targetScale-start.scale)*e;
      transform.tx = start.tx + (targetTx-start.tx)*e;
      transform.ty = start.ty + (targetTy-start.ty)*e;
      applyTransform();
      if(p<1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }

  function zoomOutRegion(region, done) {
    const z = fogZones[region] || fogZones[1];
    const cx = z.x + z.w / 2, cy = z.y + z.h / 2;
    animateCameraTo(cx, cy, 1.12, 980);
    setTimeout(() => done && done(), 1000);
  }

  function focusActive() {
    const m = activeMission();
    if (!m) {
      animateCameraTo(WORLD_W / 2, WORLD_H / 2, 1.0, 980);
      return;
    }
    const a = anchorFor(m);
    animateCameraTo(a.x, a.y, 1.9, 860);
  }

  function toggleMissionPanel(force) {
    const next = typeof force === 'boolean' ? force : !missionPanelOpen;
    missionPanelOpen = next;
    missionCard.classList.toggle('collapsed', !missionPanelOpen);
    missionFab.classList.toggle('active', missionPanelOpen);
  }

  function showToast(text) {
    const t=$('toast'); t.textContent=text; t.classList.add('show');
    clearTimeout(showToast.timer); showToast.timer=setTimeout(()=>t.classList.remove('show'),1800);
  }

  function showReward(m) {
    const b=$('rewardBurst');
    b.innerHTML=`<span class="coin">●</span> +${fa(m.coins)} &nbsp;&nbsp; <span class="star">★</span> +${fa(m.xp)}`;
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  }

  function completeMission(m) {
    if (!m || m.completed) return;
    const regionBefore=m.region;
    m.completed=true;
    stats.coins += Number(m.coins)||0;
    stats.totalXp += Number(m.xp)||0;
    startedMissionId='';
    saveAll();
    showReward(m);
    updateHud();

    animateReveal(m, () => {
      const regionDone=isRegionComplete(regionBefore);
      updateMarkers();
      updateMissionCard();
      if (regionDone) {
        zoomOutRegion(regionBefore, () => showRegionComplete(regionBefore));
      } else {
        const next=activeMission();
        if(next) setTimeout(()=>{ const a=anchorFor(next); animateCameraTo(a.x,a.y,1.55,850); },260);
      }
    });
  }

  function showRegionComplete(region) {
    $('completeTitle').textContent = `${zoneNames[region-1]} کامل شد!`;
    $('completeSubtitle').textContent = region < 5 ? 'منطقه بعدی ویلای رؤیایی برایت باز شد.' : 'تمام مناطق این مسیر را کامل کردی.';
    $('completeModal').classList.remove('hidden');
    startConfetti();
  }

  function startConfetti() {
    const c=$('confettiCanvas'), ctx=c.getContext('2d');
    c.width=innerWidth; c.height=innerHeight;
    const parts=Array.from({length:90},()=>({x:Math.random()*c.width,y:-20-Math.random()*c.height*.4,vx:-1.2+Math.random()*2.4,vy:2+Math.random()*4,r:3+Math.random()*5,h:Math.floor(Math.random()*360),spin:Math.random()*6}));
    let start=performance.now();
    const draw=now=>{
      ctx.clearRect(0,0,c.width,c.height);
      parts.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.spin+=.1;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.spin);ctx.fillStyle=`hsl(${p.h} 85% 62%)`;ctx.fillRect(-p.r,-p.r/2,p.r*2,p.r);ctx.restore();});
      if(now-start<4500 && !$('completeModal').classList.contains('hidden')) requestAnimationFrame(draw); else ctx.clearRect(0,0,c.width,c.height);
    };
    requestAnimationFrame(draw);
  }

  $('continueBtn').addEventListener('click',()=>{
    $('completeModal').classList.add('hidden');
    const next=activeMission();
    if(next){ const a=anchorFor(next); setTimeout(()=>animateCameraTo(a.x,a.y,1.55,900),100); }
    else focusActive();
  });

  missionFab.addEventListener('click',()=>{
    toggleMissionPanel();
    if (missionPanelOpen) focusActive();
  });

  $('missionActionBtn').addEventListener('click',()=>{
    const m=activeMission(); if(!m) return;
    if(startedMissionId !== m.id) {
      startedMissionId=m.id; saveAll(); updateMissionCard(); toggleMissionPanel(true);
      const a=anchorFor(m); animateCameraTo(a.x,a.y,1.98,760);
      showToast('مأموریت شروع شد؛ بعد از انجام کار، «انجام شد» را بزن.');
    } else {
      completeMission(m);
    }
  });

  $('focusBtn').addEventListener('click',focusActive);
  $('settingsBtn').addEventListener('click',()=> $('settingsModal').classList.remove('hidden'));
  $('closeSettingsBtn').addEventListener('click',()=> $('settingsModal').classList.add('hidden'));
  $('openManagerBtn').addEventListener('click',()=>{ $('settingsModal').classList.add('hidden'); openManager(); });
  $('resetProgressBtn').addEventListener('click',()=>{
    if(!confirm('پیشرفت، سکه و XP از ابتدا شروع شود؟')) return;
    missions.forEach(m=>m.completed=false); stats={coins:0,totalXp:0}; startedMissionId=''; saveAll();
    $('settingsModal').classList.add('hidden'); updateAll(); setInitialTransform(); setTimeout(focusActive,250);
  });

  function openManager(){
    toggleMissionPanel(false);
    gameScreen.classList.remove('active'); managerScreen.classList.add('active'); renderManager();
  }
  function closeManager(){
    managerScreen.classList.remove('active'); gameScreen.classList.add('active'); updateAll(); setTimeout(focusActive,150);
  }
  $('closeManagerBtn').addEventListener('click',closeManager);

  function renderManager() {
    const list=$('missionList'); list.innerHTML='';
    for(let r=1;r<=5;r++){
      const heading=document.createElement('div'); heading.className='region-group region-heading';
      const count=missionsInRegion(r).length;
      heading.innerHTML=`<h3>منطقه ${fa(r)} — ${zoneNames[r-1]}</h3><span>${fa(count)} مأموریت</span>`;
      list.appendChild(heading);
      missionsInRegion(r).forEach(m=>{
        const v=visualInfo(m.visual);
        const row=document.createElement('div'); row.className='mission-row'+(m.completed?' completed-row':'');
        row.innerHTML=`<div class="row-icon">${m.completed?'✓':v.icon}</div><div class="row-copy"><h4>${escapeHtml(m.title)}</h4><div class="row-meta"><span class="meta-pill">مرحله ${fa(m.step)}</span><span class="meta-pill">اهمیت ${importanceText(m.importance)}</span><span class="meta-pill">${fa(m.coins)} سکه</span><span class="meta-pill">${fa(m.xp)} XP</span>${m.completed?'<span class="meta-pill">انجام شده</span>':''}</div></div><button class="edit-btn" type="button">ویرایش</button>`;
        row.querySelector('.edit-btn').addEventListener('click',()=>openMissionEditor(m));
        list.appendChild(row);
      });
    }
  }

  function escapeHtml(s='') { return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

  function fillEditorOptions() {
    $('editRegion').innerHTML = Array.from({length:5},(_,i)=>`<option value="${i+1}">منطقه ${fa(i+1)} — ${zoneNames[i]}</option>`).join('');
    $('editStep').innerHTML = Array.from({length:5},(_,i)=>`<option value="${i+1}">مرحله ${fa(i+1)}</option>`).join('');
    $('editVisual').innerHTML = visualCatalog.map(v=>`<option value="${v.key}">${v.icon} ${v.name}</option>`).join('');
  }

  function openMissionEditor(m=null) {
    fillEditorOptions();
    $('missionModalTitle').textContent=m?'ویرایش مأموریت':'مأموریت جدید';
    $('missionId').value=m?.id||'';
    $('editTitle').value=m?.title||'';
    $('editDescription').value=m?.description||'';
    $('editRegion').value=m?.region||1;
    $('editStep').value=m?.step||findFirstEmptyStep(1);
    $('editImportance').value=m?.importance||'medium';
    $('editVisual').value=m?.visual||'gate';
    const preset=rewardPreset[m?.importance||'medium'];
    $('editCoins').value=m?.coins ?? preset.coins;
    $('editXp').value=m?.xp ?? preset.xp;
    $('deleteMissionBtn').style.visibility=m?'visible':'hidden';
    $('missionModal').classList.remove('hidden');
  }

  function findFirstEmptyStep(region, excludingId='') {
    const used=new Set(missions.filter(m=>m.region===region && m.id!==excludingId).map(m=>m.step));
    for(let i=1;i<=5;i++) if(!used.has(i)) return i;
    return 1;
  }

  $('editImportance').addEventListener('change',()=>{
    const p=rewardPreset[$('editImportance').value]; $('editCoins').value=p.coins; $('editXp').value=p.xp;
  });
  $('editRegion').addEventListener('change',()=>{
    const id=$('missionId').value; $('editStep').value=findFirstEmptyStep(Number($('editRegion').value),id);
  });
  $('cancelMissionBtn').addEventListener('click',()=> $('missionModal').classList.add('hidden'));
  $('addMissionBtn').addEventListener('click',()=>openMissionEditor(null));

  $('missionForm').addEventListener('submit',e=>{
    e.preventDefault();
    const id=$('missionId').value;
    const region=Number($('editRegion').value), step=Number($('editStep').value);
    const conflict=missions.find(m=>m.region===region && m.step===step && m.id!==id);
    if(conflict){ showToastManager(`این جایگاه قبلاً برای «${conflict.title}» استفاده شده است.`); return; }
    const data={
      id:id||('m'+Date.now()), region, step,
      title:$('editTitle').value.trim(), description:$('editDescription').value.trim(),
      importance:$('editImportance').value, visual:$('editVisual').value,
      coins:Math.max(0,Number($('editCoins').value)||0), xp:Math.max(0,Number($('editXp').value)||0)
    };
    if(id){
      const old=missions.find(m=>m.id===id); Object.assign(old,data);
    } else {
      missions.push({...data,completed:false});
    }
    saveAll(); $('missionModal').classList.add('hidden'); renderManager();
  });

  $('deleteMissionBtn').addEventListener('click',()=>{
    const id=$('missionId').value; if(!id) return;
    const m=missions.find(x=>x.id===id);
    if(!confirm(`مأموریت «${m?.title||''}» حذف شود؟`)) return;
    missions=missions.filter(x=>x.id!==id); if(startedMissionId===id) startedMissionId=''; saveAll();
    $('missionModal').classList.add('hidden'); renderManager();
  });

  $('resetMissionsBtn').addEventListener('click',()=>{
    if(!confirm('فهرست مأموریت‌ها به حالت پیش‌فرض برگردد؟ پیشرفت هم از نو شروع می‌شود.')) return;
    missions=JSON.parse(JSON.stringify(defaultMissions)); stats={coins:0,totalXp:0}; startedMissionId=''; saveAll(); renderManager();
  });

  function showToastManager(text){
    alert(text);
  }

  // Pan + pinch zoom. The player can always explore freely.
  mapViewport.addEventListener('pointerdown',e=>{
    if(e.target.closest('.floating-hud,.mission-strip,.mission-fab')) return;
    mapViewport.setPointerCapture?.(e.pointerId);
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    userInteracting=true;
    if(pointers.size===1) lastPan={x:e.clientX,y:e.clientY,tx:transform.tx,ty:transform.ty};
    if(pointers.size===2){
      const p=[...pointers.values()];
      const dx=p[0].x-p[1].x,dy=p[0].y-p[1].y;
      pinchStart={dist:Math.hypot(dx,dy),scale:transform.scale,tx:transform.tx,ty:transform.ty,cx:(p[0].x+p[1].x)/2,cy:(p[0].y+p[1].y)/2};
    }
  });
  mapViewport.addEventListener('pointermove',e=>{
    if(!pointers.has(e.pointerId)) return;
    pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(pointers.size===1 && lastPan){
      transform.tx=lastPan.tx+(e.clientX-lastPan.x); transform.ty=lastPan.ty+(e.clientY-lastPan.y); applyTransform();
    } else if(pointers.size===2 && pinchStart){
      const p=[...pointers.values()],dx=p[0].x-p[1].x,dy=p[0].y-p[1].y,dist=Math.hypot(dx,dy);
      const newScale=Math.max(minScale(),Math.min(minScale()*2.5,pinchStart.scale*(dist/pinchStart.dist)));
      const worldX=(pinchStart.cx-pinchStart.tx)/pinchStart.scale, worldY=(pinchStart.cy-pinchStart.ty)/pinchStart.scale;
      transform.scale=newScale; transform.tx=pinchStart.cx-worldX*newScale; transform.ty=pinchStart.cy-worldY*newScale; applyTransform();
    }
  });
  const pointerUp=e=>{
    pointers.delete(e.pointerId);
    if(pointers.size<2) pinchStart=null;
    if(pointers.size===1){ const p=[...pointers.values()][0]; lastPan={x:p.x,y:p.y,tx:transform.tx,ty:transform.ty}; }
    if(pointers.size===0){ lastPan=null; userInteracting=false; }
  };
  mapViewport.addEventListener('pointerup',pointerUp); mapViewport.addEventListener('pointercancel',pointerUp);
  mapViewport.addEventListener('wheel',e=>{
    e.preventDefault();
    const old=transform.scale, next=Math.max(minScale(),Math.min(minScale()*2.5,old*(e.deltaY<0?1.12:.9)));
    const wx=(e.clientX-transform.tx)/old, wy=(e.clientY-transform.ty)/old;
    transform.scale=next; transform.tx=e.clientX-wx*next; transform.ty=e.clientY-wy*next; applyTransform();
  },{passive:false});

  function updateAll(){ updateHud(); updateMissionCard(); updateMarkers(); drawFog(); }

  window.addEventListener('resize',()=>{ applyTransform(); });
  $('worldImage').addEventListener('load',()=>{ setWorldSize(); setInitialTransform(); updateAll(); setTimeout(focusActive,500); });
  updateAll();
})();
