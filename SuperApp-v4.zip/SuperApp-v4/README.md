# Super App v4 — Compact Action-first UI

Offline-first Android milestone for the Network Marketing Super App.

## Included
- Stable application id: `com.liateam.superapp`
- Stable signing keystore from previous versions
- versionCode 4 / versionName 1.2.0
- Light Legacy-inspired design system
- RTL-first Persian UI
- Home V2: no vertical scrolling on the primary screen
- Compact Header + Level / XP / Streak strip
- Next Action hero as the dominant Home element
- Mini Progress Path with Done / Fail / Current / Locked states
- Top 3 Today compact plan
- Action Center V2: no vertical scrolling on the primary screen
- Team / Sponsor / Personal tabs with max 3 priority tasks per view
- Done / Failed / Reset local task states
- Current-centered Progress Path with previous/current/next in one view
- Full 8-step Progress Path available as a separate detailed view
- Final main bottom navigation: Home / Actions / My Network / Messages / More
- Backend calls remain disabled; local mock/state only

## Build
`./gradlew assembleDebug --stacktrace`
