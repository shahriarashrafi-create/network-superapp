package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskStatus

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenProgress: () -> Unit,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    val pendingTasks = tasks.filter { it.status == TaskStatus.TODO }
    val nextAction = pendingTasks.firstOrNull() ?: tasks.first()
    val doneCount = tasks.count { it.status == TaskStatus.DONE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuperColors.Background)
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
    ) {
        HomeHeaderCompact()
        Spacer(Modifier.height(7.dp))
        StatusStrip()
        Spacer(Modifier.height(8.dp))

        NextActionHero(
            modifier = Modifier.weight(1.55f),
            task = nextAction,
            onStart = onOpenActions
        )

        Spacer(Modifier.height(8.dp))
        MiniProgressCard(
            modifier = Modifier.weight(0.92f),
            doneCount = doneCount,
            totalCount = tasks.size,
            onClick = onOpenProgress
        )

        Spacer(Modifier.height(8.dp))
        TodayTopThree(
            modifier = Modifier.weight(1.48f),
            tasks = tasks.take(3),
            onOpenActions = onOpenActions,
            onTaskStatus = onTaskStatus
        )
    }
}

@Composable
private fun HomeHeaderCompact() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(SuperColors.BlueSoft)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("ش", color = SuperColors.Blue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(modifier = Modifier.padding(start = 10.dp)) {
                Text("سلام، شهریار", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                Text("امروز روی قدم بعدی تمرکز کن", color = SuperColors.TextSecondary, fontSize = 11.5.sp)
            }
        }
        IconButton(onClick = {}) {
            Icon(Icons.Outlined.NotificationsNone, contentDescription = "اعلان‌ها", tint = SuperColors.Navy)
        }
    }
}

@Composable
private fun StatusStrip() {
    Card(
        modifier = Modifier.fillMaxWidth().height(62.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = SuperShapes.Small,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatBlock("سطح ۳", "در مسیر لیدر", SuperColors.Gold)
            VerticalHairline()
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("XP", color = SuperColors.TextSecondary, fontSize = 10.5.sp)
                    Text("۲۴۰ / ۵۰۰", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { 0.48f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = SuperColors.NeutralSoft
                )
            }
            VerticalHairline()
            StatBlock("۷ روز", "متوالی", SuperColors.Orange)
        }
    }
}

@Composable
private fun VerticalHairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .width(1.dp)
            .height(32.dp)
            .background(SuperColors.Border)
    )
}

@Composable
private fun StatBlock(value: String, label: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Text(label, color = accent, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(Color(0xFFF3F9FF), Color(0xFFE5F3FF))))
                .border(1.dp, Color(0xFFCAE3FF), SuperShapes.Card)
                .padding(16.dp)
        ) {
            val compact = maxHeight < 155.dp
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1.45f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                    Text("قدم بعدی", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        task.title,
                        color = SuperColors.Text,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = if (compact) 21.sp else 24.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (!compact) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            task.subtitle,
                            color = SuperColors.TextSecondary,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(if (compact) 8.dp else 12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = onStart,
                            modifier = Modifier.weight(1f).height(if (compact) 42.dp else 46.dp),
                            shape = SuperShapes.Small,
                            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                        ) {
                            Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(19.dp))
                            Text("شروع", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        if (task.points > 0) {
                            Box(
                                modifier = Modifier
                                    .padding(start = 8.dp)
                                    .background(SuperColors.GoldSoft, SuperShapes.Pill)
                                    .padding(horizontal = 10.dp, vertical = 9.dp)
                            ) {
                                Text("+${task.points} XP", color = Color(0xFF946400), fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                GoalShape(modifier = Modifier.weight(0.72f).fillMaxHeight())
            }
        }
    }
}

@Composable
private fun GoalShape(modifier: Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(94.dp)
                .clip(SuperShapes.Small)
                .background(Color(0xFFDDEEFF))
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(8.dp)
                .size(38.dp)
                .clip(SuperShapes.Small)
                .background(SuperColors.Blue)
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(7.dp)
                .size(48.dp)
                .clip(SuperShapes.Small)
                .background(SuperColors.GoldSoft),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Gold, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun MiniProgressCard(
    modifier: Modifier,
    doneCount: Int,
    totalCount: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        onClick = onClick
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 10.dp), verticalArrangement = Arrangement.Center) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).background(SuperColors.BlueSoft, SuperShapes.Small),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(21.dp))
                }
                Column(modifier = Modifier.weight(1f).padding(start = 9.dp)) {
                    Text("مسیر پیشرفت", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text("مرحله فعلی: دعوت و پیش‌مشاوره", color = SuperColors.TextSecondary, fontSize = 10.5.sp, maxLines = 1)
                }
                Text("مشاهده", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
            }
            Spacer(Modifier.height(7.dp))
            ProgressDots()
            Spacer(Modifier.height(5.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("کارهای امروز", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
                Text("$doneCount از $totalCount انجام شده", color = SuperColors.Text, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ProgressDots() {
    val states = listOf(1, 1, -1, 2, 0)
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        states.forEachIndexed { index, state ->
            val color = when (state) {
                1 -> SuperColors.Green
                -1 -> SuperColors.Red
                2 -> SuperColors.Blue
                else -> Color(0xFFDDE4EE)
            }
            if (index > 0) {
                Box(modifier = Modifier.weight(1f).height(3.dp).background(if (state == 0) Color(0xFFE5EAF2) else color.copy(alpha = 0.75f)))
            }
            Box(
                modifier = Modifier
                    .size(if (state == 2) 24.dp else 20.dp)
                    .clip(CircleShape)
                    .background(if (state == 2) SuperColors.GoldSoft else color)
                    .then(if (state == 2) Modifier.border(3.dp, SuperColors.Blue, CircleShape) else Modifier),
                contentAlignment = Alignment.Center
            ) {
                when (state) {
                    1 -> Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    -1 -> Icon(Icons.Outlined.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    0 -> Icon(Icons.Outlined.Lock, contentDescription = null, tint = SuperColors.TextSecondary, modifier = Modifier.size(11.dp))
                    else -> Box(modifier = Modifier.size(7.dp).background(Color.White, CircleShape))
                }
            }
        }
    }
}

@Composable
private fun TodayTopThree(
    modifier: Modifier,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 9.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("برنامه امروز", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Spacer(Modifier.weight(1f))
                Text("مشاهده همه", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
            }
            Spacer(Modifier.height(3.dp))
            tasks.forEachIndexed { index, task ->
                CompactPlanRow(
                    modifier = Modifier.weight(1f),
                    task = task,
                    onStart = onOpenActions,
                    onDone = { onTaskStatus(task.id, TaskStatus.DONE) }
                )
                if (index != tasks.lastIndex) Divider(color = SuperColors.Border, thickness = 0.7.dp)
            }
        }
    }
}

@Composable
private fun CompactPlanRow(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit,
    onDone: () -> Unit
) {
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onDone, modifier = Modifier.size(34.dp)) {
            Icon(
                if (task.status == TaskStatus.DONE) Icons.Outlined.Check else Icons.Outlined.RadioButtonUnchecked,
                contentDescription = "تغییر وضعیت",
                tint = if (task.status == TaskStatus.DONE) SuperColors.Green else SuperColors.TextSecondary,
                modifier = Modifier.size(23.dp)
            )
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 6.dp)) {
            Text(task.title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(task.source.label, color = SuperColors.TextSecondary, fontSize = 9.5.sp, maxLines = 1)
        }
        Box(
            modifier = Modifier
                .background(SuperColors.BlueSoft, SuperShapes.Pill)
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            Text(task.source.label, color = SuperColors.Blue, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        IconButton(onClick = onStart, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Outlined.PlayArrow, contentDescription = "شروع", tint = SuperColors.Blue, modifier = Modifier.size(22.dp))
        }
    }
}
