@echo off
setlocal
set GRADLE_VERSION=8.9
set APP_HOME=%~dp0
set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set INSTALL_DIR=%GRADLE_USER_HOME%\custom-wrapper\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%INSTALL_DIR%\bin\gradle.bat
set ZIP_FILE=%GRADLE_USER_HOME%\custom-wrapper\gradle-%GRADLE_VERSION%-bin.zip
set DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip

if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_USER_HOME%\custom-wrapper" mkdir "%GRADLE_USER_HOME%\custom-wrapper"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%DIST_URL%' -OutFile '%ZIP_FILE%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_FILE%' '%GRADLE_USER_HOME%\custom-wrapper'"
)

cd /d "%APP_HOME%"
call "%GRADLE_BIN%" %*
endlocal
