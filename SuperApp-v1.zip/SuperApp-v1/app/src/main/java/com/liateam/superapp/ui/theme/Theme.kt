package com.liateam.superapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SuperAppColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    secondary = Color(0xFF7C3AED),
    background = Color(0xFFF7F9FC),
    surface = Color.White,
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827),
    error = Color(0xFFDC2626)
)

@Composable
fun SuperAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SuperAppColors,
        content = content
    )
}
