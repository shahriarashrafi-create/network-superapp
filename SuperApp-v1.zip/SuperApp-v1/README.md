# Super App — Version 1

This is the first buildable Android skeleton for the Network Marketing Super App.

## Locked application identity
- Application ID: `com.liateam.superapp`
- Version Code: `1`
- Version Name: `1.0.0`
- Java: `17`
- Android Gradle Plugin: `8.7.3`
- Gradle: `8.9`
- Kotlin: `2.0.21`
- UI: Jetpack Compose

## Signing
The fixed signing keystore is intentionally included in this project under:

`signing/superapp-release.jks`

Do not replace this keystore in future versions. Future APKs must use the same keystore, alias and passwords so Android can install them as updates over this version.

Both `debug` and `release` builds use the same fixed signing identity for update continuity during the project.

## GitHub Actions
Upload this ZIP to the repository root. The fixed workflow extracts it, finds this Gradle project, runs:

`./gradlew assembleDebug`

and uploads the resulting APK artifact.

## Versioning rule
For every future version:
1. Keep `applicationId` unchanged.
2. Keep the complete `signing/` directory unchanged.
3. Increase `versionCode` by at least 1.
4. Update `versionName` as needed.
