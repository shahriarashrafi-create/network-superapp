package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.networksuper.ui.theme.*

private enum class StageStatus { COMPLETED, CURRENT, UPCOMING }

private data class ProgressStage(
    val number: Int,
    val title: String,
    val icon: ImageVector,
    val status: StageStatus
)

private val stages = listOf(
    ProgressStage(12, "نقطه اوج", Icons.Rounded.EmojiEvents, StageStatus.UPCOMING),
    ProgressStage(11, "رهبری تیم", Icons.Rounded.Groups, StageStatus.UPCOMING),
    ProgressStage(10, "ساخت عادت", Icons.Rounded.AutoAwesome, StageStatus.UPCOMING),
    ProgressStage(9, "توسعه مهارت‌ها", Icons.Rounded.School, StageStatus.UPCOMING),
    ProgressStage(8, "ارتباط با مشتری", Icons.Rounded.PeopleAlt, StageStatus.UPCOMING),
    ProgressStage(7, "مهارت ارتباطی", Icons.Rounded.RecordVoiceOver, StageStatus.UPCOMING),
    ProgressStage(6, "ورزش روزانه", Icons.Rounded.FitnessCenter, StageStatus.CURRENT),
    ProgressStage(5, "مطالعه و یادگیری", Icons.Rounded.MenuBook, StageStatus.COMPLETED),
    ProgressStage(4, "مدیریت مالی", Icons.Rounded.AccountBalanceWallet, StageStatus.COMPLETED),
    ProgressStage(3, "برنامه‌ریزی هفتگی", Icons.Rounded.CalendarMonth, StageStatus.COMPLETED),
    ProgressStage(2, "هدف‌گذاری", Icons.Rounded.Flag, StageStatus.COMPLETED),
    ProgressStage(1, "چشم‌انداز شخصی", Icons.Rounded.TrackChanges, StageStatus.COMPLETED)
)

private val stageSpacing = 228.dp
private val stageCardHeight = 112.dp
private val worldTopPadding = 76.dp

@Composable
fun ProgressPathContent(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    val currentIndex = remember { stages.indexOfFirst { it.status == StageStatus.CURRENT } }

    LaunchedEffect(Unit) {
        val target = with(density) {
            (worldTopPadding + stageSpacing * currentIndex.toFloat() - 180.dp).toPx().toInt()
        }.coerceAtLeast(0)
        scrollState.scrollTo(target)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        ProgressPathHeader()
        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFFF7FBFF))
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            ) {
                val worldHeight = worldTopPadding * 2f + stageSpacing * (stages.size - 1).toFloat() + stageCardHeight + 70.dp
                val cardWidth = maxWidth * 0.64f
                val nodeSize = 64.dp

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(worldHeight)
                ) {
                    ProgressWorldBackdrop(Modifier.matchParentSize())
                    ProgressRoad(
                        modifier = Modifier.matchParentSize(),
                        count = stages.size
                    )

                    stages.forEachIndexed { index, stage ->
                        val isCardOnRight = index % 2 == 0
                        val nodeFraction = if (isCardOnRight) 0.36f else 0.64f
                        val cardTop = worldTopPadding + stageSpacing * index.toFloat()
                        val nodeCenterY = cardTop + stageCardHeight / 2f
                        val nodeLeft = maxWidth * nodeFraction - nodeSize / 2f

                        StageCard(
                            stage = stage,
                            modifier = Modifier
                                .align(if (isCardOnRight) Alignment.TopEnd else Alignment.TopStart)
                                .offset(
                                    x = if (isCardOnRight) (-10).dp else 10.dp,
                                    y = cardTop
                                )
                                .width(cardWidth)
                                .height(stageCardHeight)
                        )

                        StageNode(
                            stage = stage,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset(x = nodeLeft, y = nodeCenterY - nodeSize / 2f)
                                .size(nodeSize)
                        )
                    }
                }
            }

            // subtle top/bottom fades make the path feel continuous outside the viewport
            Canvas(Modifier.matchParentSize()) {
                val fadeHeight = 24.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color(0xFFF7FBFF),
                        1f to Color.Transparent,
                        startY = 0f,
                        endY = fadeHeight
                    ),
                    size = Size(size.width, fadeHeight)
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        1f to Color(0xFFF7FBFF),
                        startY = size.height - fadeHeight,
                        endY = size.height
                    ),
                    topLeft = Offset(0f, size.height - fadeHeight),
                    size = Size(size.width, fadeHeight)
                )
            }
        }
    }
}

@Composable
private fun ProgressPathHeader() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                4.dp,
                RoundedCornerShape(26.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.07f),
                spotColor = PrimaryBlue.copy(alpha = 0.08f)
            ),
        shape = RoundedCornerShape(26.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEAF2FC))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = SoftBlue,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.20f))
                ) {
                    Text(
                        text = "مرحله ۶ از ۱۲",
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = PrimaryBlueDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "مسیر پیشرفت",
                        color = Navy,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .shadow(5.dp, CircleShape)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color.White, Color(0xFFFFF2C8))
                                )
                            )
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EmojiEvents,
                            contentDescription = null,
                            tint = RewardGold,
                            modifier = Modifier.size(31.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(12.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDDEAF9))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.50f)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF29B8EF), Color(0xFF0E6FFF))
                                )
                            )
                    )
                }
                Text(
                    text = "50%",
                    color = PrimaryBlue,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun ProgressWorldBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRect(
            brush = Brush.verticalGradient(
                listOf(
                    Color(0xFFF9FCFF),
                    Color(0xFFF1F8FF),
                    Color(0xFFF8FBFF)
                )
            )
        )

        fun mountain(baseY: Float, x: Float, width: Float, height: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(x, baseY)
                lineTo(x + width * 0.50f, baseY - height)
                lineTo(x + width, baseY)
                close()
            }
            drawPath(p, Color(0xFFB8D9F6).copy(alpha = alpha))
        }

        val band = 330.dp.toPx()
        var y = 250.dp.toPx()
        var row = 0
        while (y < h + band) {
            val shift = if (row % 2 == 0) 0f else w * 0.12f
            mountain(y, -w * 0.08f + shift, w * 0.60f, 115.dp.toPx(), 0.23f)
            mountain(y + 16.dp.toPx(), w * 0.40f + shift, w * 0.56f, 95.dp.toPx(), 0.16f)

            drawCircle(
                color = Color.White.copy(alpha = 0.88f),
                radius = 22.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.78f else 0.20f, y - 120.dp.toPx())
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.82f),
                radius = 16.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.83f else 0.25f, y - 118.dp.toPx())
            )

            // Minimal coded trees; deliberately faint so cards stay dominant.
            val treeX = w * if (row % 2 == 0) 0.12f else 0.86f
            drawRoundRect(
                color = Color(0xFF8BC2D9).copy(alpha = 0.30f),
                topLeft = Offset(treeX - 2.dp.toPx(), y - 70.dp.toPx()),
                size = Size(4.dp.toPx(), 31.dp.toPx()),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            val tree = Path().apply {
                moveTo(treeX, y - 118.dp.toPx())
                lineTo(treeX - 15.dp.toPx(), y - 68.dp.toPx())
                lineTo(treeX + 15.dp.toPx(), y - 68.dp.toPx())
                close()
            }
            drawPath(tree, Color(0xFF64BCD3).copy(alpha = 0.30f))

            y += band
            row++
        }
    }
}

@Composable
private fun ProgressRoad(
    count: Int,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (count <= 0) return@Canvas

        val nodeYs = List(count) { index ->
            (worldTopPadding + stageSpacing * index.toFloat() + stageCardHeight / 2f).toPx()
        }
        val nodeXs = List(count) { index ->
            size.width * if (index % 2 == 0) 0.36f else 0.64f
        }

        val roadPath = Path().apply {
            moveTo(nodeXs.first(), nodeYs.first() - 86.dp.toPx())
            lineTo(nodeXs.first(), nodeYs.first())
            for (i in 0 until count - 1) {
                val x0 = nodeXs[i]
                val y0 = nodeYs[i]
                val x1 = nodeXs[i + 1]
                val y1 = nodeYs[i + 1]
                val midY = (y0 + y1) / 2f
                cubicTo(x0, midY, x1, midY, x1, y1)
            }
            lineTo(nodeXs.last(), nodeYs.last() + 88.dp.toPx())
        }

        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.95f),
            style = Stroke(width = 54.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color(0xFF8BCBFF).copy(alpha = 0.22f),
            style = Stroke(width = 48.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFF7EC5FF), Color(0xFF4AA4FA), Color(0xFF8ACBFF))
            ),
            style = Stroke(width = 38.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.94f),
            style = Stroke(
                width = 3.2.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(
                    floatArrayOf(13.dp.toPx(), 13.dp.toPx())
                )
            )
        )
    }
}

@Composable
private fun StageCard(
    stage: ProgressStage,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val completed = stage.status == StageStatus.COMPLETED
    val accent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.UPCOMING -> PrimaryBlue
    }

    val contentAlpha = if (stage.status == StageStatus.UPCOMING) 0.72f else 1f

    Box(modifier = modifier) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    if (current) 10.dp else 4.dp,
                    RoundedCornerShape(25.dp),
                    ambientColor = accent.copy(alpha = if (current) 0.18f else 0.06f),
                    spotColor = accent.copy(alpha = if (current) 0.20f else 0.08f)
                ),
            shape = RoundedCornerShape(25.dp),
            color = Color.White.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.82f else 0.98f),
            border = androidx.compose.foundation.BorderStroke(
                if (current) 2.dp else 1.dp,
                if (current) PrimaryBlue else accent.copy(alpha = if (completed) 0.20f else 0.13f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color.White,
                                    accent.copy(alpha = if (completed) 0.14f else 0.18f)
                                )
                            )
                        )
                        .border(1.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = stage.icon,
                        contentDescription = null,
                        tint = accent.copy(alpha = contentAlpha),
                        modifier = Modifier.size(31.dp)
                    )
                }

                Text(
                    text = stage.title,
                    modifier = Modifier.weight(1f),
                    color = Navy.copy(alpha = contentAlpha),
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (current) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-10).dp, y = (-13).dp),
                shape = RoundedCornerShape(14.dp),
                color = PrimaryBlue,
                shadowElevation = 3.dp
            ) {
                Text(
                    text = "مرحله فعلی",
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 6.dp),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun StageNode(
    stage: ProgressStage,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val completed = stage.status == StageStatus.COMPLETED
    val nodeColor = when {
        current -> PrimaryBlue
        completed -> SuccessGreen
        else -> Color.White
    }
    val borderColor = when {
        current -> Color(0xFF2EA6FF)
        completed -> Color(0xFF62D9B0)
        else -> Color(0xFFBBC8DA)
    }

    Box(
        modifier = modifier
            .shadow(
                if (current) 12.dp else 4.dp,
                CircleShape,
                ambientColor = borderColor.copy(alpha = 0.20f),
                spotColor = borderColor.copy(alpha = 0.22f)
            )
            .clip(CircleShape)
            .background(Color.White)
            .border(if (current) 4.dp else 3.dp, borderColor, CircleShape)
            .padding(5.dp)
            .clip(CircleShape)
            .background(nodeColor),
        contentAlignment = Alignment.Center
    ) {
        if (completed) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "انجام شده",
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        } else {
            Text(
                text = stage.number.toString(),
                color = if (current) Color.White else Navy.copy(alpha = 0.78f),
                fontSize = if (current) 24.sp else 20.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
        }
    }
}
