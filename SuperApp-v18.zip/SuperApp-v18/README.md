# SuperApp v17

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## v2.5.0 / Build 17
- Home polish: single-piece XP bar, no 48% badge on Home, compact right-aligned Next Action content, code-only reward chest and journey strip, no text labels on the Home journey, tighter shortcut hub placement.
- Progress Path rebuilt from scratch as a stable vertical journey: alternating step cards, centered state nodes, Done/Current/Locked/Failed states, integrated milestones, rewards, map/list switch, step details bottom sheet and "مرحله من" shortcut.
- Current step appears only once in the journey; repeated active-stage hero removed to reduce clutter and layout bugs.
- Progress visuals use Compose Canvas/Vector/Shape/Gradient only; no decorative PNG/JPG/WebP assets are included.
- Existing Task → Subtask → Focus → Result → XP/Coin/Combo → Next Action flow and 30-link Home pager remain intact.
- Application ID and signing configuration are preserved for in-place APK updates.


### Build 17
- Home layout rebuilt for tighter mission/reward/path/shortcut hierarchy.
- Progress-stage child screens added for current, completed and locked stages.
- Milestone detail and reward preview screens added.
- Task flow rebuilt: preparation, focus, result, success, failure/reset.
- All new visuals are Compose/Canvas/vector only; no decorative bitmap backgrounds.
