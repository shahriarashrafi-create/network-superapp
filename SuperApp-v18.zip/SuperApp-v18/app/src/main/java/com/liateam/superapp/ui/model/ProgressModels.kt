package com.liateam.superapp.ui.model

enum class ProgressStageState { DONE, FAILED, CURRENT, LOCKED }

data class ProgressStage(
    val id: Int,
    val title: String,
    val subtitle: String,
    val description: String,
    val rewardXp: Int,
    val rewardCoin: Int,
    val state: ProgressStageState,
    val taskId: Int? = null,
    val unlockCondition: String = "مرحله قبلی را کامل کن",
    val durationMinutes: Int = 10,
    val progressCurrent: Int = 0,
    val progressTotal: Int = 0,
    val nextTitle: String? = null,
    val relatedDestination: HomeDestination? = null,
    val subtasks: List<String> = emptyList()
)

data class ProgressMilestone(
    val id: Int,
    val title: String,
    val subtitle: String,
    val rewardCoin: Int,
    val rewardXp: Int,
    val badgeTitle: String,
    val afterStage: Int,
    val progress: Float,
    val final: Boolean = false
)

fun progressStages(): List<ProgressStage> = listOf(
    ProgressStage(
        id = 1,
        title = "آشنایی و ذهنیت",
        subtitle = "پایه‌های شروع حرفه‌ای",
        description = "هدف این مرحله این است که ذهنیت، ریتم کاری و اصول پایه مسیر را یک‌دست کنی.",
        rewardXp = 30,
        rewardCoin = 3,
        state = ProgressStageState.DONE,
        durationMinutes = 8,
        nextTitle = "ارتباط‌سازی",
        relatedDestination = HomeDestination.ACADEMY,
        subtasks = listOf("مرور اصول پایه", "تعیین هدف کوتاه‌مدت", "ثبت تعهد روزانه")
    ),
    ProgressStage(
        id = 2,
        title = "ارتباط‌سازی",
        subtitle = "ساخت لیست و شروع گفت‌وگو",
        description = "یک لیست واقعی از مخاطبان بساز و اولین ارتباط‌های طبیعی را بدون فشار شروع کن.",
        rewardXp = 40,
        rewardCoin = 4,
        state = ProgressStageState.DONE,
        durationMinutes = 12,
        nextTitle = "دعوت یک نفر",
        relatedDestination = HomeDestination.CUSTOMERS,
        subtasks = listOf("ساخت لیست اولیه", "اولویت‌بندی مخاطبان", "شروع حداقل یک گفت‌وگو")
    ),
    ProgressStage(
        id = 3,
        title = "دعوت یک نفر",
        subtitle = "گفت‌وگوی کوتاه با یک مخاطب جدید",
        description = "یک مخاطب مناسب را انتخاب کن، گفت‌وگو را طبیعی شروع کن و نتیجه را در CRM ثبت کن.",
        rewardXp = 20,
        rewardCoin = 2,
        state = ProgressStageState.CURRENT,
        taskId = 1,
        durationMinutes = 15,
        progressCurrent = 1,
        progressTotal = 3,
        nextTitle = "معرفی محصول",
        relatedDestination = HomeDestination.CUSTOMERS,
        subtasks = listOf("انتخاب یک مخاطب مناسب", "شروع یک گفت‌وگوی کوتاه", "ثبت نتیجه و اقدام بعدی")
    ),
    ProgressStage(
        id = 4,
        title = "معرفی محصول",
        subtitle = "معرفی ساده و درست محصول",
        description = "محصول مناسب را بر اساس نیاز مخاطب معرفی کن و روی تجربه واقعی تمرکز داشته باش.",
        rewardXp = 25,
        rewardCoin = 3,
        state = ProgressStageState.LOCKED,
        taskId = 3,
        unlockCondition = "مرحله دعوت یک نفر را کامل کن",
        durationMinutes = 12,
        nextTitle = "پیگیری حرفه‌ای",
        relatedDestination = HomeDestination.CUSTOMERS,
        subtasks = listOf("شناخت نیاز مخاطب", "انتخاب محصول مناسب", "ثبت بازخورد مخاطب")
    ),
    ProgressStage(
        id = 5,
        title = "پیگیری حرفه‌ای",
        subtitle = "Follow-up با اقدام بعدی روشن",
        description = "پیگیری را در زمان مناسب انجام بده و هر گفت‌وگو را با یک اقدام بعدی مشخص تمام کن.",
        rewardXp = 25,
        rewardCoin = 3,
        state = ProgressStageState.LOCKED,
        taskId = 2,
        unlockCondition = "معرفی محصول را کامل کن",
        durationMinutes = 10,
        nextTitle = "اولین مشتری",
        relatedDestination = HomeDestination.CUSTOMERS,
        subtasks = listOf("مرور گفت‌وگوی قبلی", "پیگیری هدفمند", "ثبت اقدام بعدی")
    ),
    ProgressStage(
        id = 6,
        title = "اولین مشتری",
        subtitle = "ثبت اولین خرید موفق",
        description = "فرآیند خرید را تا پایان همراهی کن و اطلاعات مشتری را کامل در CRM ثبت کن.",
        rewardXp = 40,
        rewardCoin = 5,
        state = ProgressStageState.LOCKED,
        unlockCondition = "پیگیری حرفه‌ای را کامل کن",
        durationMinutes = 15,
        nextTitle = "ساخت تیم",
        relatedDestination = HomeDestination.SALES,
        subtasks = listOf("تأیید نیاز مشتری", "ثبت سفارش", "برنامه‌ریزی پیگیری پس از خرید")
    ),
    ProgressStage(
        id = 7,
        title = "ساخت تیم",
        subtitle = "ثبت عضو و شروع مسیر حمایتی",
        description = "اولین عضو فعال را وارد مسیر کن و برای شروع او یک برنامه حمایتی روشن داشته باش.",
        rewardXp = 50,
        rewardCoin = 6,
        state = ProgressStageState.LOCKED,
        unlockCondition = "اولین مشتری را ثبت کن",
        durationMinutes = 20,
        nextTitle = "تکثیر و رهبری",
        relatedDestination = HomeDestination.TREE,
        subtasks = listOf("ثبت عضو جدید", "تعیین قدم بعدی عضو", "ثبت برنامه پیگیری")
    ),
    ProgressStage(
        id = 8,
        title = "تکثیر و رهبری",
        subtitle = "کمک به تیم برای تکرار مسیر",
        description = "به اعضا کمک کن همین مسیر را مستقل تکرار کنند و از اجرا به کوچینگ حرکت کن.",
        rewardXp = 70,
        rewardCoin = 8,
        state = ProgressStageState.LOCKED,
        unlockCondition = "ساخت تیم را کامل کن",
        durationMinutes = 25,
        relatedDestination = HomeDestination.LEADER_CENTER,
        subtasks = listOf("انتخاب عضو نیازمند حمایت", "تعیین اقدام کوچینگ", "ثبت نتیجه و پیگیری")
    )
)

fun progressMilestones(): List<ProgressMilestone> = listOf(
    ProgressMilestone(
        id = 1,
        title = "جایزه میانی",
        subtitle = "بعد از تکمیل مرحله ۴",
        rewardCoin = 50,
        rewardXp = 80,
        badgeTitle = "نشان حرکت",
        afterStage = 4,
        progress = 0.75f
    ),
    ProgressMilestone(
        id = 2,
        title = "جایزه نهایی مسیر",
        subtitle = "بعد از تکمیل مرحله ۸",
        rewardCoin = 150,
        rewardXp = 250,
        badgeTitle = "نشان رهبر مسیر",
        afterStage = 8,
        progress = 0.38f,
        final = true
    )
)

/** Local-first live path state derived from the prototype task ledger. */
fun progressStages(tasks: List<AppTask>): List<ProgressStage> {
    val base = progressStages()
    val invite = tasks.firstOrNull { it.id == 1 }?.status ?: TaskStatus.TODO
    val product = tasks.firstOrNull { it.id == 3 }?.status ?: TaskStatus.TODO
    val followUp = tasks.firstOrNull { it.id == 2 }?.status ?: TaskStatus.TODO

    fun fromTask(status: TaskStatus): ProgressStageState = when (status) {
        TaskStatus.DONE -> ProgressStageState.DONE
        TaskStatus.FAILED -> ProgressStageState.FAILED
        TaskStatus.TODO -> ProgressStageState.CURRENT
    }

    val stage3 = fromTask(invite)
    val stage4 = when {
        invite != TaskStatus.DONE -> ProgressStageState.LOCKED
        else -> fromTask(product)
    }
    val stage5 = when {
        invite != TaskStatus.DONE || product != TaskStatus.DONE -> ProgressStageState.LOCKED
        else -> fromTask(followUp)
    }
    val stage6 = if (invite == TaskStatus.DONE && product == TaskStatus.DONE && followUp == TaskStatus.DONE) {
        ProgressStageState.CURRENT
    } else {
        ProgressStageState.LOCKED
    }

    return base.map { stage ->
        stage.copy(
            state = when (stage.id) {
                1, 2 -> ProgressStageState.DONE
                3 -> stage3
                4 -> stage4
                5 -> stage5
                6 -> stage6
                else -> ProgressStageState.LOCKED
            }
        )
    }
}
