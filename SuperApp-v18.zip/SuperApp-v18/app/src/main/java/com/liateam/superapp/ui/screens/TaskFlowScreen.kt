package com.liateam.superapp.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskStatus
import kotlinx.coroutines.delay

private enum class TaskFlowPhase { DETAIL, FOCUS, COMPLETE, FAILED }

private data class TaskSubtask(
    val title: String,
    val hint: String,
    val iconType: Int,
    val crmLinked: Boolean = false,
    val required: Boolean = true
)

private fun taskSubtasks(task: AppTask): List<TaskSubtask> = when (task.id) {
    1 -> listOf(
        TaskSubtask("انتخاب یک مخاطب مناسب", "از CRM یا لیست ارتباطات", 0, crmLinked = true),
        TaskSubtask("شروع یک گفت‌وگوی کوتاه", "ساده، طبیعی و بدون فشار", 1),
        TaskSubtask("ثبت نتیجه و اقدام بعدی", "نتیجه را در CRM ذخیره کن", 2, crmLinked = true)
    )
    2 -> listOf(
        TaskSubtask("مرور گفت‌وگوی قبلی", "آخرین وضعیت مخاطب را ببین", 2, crmLinked = true),
        TaskSubtask("پیگیری هدفمند", "یک سؤال یا اقدام روشن", 1),
        TaskSubtask("ثبت Next Action", "قدم بعدی را مشخص کن", 2, crmLinked = true)
    )
    3 -> listOf(
        TaskSubtask("نیاز مخاطب را مشخص کن", "مشکل واقعی را پیدا کن", 0, crmLinked = true),
        TaskSubtask("محصول مناسب را انتخاب کن", "فقط گزینه مرتبط را معرفی کن", 2),
        TaskSubtask("بازخورد را ثبت کن", "نتیجه معرفی را ذخیره کن", 2, crmLinked = true)
    )
    else -> listOf(
        TaskSubtask("آماده‌سازی", "قبل از شروع یک مرور کوتاه", 2),
        TaskSubtask("انجام اقدام اصلی", "روی یک نتیجه مشخص تمرکز کن", 1),
        TaskSubtask("ثبت نتیجه", "نتیجه و قدم بعدی را ذخیره کن", 2)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskFlowScreen(
    contentPadding: PaddingValues,
    task: AppTask,
    onBack: () -> Unit,
    onStatusChange: (TaskStatus) -> Unit,
    onOpenCrm: () -> Unit,
    onContinueToNext: () -> Unit
) {
    val subtasks = remember(task.id) { taskSubtasks(task) }
    var phase by remember(task.id) { mutableStateOf(TaskFlowPhase.DETAIL) }
    var selectedMinutes by remember(task.id) { mutableIntStateOf(15) }
    var showResultSheet by remember(task.id) { mutableStateOf(false) }
    val completed = remember(task.id) {
        mutableStateListOf<Boolean>().apply { repeat(subtasks.size) { add(false) } }
    }

    BackHandler(enabled = true) {
        when {
            showResultSheet -> showResultSheet = false
            phase == TaskFlowPhase.FOCUS -> phase = TaskFlowPhase.DETAIL
            phase == TaskFlowPhase.COMPLETE || phase == TaskFlowPhase.FAILED -> onContinueToNext()
            else -> onBack()
        }
    }

    when (phase) {
        TaskFlowPhase.DETAIL -> TaskDetailContent(
            contentPadding = contentPadding,
            task = task,
            subtasks = subtasks,
            completed = completed,
            selectedMinutes = selectedMinutes,
            onSelectedMinutes = { selectedMinutes = it },
            onToggleSubtask = { index -> completed[index] = !completed[index] },
            onOpenCrm = onOpenCrm,
            onStartFocus = { phase = TaskFlowPhase.FOCUS },
            onBack = onBack
        )
        TaskFlowPhase.FOCUS -> FocusContent(
            task = task,
            minutes = selectedMinutes,
            completedCount = completed.count { it },
            totalSubtasks = completed.size,
            onBack = { phase = TaskFlowPhase.DETAIL },
            onFinish = { showResultSheet = true }
        )
        TaskFlowPhase.COMPLETE -> CompletionContent(
            contentPadding = contentPadding,
            task = task,
            onContinue = onContinueToNext
        )
        TaskFlowPhase.FAILED -> FailureContent(
            contentPadding = contentPadding,
            task = task,
            onRetry = {
                onStatusChange(TaskStatus.TODO)
                phase = TaskFlowPhase.DETAIL
            },
            onBackToPath = onContinueToNext
        )
    }

    if (showResultSheet) {
        ModalBottomSheet(
            onDismissRequest = { showResultSheet = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
        ) {
            ResultSheet(
                canComplete = completed.indices.all { index -> !subtasks[index].required || completed[index] },
                remaining = subtasks.indices.count { index -> subtasks[index].required && !completed[index] },
                onDone = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.DONE)
                    phase = TaskFlowPhase.COMPLETE
                },
                onLater = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.TODO)
                    onBack()
                },
                onFail = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.FAILED)
                    phase = TaskFlowPhase.FAILED
                }
            )
        }
    }
}

@Composable
private fun TaskDetailContent(
    contentPadding: PaddingValues,
    task: AppTask,
    subtasks: List<TaskSubtask>,
    completed: List<Boolean>,
    selectedMinutes: Int,
    onSelectedMinutes: (Int) -> Unit,
    onToggleSubtask: (Int) -> Unit,
    onOpenCrm: () -> Unit,
    onStartFocus: () -> Unit,
    onBack: () -> Unit
) {
    val doneCount = completed.count { it }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF4FAFF), Color.White, Color(0xFFF8FBFF))))
    ) {
        TaskAmbientBackdrop()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = contentPadding.calculateTopPadding() + 6.dp,
                    bottom = contentPadding.calculateBottomPadding() + 92.dp
                ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("آماده‌سازی اقدام", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 22.sp)
                    Text("قدم‌ها را ببین و با تمرکز شروع کن", color = SuperColors.TextSecondary, fontSize = 9.3.sp)
                }
            }

            TaskHero(task = task, selectedMinutes = selectedMinutes)
            WhyThisTaskCard(task)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.8.dp)
            ) {
                Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("زیرکارها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        Text("$doneCount / ${subtasks.size}", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                    LinearProgressIndicator(
                        progress = { if (subtasks.isEmpty()) 0f else doneCount / subtasks.size.toFloat() },
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = SuperColors.BlueSoft
                    )
                    subtasks.forEachIndexed { index, item ->
                        SubtaskRow(
                            item = item,
                            checked = completed[index],
                            onToggle = { onToggleSubtask(index) },
                            onOpenCrm = if (item.crmLinked) onOpenCrm else null
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Timer, contentDescription = null, tint = SuperColors.Purple, modifier = Modifier.size(20.dp))
                        Text("زمان تمرکز", modifier = Modifier.weight(1f).padding(horizontal = 7.dp), color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(15, 30, 45).forEach { minutes ->
                            TimeChoice(
                                text = "$minutes دقیقه",
                                selected = selectedMinutes == minutes,
                                onClick = { onSelectedMinutes(minutes) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp), clip = false),
            color = Color.White.copy(alpha = 0.97f),
            shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)
            ) {
                Button(
                    onClick = onStartFocus,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("شروع تمرکز", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.5.sp)
                }
            }
        }
    }
}

@Composable
private fun TaskAmbientBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(Color(0xFF7EC6FF).copy(alpha = 0.08f), size.width * 0.42f, Offset(size.width * 0.94f, size.height * 0.11f))
        drawCircle(Color(0xFF47C995).copy(alpha = 0.04f), size.width * 0.28f, Offset(size.width * 0.06f, size.height * 0.70f))
    }
}

@Composable
private fun TaskHero(task: AppTask, selectedMinutes: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(3.dp, RoundedCornerShape(24.dp), clip = false),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            TaskMissionAsset(modifier = Modifier.size(88.dp))
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text("مرحله فعال", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
                Spacer(Modifier.height(2.dp))
                Text(task.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallReward("+${task.points.coerceAtLeast(20)} XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallReward("+2 سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    SmallReward("$selectedMinutes دقیقه", SuperColors.Purple, SuperColors.PurpleSoft)
                }
            }
        }
    }
}

@Composable
private fun TaskMissionAsset(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawCircle(Color(0xFFDFF2FF), radius = w * 0.46f, center = Offset(w * 0.50f, h * 0.52f))
        fun cube(cx: Float, cy: Float, s: Float, top: Color, left: Color, right: Color) {
            val p1 = Path().apply {
                moveTo(cx, cy - s * 0.42f)
                lineTo(cx + s * 0.50f, cy - s * 0.12f)
                lineTo(cx, cy + s * 0.16f)
                lineTo(cx - s * 0.50f, cy - s * 0.12f)
                close()
            }
            val p2 = Path().apply {
                moveTo(cx - s * 0.50f, cy - s * 0.12f)
                lineTo(cx, cy + s * 0.16f)
                lineTo(cx, cy + s * 0.68f)
                lineTo(cx - s * 0.50f, cy + s * 0.40f)
                close()
            }
            val p3 = Path().apply {
                moveTo(cx + s * 0.50f, cy - s * 0.12f)
                lineTo(cx, cy + s * 0.16f)
                lineTo(cx, cy + s * 0.68f)
                lineTo(cx + s * 0.50f, cy + s * 0.40f)
                close()
            }
            drawPath(p1, top)
            drawPath(p2, left)
            drawPath(p3, right)
        }
        cube(w * 0.28f, h * 0.64f, w * 0.24f, Color.White, Color(0xFFDCEBFA), Color(0xFFF0F7FF))
        cube(w * 0.48f, h * 0.55f, w * 0.25f, Color(0xFF5CB9FF), SuperColors.Blue, Color(0xFF3E9DEB))
        cube(w * 0.70f, h * 0.38f, w * 0.30f, SuperColors.GoldBright, SuperColors.Gold, Color(0xFFE89B0C))
        val arrow = Path().apply {
            moveTo(w * 0.16f, h * 0.56f)
            cubicTo(w * 0.30f, h * 0.48f, w * 0.42f, h * 0.31f, w * 0.57f, h * 0.27f)
        }
        drawPath(arrow, SuperColors.Blue, style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round))
        drawLine(SuperColors.GoldDeep, Offset(w * 0.70f, h * 0.12f), Offset(w * 0.70f, h * 0.30f), 3.5f, StrokeCap.Round)
        val flag = Path().apply {
            moveTo(w * 0.70f, h * 0.12f)
            lineTo(w * 0.86f, h * 0.16f)
            lineTo(w * 0.70f, h * 0.22f)
            close()
        }
        drawPath(flag, SuperColors.Gold)
    }
}

@Composable
private fun WhyThisTaskCard(task: AppTask) {
    val copy = when (task.id) {
        1 -> "هر دعوت واقعی، یک قدم برای ساخت ارتباط و ایجاد فرصت جدید است."
        2 -> "پیگیری منظم، مخاطب را از علاقه به تصمیم نزدیک می‌کند."
        3 -> "معرفی درست محصول باید از نیاز مخاطب شروع شود، نه از توضیح زیاد."
        else -> "این اقدام بخشی از ریتم روزانه‌ای است که مسیر رشد را پایدار می‌کند."
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = SuperColors.GoldSoft),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Lightbulb, contentDescription = null, tint = SuperColors.GoldDeep, modifier = Modifier.size(20.dp))
            Column(Modifier.weight(1f).padding(horizontal = 8.dp), horizontalAlignment = Alignment.End) {
                Text("چرا این اقدام مهم است؟", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                Text(copy, color = SuperColors.TextSecondary, fontSize = 9.sp, textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun SubtaskRow(
    item: TaskSubtask,
    checked: Boolean,
    onToggle: () -> Unit,
    onOpenCrm: (() -> Unit)?
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (checked) SuperColors.GreenSoft else Color(0xFFF8FBFF), RoundedCornerShape(15.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .background(if (checked) SuperColors.Green else Color.White, CircleShape)
                .border(1.dp, if (checked) SuperColors.Green else SuperColors.BorderBlue, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
            } else {
                Icon(
                    when (item.iconType) {
                        0 -> Icons.Outlined.Person
                        1 -> Icons.Outlined.ChatBubbleOutline
                        else -> Icons.Outlined.Description
                    },
                    contentDescription = null,
                    tint = SuperColors.Blue,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 9.dp), horizontalAlignment = Alignment.End) {
            Text(item.title, color = SuperColors.Navy, fontWeight = FontWeight.Bold, fontSize = 10.5.sp, maxLines = 1)
            Text(item.hint, color = SuperColors.TextSecondary, fontSize = 8.3.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (onOpenCrm != null) {
            Text(
                "CRM",
                color = SuperColors.Blue,
                fontWeight = FontWeight.Black,
                fontSize = 8.3.sp,
                modifier = Modifier
                    .background(SuperColors.BlueSoft, SuperShapes.Pill)
                    .clickable { onOpenCrm() }
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
private fun TimeChoice(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(
        modifier = modifier
            .height(38.dp)
            .background(if (selected) SuperColors.BlueSoft else Color(0xFFF8FBFF), RoundedCornerShape(12.dp))
            .border(1.dp, if (selected) SuperColors.Blue.copy(alpha = 0.45f) else SuperColors.Border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) SuperColors.Blue else SuperColors.TextSecondary, fontWeight = FontWeight.Bold, fontSize = 9.2.sp)
    }
}

@Composable
private fun FocusContent(
    task: AppTask,
    minutes: Int,
    completedCount: Int,
    totalSubtasks: Int,
    onBack: () -> Unit,
    onFinish: () -> Unit
) {
    var secondsRemaining by remember(minutes) { mutableIntStateOf(minutes * 60) }
    var running by remember { mutableStateOf(true) }
    var musicOn by remember { mutableStateOf(false) }

    LaunchedEffect(running, secondsRemaining) {
        if (running && secondsRemaining > 0) {
            delay(1000)
            secondsRemaining -= 1
        } else if (secondsRemaining <= 0) {
            onFinish()
        }
    }

    val mins = secondsRemaining / 60
    val secs = secondsRemaining % 60
    val progress = if (minutes > 0) 1f - (secondsRemaining / (minutes * 60f)) else 0f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF0F8FF), Color.White, Color(0xFFF7FBFF))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0xFF78C6FF).copy(alpha = 0.12f), size.width * 0.48f, Offset(size.width * 0.50f, size.height * 0.40f))
            drawCircle(Color(0xFF90D9C0).copy(alpha = 0.06f), size.width * 0.30f, Offset(size.width * 0.08f, size.height * 0.82f))
        }
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(42.dp).background(Color.White, CircleShape)) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                }
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("حالت تمرکز", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text(task.title, color = SuperColors.TextSecondary, fontSize = 9.5.sp)
                }
                IconButton(
                    onClick = { musicOn = !musicOn },
                    modifier = Modifier.size(42.dp).background(if (musicOn) SuperColors.PurpleSoft else Color.White, CircleShape)
                ) {
                    Icon(Icons.Outlined.MusicNote, contentDescription = "موسیقی", tint = if (musicOn) SuperColors.Purple else SuperColors.TextSecondary)
                }
            }

            Spacer(Modifier.weight(0.6f))
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.size(220.dp),
                    color = SuperColors.Blue,
                    trackColor = Color(0xFFDCECF9),
                    strokeWidth = 11.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%02d:%02d".format(mins, secs), color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 44.sp)
                    Text(if (running) "تمرکز روی یک اقدام" else "مکث", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
                }
            }

            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.padding(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(36.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 9.dp), horizontalAlignment = Alignment.End) {
                            Text(task.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("$completedCount از $totalSubtasks زیرکار آماده", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                        }
                        Text("+${task.points.coerceAtLeast(20)} XP", color = SuperColors.GoldDeep, fontWeight = FontWeight.Black, fontSize = 9.5.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("فقط همین قدم را انجام بده؛ بقیه بعداً.", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { running = !running },
                    modifier = Modifier.size(58.dp).background(SuperColors.BlueSoft, CircleShape)
                ) {
                    Icon(if (running) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(27.dp))
                }
                Button(
                    onClick = onFinish,
                    modifier = Modifier.height(52.dp).width(190.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) {
                    Text("پایان و ثبت نتیجه", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ResultSheet(
    canComplete: Boolean,
    remaining: Int,
    onDone: () -> Unit,
    onLater: () -> Unit,
    onFail: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(54.dp).background(if (canComplete) SuperColors.GreenSoft else SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(if (canComplete) Icons.Outlined.Check else Icons.Outlined.Flag, contentDescription = null, tint = if (canComplete) SuperColors.Green else SuperColors.Blue, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("نتیجه این اقدام؟", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
        Text(
            if (canComplete) "نتیجه را ثبت کن؛ پاداش و مسیر بلافاصله به‌روز می‌شود."
            else "$remaining زیرکار اجباری هنوز کامل نشده؛ می‌توانی ادامه بدهی یا بعداً برگردی.",
            color = SuperColors.TextSecondary,
            fontSize = 9.3.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onDone,
            enabled = canComplete,
            modifier = Modifier.fillMaxWidth().height(44.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Green, disabledContainerColor = Color(0xFFDCE8E3))
        ) { Text("انجام شد", fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(7.dp))
        OutlinedButton(onClick = onLater, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(14.dp)) {
            Text("ادامه بعداً", color = SuperColors.Blue, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(7.dp))
        OutlinedButton(onClick = onFail, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Outlined.Close, contentDescription = null, tint = SuperColors.Red, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text("ناموفق", color = SuperColors.Red, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CompletionContent(contentPadding: PaddingValues, task: AppTask, onContinue: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF5FFF9), Color.White, Color(0xFFF4FAFF))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(SuperColors.Green.copy(alpha = 0.09f), size.width * 0.48f, Offset(size.width * 0.5f, size.height * 0.32f))
            drawCircle(SuperColors.Gold.copy(alpha = 0.06f), size.width * 0.30f, Offset(size.width * 0.12f, size.height * 0.80f))
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = 18.dp,
                    end = 18.dp,
                    top = contentPadding.calculateTopPadding() + 26.dp,
                    bottom = contentPadding.calculateBottomPadding() + 18.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(0.45f))
            Box(Modifier.size(90.dp).background(SuperColors.GreenSoft, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Check, contentDescription = null, tint = SuperColors.Green, modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("مرحله ثبت شد", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 26.sp)
            Text(task.title, color = SuperColors.TextSecondary, fontSize = 10.5.sp)
            Spacer(Modifier.height(18.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatRewardCard("+${task.points.coerceAtLeast(20)}", "XP", SuperColors.Blue, SuperColors.BlueSoft, Modifier.weight(1f))
                StatRewardCard("+2", "سکه", SuperColors.GoldDeep, SuperColors.GoldSoft, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("کمبو", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("2 / 3", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    LinearProgressIndicator(
                        progress = { 2f / 3f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = SuperColors.BlueSoft
                    )
                    Spacer(Modifier.height(6.dp))
                    Text("۱ اقدام دیگه تا فعال شدن کمبو ×2", color = SuperColors.TextSecondary, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2)
            ) {
                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
                    Column(Modifier.weight(1f).padding(horizontal = 9.dp), horizontalAlignment = Alignment.End) {
                        Text("قدم بعدی آماده است", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        Text("مسیر پیشرفت و Next Action با نتیجه جدید همگام می‌شوند.", color = SuperColors.TextSecondary, fontSize = 8.8.sp)
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Button(
                onClick = onContinue,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
            ) {
                Text("ادامه مسیر", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FailureContent(
    contentPadding: PaddingValues,
    task: AppTask,
    onRetry: () -> Unit,
    onBackToPath: () -> Unit
) {
    var selectedReason by remember { mutableStateOf("زمان مناسب نبود") }
    val reasons = listOf("زمان مناسب نبود", "پاسخ نگرفتم", "نیاز به پیگیری")
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFFFF7F7), Color.White, Color(0xFFF8FBFF))))
            .padding(
                start = 18.dp,
                end = 18.dp,
                top = contentPadding.calculateTopPadding() + 28.dp,
                bottom = contentPadding.calculateBottomPadding() + 18.dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.4f))
        Box(Modifier.size(86.dp).background(SuperColors.RedSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Close, contentDescription = null, tint = SuperColors.Red, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("این تلاش ناموفق ثبت شد", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 23.sp)
        Text(task.title, color = SuperColors.TextSecondary, fontSize = 10.sp)
        Spacer(Modifier.height(18.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.7.dp)
        ) {
            Column(Modifier.padding(13.dp)) {
                Text("دلیل کوتاه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    reasons.forEach { reason ->
                        Surface(
                            modifier = Modifier.weight(1f).clickable { selectedReason = reason },
                            color = if (selectedReason == reason) SuperColors.RedSoft else Color(0xFFF7F9FC),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                reason,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 8.dp),
                                color = if (selectedReason == reason) SuperColors.Red else SuperColors.TextSecondary,
                                fontSize = 7.7.sp,
                                fontWeight = if (selectedReason == reason) FontWeight.Black else FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("ناموفق بودن مسیر را نمی‌بندد؛ می‌توانی Reset کنی و دوباره تلاش کنی.", color = SuperColors.TextSecondary, fontSize = 9.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onRetry,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
        ) {
            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(5.dp))
            Text("Reset و تلاش دوباره", fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onBackToPath,
            modifier = Modifier.fillMaxWidth().height(44.dp),
            shape = RoundedCornerShape(15.dp)
        ) {
            Text("بازگشت به مسیر", color = SuperColors.Blue, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SmallReward(text: String, color: Color, background: Color) {
    Box(
        Modifier.background(background, SuperShapes.Pill).padding(horizontal = 8.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 8.3.sp, maxLines = 1)
    }
}

@Composable
private fun StatRewardCard(title: String, subtitle: String, color: Color, background: Color, modifier: Modifier) {
    Card(modifier = modifier.height(78.dp), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = background)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, color = color, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(subtitle, color = SuperColors.TextSecondary, fontSize = 9.sp)
        }
    }
}
