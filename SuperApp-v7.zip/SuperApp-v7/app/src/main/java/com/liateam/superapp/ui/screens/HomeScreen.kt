package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.MotivationalQuotes
import com.liateam.superapp.ui.model.homeDestinations

private data class ShortcutVisual(
    val icon: ImageVector,
    val accent: Color,
    val accent2: Color,
    val soft: Color
)

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val nextAction = tasks.firstOrNull { it.status.name == "TODO" } ?: tasks.first()
    val quote = remember { MotivationalQuotes.all.random() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.White, Color(0xFFF9FCFF), SuperColors.Background)
                )
            )
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 4.dp,
                bottom = contentPadding.calculateBottomPadding() + 3.dp
            )
    ) {
        HomeHeader(
            quote = quote,
            onNotifications = { onOpenDestination(HomeDestination.NOTIFICATIONS) },
            onProfile = { onOpenDestination(HomeDestination.PROFILE) }
        )
        Spacer(Modifier.height(5.dp))
        StatusStrip()
        Spacer(Modifier.height(7.dp))

        NextActionHero(
            modifier = Modifier.height(142.dp),
            task = nextAction,
            onStart = onOpenActions
        )

        Spacer(Modifier.height(7.dp))
        RewardStrip(onClick = { onOpenDestination(HomeDestination.REWARD_STORE) })
        Spacer(Modifier.height(7.dp))

        ShortcutPager(
            modifier = Modifier.weight(1f),
            onOpenDestination = onOpenDestination
        )
    }
}

@Composable
private fun HomeHeader(
    quote: String,
    onNotifications: () -> Unit,
    onProfile: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(40.dp)
                    .shadow(2.dp, SuperShapes.Small, clip = false)
                    .background(Color.White, SuperShapes.Small)
                    .border(1.dp, SuperColors.Border, SuperShapes.Small),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onNotifications, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.NotificationsNone,
                        contentDescription = "اعلان‌ها",
                        tint = SuperColors.Navy,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(9.dp)
                        .background(SuperColors.Red, CircleShape)
                        .border(2.dp, Color.White, CircleShape)
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxWidth(0.68f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "شهریار",
                        color = SuperColors.Text,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 21.sp,
                        lineHeight = 22.sp,
                        maxLines = 1
                    )
                    AdaptiveMotivationText(quote)
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(45.dp)
                    .shadow(2.dp, CircleShape, clip = false)
                    .background(
                        Brush.radialGradient(listOf(Color.White, SuperColors.BlueSoft)),
                        CircleShape
                    )
                    .border(1.5.dp, SuperColors.Gold.copy(alpha = 0.9f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onProfile, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.Person,
                        contentDescription = "پروفایل",
                        tint = SuperColors.Blue,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(15.dp)
                        .background(SuperColors.Gold, CircleShape)
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("3", color = SuperColors.Navy, fontSize = 7.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun AdaptiveMotivationText(quote: String) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val widthPerChar = maxWidth.value / quote.length.coerceAtLeast(1)
        val font = when {
            widthPerChar >= 12f -> 11.8.sp
            widthPerChar >= 9f -> 11.0.sp
            widthPerChar >= 7f -> 10.2.sp
            widthPerChar >= 5.5f -> 9.4.sp
            else -> 8.5.sp
        }
        Text(
            text = quote,
            color = SuperColors.TextSecondary,
            fontSize = font,
            lineHeight = font,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun StatusStrip() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .shadow(2.dp, SuperShapes.Small, clip = false),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = SuperShapes.Small,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, SuperColors.Border, SuperShapes.Small)
                    .padding(horizontal = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatItem(
                    modifier = Modifier.weight(0.88f),
                    icon = Icons.Outlined.WorkspacePremium,
                    value = "سطح ۳",
                    label = "Level",
                    accent = SuperColors.Gold
                )
                Hairline()
                Column(modifier = Modifier.weight(1.55f)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("240 / 500", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 10.5.sp)
                        Text("XP", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    LinearProgressIndicator(
                        progress = { 0.48f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = Color(0xFFE5EEF8)
                    )
                }
                Hairline()
                StatItem(
                    modifier = Modifier.weight(0.72f),
                    icon = Icons.Outlined.EmojiEvents,
                    value = "۶۹۵",
                    label = "Coin",
                    accent = SuperColors.Gold
                )
                Hairline()
                StatItem(
                    modifier = Modifier.weight(0.78f),
                    icon = Icons.Outlined.Timer,
                    value = "۷ روز",
                    label = "Streak",
                    accent = SuperColors.Orange
                )
            }
        }
    }
}

@Composable
private fun StatItem(
    modifier: Modifier,
    icon: ImageVector,
    value: String,
    label: String,
    accent: Color
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(
                modifier = Modifier.size(20.dp).background(accent.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(13.dp))
            }
            Spacer(Modifier.width(3.dp))
            Text(value, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 10.8.sp, maxLines = 1)
        }
        Text(label, color = accent, fontSize = 7.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun Hairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 6.dp)
            .width(1.dp)
            .height(28.dp)
            .background(SuperColors.Border)
    )
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(3.dp, SuperShapes.Card, clip = false),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color.White, Color(0xFFF1F7FF), SuperColors.BlueSoft)
                    )
                )
                .border(1.dp, SuperColors.BorderBlue, SuperShapes.Card)
                .padding(horizontal = 13.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoalPathIllustration(modifier = Modifier.weight(0.86f).fillMaxHeight())
            Spacer(Modifier.width(8.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.weight(1.28f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        "قدم بعدی",
                        color = SuperColors.Blue,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        task.title,
                        color = SuperColors.Text,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        task.subtitle,
                        color = SuperColors.TextSecondary,
                        fontSize = 9.2.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(7.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = onStart,
                            modifier = Modifier.height(34.dp),
                            shape = SuperShapes.Pill,
                            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.BlueStrong),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("شروع", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Spacer(Modifier.width(6.dp))
                        RewardChip("+${task.points.coerceAtLeast(20)} XP", SuperColors.Blue, SuperColors.BlueSoft)
                        Spacer(Modifier.width(4.dp))
                        RewardChip("+2 Coin", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    }
                }
            }
        }
    }
}

@Composable
private fun RewardChip(text: String, accent: Color, soft: Color) {
    Box(
        modifier = Modifier
            .height(26.dp)
            .background(soft, SuperShapes.Pill)
            .border(1.dp, accent.copy(alpha = 0.22f), SuperShapes.Pill)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = accent, fontSize = 8.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun GoalPathIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawCircle(SuperColors.Blue.copy(alpha = 0.07f), radius = w * 0.36f, center = Offset(w * 0.50f, h * 0.50f))

        val stepW = w * 0.26f
        val stepH = h * 0.13f
        val xs = listOf(w * 0.10f, w * 0.30f, w * 0.50f, w * 0.70f)
        val ys = listOf(h * 0.69f, h * 0.56f, h * 0.43f, h * 0.30f)
        xs.zip(ys).forEachIndexed { index, (x, y) ->
            drawRoundRect(
                color = if (index == 3) SuperColors.BlueStrong else Color(0xFFDDEEFF),
                topLeft = Offset(x, y),
                size = Size(stepW, stepH),
                cornerRadius = CornerRadius(10f, 10f)
            )
            drawRoundRect(
                color = if (index == 3) SuperColors.BlueDeep.copy(alpha = 0.45f) else SuperColors.Blue.copy(alpha = 0.12f),
                topLeft = Offset(x, y + stepH * 0.72f),
                size = Size(stepW, stepH * 0.28f),
                cornerRadius = CornerRadius(7f, 7f)
            )
        }

        val path = Path().apply {
            moveTo(w * 0.18f, h * 0.73f)
            cubicTo(w * 0.33f, h * 0.63f, w * 0.48f, h * 0.55f, w * 0.62f, h * 0.43f)
            cubicTo(w * 0.71f, h * 0.35f, w * 0.78f, h * 0.27f, w * 0.81f, h * 0.20f)
        }
        drawPath(path, color = SuperColors.Gold, style = Stroke(width = 5f, cap = StrokeCap.Round))

        drawLine(SuperColors.Navy, Offset(w * 0.81f, h * 0.28f), Offset(w * 0.81f, h * 0.12f), strokeWidth = 4f, cap = StrokeCap.Round)
        val flag = Path().apply {
            moveTo(w * 0.81f, h * 0.12f)
            lineTo(w * 0.96f, h * 0.16f)
            lineTo(w * 0.81f, h * 0.21f)
            close()
        }
        drawPath(flag, SuperColors.Gold)
        drawCircle(SuperColors.GoldBright, radius = w * 0.03f, center = Offset(w * 0.14f, h * 0.78f))
        drawCircle(SuperColors.Blue, radius = w * 0.02f, center = Offset(w * 0.42f, h * 0.38f))
    }
}

@Composable
private fun RewardStrip(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(62.dp)
            .shadow(2.dp, SuperShapes.Small, clip = false),
        onClick = onClick,
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, SuperColors.Border, SuperShapes.Small)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RewardChestAsset(modifier = Modifier.size(width = 58.dp, height = 48.dp))
                Spacer(Modifier.width(9.dp))
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                    Text("صندوق پاداش", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 12.5.sp)
                    Text("تا باز شدن بعدی", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                }
                Box(
                    modifier = Modifier
                        .background(SuperColors.GoldSoft, SuperShapes.Pill)
                        .border(1.dp, SuperColors.Gold.copy(alpha = 0.38f), SuperShapes.Pill)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text("۰۲:۵۸:۴۰", color = SuperColors.GoldDeep, fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun RewardChestAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(SuperColors.Navy.copy(alpha = 0.08f), Offset(w * 0.10f, h * 0.78f), Size(w * 0.80f, h * 0.14f))
        drawRoundRect(
            color = SuperColors.BlueDeep,
            topLeft = Offset(w * 0.13f, h * 0.40f),
            size = Size(w * 0.74f, h * 0.40f),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            color = SuperColors.Blue,
            topLeft = Offset(w * 0.11f, h * 0.27f),
            size = Size(w * 0.78f, h * 0.26f),
            cornerRadius = CornerRadius(14f, 14f)
        )
        drawRoundRect(
            color = SuperColors.Gold,
            topLeft = Offset(w * 0.44f, h * 0.38f),
            size = Size(w * 0.13f, h * 0.24f),
            cornerRadius = CornerRadius(5f, 5f)
        )
        drawCircle(SuperColors.GoldBright, radius = w * 0.045f, center = Offset(w * 0.50f, h * 0.50f))
        drawLine(SuperColors.GoldBright, Offset(w * 0.23f, h * 0.25f), Offset(w * 0.18f, h * 0.14f), 3.5f, StrokeCap.Round)
        drawLine(SuperColors.GoldBright, Offset(w * 0.50f, h * 0.19f), Offset(w * 0.50f, h * 0.08f), 3.5f, StrokeCap.Round)
        drawLine(SuperColors.GoldBright, Offset(w * 0.77f, h * 0.25f), Offset(w * 0.82f, h * 0.14f), 3.5f, StrokeCap.Round)
    }
}

@Composable
private fun ShortcutPager(
    modifier: Modifier,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val pages = remember { homeDestinations().chunked(6) }
    val pagerState = rememberPagerState(pageCount = { pages.size })

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, SuperColors.Border, SuperShapes.Card)
                .padding(top = 7.dp, bottom = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(22.dp).padding(horizontal = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("دسترسی سریع", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text("بکش ←", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
            }

            Spacer(Modifier.height(3.dp))
            BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
                val pageWidth = maxWidth - 17.dp
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        pageSize = PageSize.Fixed(pageWidth),
                        pageSpacing = 8.dp,
                        contentPadding = PaddingValues(start = 0.dp, end = 17.dp),
                        beyondViewportPageCount = 1
                    ) { page ->
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            ShortcutGrid(
                                destinations = pages[page],
                                onOpenDestination = onOpenDestination
                            )
                        }
                    }
                }

                if (pagerState.currentPage < pages.lastIndex) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxHeight()
                            .width(18.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color.Transparent, Color.White.copy(alpha = 0.84f))
                                )
                            )
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().height(13.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(pages.size) { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(if (index == pagerState.currentPage) 8.dp else 5.dp)
                            .background(
                                if (index == pagerState.currentPage) SuperColors.Blue else Color(0xFFD8E3EF),
                                CircleShape
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun ShortcutGrid(
    destinations: List<HomeDestination>,
    onOpenDestination: (HomeDestination) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 3.dp)) {
        val top = destinations.take(3)
        val bottom = destinations.drop(3)
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            top.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bottom.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
            repeat(3 - bottom.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
private fun ShortcutTile(
    modifier: Modifier,
    destination: HomeDestination,
    onClick: () -> Unit
) {
    val visual = shortcutVisual(destination)
    Card(
        modifier = modifier.shadow(1.dp, SuperShapes.Small, clip = false),
        onClick = onClick,
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, SuperColors.Border, SuperShapes.Small)
                .background(
                    Brush.verticalGradient(listOf(Color.White, visual.soft.copy(alpha = 0.48f))),
                    SuperShapes.Small
                )
        ) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(0.54f)
                    .height(3.dp)
                    .background(visual.accent, SuperShapes.Pill)
            )
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ShortcutAsset(visual = visual)
                Spacer(Modifier.height(3.dp))
                Text(
                    destination.title,
                    color = SuperColors.Text,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 9.7.sp,
                    maxLines = 1,
                    textAlign = TextAlign.Center,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ShortcutAsset(visual: ShortcutVisual) {
    Box(
        modifier = Modifier.size(width = 58.dp, height = 44.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val base = Path().apply {
                moveTo(size.width * 0.18f, size.height * 0.66f)
                lineTo(size.width * 0.48f, size.height * 0.48f)
                lineTo(size.width * 0.82f, size.height * 0.66f)
                lineTo(size.width * 0.51f, size.height * 0.84f)
                close()
            }
            drawPath(base, visual.accent.copy(alpha = 0.13f))
            drawCircle(visual.accent2.copy(alpha = 0.12f), radius = size.height * 0.22f, center = Offset(size.width * 0.72f, size.height * 0.27f))
            drawCircle(visual.accent.copy(alpha = 0.08f), radius = size.height * 0.16f, center = Offset(size.width * 0.22f, size.height * 0.35f))
        }
        Box(
            modifier = Modifier
                .size(32.dp)
                .shadow(1.dp, CircleShape, clip = false)
                .background(Color.White, CircleShape)
                .border(1.dp, visual.accent.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(21.dp))
        }
    }
}

private fun shortcutVisual(destination: HomeDestination): ShortcutVisual = when (destination) {
    HomeDestination.PROGRESS -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.Sky, SuperColors.BlueSoft)
    HomeDestination.NETWORK -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, Color(0xFF59C995), SuperColors.GreenSoft)
    HomeDestination.ACADEMY -> ShortcutVisual(Icons.Outlined.School, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.MY_WEEK -> ShortcutVisual(Icons.Outlined.CalendarMonth, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.ACTIONS -> ShortcutVisual(Icons.Outlined.TaskAlt, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.CUSTOMERS -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Orange, SuperColors.Gold, SuperColors.OrangeSoft)
    HomeDestination.LEADER_CENTER -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.BlueDeep, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.GOALS -> ShortcutVisual(Icons.Outlined.TrackChanges, SuperColors.Red, SuperColors.Orange, SuperColors.RedSoft)
    HomeDestination.RANK_REWARDS -> ShortcutVisual(Icons.Outlined.EmojiEvents, SuperColors.GoldDeep, SuperColors.GoldBright, SuperColors.GoldSoft)
    HomeDestination.EVENTS -> ShortcutVisual(Icons.Outlined.Event, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.LIBRARY -> ShortcutVisual(Icons.Outlined.MenuBook, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.SALES -> ShortcutVisual(Icons.Outlined.ShoppingCart, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.REPORTS -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.PERSONAL_STORE -> ShortcutVisual(Icons.Outlined.Storefront, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.PROFILE -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.SETTINGS -> ShortcutVisual(Icons.Outlined.Settings, SuperColors.TextSecondary, SuperColors.Blue, SuperColors.NeutralSoft)
    HomeDestination.SEARCH -> ShortcutVisual(Icons.Outlined.Search, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.NOTIFICATIONS -> ShortcutVisual(Icons.Outlined.NotificationsNone, SuperColors.Red, SuperColors.Gold, SuperColors.RedSoft)
    HomeDestination.FOCUS -> ShortcutVisual(Icons.Outlined.Timer, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TREE -> ShortcutVisual(Icons.Outlined.AccountTree, SuperColors.Green, SuperColors.Blue, SuperColors.GreenSoft)
    HomeDestination.PROFILE_360 -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.GROUPS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Orange, SuperColors.Green, SuperColors.OrangeSoft)
    HomeDestination.CHANNELS -> ShortcutVisual(Icons.Outlined.ChatBubbleOutline, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TEAM_MEMBERS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.DREAM_BOARD -> ShortcutVisual(Icons.Outlined.Flag, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.ACHIEVEMENTS -> ShortcutVisual(Icons.Outlined.WorkspacePremium, SuperColors.GoldDeep, SuperColors.Purple, SuperColors.GoldSoft)
    HomeDestination.LEADERBOARD -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.REWARD_STORE -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.WEBSITE -> ShortcutVisual(Icons.Outlined.Language, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.ORDERS -> ShortcutVisual(Icons.Outlined.ReceiptLong, SuperColors.Green, SuperColors.Orange, SuperColors.GreenSoft)
}
