package com.liateam.superapp.ui.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Legacy-inspired light design system. */
object SuperColors {
    // Primary identity
    val Blue = Color(0xFF1976F3)
    val BlueStrong = Color(0xFF0F67DE)
    val BlueDeep = Color(0xFF0B57C7)
    val BlueSoft = Color(0xFFEAF4FF)
    val BlueSoft2 = Color(0xFFF4F9FF)
    val Sky = Color(0xFF69B7FF)

    // Neutral / typography
    val Navy = Color(0xFF0B1F4D)
    val Text = Color(0xFF0B1838)
    val TextSecondary = Color(0xFF71809A)
    val Border = Color(0xFFDCE8F7)
    val BorderBlue = Color(0xFFC8DFF8)
    val Background = Color(0xFFF7FAFF)
    val Surface = Color.White

    // Semantic colors
    val Green = Color(0xFF22B573)
    val GreenSoft = Color(0xFFEAF8F1)
    val Red = Color(0xFFE84545)
    val RedSoft = Color(0xFFFFEEEE)
    val Orange = Color(0xFFF59E0B)
    val OrangeSoft = Color(0xFFFFF5DF)
    val Purple = Color(0xFF7657E8)
    val PurpleSoft = Color(0xFFF1EDFF)

    // Gamification only
    val Gold = Color(0xFFF5B82E)
    val GoldBright = Color(0xFFFFD058)
    val GoldDeep = Color(0xFFCE8E14)
    val GoldSoft = Color(0xFFFFF6D8)
    val NeutralSoft = Color(0xFFF1F5FA)
}

object SuperDimens {
    val ScreenPadding = 16.dp
    val CardRadius = 20.dp
    val SmallRadius = 15.dp
    val PillRadius = 999.dp
}

object SuperShapes {
    val Card = RoundedCornerShape(SuperDimens.CardRadius)
    val Small = RoundedCornerShape(SuperDimens.SmallRadius)
    val Pill = RoundedCornerShape(SuperDimens.PillRadius)
}
