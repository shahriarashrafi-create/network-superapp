package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors

@Composable
fun PlaceholderScreen(
    contentPadding: PaddingValues,
    title: String,
    subtitle: String,
    onBack: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuperColors.Background)
            .padding(contentPadding)
            .padding(20.dp)
    ) {
        if (onBack != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Text)
                }
                Text(title, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (onBack == null) {
                    Text(title, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                }
                Text(subtitle, color = SuperColors.TextSecondary, textAlign = TextAlign.Center, lineHeight = 22.sp)
                Text("این لینک از Home فعال است و در فاز بعدی محتوای کامل این ماژول روی همین Route ساخته می‌شود.", color = SuperColors.Blue, textAlign = TextAlign.Center, fontSize = 12.sp)
            }
        }
    }
}
