package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

@Composable
fun ProfileScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color.White, Color(0xFFF8FBFF), SuperColors.Background))
            )
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 5.dp,
                bottom = contentPadding.calculateBottomPadding() + 5.dp
            )
            .verticalScroll(rememberScrollState())
    ) {
        ProfileTopBar(onBack = onBack)
        Spacer(Modifier.height(10.dp))
        ProfileHero()
        Spacer(Modifier.height(10.dp))
        ProgressCard()
        Spacer(Modifier.height(10.dp))
        AchievementPreview()
        Spacer(Modifier.height(10.dp))
        TeamCard()
        Spacer(Modifier.height(10.dp))
        ProfileMenu(onOpenSettings = onOpenSettings)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun ProfileTopBar(onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(44.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Spacer(Modifier.weight(1f))
        Text("پروفایل", color = SuperColors.Text, fontWeight = FontWeight.Black, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.size(40.dp))
    }
}

@Composable
private fun ProfileHero() {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(2.dp, SuperShapes.Card, clip = false),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SuperColors.Border, SuperShapes.Card)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(
                            Brush.radialGradient(listOf(Color.White, SuperColors.BlueSoft)),
                            CircleShape
                        )
                        .border(2.dp, SuperColors.Gold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Person, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(40.dp))
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .size(23.dp)
                            .background(SuperColors.Gold, CircleShape)
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("3", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("شهریار", color = SuperColors.Text, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    Text("تیم Legacy • عضو فعال", color = SuperColors.TextSecondary, fontSize = 10.5.sp)
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ProfileBadge("لیدر", SuperColors.Blue, SuperColors.BlueSoft)
                        ProfileBadge("سطح ۳", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileBadge(text: String, accent: Color, soft: Color) {
    Box(
        modifier = Modifier
            .background(soft, SuperShapes.Pill)
            .border(1.dp, accent.copy(alpha = 0.24f), SuperShapes.Pill)
            .padding(horizontal = 9.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = accent, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun ProgressCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SuperColors.Border, SuperShapes.Card)
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("رشد شما", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Text("240 / 500 XP", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { 0.48f },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = Color(0xFFE6EEF8)
            )
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                MiniStat(Icons.Outlined.EmojiEvents, "۶۹۵", "Coin", SuperColors.GoldDeep)
                MiniStat(Icons.Outlined.WorkspacePremium, "۱۲", "دستاورد", SuperColors.GoldDeep)
                MiniStat(Icons.Outlined.Groups, "۲۴", "اعضای شبکه", SuperColors.Green)
            }
        }
    }
}

@Composable
private fun MiniStat(icon: ImageVector, value: String, label: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(31.dp).background(accent.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(value, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
        Text(label, color = SuperColors.TextSecondary, fontSize = 8.5.sp)
    }
}

@Composable
private fun AchievementPreview() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SuperColors.Border, SuperShapes.Card)
                .padding(14.dp)
        ) {
            Text("دستاوردهای اخیر", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AchievementItem("اولین فروش", SuperColors.Gold, Modifier.weight(1f))
                AchievementItem("۷ روز استمرار", SuperColors.Orange, Modifier.weight(1f))
                AchievementItem("دوره کامل", SuperColors.Purple, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun AchievementItem(title: String, accent: Color, modifier: Modifier) {
    Column(
        modifier = modifier
            .background(accent.copy(alpha = 0.08f), SuperShapes.Small)
            .border(1.dp, accent.copy(alpha = 0.17f), SuperShapes.Small)
            .padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Outlined.WorkspacePremium, contentDescription = null, tint = accent, modifier = Modifier.size(25.dp))
        Spacer(Modifier.height(5.dp))
        Text(title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 8.5.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun TeamCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SuperColors.BorderBlue, SuperShapes.Card)
                .padding(13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.size(40.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Groups, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("تیم Legacy", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                Text("تمرکز فعلی: رشد شبکه و استمرار", color = SuperColors.TextSecondary, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun ProfileMenu(onOpenSettings: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, SuperColors.Border, SuperShapes.Card)
        ) {
            ProfileMenuRow(Icons.Outlined.Settings, "تنظیمات حساب", "زبان، نمایش و ترجیحات", onOpenSettings)
            DividerLine()
            ProfileMenuRow(Icons.Outlined.Shield, "حریم خصوصی", "نمایش اطلاعات و دسترسی‌ها", onOpenSettings)
            DividerLine()
            ProfileMenuRow(Icons.Outlined.Lock, "امنیت", "رمز، نشست‌ها و دستگاه‌ها", onOpenSettings)
        }
    }
}

@Composable
private fun ProfileMenuRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(35.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(subtitle, color = SuperColors.TextSecondary, fontSize = 8.7.sp)
        }
        Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = SuperColors.TextSecondary, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DividerLine() {
    Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 13.dp).height(1.dp).background(SuperColors.Border))
}
