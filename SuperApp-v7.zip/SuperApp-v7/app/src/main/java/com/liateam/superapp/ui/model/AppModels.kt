package com.liateam.superapp.ui.model

enum class AppSection {
    HOME, ACTIONS, NETWORK, MESSAGES, MORE, PROGRESS
}

enum class TaskSource(val label: String) {
    TEAM("ثابت تیم"),
    SPONSOR("حامی"),
    PERSONAL("شخصی")
}

enum class TaskStatus {
    TODO, DONE, FAILED
}

data class AppTask(
    val id: Int,
    val title: String,
    val subtitle: String,
    val source: TaskSource,
    val status: TaskStatus = TaskStatus.TODO,
    val points: Int = 0
)

enum class HomeDestination(val title: String, val subtitle: String) {
    PROGRESS("مسیر پیشرفت", "مسیر مرحله‌ای رشد و Next Step"),
    NETWORK("شبکه من", "درختواره، اعضا و سازمان"),
    ACADEMY("آموزش", "Academy و مسیر یادگیری"),
    MY_WEEK("هفته من", "برنامه هفتگی و Timesheet"),
    ACTIONS("اقدامات", "Action Center و کارهای جاری"),
    CUSTOMERS("مشتریان", "CRM مشتری و Prospect"),

    LEADER_CENTER("مرکز حامی", "افراد نیازمند توجه و تأییدها"),
    GOALS("هدف‌ها", "Goal، Milestone و Next Action"),
    RANK_REWARDS("رتبه و پاداش", "Rank، Coin و Recognition"),
    EVENTS("رویدادها", "تقویم، ثبت‌نام و حضور"),
    LIBRARY("کتابخانه", "کتاب، صوت و ادامه مطالعه"),
    SALES("مرکز فروش", "فروش، PV/GPV و سفارش‌ها"),

    REPORTS("گزارش‌ها", "گزارش‌های عملکرد و روندها"),
    PERSONAL_STORE("فروشگاه شخصی", "فروشگاه و لینک‌های اختصاصی"),
    PROFILE("پروفایل", "حساب، Rank و دستاوردها"),
    SETTINGS("تنظیمات", "حریم خصوصی، امنیت و ترجیحات"),
    SEARCH("جستجو", "جستجوی سراسری سوپر اپ"),
    NOTIFICATIONS("اعلان‌ها", "Action Required و اطلاع‌رسانی‌ها"),

    FOCUS("تمرکز", "Focus Mode، تایمر و Start Work"),
    TREE("درختواره", "نمای چندسطحی سازمان"),
    PROFILE_360("پروفایل ۳۶۰", "نمای کوچینگ کامل اعضا"),
    GROUPS("گروه‌ها", "گروه‌های تیمی و گفتگو"),
    CHANNELS("کانال‌ها", "اعلان‌ها و کانال‌های رسمی"),
    TEAM_MEMBERS("اعضای سازمان", "اعضا، نقش‌ها و وضعیت"),

    DREAM_BOARD("دریم‌بورد", "Dream Board و آرزوهای قابل اندازه‌گیری"),
    ACHIEVEMENTS("دستاوردها", "Badgeها و Achievementها"),
    LEADERBOARD("لیدربورد", "رتبه‌بندی روزانه، هفتگی و ماهانه"),
    REWARD_STORE("فروشگاه پاداش", "خرج Coin برای Rewardها"),
    WEBSITE("سایت شخصی", "Website Builder و دامنه شخصی"),
    ORDERS("سفارش‌ها", "وضعیت سفارش و خرید مجدد")
}

fun homeDestinations(): List<HomeDestination> = listOf(
    // Page 1: keep the approved Home layout order in RTL.
    HomeDestination.ACADEMY, HomeDestination.NETWORK, HomeDestination.PROGRESS,
    HomeDestination.CUSTOMERS, HomeDestination.ACTIONS, HomeDestination.MY_WEEK,

    // Page 2
    HomeDestination.SALES, HomeDestination.LIBRARY, HomeDestination.EVENTS,
    HomeDestination.RANK_REWARDS, HomeDestination.GOALS, HomeDestination.LEADER_CENTER,

    // Page 3
    HomeDestination.NOTIFICATIONS, HomeDestination.SEARCH, HomeDestination.SETTINGS,
    HomeDestination.PROFILE, HomeDestination.PERSONAL_STORE, HomeDestination.REPORTS,

    // Page 4
    HomeDestination.TEAM_MEMBERS, HomeDestination.CHANNELS, HomeDestination.GROUPS,
    HomeDestination.PROFILE_360, HomeDestination.TREE, HomeDestination.FOCUS,

    // Page 5
    HomeDestination.ORDERS, HomeDestination.WEBSITE, HomeDestination.REWARD_STORE,
    HomeDestination.LEADERBOARD, HomeDestination.ACHIEVEMENTS, HomeDestination.DREAM_BOARD
)

fun initialTasks(): List<AppTask> = listOf(
    AppTask(1, "دعوت یک نفر", "امروز با یک مخاطب جدید گفتگو را شروع کن", TaskSource.TEAM, points = 20),
    AppTask(2, "پیگیری یک مشتری بالقوه", "حداقل یک Follow-up واقعی ثبت کن", TaskSource.TEAM, points = 15),
    AppTask(3, "معرفی محصول", "محصول مناسب را به یک مخاطب معرفی کن", TaskSource.TEAM, points = 20),
    AppTask(4, "مرور متن دعوت", "متن دعوت را یک‌بار تمرین و آماده کن", TaskSource.SPONSOR, points = 10),
    AppTask(5, "ثبت گزارش روز", "خلاصه فعالیت‌های امروز را مرور کن", TaskSource.SPONSOR, points = 10),
    AppTask(6, "۱۰ دقیقه مطالعه", "روی رشد فردی خودت سرمایه‌گذاری کن", TaskSource.PERSONAL),
    AppTask(7, "برنامه فردا", "سه اولویت فردا را مشخص کن", TaskSource.PERSONAL)
)
