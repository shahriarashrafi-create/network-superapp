# SuperApp v7

Android prototype for the Network Marketing Super App.

## Version
- applicationId: `com.liateam.superapp`
- versionCode: `7`
- versionName: `1.5.0`
- signing: same embedded keystore used by previous builds

## v7 changes
- Legacy-inspired stronger blue visual system
- Cleaner Home hierarchy and reduced shadows
- Single-line adaptive motivational header with a 500-line quote bank
- More compact Next Action and reward cards
- 30 Home shortcuts in a 5-page horizontal pager (6 per page)
- All shortcuts navigate to a real route or an explicit placeholder
- Improved code/vector-only shortcut illustrations and reward chest
- Safe-area-aware custom bottom navigation
- New Profile screen with growth, achievements, team, privacy/security/settings entry points
- No decorative bitmap/photo/background assets are used
