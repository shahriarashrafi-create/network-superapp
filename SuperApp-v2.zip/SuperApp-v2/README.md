# Super App Android — Version 2

This build proves the first real Android → Backend connection.

- applicationId: `com.liateam.superapp`
- versionCode: `2`
- versionName: `1.0.1`
- Backend: `https://super-app-api.weblines.ir`
- Health endpoint: `/api/v1/health`
- Signing keystore: unchanged from v1

The app checks backend health on launch and shows the connection status.
