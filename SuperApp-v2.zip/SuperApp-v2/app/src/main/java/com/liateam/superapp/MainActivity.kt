package com.liateam.superapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.theme.SuperAppTheme
import java.net.HttpURLConnection
import java.net.URL

private const val API_HEALTH_URL = "https://super-app-api.weblines.ir/api/v1/health"

class MainActivity : ComponentActivity() {
    private var connectionState by mutableStateOf<ConnectionState>(ConnectionState.Checking)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            SuperAppTheme {
                VersionTwoScreen(
                    connectionState = connectionState,
                    onRetry = ::checkBackend
                )
            }
        }

        checkBackend()
    }

    private fun checkBackend() {
        connectionState = ConnectionState.Checking

        Thread {
            val result = try {
                val connection = (URL(API_HEALTH_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    setRequestProperty("Accept", "application/json")
                }

                try {
                    val statusCode = connection.responseCode
                    val body = if (statusCode in 200..299) {
                        connection.inputStream.bufferedReader().use { it.readText() }
                    } else {
                        ""
                    }

                    if (statusCode == 200 && body.contains("healthy", ignoreCase = true)) {
                        ConnectionState.Connected
                    } else {
                        ConnectionState.Error("پاسخ سرور نامعتبر بود (HTTP $statusCode)")
                    }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                ConnectionState.Error(e.message ?: "اتصال به سرور برقرار نشد")
            }

            runOnUiThread {
                connectionState = result
            }
        }.start()
    }
}

private sealed interface ConnectionState {
    data object Checking : ConnectionState
    data object Connected : ConnectionState
    data class Error(val message: String) : ConnectionState
}

@Composable
private fun VersionTwoScreen(
    connectionState: ConnectionState,
    onRetry: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF7F9FC)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFEAF2FF), RoundedCornerShape(18.dp))
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = "SUPER APP",
                            color = Color(0xFF2563EB),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "اتصال اپ به سرور",
                        color = Color(0xFF111827),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "نسخه ۲ اولین ارتباط واقعی Android با Backend سوپر اپ را تست می‌کند.",
                        color = Color(0xFF6B7280),
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    when (connectionState) {
                        ConnectionState.Checking -> {
                            CircularProgressIndicator(color = Color(0xFF2563EB))
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "در حال بررسی سرور...",
                                color = Color(0xFF6B7280),
                                textAlign = TextAlign.Center
                            )
                        }

                        ConnectionState.Connected -> {
                            ConnectionBadge(
                                text = "سرور آنلاین و متصل است ✓",
                                background = Color(0xFFDCFCE7),
                                foreground = Color(0xFF15803D)
                            )
                        }

                        is ConnectionState.Error -> {
                            ConnectionBadge(
                                text = "اتصال برقرار نشد",
                                background = Color(0xFFFEE2E2),
                                foreground = Color(0xFFB91C1C)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = connectionState.message,
                                color = Color(0xFF6B7280),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                            ) {
                                Text("تلاش دوباره")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    Text(
                        text = "https://super-app-api.weblines.ir",
                        color = Color(0xFF6B7280),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "v1.0.1  •  Build 2",
                        color = Color(0xFF2563EB),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun ConnectionBadge(
    text: String,
    background: Color,
    foreground: Color
) {
    Box(
        modifier = Modifier
            .background(background, RoundedCornerShape(18.dp))
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        Text(
            text = text,
            color = foreground,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}
