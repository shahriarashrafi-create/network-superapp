package app.networksuper.ui.progress

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MissionRulesTest {
    @Test
    fun requiredItemsGateCompletionButOptionalItemsDoNot() {
        val items = listOf(
            MissionChecklistItem(1, "required done", required = true, checked = true),
            MissionChecklistItem(2, "required pending", required = true, checked = false),
            MissionChecklistItem(3, "optional pending", required = false, checked = false)
        )

        assertFalse(MissionRules.requiredComplete(items))
        assertEquals(1, MissionRules.remainingRequired(items))

        val completedRequired = items.map { if (it.id == 2L) it.copy(checked = true) else it }
        assertTrue(MissionRules.requiredComplete(completedRequired))
        assertEquals(0, MissionRules.remainingRequired(completedRequired))
    }

    @Test
    fun timerUsesPersistedEndTimestamp() {
        val stage = ProgressStage(
            id = 1,
            number = 1,
            title = "A",
            status = StageStatus.CURRENT,
            missionStatus = MissionStatus.ACTIVE,
            durationMinutes = 30,
            startedAtMillis = 1_000L,
            endAtMillis = 61_000L
        )

        assertEquals(31_000L, MissionRules.remainingMillis(stage, 30_000L))
        assertEquals(0L, MissionRules.remainingMillis(stage, 70_000L))
        assertTrue(MissionRules.shouldExpire(stage, 61_000L))
    }

    @Test
    fun expiredTimerDoesNotMeanFailedResult() {
        val stage = ProgressStage(
            id = 1,
            number = 1,
            title = "A",
            status = StageStatus.CURRENT,
            missionStatus = MissionStatus.EXPIRED,
            endAtMillis = 1_000L
        )

        assertFalse(stage.missionStatus == MissionStatus.FAILED)
    }

    @Test
    fun checklistProgressCountsAllItems() {
        val items = listOf(
            MissionChecklistItem(1, "a", true, true),
            MissionChecklistItem(2, "b", false, false),
            MissionChecklistItem(3, "c", false, true)
        )

        assertEquals(2, MissionRules.completedCount(items))
        assertEquals(2f / 3f, MissionRules.completionFraction(items), 0.0001f)
    }
    @Test
    fun restoreClearsExecutionButPreservesNoteAndConfiguration() {
        val stage = ProgressStage(
            id = 1,
            number = 1,
            title = "A",
            status = StageStatus.CURRENT,
            missionStatus = MissionStatus.EXPIRED,
            durationMinutes = 45,
            startedAtMillis = 1_000L,
            endAtMillis = 2_000L,
            attemptCount = 3,
            note = "important note",
            checklist = listOf(MissionChecklistItem(1, "required", true, true))
        )

        val restored = MissionRules.restored(stage)

        assertEquals(MissionStatus.NOT_STARTED, restored.missionStatus)
        assertEquals("important note", restored.note)
        assertEquals(45, restored.durationMinutes)
        assertFalse(restored.checklist.single().checked)
        assertEquals(0, restored.attemptCount)
    }

    @Test
    fun retryStartsFreshAttemptAndPreservesNote() {
        val stage = ProgressStage(
            id = 2,
            number = 2,
            title = "B",
            status = StageStatus.CURRENT,
            missionStatus = MissionStatus.FAILED,
            durationMinutes = 20,
            attemptCount = 2,
            note = "keep me",
            checklist = listOf(MissionChecklistItem(20, "done before", true, true))
        )

        val retried = MissionRules.retried(stage, 5_000L)

        assertEquals(MissionStatus.ACTIVE, retried.missionStatus)
        assertEquals(3, retried.attemptCount)
        assertEquals("keep me", retried.note)
        assertFalse(retried.checklist.single().checked)
        assertEquals(1_205_000L, retried.endAtMillis)
    }

}
