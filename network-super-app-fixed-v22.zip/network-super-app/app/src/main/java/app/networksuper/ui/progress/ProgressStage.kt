package app.networksuper.ui.progress

enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

enum class MissionStatus { NOT_STARTED, ACTIVE, EXPIRED, COMPLETED, FAILED }

data class MissionChecklistItem(
    val id: Long,
    val text: String,
    val required: Boolean,
    val checked: Boolean = false
)

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus,
    val description: String = "",
    val missionStatus: MissionStatus = when (status) {
        StageStatus.COMPLETED -> MissionStatus.COMPLETED
        StageStatus.FAILED -> MissionStatus.FAILED
        StageStatus.CURRENT, StageStatus.UPCOMING -> MissionStatus.NOT_STARTED
    },
    val durationMinutes: Int = DEFAULT_MISSION_DURATION_MINUTES,
    val startedAtMillis: Long? = null,
    val endAtMillis: Long? = null,
    val completedAtMillis: Long? = null,
    val attemptCount: Int = 0,
    val note: String = "",
    val checklist: List<MissionChecklistItem> = emptyList()
) {
    companion object {
        const val DEFAULT_MISSION_DURATION_MINUTES = 30
    }
}
