package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Single source of truth for the progress path and mission execution state.
 *
 * Persistence is versioned JSON with migration from v2 and the original legacy format.
 * Mission timers are timestamp based so they continue correctly while the app is backgrounded.
 */
object ProgressPathStore {
    private const val PREFS_NAME = "progress_path_v1"
    private const val KEY_STAGES_JSON = "stages_json_v3"
    private const val KEY_STAGES_JSON_V2 = "stages_json_v2"
    private const val KEY_STAGES_JSON_BACKUP = "stages_json_v3_backup"
    private const val KEY_STAGES_JSON_V2_BACKUP = "stages_json_v2_backup"
    private const val KEY_STAGES_LEGACY = "stages"
    private const val SCHEMA_VERSION = 3

    private val defaultStages = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    ).map { ensureMissionDefaults(it) }

    val stages = mutableStateListOf<ProgressStage>()

    private var prefs: SharedPreferences? = null
    private var initialized = false

    fun initialize(context: Context) {
        if (initialized) return

        val sharedPreferences = context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sharedPreferences

        val now = System.currentTimeMillis()
        val restored = (restore(sharedPreferences) ?: defaultStages).map { stage ->
            if (MissionRules.shouldExpire(stage, now)) stage.copy(missionStatus = MissionStatus.EXPIRED) else stage
        }
        replaceWithRenumbered(restored, persistAfter = false)
        persist()
        sharedPreferences.edit()
            .remove(KEY_STAGES_LEGACY)
            .remove(KEY_STAGES_JSON_V2)
            .apply()
        initialized = true
    }

    fun stage(id: Long): ProgressStage? = stages.firstOrNull { it.id == id }

    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    fun currentOrdinal(): Int = ProgressPathRules.currentOrdinal(stages)

    fun isComplete(): Boolean = stages.isNotEmpty() &&
        stages.none { it.status == StageStatus.CURRENT || it.status == StageStatus.UPCOMING }

    fun positionCount(isNew: Boolean): Int = (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    fun addStage(title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        val nextId = nextAvailableId(ordered)
        ordered.add(
            insertionIndex,
            ensureMissionDefaults(
                ProgressStage(
                    id = nextId,
                    number = position,
                    title = cleanTitle,
                    status = StageStatus.UPCOMING
                )
            )
        )
        replaceWithRenumbered(ordered)
    }

    fun editStage(id: Long, title: String, position: Int) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return

        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return

        val updated = ordered.removeAt(oldIndex).copy(title = cleanTitle)
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(insertionIndex, updated)
        replaceWithRenumbered(ordered)
    }

    fun updateMissionConfig(
        id: Long,
        title: String,
        description: String,
        durationMinutes: Int,
        checklist: List<MissionChecklistItem>
    ) {
        val cleanTitle = title.trim()
        if (cleanTitle.isBlank()) return
        val cleanDuration = durationMinutes.coerceIn(1, 24 * 60)
        val cleanChecklist = checklist
            .mapIndexedNotNull { index, item ->
                val text = item.text.trim()
                if (text.isBlank()) null else item.copy(
                    id = item.id.takeIf { it > 0 } ?: nextChecklistId(id, index),
                    text = text
                )
            }
            .distinctBy { it.id }

        updateStage(id) { stage ->
            val end = if (stage.missionStatus == MissionStatus.ACTIVE && stage.startedAtMillis != null) {
                stage.startedAtMillis + cleanDuration * 60_000L
            } else {
                stage.endAtMillis
            }
            stage.copy(
                title = cleanTitle,
                description = description.trim(),
                durationMinutes = cleanDuration,
                checklist = cleanChecklist,
                endAtMillis = end
            )
        }
    }

    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val target = ordered.removeAt(targetIndex)
        if (target.status == StageStatus.CURRENT) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex)
        }
        replaceWithRenumbered(ordered)
    }

    fun setCurrent(id: Long) {
        if (stages.none { it.id == id }) return

        val ordered = stages.sortedBy { it.number }.map { stage ->
            when {
                stage.id == id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        replaceWithRenumbered(ordered)
    }

    fun startMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { stage ->
            val duration = stage.durationMinutes.coerceAtLeast(1)
            stage.copy(
                missionStatus = MissionStatus.ACTIVE,
                startedAtMillis = nowMillis,
                endAtMillis = nowMillis + duration * 60_000L,
                completedAtMillis = null,
                attemptCount = stage.attemptCount + 1
            )
        }
    }

    fun markExpiredIfNeeded(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        val stage = stage(id) ?: return
        if (!MissionRules.shouldExpire(stage, nowMillis)) return
        updateStage(id) { it.copy(missionStatus = MissionStatus.EXPIRED) }
    }

    fun toggleChecklistItem(stageId: Long, itemId: Long, checked: Boolean) {
        updateStage(stageId) { stage ->
            stage.copy(
                checklist = stage.checklist.map { item ->
                    if (item.id == itemId) item.copy(checked = checked) else item
                }
            )
        }
    }

    fun updateNote(id: Long, note: String) {
        updateStage(id) { it.copy(note = note) }
    }

    fun canCompleteMission(id: Long): Boolean =
        stage(id)?.let { MissionRules.requiredComplete(it.checklist) } == true

    fun completeMission(id: Long, nowMillis: Long = System.currentTimeMillis()): Boolean {
        val stage = stage(id) ?: return false
        if (!MissionRules.requiredComplete(stage.checklist)) return false

        updateStage(id, persistAfter = false) {
            it.copy(
                missionStatus = MissionStatus.COMPLETED,
                completedAtMillis = nowMillis
            )
        }
        markResult(id, StageStatus.COMPLETED)
        return true
    }

    fun failMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        updateStage(id, persistAfter = false) {
            it.copy(
                missionStatus = MissionStatus.FAILED,
                completedAtMillis = nowMillis
            )
        }
        markResult(id, StageStatus.FAILED)
    }

    fun retryMission(id: Long, nowMillis: Long = System.currentTimeMillis()) {
        setCurrent(id)
        updateStage(id) { stage -> MissionRules.retried(stage, nowMillis) }
    }

    /** Reset execution state while intentionally preserving the user's note and custom setup. */
    fun restoreMission(id: Long) {
        setCurrent(id)
        updateStage(id) { stage -> MissionRules.restored(stage) }
    }

    fun markCompleted(id: Long) {
        updateStage(id, persistAfter = false) { it.copy(missionStatus = MissionStatus.COMPLETED) }
        markResult(id, StageStatus.COMPLETED)
    }

    fun markFailed(id: Long) {
        updateStage(id, persistAfter = false) { it.copy(missionStatus = MissionStatus.FAILED) }
        markResult(id, StageStatus.FAILED)
    }

    private fun markResult(id: Long, result: StageStatus) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return

        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)

        if (wasCurrent) {
            promoteNextUpcoming(ordered, preferredStartIndex = targetIndex + 1)
        }
        replaceWithRenumbered(ordered)
    }

    private fun promoteNextUpcoming(
        ordered: MutableList<ProgressStage>,
        preferredStartIndex: Int
    ) {
        if (ordered.any { it.status == StageStatus.CURRENT }) return

        val safeStart = preferredStartIndex.coerceIn(0, ordered.size)
        val nextIndex = (safeStart until ordered.size)
            .firstOrNull { ordered[it].status == StageStatus.UPCOMING }
            ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING }.takeIf { it >= 0 }

        if (nextIndex != null) {
            ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
        }
    }

    private fun updateStage(
        id: Long,
        persistAfter: Boolean = true,
        transform: (ProgressStage) -> ProgressStage
    ) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val index = ordered.indexOfFirst { it.id == id }
        if (index < 0) return
        ordered[index] = ensureMissionDefaults(transform(ordered[index]))
        replaceWithRenumbered(ordered, persistAfter)
    }

    private fun replaceWithRenumbered(
        ascendingItems: List<ProgressStage>,
        persistAfter: Boolean = true
    ) {
        val ordered = ProgressPathRules.normalize(ascendingItems)
            .map { ensureMissionDefaults(it) }

        stages.clear()
        stages.addAll(ordered.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun nextAvailableId(items: List<ProgressStage>): Long {
        val used = items.asSequence().map { it.id }.toHashSet()
        var candidate = (used.maxOrNull() ?: 0L) + 1L
        while (candidate in used || candidate <= 0L) candidate++
        return candidate
    }

    private fun restore(sharedPreferences: SharedPreferences): List<ProgressStage>? {
        decodeV3(sharedPreferences.getString(KEY_STAGES_JSON, null))?.let { return it }
        decodeV3(sharedPreferences.getString(KEY_STAGES_JSON_BACKUP, null))?.let { return it }
        decodeV2(sharedPreferences.getString(KEY_STAGES_JSON_V2, null))?.let { return it }
        decodeV2(sharedPreferences.getString(KEY_STAGES_JSON_V2_BACKUP, null))?.let { return it }
        decodeLegacy(sharedPreferences.getString(KEY_STAGES_LEGACY, null))?.let { return it }
        return null
    }

    private fun persist() {
        val sharedPreferences = prefs ?: return
        val payload = encodeJson(stages)
        val previous = sharedPreferences.getString(KEY_STAGES_JSON, null)

        sharedPreferences.edit().apply {
            if (!previous.isNullOrBlank() && previous != payload && decodeV3(previous) != null) {
                putString(KEY_STAGES_JSON_BACKUP, previous)
            }
            putString(KEY_STAGES_JSON, payload)
        }.apply()
    }

    private fun encodeJson(items: List<ProgressStage>): String {
        val array = JSONArray()
        items.sortedBy { it.number }.forEach { stage ->
            val checklist = JSONArray()
            stage.checklist.forEach { item ->
                checklist.put(
                    JSONObject()
                        .put("id", item.id)
                        .put("text", item.text)
                        .put("required", item.required)
                        .put("checked", item.checked)
                )
            }

            array.put(
                JSONObject()
                    .put("id", stage.id)
                    .put("number", stage.number)
                    .put("title", stage.title)
                    .put("status", stage.status.name)
                    .put("description", stage.description)
                    .put("missionStatus", stage.missionStatus.name)
                    .put("durationMinutes", stage.durationMinutes)
                    .put("startedAtMillis", stage.startedAtMillis ?: JSONObject.NULL)
                    .put("endAtMillis", stage.endAtMillis ?: JSONObject.NULL)
                    .put("completedAtMillis", stage.completedAtMillis ?: JSONObject.NULL)
                    .put("attemptCount", stage.attemptCount)
                    .put("note", stage.note)
                    .put("checklist", checklist)
            )
        }
        return JSONObject()
            .put("version", SCHEMA_VERSION)
            .put("stages", array)
            .toString()
    }

    private fun decodeV3(raw: String?): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != SCHEMA_VERSION) return@runCatching null
            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    val checklistArray = item.optJSONArray("checklist") ?: JSONArray()
                    val checklist = buildList {
                        for (checkIndex in 0 until checklistArray.length()) {
                            val check = checklistArray.getJSONObject(checkIndex)
                            add(
                                MissionChecklistItem(
                                    id = check.getLong("id"),
                                    text = check.getString("text"),
                                    required = check.optBoolean("required", false),
                                    checked = check.optBoolean("checked", false)
                                )
                            )
                        }
                    }
                    add(
                        ensureMissionDefaults(
                            ProgressStage(
                                id = item.getLong("id"),
                                number = item.getInt("number"),
                                title = item.getString("title"),
                                status = StageStatus.valueOf(item.getString("status")),
                                description = item.optString("description", ""),
                                missionStatus = MissionStatus.valueOf(item.optString("missionStatus", MissionStatus.NOT_STARTED.name)),
                                durationMinutes = item.optInt("durationMinutes", ProgressStage.DEFAULT_MISSION_DURATION_MINUTES),
                                startedAtMillis = item.optNullableLong("startedAtMillis"),
                                endAtMillis = item.optNullableLong("endAtMillis"),
                                completedAtMillis = item.optNullableLong("completedAtMillis"),
                                attemptCount = item.optInt("attemptCount", 0),
                                note = item.optString("note", ""),
                                checklist = checklist
                            )
                        )
                    )
                }
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun decodeV2(raw: String?): List<ProgressStage>? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            val root = JSONObject(raw)
            if (root.optInt("version", -1) != 2) return@runCatching null
            val array = root.getJSONArray("stages")
            val parsed = buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        ensureMissionDefaults(
                            ProgressStage(
                                id = item.getLong("id"),
                                number = item.getInt("number"),
                                title = item.getString("title"),
                                status = StageStatus.valueOf(item.getString("status"))
                            )
                        )
                    )
                }
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun decodeLegacy(raw: String?): List<ProgressStage>? {
        if (raw == null) return null
        if (raw.isBlank()) return emptyList()

        return runCatching {
            val tokens = raw.split('|')
            val parsed = tokens.map { token ->
                val parts = token.split(',', limit = 4)
                require(parts.size == 4)
                ensureMissionDefaults(
                    ProgressStage(
                        id = parts[0].toLong(),
                        number = parts[1].toInt(),
                        status = StageStatus.valueOf(parts[2]),
                        title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                    )
                )
            }
            validateParsed(parsed)
        }.getOrNull()
    }

    private fun validateParsed(items: List<ProgressStage>): List<ProgressStage>? {
        if (items.any { it.id <= 0L || it.number <= 0 || it.title.isBlank() }) return null
        if (items.map { it.id }.toSet().size != items.size) return null
        if (items.map { it.number }.toSet().size != items.size) return null
        if (items.any { it.durationMinutes !in 1..(24 * 60) }) return null
        if (items.any { stage -> stage.checklist.map { it.id }.toSet().size != stage.checklist.size }) return null
        return items
    }

    private fun ensureMissionDefaults(stage: ProgressStage): ProgressStage {
        val status = when (stage.status) {
            StageStatus.COMPLETED -> MissionStatus.COMPLETED
            StageStatus.FAILED -> MissionStatus.FAILED
            else -> stage.missionStatus
        }
        val checklist = if (stage.checklist.isEmpty()) defaultChecklist(stage.id) else stage.checklist
        return stage.copy(
            missionStatus = status,
            durationMinutes = stage.durationMinutes.coerceIn(1, 24 * 60),
            checklist = checklist
        )
    }

    private fun defaultChecklist(stageId: Long): List<MissionChecklistItem> = listOf(
        MissionChecklistItem(nextChecklistId(stageId, 0), "مرور هدف این مرحله", required = true),
        MissionChecklistItem(nextChecklistId(stageId, 1), "انجام اقدام اصلی مرحله", required = true),
        MissionChecklistItem(nextChecklistId(stageId, 2), "ثبت جمع‌بندی کوتاه", required = false)
    )

    private fun nextChecklistId(stageId: Long, index: Int): Long =
        (stageId.coerceAtLeast(1L) * 10_000L) + index + 1L

    private fun JSONObject.optNullableLong(key: String): Long? =
        if (!has(key) || isNull(key)) null else optLong(key)
}
