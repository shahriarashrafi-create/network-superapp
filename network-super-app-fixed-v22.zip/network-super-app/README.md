# Network Super App

پروتوتایپ اندروید RTL برای سوپر اپ نتورک مارکتینگ با Kotlin، Jetpack Compose و Material 3.

## وضعیت فعلی — v19 foundation refactor

در این نسخه ظاهر تأییدشده‌ی Home و Progress Path حفظ شده و لایه‌ی پایه برای توسعه‌ی بعدی تمیز شده است:

- Home از App Scaffold و Bottom Navigation جدا شده است.
- هر تب مقصد مستقل دارد؛ تب‌های ساخته‌نشده دیگر Home را به‌اشتباه نمایش نمی‌دهند.
- Progress Path منبع داده‌ی واحد برای Home و صفحه‌ی Progress باقی مانده است.
- State ذخیره‌شده قبل از اولین Composition بارگذاری می‌شود؛ Flash داده‌ی پیش‌فرض حذف شده است.
- پایان آخرین مرحله به‌درستی 100٪ نمایش داده می‌شود.
- دکمه‌های «شروع» دیگر no-op نیستند؛ Home دیالوگ مرحله‌ی جاری را باز می‌کند و Start در Quick Dialog همان مرحله را Current می‌کند.
- Persistence از فرمت legacy به JSON نسخه‌دار با backup مهاجرت می‌کند.
- منطق خالص Progress از Android persistence جدا شده و Unit Test دارد.
- فایل‌های 1000+ خطی Home/Progress به فایل‌های مسئولیت‌محور شکسته شده‌اند.
- Backdrop هندسی، CTA شروع و LazyRow preview مشترک شده‌اند و duplication حذف شده است.
- رشته‌های رابط عمومی و Navigation به resources منتقل شده‌اند.
- Gradle launcher نسخه‌ی 8.9 را pin می‌کند و CI فقط از wrapper پروژه استفاده می‌کند.

> داده‌های Home هنوز Mock هستند و در `HomeUiState.kt` متمرکز شده‌اند تا بعداً به ViewModel/Backend وصل شوند.

## تکنولوژی

- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Jetpack Compose / Material 3
- Min SDK 26 / Target SDK 35
- Java 17

## اجرا

پروژه را در Android Studio باز کنید و Gradle Sync را اجرا کنید. سپس ماژول `app` را Run کنید.

از خط فرمان:

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

اگر `gradle-wrapper.jar` در یک آرشیو source-only موجود نباشد، `gradlew` Wrapper رسمی Gradle 8.9 را یک‌بار بازیابی و SHA-256 رسمی آن را قبل از اجرا بررسی می‌کند. نسخه و SHA-256 توزیع Gradle نیز در `gradle-wrapper.properties` pin شده‌اند.

## ساختار

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
└── ui/
    ├── components/
    │   ├── ActionVisuals.kt
    │   └── EdgePreviewLazyRow.kt
    ├── navigation/
    │   └── AppRoot.kt
    ├── home/
    │   ├── HomeScreen.kt
    │   ├── HomeUiState.kt
    │   ├── HomeHeader.kt
    │   ├── HomeActions.kt
    │   └── HomeSections.kt
    ├── progress/
    │   ├── ProgressStage.kt
    │   ├── ProgressPathRules.kt
    │   ├── ProgressPathStore.kt
    │   ├── ProgressPathLayout.kt
    │   ├── ProgressPathScreen.kt
    │   ├── ProgressPathHeader.kt
    │   ├── ProgressPathWorld.kt
    │   └── ProgressPathDialogs.kt
    └── theme/
        ├── Color.kt
        ├── Theme.kt
        └── Type.kt
```

## مستندات

- `docs/home-reference.png` — مرجع تصویری Home
- `docs/HOME_SPEC_FA.md` — تاریخچه و مشخصات طراحی Home
- `docs/CURRENT_ARCHITECTURE.md` — مرجع معماری جاری و قواعد توسعه‌ی بعدی

## قواعد ادامه‌ی پروژه

Home و Progress visual baseline محسوب می‌شوند؛ Refactorهای بعدی نباید بدون درخواست صریح اندازه‌ها، spacing، Canvas geometry، رنگ‌ها یا RTL behavior این دو صفحه را تغییر دهند. قابلیت‌های جدید از AppRoot به مقصد مستقل وصل شوند و منطق persistence/business داخل Composableها قرار نگیرد.

## V22 — Mission Detail / Stage Execution

The progress path now has a real mission flow implemented entirely with Jetpack Compose (no image backgrounds/assets):

- Stage cards and Home "Start" open a dedicated mission detail screen.
- Timestamp-based countdown survives navigation, app backgrounding, and process recreation via persisted `startedAt/endAt` values.
- Required/optional checklist items with required-item completion gating.
- Editable mission title, short description, default duration, checklist text/type/order, and item add/delete.
- Full-screen note editor with debounced auto-save; Restore intentionally preserves notes.
- Explicit mission states: `NOT_STARTED`, `ACTIVE`, `EXPIRED`, `COMPLETED`, `FAILED`.
- Expired time warns only; it never auto-fails a mission.
- Large primary "Done" action, smaller "Failed" action with confirmation, and Restore with confirmation.
- Retry resets checklist/timer but preserves the note and custom mission setup.
- Success state advances to the next current stage or returns to the progress path.
- Persistence schema upgraded to v3 with migration from v2/legacy data.
- Pure mission rules have unit coverage for required gating, persisted countdown math, expiration semantics, progress, and Restore note preservation.
