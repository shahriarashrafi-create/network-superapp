package ir.royesh.core

import java.time.LocalDate
import java.time.LocalDateTime
import java.util.UUID

enum class Stage(val label: String) { NEW("جدید"), CONTACTED("ارتباط برقرارشده"), INVITED("دعوت‌شده"), PRESENTED("معرفی‌شده"), FOLLOWUP("در حال پیگیری"), JOINED("عضوشده"), LATER("فعلاً نه") }
data class Person(val id: String = UUID.randomUUID().toString(), val name: String, val phone: String = "", val stage: Stage = Stage.NEW)
data class Task(val id: String = UUID.randomUUID().toString(), val title: String, val personId: String? = null, val due: String, val priority: Int = 1, val done: Boolean = false)
data class Action(val id: String = UUID.randomUUID().toString(), val taskId: String, val personId: String?, val title: String, val result: String, val occurredAt: String, val xp: Int = 10)
data class Profile(val name: String = "", val dailyGoal: Int = 3)
data class TimeBlock(val id: String = UUID.randomUUID().toString(), val title: String, val date: String, val hour: Int, val minutes: Int, val weekly: Boolean = false, val actuals: Map<String, Int> = emptyMap())
data class MonthlyGoal(val month: String, val target: Int)
data class FocusSession(val taskId: String, val startedAt: Long, val endsAt: Long)
data class AppState(val profile: Profile = Profile(), val people: List<Person> = emptyList(), val tasks: List<Task> = emptyList(), val actions: List<Action> = emptyList(), val blocks: List<TimeBlock> = emptyList(), val goals: List<MonthlyGoal> = emptyList(), val focus: FocusSession? = null) {
    val xp get() = actions.sumOf { it.xp }
    val level get() = xp / 100 + 1
    fun todayCount(date: String) = actions.count { it.occurredAt.take(10) == date }
    fun nextTask() = tasks.filterNot { it.done }.sortedWith(compareBy<Task> { it.due }.thenByDescending { it.priority }).firstOrNull()
    fun complete(id: String, result: String, now: String, next: String = "", nextDue: String = ""): AppState {
        require(result.isNotBlank()); LocalDateTime.parse(now)
        if (next.isNotBlank()) LocalDate.parse(nextDue)
        val task = tasks.firstOrNull { it.id == id } ?: return this
        if (task.done || actions.any { it.taskId == id }) return this
        return copy(tasks = tasks.map { if (it.id == id) it.copy(done = true) else it } + if (next.isNotBlank()) listOf(Task(title = next.trim(), personId = task.personId, due = nextDue)) else emptyList(),
            actions = actions + Action(taskId = id, personId = task.personId, title = task.title, result = result.trim(), occurredAt = now), focus = focus?.takeUnless { it.taskId == id })
    }
}
object Planning {
    fun weekStart(date: LocalDate): LocalDate = date.minusDays(((date.dayOfWeek.value + 1) % 7).toLong())
    fun occurs(b: TimeBlock, date: LocalDate): Boolean {
        val first = LocalDate.parse(b.date)
        return first == date || (b.weekly && date >= first && first.dayOfWeek == date.dayOfWeek)
    }
    fun dailyTarget(target: Int, date: LocalDate): Int {
        require(target >= 0)
        return target / date.lengthOfMonth() + if (date.dayOfMonth <= target % date.lengthOfMonth()) 1 else 0
    }
    fun weeklyTarget(target: Int, date: LocalDate) = (0L..6L).map { weekStart(date).plusDays(it) }.filter { it.month == date.month && it.year == date.year }.sumOf { dailyTarget(target, it) }
    fun streak(actions: List<Action>, today: LocalDate): Int {
        val days = actions.map { it.occurredAt.take(10) }.toSet()
        var date = if (today.toString() in days) today else today.minusDays(1)
        var count = 0
        while (date.toString() in days) { count++; date = date.minusDays(1) }
        return count
    }
}
