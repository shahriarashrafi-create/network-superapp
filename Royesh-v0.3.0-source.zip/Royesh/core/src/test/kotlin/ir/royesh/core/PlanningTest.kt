package ir.royesh.core
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class PlanningTest {
    private val initial = AppState(tasks = listOf(Task(id = "t1", title = "پیگیری", due = "2026-10-18")))
    @Test fun saturdayStartsWeek() {
        assertEquals("2026-10-17", Planning.weekStart(LocalDate.parse("2026-10-18")).toString())
        assertEquals("2026-10-17", Planning.weekStart(LocalDate.parse("2026-10-23")).toString())
        assertEquals("2026-10-24", Planning.weekStart(LocalDate.parse("2026-10-24")).toString())
    }
    @Test fun monthlySplitPreservesRemainder() {
        for (month in listOf("2026-02", "2028-02", "2026-04", "2026-10")) {
            val ym = YearMonth.parse(month)
            for (target in listOf(1, 3, 30, 100, 10000)) assertEquals(target, (1..ym.lengthOfMonth()).sumOf { Planning.dailyTarget(target, ym.atDay(it)) })
        }
    }
    @Test fun weekDoesNotIncludeOtherMonths() {
        val date = LocalDate.parse("2026-11-01")
        assertEquals((1..6).sumOf { Planning.dailyTarget(100, LocalDate.of(2026, 11, it)) }, Planning.weeklyTarget(100, date))
    }
    @Test fun recurrenceNeverBackdates() {
        val b = TimeBlock(title = "تماس", date = "2026-10-18", hour = 9, minutes = 60, weekly = true)
        assertFalse(Planning.occurs(b, LocalDate.parse("2026-10-11")))
        assertTrue(Planning.occurs(b, LocalDate.parse("2026-10-25")))
        assertFalse(Planning.occurs(b, LocalDate.parse("2026-10-26")))
    }
    @Test fun actualMinutesArePerDate() {
        val b = TimeBlock(title = "تماس", date = "2026-10-18", hour = 9, minutes = 60, actuals = mapOf("2026-10-18" to 45))
        assertEquals(45, b.actuals["2026-10-18"]); assertNull(b.actuals["2026-10-25"])
    }
    @Test fun resultCreatesFollowupAndEndsFocus() {
        val state = initial.copy(focus = FocusSession("t1", 100, 1000)).complete("t1", "هماهنگ شد", "2026-10-18T12:00:00", "جلسه", "2026-10-19")
        assertEquals(2, state.tasks.size); assertTrue(state.tasks.first().done); assertEquals(1, state.actions.size); assertNull(state.focus)
    }
    @Test fun duplicateResultNeverRewardsTwice() {
        val state = initial.complete("t1", "ثبت شد", "2026-10-18T12:00:00")
        assertEquals(state, state.complete("t1", "دوباره", "2026-10-18T13:00:00")); assertEquals(10, state.xp)
    }
    @Test(expected = IllegalArgumentException::class) fun blankResultRejected() { initial.complete("t1", " ", "2026-10-18T12:00:00") }
    @Test fun nextActionRespectsDateThenPriority() {
        val s = AppState(tasks = listOf(Task(title = "بعدی", due = "2026-10-19", priority = 2), Task(title = "مهم", due = "2026-10-18", priority = 2), Task(title = "عادی", due = "2026-10-18")))
        assertEquals("مهم", s.nextTask()?.title)
    }
    @Test fun streakAllowsTodayToRemainUnfinished() {
        val s = initial.complete("t1", "ثبت", "2026-10-17T12:00:00")
        assertEquals(1, Planning.streak(s.actions, LocalDate.parse("2026-10-18")))
        assertEquals(0, Planning.streak(s.actions, LocalDate.parse("2026-10-19")))
    }
}
