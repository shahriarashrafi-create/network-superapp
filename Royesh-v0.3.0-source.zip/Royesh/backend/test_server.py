import concurrent.futures
import http.client
import json
import os
import tempfile
import threading
import unittest
import server

class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        server.DB = os.path.join(cls.temp.name, 'test.sqlite3'); server.init()
        cls.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        threading.Thread(target=cls.http.serve_forever, daemon=True).start()
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown(); cls.http.server_close(); cls.temp.cleanup()
    def call(self, path, method='GET', body=None, token=None):
        c = http.client.HTTPConnection('127.0.0.1', self.http.server_port, timeout=10)
        headers = {'Content-Type': 'application/json'}
        if token: headers['Authorization'] = 'Bearer ' + token
        c.request(method, path, json.dumps(body) if body is not None else None, headers)
        r = c.getresponse(); value = r.status, json.loads(r.read()); c.close(); return value
    def new(self, name):
        status, user = self.call('/register', 'POST', {'email': name + '@example.com', 'password': 'correct-password', 'device': 'phone A'})
        self.assertEqual(201, status); return user
    def snapshot(self):
        return {'schema': 2, 'profile': {'name': 'علی', 'dailyGoal': 3}, 'people': [], 'tasks': [], 'actions': [], 'blocks': [], 'goals': []}
    def test_multi_device_conflict_and_isolation(self):
        a = self.new('alice'); b = self.new('bob')
        status, second = self.call('/login', 'POST', {'email': 'alice@example.com', 'password': 'correct-password', 'device': 'phone B'})
        self.assertEqual(200, status)
        data = self.snapshot()
        self.assertEqual(200, self.call('/snapshot', 'PUT', {'version': 0, 'data': data}, a['token'])[0])
        status, remote = self.call('/snapshot', token=second['token'])
        self.assertEqual(200, status); self.assertEqual(1, remote['version']); self.assertEqual(data, remote['data'])
        self.assertEqual(409, self.call('/snapshot', 'PUT', {'version': 0, 'data': data}, second['token'])[0])
        self.assertIsNone(self.call('/snapshot', token=b['token'])[1]['data'])
        self.assertEqual(2, len(self.call('/sessions', token=a['token'])[1]['sessions']))
    def test_recovery_revokes_sessions_and_rotates_code(self):
        a = self.new('recovery')
        body = {'email': a['email'], 'password': 'replacement-password', 'recovery_code': a['recovery_code']}
        status, recovered = self.call('/recover', 'POST', body)
        self.assertEqual(200, status); self.assertNotEqual(a['recovery_code'], recovered['recovery_code'])
        self.assertEqual(401, self.call('/snapshot', token=a['token'])[0])
        self.assertEqual(401, self.call('/recover', 'POST', body)[0])
        self.assertEqual(200, self.call('/login', 'POST', {'email': body['email'], 'password': body['password']})[0])
    def test_logout_all(self):
        a = self.new('logout'); _, b = self.call('/login', 'POST', {'email': a['email'], 'password': 'correct-password'})
        self.assertEqual(200, self.call('/logout-all', 'POST', {}, a['token'])[0])
        self.assertEqual(401, self.call('/sessions', token=b['token'])[0])
    def test_invalid_credentials_and_data(self):
        a = self.new('validation')
        self.assertEqual(401, self.call('/login', 'POST', {'email': a['email'], 'password': 'wrong-password'})[0])
        self.assertEqual(400, self.call('/snapshot', 'PUT', {'version': 0, 'data': {}}, a['token'])[0])
        self.assertEqual(401, self.call('/snapshot')[0])
    def test_expiry_and_hashed_storage(self):
        a = self.new('expiry')
        with server.connect() as db:
            row = db.execute('SELECT * FROM sessions WHERE user_id=?', (a['user_id'],)).fetchone()
            user = db.execute('SELECT * FROM users WHERE id=?', (a['user_id'],)).fetchone()
            self.assertNotEqual(a['token'], row['token']); self.assertNotEqual(a['recovery_code'], user['recovery']); self.assertNotEqual('correct-password', user['password'])
            db.execute('UPDATE sessions SET expires=0 WHERE user_id=?', (a['user_id'],))
        self.assertEqual(401, self.call('/snapshot', token=a['token'])[0])
    def test_simultaneous_writes_only_one_wins(self):
        a = self.new('concurrent'); body = {'version': 0, 'data': self.snapshot()}
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            statuses = list(pool.map(lambda _: self.call('/snapshot', 'PUT', body, a['token'])[0], range(2)))
        self.assertEqual([200, 409], sorted(statuses))
        self.assertEqual(1, self.call('/snapshot', token=a['token'])[1]['version'])

if __name__ == '__main__': unittest.main()
