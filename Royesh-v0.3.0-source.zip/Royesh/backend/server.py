"""Royesh 0.3 development API; deploy behind the included HTTPS proxy."""
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DB = os.environ.get('ROYESH_DB', 'royesh.sqlite3')
LIMIT = 2_000_000
attempts = {}
lock = threading.Lock()

def connect():
    db = sqlite3.connect(DB, timeout=10)
    db.row_factory = sqlite3.Row
    return db

def init():
    with connect() as db:
        db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,salt TEXT,password TEXT,recovery TEXT);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT,device TEXT,expires INTEGER);
        CREATE TABLE IF NOT EXISTS snapshots(user_id TEXT PRIMARY KEY,version INTEGER,data TEXT);
        ''')

def digest(text): return hashlib.sha256(text.encode()).hexdigest()
def password_hash(password, salt): return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 600_000).hex()

class ApiError(Exception):
    def __init__(self, status, message): self.status, self.message = status, message

def validate(data):
    if not isinstance(data, dict) or data.get('schema') not in (1, 2): raise ApiError(400, 'Invalid snapshot schema')
    p = data.get('profile', {})
    if not isinstance(p, dict) or not isinstance(p.get('name'), str) or type(p.get('dailyGoal')) is not int or not 1 <= p['dailyGoal'] <= 10: raise ApiError(400, 'Invalid profile')
    for k in ('people', 'tasks', 'actions'):
        if not isinstance(data.get(k), list) or len(data[k]) > 10000: raise ApiError(400, 'Invalid collection')
    # Full domain validation also runs on Android before remote data is applied.

class Handler(BaseHTTPRequestHandler):
    server_version = 'Royesh/0.3'
    def log_message(self, *args): pass
    def body(self):
        try: size = int(self.headers.get('Content-Length', '0'))
        except ValueError: raise ApiError(400, 'Invalid length')
        if not 1 <= size <= LIMIT: raise ApiError(413, 'Body size invalid')
        try:
            value = json.loads(self.rfile.read(size))
            if not isinstance(value, dict): raise ValueError()
            return value
        except (ValueError, UnicodeError): raise ApiError(400, 'Invalid JSON')
    def auth(self, db):
        header = self.headers.get('Authorization', '')
        if not header.startswith('Bearer '): raise ApiError(401, 'Sign in required')
        row = db.execute('SELECT * FROM sessions WHERE token=? AND expires>?', (digest(header[7:]), int(time.time()))).fetchone()
        if not row: raise ApiError(401, 'Session expired; sign in again')
        return row
    def session(self, db, user, device):
        token, expires = secrets.token_urlsafe(32), int(time.time()) + 30 * 86400
        db.execute('DELETE FROM sessions WHERE expires<=?', (int(time.time()),))
        db.execute('INSERT INTO sessions VALUES(?,?,?,?)', (digest(token), user['id'], str(device)[:100], expires))
        return {'token': token, 'user_id': user['id'], 'email': user['email'], 'expires': expires}
    def api(self, method):
        path = self.path
        if path == '/health' and method == 'GET': return 200, {'ok': True}
        if path in ('/register', '/login', '/recover'):
            if method != 'POST': raise ApiError(405, 'POST required')
            now = time.time()
            with lock:
                for key in list(attempts):
                    if attempts[key][0] < now - 600: del attempts[key]
                key = self.client_address[0]
                start, count = attempts.get(key, (now, 0))
                if count >= 30: raise ApiError(429, 'Try again after ten minutes')
                attempts[key] = (start, count + 1)
            data = self.body(); email = data.get('email', ''); password = data.get('password', '')
            if not isinstance(email, str) or not isinstance(password, str): raise ApiError(400, 'Invalid credentials')
            email = email.strip().lower()
            if len(email) > 254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or not 10 <= len(password) <= 256: raise ApiError(400, 'Email and password of 10-256 characters required')
            with connect() as db:
                if path == '/register':
                    uid, salt, recovery = secrets.token_hex(16), secrets.token_hex(16), secrets.token_urlsafe(24)
                    try: db.execute('INSERT INTO users VALUES(?,?,?,?,?)', (uid, email, salt, password_hash(password, salt), digest(recovery)))
                    except sqlite3.IntegrityError: raise ApiError(409, 'Account exists')
                    db.execute('INSERT INTO snapshots VALUES(?,0,NULL)', (uid,))
                    user = db.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
                    return 201, dict(self.session(db, user, data.get('device', 'Android')), recovery_code=recovery)
                user = db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
                if path == '/recover':
                    code = data.get('recovery_code', '')
                    if not isinstance(code, str) or not user or not hmac.compare_digest(user['recovery'], digest(code)): raise ApiError(401, 'Invalid recovery credentials')
                    new_code, salt = secrets.token_urlsafe(24), secrets.token_hex(16)
                    db.execute('UPDATE users SET salt=?,password=?,recovery=? WHERE id=?', (salt, password_hash(password, salt), digest(new_code), user['id']))
                    db.execute('DELETE FROM sessions WHERE user_id=?', (user['id'],))
                    return 200, {'recovery_code': new_code}
                candidate = password_hash(password, user['salt'] if user else '00' * 16)
                if not user or not hmac.compare_digest(user['password'], candidate): raise ApiError(401, 'Invalid credentials')
                return 200, self.session(db, user, data.get('device', 'Android'))
        with connect() as db:
            session = self.auth(db); uid = session['user_id']
            if path == '/sessions' and method == 'GET':
                rows = db.execute('SELECT token,device,expires FROM sessions WHERE user_id=? AND expires>?', (uid, int(time.time()))).fetchall()
                return 200, {'sessions': [dict(id=r['token'], device=r['device'], expires=r['expires'], current=r['token'] == session['token']) for r in rows]}
            if path == '/logout' and method == 'POST':
                db.execute('DELETE FROM sessions WHERE token=?', (session['token'],)); return 200, {'ok': True}
            if path == '/logout-all' and method == 'POST':
                db.execute('DELETE FROM sessions WHERE user_id=?', (uid,)); return 200, {'ok': True}
            if path == '/snapshot' and method == 'GET':
                row = db.execute('SELECT * FROM snapshots WHERE user_id=?', (uid,)).fetchone()
                return 200, {'version': row['version'], 'data': json.loads(row['data']) if row['data'] else None}
            if path == '/snapshot' and method == 'PUT':
                body = self.body(); version = body.get('version'); data = body.get('data')
                if type(version) is not int: raise ApiError(400, 'Version required')
                validate(data)
                cursor = db.execute('UPDATE snapshots SET version=version+1,data=? WHERE user_id=? AND version=?', (json.dumps(data, ensure_ascii=False), uid, version))
                if cursor.rowcount != 1: raise ApiError(409, 'Cloud changed on another device. Download before uploading.')
                return 200, {'version': version + 1}
        raise ApiError(404, 'Not found')
    def dispatch(self, method):
        self.connection.settimeout(20)
        try: code, result = self.api(method)
        except ApiError as e: code, result = e.status, {'error': e.message}
        except (TimeoutError, ConnectionError): return
        except Exception: code, result = 500, {'error': 'Internal server error'}
        raw = json.dumps(result, ensure_ascii=False).encode()
        try:
            self.send_response(code); self.send_header('Content-Type', 'application/json; charset=utf-8'); self.send_header('Content-Length', str(len(raw))); self.send_header('Cache-Control', 'no-store'); self.end_headers(); self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError): pass
    def do_GET(self): self.dispatch('GET')
    def do_POST(self): self.dispatch('POST')
    def do_PUT(self): self.dispatch('PUT')

if __name__ == '__main__':
    init()
    ThreadingHTTPServer((os.environ.get('ROYESH_HOST', '127.0.0.1'), int(os.environ.get('PORT', '8080'))), Handler).serve_forever()
