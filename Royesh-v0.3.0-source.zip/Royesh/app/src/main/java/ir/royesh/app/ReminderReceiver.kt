package ir.royesh.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import java.time.ZonedDateTime

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) { schedule(context); return }
        if (!context.getSharedPreferences("reminders", Context.MODE_PRIVATE).getBoolean("enabled", false)) return
        if (Build.VERSION.SDK_INT < 33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("daily", "برنامهٔ روزانه", NotificationManager.IMPORTANCE_DEFAULT))
            val count = runCatching { LocalStore(context).load().tasks.count { !it.done && it.due <= java.time.LocalDate.now().toString() } }.getOrDefault(0)
            val open = PendingIntent.getActivity(context, 9, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            manager.notify(1, Notification.Builder(context, "daily").setSmallIcon(R.drawable.ic_royesh).setContentTitle("زمان یک قدم برای رویش است 🌱").setContentText("$count اقدام امروز و عقب‌افتاده منتظر توست").setContentIntent(open).setAutoCancel(true).build())
        }
        schedule(context)
    }
    companion object {
        fun schedule(context: Context) {
            val prefs = context.getSharedPreferences("reminders", Context.MODE_PRIVATE)
            val manager = context.getSystemService(AlarmManager::class.java)
            val pending = PendingIntent.getBroadcast(context, 8, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            manager.cancel(pending)
            if (!prefs.getBoolean("enabled", false)) return
            val now = ZonedDateTime.now()
            var next = now.withHour(prefs.getInt("hour", 9)).withMinute(0).withSecond(0).withNano(0)
            if (next <= now) next = next.plusDays(1)
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.toInstant().toEpochMilli(), pending)
        }
    }
}
