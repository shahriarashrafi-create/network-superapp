package ir.royesh.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class CloudClient(context: Context) {
    private val prefs = context.getSharedPreferences("royesh-cloud", Context.MODE_PRIVATE)
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey("royesh-session", null) as? SecretKey
        if (existing != null) return existing
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("royesh-session", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    var session: JSONObject?
        get() = prefs.getString("session", null)?.let { raw ->
            val bytes = Base64.decode(raw, Base64.NO_WRAP); val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            JSONObject(String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8))
        }
        set(value) {
            val edit = prefs.edit()
            if (value == null) edit.remove("session") else {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key())
                edit.putString("session", Base64.encodeToString(cipher.iv + cipher.doFinal(value.toString().toByteArray()), Base64.NO_WRAP))
            }
            check(edit.commit()) { "ذخیرهٔ نشست انجام نشد" }
        }
    var server: String
        get() = prefs.getString("server", "") ?: ""
        set(value) { check(prefs.edit().putString("server", value.trim().trimEnd('/')).commit()) }
    var owner: String
        get() = prefs.getString("owner", "") ?: ""
        set(value) { check(prefs.edit().putString("owner", value).commit()) }
    var version: Int
        get() = prefs.getInt("version", -1)
        set(value) { check(prefs.edit().putInt("version", value).commit()) }
    fun login(base: String, email: String, password: String, register: Boolean): JSONObject {
        server = base
        val response = request(if (register) "/register" else "/login", "POST", JSONObject().put("email", email).put("password", password).put("device", android.os.Build.MODEL), false)
        val identity = server + "|" + response.getString("user_id")
        if (owner.isNotBlank() && owner != identity) {
            runCatching { request("/logout", "POST", JSONObject(), tokenOverride = response.getString("token")) }
            error("دادهٔ محلی به حساب دیگری متصل است. ابتدا خروجی بگیر و پاکسازی محلی را انجام بده.")
        }
        owner = identity
        session = JSONObject(response.toString()).apply { remove("recovery_code") }
        version = -1
        return response
    }
    fun request(path: String, method: String = "GET", body: JSONObject? = null, authenticated: Boolean = true, tokenOverride: String? = null): JSONObject {
        val url = URL(server + path)
        require(url.protocol == "https" && url.userInfo == null && url.query == null && url.ref == null) { "آدرس سرور باید HTTPS معتبر باشد" }
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 15000; readTimeout = 20000; instanceFollowRedirects = false
            setRequestProperty("Accept", "application/json")
            if (authenticated) setRequestProperty("Authorization", "Bearer " + (tokenOverride ?: session?.getString("token") ?: error("ابتدا وارد حساب شو")))
        }
        try {
            body?.let { connection.doOutput = true; connection.setRequestProperty("Content-Type", "application/json; charset=utf-8"); connection.outputStream.use { stream -> stream.write(it.toString().toByteArray()) } }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                val out = StringBuilder(); val buffer = CharArray(4096)
                while (true) { val n = reader.read(buffer); if (n < 0) break; out.append(buffer, 0, n); require(out.length <= 2_000_000) }
                out.toString()
            } ?: "{}"
            if (status !in 200..299) error(when (status) { 401 -> "نشست منقضی یا اطلاعات ورود/بازیابی نادرست است"; 409 -> "تعارض نسخه یا حساب موجود؛ پیش از ارسال، نسخهٔ ابری را بررسی کن"; 429 -> "تلاش زیاد؛ ده دقیقه بعد امتحان کن"; else -> "خطای سرور ($status)" })
            return JSONObject(raw)
        } finally { connection.disconnect() }
    }
}
