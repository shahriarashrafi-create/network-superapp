package ir.royesh.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import ir.royesh.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable fun AccountScreen(state: AppState, client: CloudClient, store: LocalStore, busy: Boolean, setBusy: (Boolean) -> Unit, replace: (AppState) -> Boolean, clear: () -> Boolean) {
    var url by remember { mutableStateOf(client.server) }; var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }; var code by remember { mutableStateOf("") }; var mode by remember { mutableIntStateOf(0) }
    var logged by remember { mutableStateOf(runCatching { client.session?.optString("email") }.getOrNull()) }
    var status by remember { mutableStateOf("") }; var recovery by remember { mutableStateOf("") }; var devices by remember { mutableStateOf("") }
    var incoming by remember { mutableStateOf<JSONObject?>(null) }; var confirmClear by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun job(work: () -> JSONObject, done: (JSONObject) -> Unit) {
        if (busy) return
        setBusy(true); status = "در حال ارتباط…"
        scope.launch {
            try {
                val outcome = withContext(Dispatchers.IO) { runCatching(work) }
                outcome.onSuccess { response -> runCatching { done(response) }.onFailure { status = it.message ?: "خطا" } }.onFailure { status = it.message ?: "اتصال برقرار نشد" }
            } finally { setBusy(false) }
        }
    }
    Text("حساب و همگام‌سازی", style = MaterialTheme.typography.headlineSmall)
    Text("استفادهٔ آفلاین ادامه دارد. برای حساب آنلاین، سرور همراه پروژه را روی دامنهٔ خودت راه‌اندازی کن.")
    if (logged == null) {
        Field(url, { url = it }, "سرور؛ https://api.example.com")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("ورود", "ثبت‌نام", "بازیابی").forEachIndexed { i, s -> FilterChip(mode == i, { mode = i }, label = { Text(s) }) } }
        Field(email, { email = it }, "ایمیل")
        OutlinedTextField(password, { password = it }, label = { Text(if (mode == 2) "رمز جدید؛ حداقل ۱۰ کاراکتر" else "رمز؛ حداقل ۱۰ کاراکتر") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (mode == 2) Field(code, { code = it }, "کد خصوصی بازیابی")
        Text("با اولین اتصال، دادهٔ محلی به همین حساب متصل می‌شود؛ ارسال اطلاعات با انتخاب خودت انجام می‌شود.", style = MaterialTheme.typography.bodySmall)
        Button(enabled = !busy && url.startsWith("https://") && email.contains('@') && password.length in 10..256 && (mode != 2 || code.isNotBlank()), onClick = {
            val isRecovery = mode == 2; val register = mode == 1
            val base = url; val e = email; val p = password; val c = code
            job({
                if (isRecovery) { client.server = base; client.request("/recover", "POST", JSONObject().put("email", e).put("password", p).put("recovery_code", c), false) }
                else client.login(base, e, p, register)
            }) { response ->
                password = ""; code = ""; recovery = response.optString("recovery_code")
                if (isRecovery) { mode = 0; status = "رمز تغییر کرد و نشست‌های قبلی بسته شدند؛ کد جدید را نگه دار و وارد شو." }
                else { logged = response.getString("email"); status = "ورود موفق؛ ابتدا بررسی و دریافت ابر را بزن." }
            }
        }) { Text(if (busy) "لطفاً صبر کن" else listOf("ورود به حساب", "ساخت حساب", "بازیابی رمز")[mode]) }
        TextButton(enabled = !busy, onClick = { confirmClear = true }) { Text("پاکسازی محلی برای حساب دیگر") }
    } else {
        Panel(logged ?: "حساب") { Text(client.server); Text("همگام‌سازی دستی؛ روی دستگاه دوم ابتدا نسخهٔ ابری را دریافت کن.") }
        Button(enabled = !busy, onClick = { job({ client.request("/snapshot") }) { response ->
            if (response.isNull("data")) { client.version = response.getInt("version"); status = "ابر خالی است؛ می‌توانی اطلاعات همین دستگاه را ارسال کنی." }
            else { store.decode(response.getJSONObject("data").toString()); incoming = response; status = "نسخهٔ ابری برای بررسی آماده است." }
        } }) { Text("بررسی و دریافت نسخهٔ ابری") }
        Button(enabled = !busy && client.version >= 0, onClick = {
            val body = JSONObject().put("version", client.version).put("data", JSONObject(store.encode(state)))
            job({ client.request("/snapshot", "PUT", body) }) { response -> client.version = response.getInt("version"); status = "نسخهٔ ${client.version} در ابر ذخیره شد." }
        }) { Text("ارسال اطلاعات همین دستگاه به ابر") }
        OutlinedButton(enabled = !busy, onClick = { job({ client.request("/sessions") }) { response ->
            val a = response.getJSONArray("sessions")
            devices = (0 until a.length()).joinToString("\n") { i -> val d = a.getJSONObject(i); (if (d.getBoolean("current")) "این دستگاه · " else "") + d.getString("device") }
            status = "نشست‌های فعال دریافت شدند."
        } }) { Text("دستگاه‌های فعال") }
        if (devices.isNotBlank()) Text(devices)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(enabled = !busy, onClick = { job({ client.request("/logout", "POST", JSONObject()) }) { client.session = null; logged = null; devices = ""; status = "خارج شدی؛ دادهٔ محلی حفظ شد." } }) { Text("خروج") }
            TextButton(enabled = !busy, onClick = { job({ client.request("/logout-all", "POST", JSONObject()) }) { client.session = null; logged = null; devices = ""; status = "همهٔ نشست‌ها بسته شدند." } }) { Text("خروج همهٔ دستگاه‌ها") }
        }
        TextButton(enabled = !busy, onClick = { client.session = null; logged = null; devices = ""; status = "برای ورود مجدد آماده‌ای؛ نشست قبلی سرور تا انقضا یا خروج همه باقی می‌ماند." }) { Text("ورود مجدد / نشست منقضی") }
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
    if (status.isNotBlank()) Text(status)
    if (recovery.isNotBlank()) Panel("کد خصوصی بازیابی؛ در جای امن نگه دار") {
        SelectionContainer { Text(recovery) }; Text("این کد را خارج از اپ نگه دار. بازیابی ایمیلی وجود ندارد.")
        TextButton(onClick = { recovery = "" }) { Text("کد را نگه داشتم") }
    }
    incoming?.let { response ->
        val remote = store.decode(response.getJSONObject("data").toString())
        AlertDialog(onDismissRequest = { incoming = null }, title = { Text("جایگزینی با نسخهٔ ابری؟") }, text = { Text("نسخهٔ ${response.getInt("version")}: ${remote.people.size} مخاطب و ${remote.tasks.size} اقدام. اطلاعات همین دستگاه جایگزین می‌شود و نسخهٔ قبل در نقطهٔ بازیابی محلی حفظ می‌شود. ادغام خودکار وجود ندارد.") }, confirmButton = {
            TextButton(onClick = { if (replace(remote)) { client.version = response.getInt("version"); incoming = null; status = "نسخهٔ ابری اعمال شد." } }) { Text("جایگزینی و حفظ نسخهٔ قبل") }
        }, dismissButton = { TextButton(onClick = { incoming = null }) { Text("انصراف") } })
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("پاکسازی این دستگاه؟") }, text = { Text("ابتدا از پروفایل JSON بگیر. مخاطبان، اقدام‌ها و برنامه‌های محلی پاک می‌شوند؛ اطلاعات ابری حذف نمی‌شود. این کار برای تعویض حساب است.") }, confirmButton = { TextButton(onClick = { if (clear()) { client.session = null; client.owner = ""; client.version = -1; confirmClear = false; status = "پاکسازی انجام شد." } }) { Text("پاکسازی محلی") } }, dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("انصراف") } })
}
