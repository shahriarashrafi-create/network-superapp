package ir.royesh.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.royesh.core.*
import java.time.LocalDate
import java.time.YearMonth
import kotlinx.coroutines.delay

fun faDate(raw: String): String = runCatching {
    val date = LocalDate.parse(raw)
    android.icu.text.SimpleDateFormat("EEEE d MMMM yyyy", android.icu.util.ULocale("fa_IR@calendar=persian")).format(java.util.Date.from(date.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant()))
}.getOrDefault(raw)

@Composable fun PlanningScreen(state: AppState, save: (AppState) -> Boolean, result: (Task) -> Unit) {
    var section by remember { mutableIntStateOf(0) }; var selected by remember { mutableStateOf(LocalDate.now()) }
    var add by remember { mutableStateOf(false) }; var actual by remember { mutableStateOf<TimeBlock?>(null) }
    var pickedTask by remember { mutableStateOf<String?>(null) }; var duration by remember { mutableStateOf("25") }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("تایم‌شیت", "هدف‌ها", "تمرکز").forEachIndexed { i, s -> FilterChip(section == i, { section = i }, label = { Text(s) }) } }
    when (section) {
        0 -> {
            Text("هفتهٔ شنبه تا جمعه", style = MaterialTheme.typography.headlineSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { selected = selected.minusWeeks(1) }) { Text("هفتهٔ قبل") }
                TextButton(onClick = { selected = LocalDate.now() }) { Text("امروز") }
                TextButton(onClick = { selected = selected.plusWeeks(1) }) { Text("هفتهٔ بعد") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (0L..6L).forEach { offset -> val day = Planning.weekStart(selected).plusDays(offset); FilterChip(selected == day, { selected = day }, label = { Text(faDate(day.toString()).substringBeforeLast(" ")) }) }
            }
            Text(faDate(selected.toString())); Button(onClick = { add = true }) { Text("+ بلوک زمانی") }
            val blocks = state.blocks.filter { Planning.occurs(it, selected) }.sortedBy { it.hour }
            Panel("برنامه و عملکرد") { Text("برنامه: ${blocks.sumOf { it.minutes }} دقیقه"); Text("عملکرد: ${blocks.sumOf { it.actuals[selected.toString()] ?: 0 }} دقیقه"); Text("ثبت زمان به‌تنهایی XP ندارد.") }
            if (blocks.isEmpty()) Text("برای این روز یک بازهٔ کوتاه برنامه‌ریزی کن.")
            blocks.forEach { b -> Panel("${b.hour}:00 · ${b.title}") {
                Text("${b.minutes} دقیقه" + if (b.weekly) " · تکرار هفتگی" else "")
                Text("عملکرد این روز: ${b.actuals[selected.toString()] ?: 0} دقیقه")
                TextButton(onClick = { actual = b }) { Text("ثبت عملکرد") }
                TextButton(onClick = { save(state.copy(blocks = state.blocks.map { if (it.id == b.id) it.copy(weekly = !it.weekly) else it })) }) { Text(if (b.weekly) "توقف تکرار؛ حفظ سابقه" else "تکرار هفتگی") }
            } }
        }
        1 -> {
            val now = LocalDate.now(); val month = YearMonth.from(now).toString(); val goal = state.goals.firstOrNull { it.month == month }
            var target by remember(state.goals) { mutableStateOf(goal?.target?.toString() ?: "") }
            Text("هدف‌های متصل به اقدام", style = MaterialTheme.typography.headlineSmall)
            Field(target, { target = it.filter(Char::isDigit).take(5) }, "تعداد اقدام نتیجه‌دار این ماه")
            Button(enabled = (target.toIntOrNull() ?: 0) in 1..10000, onClick = { save(state.copy(goals = state.goals.filterNot { it.month == month } + MonthlyGoal(month, target.toInt()))) }) { Text("ذخیره و تقسیم هدف") }
            Text("دورهٔ محاسبهٔ هدف در این نسخه ماه میلادی است؛ نمایش تاریخ شمسی است.", style = MaterialTheme.typography.bodySmall)
            if (goal != null) {
                val monthly = state.actions.count { it.occurredAt.startsWith(month) }; val start = Planning.weekStart(now)
                val weekly = state.actions.count { val d = LocalDate.parse(it.occurredAt.take(10)); d >= start && d < start.plusDays(7) && it.occurredAt.startsWith(month) }
                listOf(Triple("ماه جاری", monthly, goal.target), Triple("سهم هفته در همین ماه", weekly, Planning.weeklyTarget(goal.target, now)), Triple("سهم امروز", state.todayCount(now.toString()), Planning.dailyTarget(goal.target, now))).forEach { (title, count, total) -> Panel("$title · $count از $total") {
                    LinearProgressIndicator(progress = { if (total == 0) 1f else (count.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                } }
                Text("هدف روزانهٔ پروفایل مستقل است؛ سهم‌های بالا از هدف ماهانه محاسبه می‌شوند.")
            }
        }
        2 -> {
            Text("یک اقدام، یک تمرکز", style = MaterialTheme.typography.headlineSmall)
            val session = state.focus
            if (session != null) {
                var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
                LaunchedEffect(session.startedAt) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
                val remaining = ((session.endsAt - now) / 1000).coerceAtLeast(0)
                Panel(state.tasks.firstOrNull { it.id == session.taskId }?.title ?: "تمرکز") {
                    Text("${remaining / 60}:${(remaining % 60).toString().padStart(2, '0')}", fontSize = 40.sp)
                    Text(if (remaining == 0L) "زمان تمام شد؛ نتیجه‌ات را ثبت کن." else "روی همین یک قدم بمان؛ زمان پایان با خروج از صفحه هم حفظ می‌شود.")
                    Button(onClick = { state.tasks.firstOrNull { it.id == session.taskId }?.let(result) }) { Text("پایان و ثبت نتیجه") }
                    TextButton(onClick = { save(state.copy(focus = null)) }) { Text("توقف بدون نتیجه و امتیاز") }
                }
            } else {
                Field(duration, { duration = it.filter(Char::isDigit).take(3) }, "مدت تمرکز؛ ۱ تا ۱۲۰ دقیقه")
                if (state.tasks.none { !it.done }) Text("اول یک اقدام باز در مرکز اقدام بساز.")
                state.tasks.filterNot { it.done }.forEach { t -> FilterChip(pickedTask == t.id, { pickedTask = t.id }, label = { Text(t.title) }) }
                Button(enabled = pickedTask != null && (duration.toIntOrNull() ?: 0) in 1..120, onClick = { val now = System.currentTimeMillis(); save(state.copy(focus = FocusSession(pickedTask!!, now, now + duration.toLong() * 60000))) }) { Text("شروع تمرکز") }
                Text("تایمر امتیاز ندارد؛ XP فقط بعد از ثبت نتیجهٔ اقدام داده می‌شود.")
            }
        }
    }
    if (add) {
        var title by remember { mutableStateOf("") }; var hour by remember { mutableStateOf("9") }; var minutes by remember { mutableStateOf("60") }; var weekly by remember { mutableStateOf(false) }
        val h = hour.toIntOrNull() ?: -1; val m = minutes.toIntOrNull() ?: -1
        val conflict = state.blocks.any { Planning.occurs(it, selected) && h * 60 < it.hour * 60 + it.minutes && it.hour * 60 < h * 60 + m }
        Form("برنامهٔ ${faDate(selected.toString())}", title.isNotBlank() && h in 0..23 && m in 15..240 && h * 60 + m <= 1440 && !conflict, {
            if (save(state.copy(blocks = state.blocks + TimeBlock(title = title.trim(), date = selected.toString(), hour = h, minutes = m, weekly = weekly)))) add = false
        }, { add = false }) {
            Field(title, { title = it }, "عنوان برنامه"); Field(hour, { hour = it.filter(Char::isDigit).take(2) }, "ساعت شروع؛ ۰ تا ۲۳")
            Field(minutes, { minutes = it.filter(Char::isDigit).take(3) }, "مدت؛ ۱۵ تا ۲۴۰ دقیقه")
            Row { Checkbox(weekly, { weekly = it }); Text("هر هفته همین روز") }
            if (conflict) Text("این بازه با برنامهٔ همین روز تداخل دارد.")
        }
    }
    actual?.let { b -> var value by remember(b.id) { mutableStateOf(b.actuals[selected.toString()]?.toString() ?: "") }
        Form("عملکرد ${b.title}", (value.toIntOrNull() ?: -1) in 0..1440, {
            if (save(state.copy(blocks = state.blocks.map { if (it.id == b.id) it.copy(actuals = it.actuals + (selected.toString() to value.toInt())) else it }))) actual = null
        }, { actual = null }) { Field(value, { value = it.filter(Char::isDigit).take(4) }, "دقیقهٔ واقعی همین روز") }
    }
}
