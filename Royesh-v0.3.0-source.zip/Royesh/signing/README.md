royesh-preview.jks کلید عمومی آزمایشی همراه این بسته است؛ رمز android و alias برابر royesh-development است.
اگر کلید اصلی royesh-development.jks موجود باشد، بیلد آن را برای ارتقای ir.royesh.app ترجیح می‌دهد.
اگر نباشد، با کلید preview برنامهٔ جداگانهٔ ir.royesh.app.preview ساخته می‌شود و نصب قبلی دست‌نخورده می‌ماند.
