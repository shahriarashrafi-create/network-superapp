# Version 4 — Asset System + V3.2 Interaction/Visual Foundation

This build combines the V3.2 foundation fix with the first real Asset Library architecture.

## V3.2 work included
- Selection regression fixed: mansion pieces, fountain pieces, gate pieces, trees, benches, plants and lamps normalize to stable selectable instance IDs.
- Ground selection ring no longer replaces materials.
- Camera pitch/radius are constrained per focus preset.
- Camera safety pushes the play camera out of important object footprints.
- Continuous main terrain replaces the visible brown world ring and large mound bubbles.
- Continuous path base plus decorative pavers.
- Lower exposure / darker natural material palette.
- Mansion roof block replaced by a designed low pavilion.
- Improved gate, fountain, tree silhouettes, benches, shrubs and lamps.

## V4 Asset System included
- AssetDefinition / AssetInstance split.
- Shared AssetCatalog with categories, states, collision metadata and LOD metadata.
- Data-driven StarterEstateLayout for reusable tree/bench/plant/lamp placement.
- Central manifest JSON at assets/definitions/asset_manifest_v1.json.
- Stable naming and 1 unit = 1 meter style guide.
- Library contains 12 tree definitions, 8 benches, 10 plants, 8 lamps, 6 fountains, 6 fences, 5 gates, 6 pools, 8 paths, 10 buildings and complementary gazebo/bridge/waterfall/table/chair/decoration definitions.
- Scene rendering uses shared asset definitions for reusable environment families.
