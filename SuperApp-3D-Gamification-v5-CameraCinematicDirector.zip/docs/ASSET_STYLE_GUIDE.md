# Asset Style Guide — Stylized Premium 3D

- World scale: 1 unit = 1 meter.
- Ground pivot: every reusable asset is authored with a stable ground pivot.
- Palette: natural greens, warm neutral stone, restrained cyan water, dark graphite metal, warm wood.
- Materials: matte-to-semi-matte; avoid plastic-white surfaces and overexposure.
- Silhouette: readable from mobile distance; no tiny decorative geometry required for recognition.
- Selection: never replace the asset material. Use a world-space ring/marker.
- Interaction: every interactive asset instance gets a stable instance ID independent of its asset definition ID.
- Reuse: asset definitions are reusable; transforms and state live on instances.
- States: OFF/NORMAL/UPGRADED/PREMIUM where relevant; trees also SMALL/GROWN/LEGENDARY.
- LOD metadata: LOD0 near, LOD1 medium, LOD2 far. Runtime switching is introduced later without changing definitions.
- Collision metadata: BOX/SPHERE/CAPSULE footprints are stored independently from render geometry.
- Naming: category_variant_## for definitions; semantic instance IDs for region placement.
