# APK Update Contract

Do not change these without an explicit migration decision:

- `applicationId = com.superapp.progressgame`
- stable signing keystore `keystore/superapp.jks`
- signing alias `superapp`
- preference file name `progress_world_foundation`
- stable world/object IDs once released

Every future APK must use a strictly greater `versionCode`.

Current V2 values:

- versionCode: `5`
- Save Schema: `2`
- World Schema: `2`

Save migrations must be non-destructive. New scene/object state must use stable IDs instead of display names.
