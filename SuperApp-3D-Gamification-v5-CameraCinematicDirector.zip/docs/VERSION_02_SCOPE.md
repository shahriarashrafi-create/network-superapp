# Version 02 Scope — Real 3D Core

## Included

- Cleanup of V1 gateway and development-only UI
- Real SceneView/Filament renderer
- True X/Y/Z world transforms
- Free 3D camera with orbit, pan and pinch zoom
- Camera presets and overview reset
- Object picking via SceneView collision hit-test
- Single-tap selection and double-tap focus
- Procedural terrain starter block + raised landscape
- Curved-feeling 3D paver path
- Entrance architecture
- Fountain landmark
- Modern mansion
- Reusable tree definitions
- Benches, plants and lamps
- Basic PBR materials
- Main and fill lighting
- Shadow-ready geometry/light setup
- Small game HUD + Mission FAB
- Persisted camera preset and selected object
- Development overlay
- Asset pipeline directories
- Stable IDs / World Object Catalog

## Deferred by design

- Advanced sculpted terrain / terrain painting: V3
- Large reusable GLB asset library / LOD pipeline: V4
- Full Camera Director cinematic transitions: V5
- Mission Manager / rewards: V6
- Particles / haptic / game feel: V7
- Water, weather, day/night, living world: V8+
