# Version 4.2 — Entrance Cinematic + Environment Polish

This version locks the first premium presentation pass on top of V4 Asset System.

Implemented:
- Authored entrance camera sequence: front gate -> approach -> pass -> hero shot.
- Stronger gameplay camera limits and enlarged collision safety bubbles.
- Gate proportions refined; beam and lamp details reduced.
- Lamp count reduced from six to four and aligned to the main path axis.
- Four intentional benches retained; no extra plaza clutter.
- Far terrain enlarged beyond playable camera bounds to hide world edges.
- Deeper material separation between grass, path, plaza, mansion and roof.
- Main path receives a thin darker underlay/border rather than floating tiles.
- Plaza receives a subtle edge ring.
- Fountain gets animated ripple/spray motion using Compose state animation.
- Mansion side and rear facades receive window/frame detail.
- Roof pavilion becomes lower and wider.
- Tree and plant layout gains rotation and controlled scale variation.
- Lamps are shorter, thinner and use smaller warm globes.
- HUD/gameplay controls reduced slightly to prioritize world visibility.
- Existing selectable-object IDs and selection ring remain compatible with V4.

Deferred to later engine versions:
- Full spline camera director with continuous keyframe interpolation.
- Screen-space obstruction fade for objects between camera and target.
- True heightfield terrain sculpting.
- Advanced PBR textures/normal maps and IBL.
- Particle-based water splash and full water shader.
