Version 3.1 — Visual Polish Pass

Goals:
- Fix terrain readability and remove the giant-overlapping-mound look.
- Keep hero/gameplay zones flat and readable.
- Make selected objects keep their own materials; selection uses a lightweight ground ring.
- Improve mansion proportions and architectural hierarchy.
- Keep trees and shrubs mostly around the perimeter so they do not dominate the camera.
- Improve path / fountain / entry composition.
- Use Cinematic render quality and stronger camera bounds.
- Reduce Mission FAB size and preserve the compact HUD.

Implemented:
1. Larger neutral world ground.
2. Rebuilt perimeter mounds with lower vertical scale.
3. Fountain plaza is a dedicated flat zone.
4. Mansion zone is a dedicated flat zone.
5. Gate resized and aligned to the path.
6. Path pavers rebalanced.
7. Fountain proportions refined.
8. Mansion body / roof / terrace / canopy / columns / frames refined.
9. Tree scales reduced.
10. Tree placement moved away from the central camera corridor.
11. Shrubs reduced and distributed.
12. Lamps resized and aligned.
13. Bench scale refined.
14. Object selection no longer replaces object material.
15. Cyan ground selection ring added.
16. Camera distance clamp added.
17. Camera minimum / maximum Y clamp added.
18. Camera X/Z world bounds added.
19. Cinematic render quality enabled.
20. Mission FAB reduced to 50dp.

Deferred:
- True terrain heightmap mesh / sculpting tools.
- Camera collision against every individual scene object.
- Animated water and particles.
- HDR sky / day-night / weather.
- GLB production asset library.
