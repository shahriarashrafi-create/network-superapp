Version 05 — Camera & Cinematic Director

Implemented:
- Dedicated CameraDirector and camera modes (Free / Focus / Cinematic / Top View)
- Full 360 orbit with restored high-pitch freedom and near top-down viewing
- Object-focused orbit targets for fountain, mansion, gate, trees, benches, lamps and plants
- Dedicated top view for selected object or whole world
- Entrance cinematic: outside gate -> approach -> pass -> fountain reveal -> mansion reveal -> hero
- Travel, reveal and celebration cinematic sequences
- Skip cinematic control and replay entrance control
- Overview, focus and top-view controls
- Dynamic camera FOV per authored shot
- Smart framing by asset category and camera anchors
- Camera collision safety and basic obstruction solver
- Expanded zoom/radius envelope for free inspection
- Camera pose and target persistence
- Improved selection feedback pulse and focus status UI
- Existing V4 asset system retained
