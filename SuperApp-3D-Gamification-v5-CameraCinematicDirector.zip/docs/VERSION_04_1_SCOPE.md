Version 4.1 — Entrance Intro + Visual Composition Polish

Implemented:
- World now opens from an authored front-facing entrance shot.
- Short entrance-to-hero camera transition after entering the world.
- Exact camera eye positions per preset instead of distance-only framing.
- Tighter game camera pitch/radius safety and obstacle push-out.
- Main path changed from stepping tiles to a continuous path with subtle seams.
- Gate enlarged/refined with bases, caps, integrated lighting and stronger proportions.
- Standalone lamps reduced and aligned on the world axis.
- Benches repositioned for a quieter premium garden composition.
- Mansion roof pavilion centered and integrated with a roof cap and base plinth.
- Material palette darkened to reduce washed-out rendering and improve contrast.
- Sky/background gradient revised for a stronger horizon feel.
- Selection object labels switched to meaningful Persian names.
- HUD/game controls reduced slightly to expose more of the world.

Preserved:
- V4 AssetDefinition / AssetCatalog / AssetInstance architecture.
- Stable package/signing/update identity.
- Existing selection ring interaction and double-tap focus behavior.
