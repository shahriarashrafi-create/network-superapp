Version 03 — Terrain & Environment + Visual Foundation Upgrade

Implemented focus:
- Terrain enlarged and visually grounded
- Perimeter mounds / berms to reduce flat platform feeling
- Improved path composition and entry gate scale
- Mansion visual upgrade with more structure and details
- Expanded tree set with more varied silhouettes
- Better shrub / lamp / bench placement
- Refined fountain landmark
- HUD polish and smaller gameplay controls
- Tutorial hint now auto-dismisses and can be tapped to dismiss
- Camera preset values updated for the upgraded scene

Still intentionally deferred to later versions:
- Mission system full gameplay loop
- Water animation and particle systems
- Weather / day-night cycle
- Advanced collision constraints on camera
- Streaming / performance LOD systems
