package com.superapp.progressgame.ui.theme

import androidx.compose.ui.graphics.Color

val Night = Color(0xFF07111F)
val DeepSurface = Color(0xFF0C1A2B)
val ElevatedSurface = Color(0xFF13243A)
val PrimaryBlue = Color(0xFF4D7FFF)
val ElectricBlue = Color(0xFF6FA3FF)
val AccentCyan = Color(0xFF5FE1E6)
val SuccessGreen = Color(0xFF4FD39A)
val WarningOrange = Color(0xFFFFB76B)
val TextPrimary = Color(0xFFF5F8FF)
val TextSecondary = Color(0xFFA9B8CE)
val GridLine = Color(0xFF244467)
