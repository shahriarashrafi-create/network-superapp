package com.superapp.progressgame.debug

import com.superapp.progressgame.BuildConfig
import com.superapp.progressgame.assets.AssetCatalog
import com.superapp.progressgame.core.config.AppConfig
import com.superapp.progressgame.core.config.FoundationFeatureFlags

data class DebugSnapshot(
    val buildType: String,
    val appId: String,
    val appVersion: String,
    val saveSchema: Int,
    val worldSchema: Int,
    val assetSchema: Int,
    val assetDefinitions: Int,
    val renderer: String,
    val enabledFoundationFlags: Int,
)

fun createDebugSnapshot(): DebugSnapshot {
    val flags = FoundationFeatureFlags.current
    val enabled = listOf(
        flags.real3DRenderer,
        flags.free3DCamera,
        flags.objectPicking,
        flags.basicTerrain,
        flags.basicLighting,
        flags.cameraFocus,
        flags.cameraSafety,
        flags.assetLibrary,
        flags.assetStates,
        flags.assetLodMetadata,
        flags.cinematicCamera,
        flags.missions,
        flags.worldBuilder,
        flags.particles,
        flags.weather,
        flags.avatar,
        flags.npcs,
        flags.debugOverlay,
    ).count { it }

    return DebugSnapshot(
        buildType = BuildConfig.BUILD_TYPE,
        appId = AppConfig.APP_ID,
        appVersion = AppConfig.FOUNDATION_VERSION,
        saveSchema = AppConfig.SAVE_SCHEMA_VERSION,
        worldSchema = AppConfig.WORLD_SCHEMA_VERSION,
        assetSchema = AppConfig.ASSET_SCHEMA_VERSION,
        assetDefinitions = AssetCatalog.definitions.size,
        renderer = AppConfig.RENDERER_NAME,
        enabledFoundationFlags = enabled,
    )
}
