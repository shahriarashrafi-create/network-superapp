package com.superapp.progressgame.world

import com.superapp.progressgame.assets.AssetCatalog
import com.superapp.progressgame.assets.AssetCategory
import com.superapp.progressgame.assets.StarterEstateLayout

data class WorldObjectDefinition(
    val id: String,
    val assetId: String,
    val category: String,
    val displayName: String,
    val cameraFocusable: Boolean = true,
)

object WorldObjectCatalog {
    val objects: List<WorldObjectDefinition> = StarterEstateLayout.allInteractive.map { instance ->
        val asset = AssetCatalog.require(instance.assetId)
        WorldObjectDefinition(
            id = instance.instanceId,
            assetId = instance.assetId,
            category = asset.category.name.lowercase(),
            displayName = displayNameFor(instance.instanceId, asset.category),
            cameraFocusable = asset.focusable,
        )
    }

    private val byId = objects.associateBy { it.id }
    private val idsLongestFirst = byId.keys.sortedByDescending { it.length }

    fun normalize(rawName: String?): String? {
        if (rawName.isNullOrBlank()) return null
        if (byId.containsKey(rawName)) return rawName
        return idsLongestFirst.firstOrNull { rawName.startsWith(it) }
    }

    fun definition(id: String?): WorldObjectDefinition? = id?.let(byId::get)

    private fun displayNameFor(id: String, category: AssetCategory): String = when {
        id == "fountain_main" -> "فواره مرکزی"
        id == "mansion_main" -> "عمارت اصلی"
        id == "entrance_gate" -> "دروازه ورودی"
        id.startsWith("tree_w_") -> "درخت باغ غربی ${id.takeLast(2).toIntOrNull() ?: 1}"
        id.startsWith("tree_e_") -> "درخت باغ شرقی ${id.takeLast(2).toIntOrNull() ?: 1}"
        id.startsWith("bench_w_") -> "نیمکت غربی ${id.takeLast(2).toIntOrNull() ?: 1}"
        id.startsWith("bench_e_") -> "نیمکت شرقی ${id.takeLast(2).toIntOrNull() ?: 1}"
        id.startsWith("lamp_") -> "چراغ مسیر ${id.takeLast(2).toIntOrNull() ?: 1}"
        id.startsWith("plant_") -> "بوته تزئینی ${id.takeLast(2).toIntOrNull() ?: 1}"
        category == AssetCategory.TREE -> "درخت"
        category == AssetCategory.BENCH -> "نیمکت"
        category == AssetCategory.LAMP -> "چراغ مسیر"
        category == AssetCategory.PLANT -> "گیاه تزئینی"
        else -> id
    }
}
