package com.superapp.progressgame.core.storage

import android.content.Context

class FoundationPreferences(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var graphicsProfile: GraphicsProfile
        get() = runCatching {
            GraphicsProfile.valueOf(prefs.getString(KEY_GRAPHICS, GraphicsProfile.AUTO.name)!!)
        }.getOrDefault(GraphicsProfile.AUTO)
        set(value) = prefs.edit().putString(KEY_GRAPHICS, value.name).apply()

    var soundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var hapticsEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTICS, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTICS, value).apply()

    var debugOverlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_DEBUG_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_DEBUG_OVERLAY, value).apply()

    var cameraPresetId: String
        get() = prefs.getString(KEY_CAMERA_PRESET, "overview") ?: "overview"
        set(value) = prefs.edit().putString(KEY_CAMERA_PRESET, value).apply()

    var selectedObjectId: String?
        get() = prefs.getString(KEY_SELECTED_OBJECT, null)
        set(value) = prefs.edit().apply {
            if (value == null) remove(KEY_SELECTED_OBJECT) else putString(KEY_SELECTED_OBJECT, value)
        }.apply()

    var worldHintSeen: Boolean
        get() = prefs.getBoolean(KEY_WORLD_HINT_SEEN, false)
        set(value) = prefs.edit().putBoolean(KEY_WORLD_HINT_SEEN, value).apply()

    var entranceCinematicSeen: Boolean
        get() = prefs.getBoolean(KEY_ENTRANCE_CINEMATIC_SEEN, false)
        set(value) = prefs.edit().putBoolean(KEY_ENTRANCE_CINEMATIC_SEEN, value).apply()

    var cameraMode: String
        get() = prefs.getString(KEY_CAMERA_MODE, "free") ?: "free"
        set(value) = prefs.edit().putString(KEY_CAMERA_MODE, value).apply()

    var cameraX: Float
        get() = prefs.getFloat(KEY_CAMERA_X, 0f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_X, value).apply()

    var cameraY: Float
        get() = prefs.getFloat(KEY_CAMERA_Y, 0f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_Y, value).apply()

    var cameraZ: Float
        get() = prefs.getFloat(KEY_CAMERA_Z, 0f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_Z, value).apply()

    var cameraTargetX: Float
        get() = prefs.getFloat(KEY_CAMERA_TARGET_X, 0f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_TARGET_X, value).apply()

    var cameraTargetY: Float
        get() = prefs.getFloat(KEY_CAMERA_TARGET_Y, 1.1f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_TARGET_Y, value).apply()

    var cameraTargetZ: Float
        get() = prefs.getFloat(KEY_CAMERA_TARGET_Z, -2f)
        set(value) = prefs.edit().putFloat(KEY_CAMERA_TARGET_Z, value).apply()

    companion object {
        private const val PREFS_NAME = "progress_world_foundation"
        private const val KEY_GRAPHICS = "graphics_profile"
        private const val KEY_SOUND = "sound_enabled"
        private const val KEY_HAPTICS = "haptics_enabled"
        private const val KEY_DEBUG_OVERLAY = "debug_overlay_enabled"
        private const val KEY_CAMERA_PRESET = "camera_preset"
        private const val KEY_SELECTED_OBJECT = "selected_object"
        private const val KEY_WORLD_HINT_SEEN = "world_hint_seen"
        private const val KEY_ENTRANCE_CINEMATIC_SEEN = "entrance_cinematic_seen"
        private const val KEY_CAMERA_MODE = "camera_mode"
        private const val KEY_CAMERA_X = "camera_x"
        private const val KEY_CAMERA_Y = "camera_y"
        private const val KEY_CAMERA_Z = "camera_z"
        private const val KEY_CAMERA_TARGET_X = "camera_target_x"
        private const val KEY_CAMERA_TARGET_Y = "camera_target_y"
        private const val KEY_CAMERA_TARGET_Z = "camera_target_z"
    }
}

enum class GraphicsProfile {
    AUTO,
    PERFORMANCE,
    QUALITY,
}
