package com.superapp.progressgame.engine.camera

import io.github.sceneview.math.Position
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private data class CameraObstacle(
    val x: Float,
    val z: Float,
    val radius: Float,
    val height: Float,
)

private val obstacles = listOf(
    CameraObstacle(0f, -9.3f, 5.6f, 4.4f),
    CameraObstacle(0f, -1.2f, 2.7f, 2.6f),
    CameraObstacle(0f, 11.0f, 2.25f, 3.3f),
    CameraObstacle(-9.6f, 7.4f, 1.55f, 4.8f), CameraObstacle(-11.3f, 1.6f, 1.65f, 4.8f),
    CameraObstacle(-9.6f, -4.9f, 1.55f, 4.8f), CameraObstacle(-11.7f, -10.7f, 1.65f, 4.8f),
    CameraObstacle(9.2f, 7.2f, 1.55f, 4.8f), CameraObstacle(11.1f, 1.5f, 1.65f, 4.8f),
    CameraObstacle(9.7f, -4.8f, 1.55f, 4.8f), CameraObstacle(11.8f, -10.6f, 1.65f, 4.8f),
)

fun constrainGameCamera(
    camera: Position,
    preset: CameraPreset,
    mode: CameraMode,
): Position {
    val target = preset.target
    val dx = camera.x - target.x
    val dz = camera.z - target.z
    val horizontal = sqrt(dx * dx + dz * dz).coerceAtLeast(0.001f)
    val dy = camera.y - target.y

    val distance = sqrt(horizontal * horizontal + dy * dy).coerceAtLeast(0.001f)
    val clampedDistance = distance.coerceIn(preset.minRadius, preset.maxRadius)

    // V5 restores the freedom lost in V4.2: near-top-down viewing is allowed in free/focus
    // modes while cinematics retain authored composition.
    val pitchBounds = when (mode) {
        CameraMode.CINEMATIC -> 4.0 to 68.0
        CameraMode.TOP_VIEW -> 18.0 to 89.0
        CameraMode.FOCUS -> -4.0 to 88.0
        CameraMode.FREE -> -8.0 to 88.0
    }
    val minPitch = Math.toRadians(pitchBounds.first).toFloat()
    val maxPitch = Math.toRadians(pitchBounds.second).toFloat()
    val pitch = atan2(dy, horizontal).coerceIn(minPitch, maxPitch)

    val horizontalAtDistance = max(0.03f, clampedDistance * cos(pitch))
    val verticalAtDistance = clampedDistance * sin(pitch)
    val planarScale = horizontalAtDistance / horizontal

    var x = target.x + dx * planarScale
    var z = target.z + dz * planarScale
    var y = target.y + verticalAtDistance

    // Keep a physical safety bubble around large scene geometry only when the lens is low.
    // High/top-down shots intentionally pass over obstacles instead of getting pushed away.
    if (y < 5.8f && mode != CameraMode.TOP_VIEW) {
        obstacles.forEach { obstacle ->
            val targetDx = target.x - obstacle.x
            val targetDz = target.z - obstacle.z
            val targetDistance = sqrt(targetDx * targetDx + targetDz * targetDz)
            if (targetDistance > obstacle.radius + 0.5f) {
                val ox = x - obstacle.x
                val oz = z - obstacle.z
                val d = sqrt(ox * ox + oz * oz).coerceAtLeast(0.001f)
                val safe = obstacle.radius + 0.48f
                if (d < safe) {
                    val push = safe / d
                    x = obstacle.x + ox * push
                    z = obstacle.z + oz * push
                }
            }
        }
    }

    // Obstruction solver: when a large object lies between target and camera, gently lift
    // the camera rather than allowing a tree/building to fill the entire frame.
    if (mode == CameraMode.FOCUS || mode == CameraMode.FREE) {
        val raised = requiredClearanceHeight(
            cameraX = x,
            cameraZ = z,
            targetX = target.x,
            targetZ = target.z,
        )
        y = max(y, raised)
    }

    return Position(
        x = x.coerceIn(-28f, 28f),
        y = y.coerceIn(0.95f, 19.5f),
        z = z.coerceIn(-30f, 29f),
    )
}

private fun requiredClearanceHeight(
    cameraX: Float,
    cameraZ: Float,
    targetX: Float,
    targetZ: Float,
): Float {
    var clearance = 0.95f
    obstacles.forEach { obstacle ->
        val targetDx = targetX - obstacle.x
        val targetDz = targetZ - obstacle.z
        if (sqrt(targetDx * targetDx + targetDz * targetDz) <= obstacle.radius + 0.55f) return@forEach

        val d = distancePointToSegment(
            px = obstacle.x,
            pz = obstacle.z,
            ax = cameraX,
            az = cameraZ,
            bx = targetX,
            bz = targetZ,
        )
        if (d < obstacle.radius * 0.78f) {
            clearance = max(clearance, obstacle.height + 0.55f)
        }
    }
    return min(clearance, 6.3f)
}

private fun distancePointToSegment(
    px: Float,
    pz: Float,
    ax: Float,
    az: Float,
    bx: Float,
    bz: Float,
): Float {
    val abx = bx - ax
    val abz = bz - az
    val apx = px - ax
    val apz = pz - az
    val ab2 = abx * abx + abz * abz
    if (ab2 <= 0.0001f) return sqrt(apx * apx + apz * apz)
    val t = ((apx * abx + apz * abz) / ab2).coerceIn(0f, 1f)
    val qx = ax + abx * t
    val qz = az + abz * t
    val dx = px - qx
    val dz = pz - qz
    return sqrt(dx * dx + dz * dz)
}
