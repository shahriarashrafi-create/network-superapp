package com.superapp.progressgame.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val FoundationColors = darkColorScheme(
    primary = PrimaryBlue,
    secondary = AccentCyan,
    tertiary = SuccessGreen,
    background = Night,
    surface = DeepSurface,
    surfaceVariant = ElevatedSurface,
    onPrimary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
)

@Composable
fun ProgressWorldTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = FoundationColors,
        content = content,
    )
}
