package com.superapp.progressgame.engine.camera

import com.superapp.progressgame.assets.AssetCategory
import com.superapp.progressgame.assets.StarterEstateLayout
import com.superapp.progressgame.assets.AssetCatalog
import io.github.sceneview.math.Position

data class CameraPreset(
    val id: String,
    val eye: Position,
    val target: Position,
    val minRadius: Float,
    val maxRadius: Float,
    val fovDegrees: Float = 50f,
    val transitionMillis: Long = 650L,
)

enum class CameraMode {
    FREE,
    FOCUS,
    CINEMATIC,
    TOP_VIEW,
}

object CameraPresets {
    val EntranceFront = CameraPreset(
        id = "entrance_front",
        eye = Position(x = 0f, y = 2.35f, z = 21.0f),
        target = Position(x = 0f, y = 1.20f, z = -1.8f),
        minRadius = 12.0f,
        maxRadius = 28.0f,
        fovDegrees = 58f,
        transitionMillis = 900L,
    )

    val EntranceApproach = CameraPreset(
        id = "entrance_approach",
        eye = Position(x = 0f, y = 2.45f, z = 15.2f),
        target = Position(x = 0f, y = 1.15f, z = -1.7f),
        minRadius = 9.0f,
        maxRadius = 22.0f,
        fovDegrees = 55f,
        transitionMillis = 760L,
    )

    val EntrancePass = CameraPreset(
        id = "entrance_pass",
        eye = Position(x = 0f, y = 2.70f, z = 9.2f),
        target = Position(x = 0f, y = 1.08f, z = -1.7f),
        minRadius = 6.5f,
        maxRadius = 18.0f,
        fovDegrees = 52f,
        transitionMillis = 720L,
    )

    val FountainReveal = CameraPreset(
        id = "fountain_reveal",
        eye = Position(x = 3.4f, y = 3.20f, z = 5.1f),
        target = Position(x = 0f, y = 1.0f, z = -1.2f),
        minRadius = 4.0f,
        maxRadius = 12.0f,
        fovDegrees = 47f,
        transitionMillis = 760L,
    )

    val MansionReveal = CameraPreset(
        id = "mansion_reveal",
        eye = Position(x = -4.8f, y = 3.60f, z = 1.8f),
        target = Position(x = 0f, y = 1.75f, z = -8.8f),
        minRadius = 7.0f,
        maxRadius = 17.0f,
        fovDegrees = 44f,
        transitionMillis = 850L,
    )

    val Hero = CameraPreset(
        id = "hero",
        eye = Position(x = 4.8f, y = 3.25f, z = 6.6f),
        target = Position(x = 0f, y = 1.12f, z = -2.0f),
        minRadius = 4.8f,
        maxRadius = 24.0f,
        fovDegrees = 50f,
    )

    val Overview = CameraPreset(
        id = "overview",
        eye = Position(x = 8.4f, y = 6.2f, z = 9.8f),
        target = Position(x = 0f, y = 1.05f, z = -2.0f),
        minRadius = 7.0f,
        maxRadius = 28.0f,
        fovDegrees = 58f,
    )

    val WideShot = CameraPreset(
        id = "wide_shot",
        eye = Position(x = -11.0f, y = 7.4f, z = 11.8f),
        target = Position(x = 0f, y = 1.10f, z = -2.2f),
        minRadius = 10.0f,
        maxRadius = 32.0f,
        fovDegrees = 62f,
        transitionMillis = 850L,
    )

    val Fountain = CameraPreset(
        id = "fountain_main",
        eye = Position(x = 4.65f, y = 3.05f, z = 3.85f),
        target = Position(x = 0f, y = 1.00f, z = -1.2f),
        minRadius = 2.8f,
        maxRadius = 13.0f,
        fovDegrees = 43f,
    )

    val FountainTop = CameraPreset(
        id = "fountain_top",
        eye = Position(x = 0.18f, y = 12.5f, z = -1.15f),
        target = Position(x = 0f, y = 0.55f, z = -1.2f),
        minRadius = 5.5f,
        maxRadius = 18.0f,
        fovDegrees = 46f,
        transitionMillis = 700L,
    )

    val Mansion = CameraPreset(
        id = "mansion_main",
        eye = Position(x = 5.2f, y = 3.35f, z = -2.35f),
        target = Position(x = 0f, y = 1.72f, z = -9.0f),
        minRadius = 4.5f,
        maxRadius = 18.0f,
        fovDegrees = 45f,
    )

    val Entrance = CameraPreset(
        id = "entrance_gate",
        eye = Position(x = 0f, y = 2.25f, z = 17.7f),
        target = Position(x = 0f, y = 1.28f, z = 11.0f),
        minRadius = 3.8f,
        maxRadius = 14.0f,
        fovDegrees = 48f,
    )

    val Celebration = CameraPreset(
        id = "celebration",
        eye = Position(x = -7.4f, y = 6.6f, z = 5.8f),
        target = Position(x = 0f, y = 1.25f, z = -2.0f),
        minRadius = 7.5f,
        maxRadius = 24.0f,
        fovDegrees = 60f,
        transitionMillis = 900L,
    )

    fun forObject(objectId: String?): CameraPreset {
        if (objectId == null) return Hero
        return when (objectId) {
            "fountain_main" -> Fountain
            "mansion_main" -> Mansion
            "entrance_gate" -> Entrance
            else -> focusForObject(objectId)
        }
    }

    fun focusForObject(objectId: String): CameraPreset {
        val instance = StarterEstateLayout.instance(objectId) ?: return Hero
        val asset = AssetCatalog.require(instance.assetId)
        val anchor = instance.cameraAnchor ?: instance.position
        val radius = when (asset.category) {
            AssetCategory.BUILDING -> 8.2f
            AssetCategory.FOUNTAIN -> 5.0f
            AssetCategory.GATE -> 5.8f
            AssetCategory.TREE -> 4.1f
            AssetCategory.BENCH -> 3.2f
            AssetCategory.LAMP -> 2.8f
            AssetCategory.PLANT -> 2.7f
            else -> 4.0f
        }
        val elevation = when (asset.category) {
            AssetCategory.TREE -> 2.8f
            AssetCategory.LAMP -> 2.1f
            AssetCategory.BENCH, AssetCategory.PLANT -> 1.6f
            else -> 2.7f
        }
        val side = if (anchor.x >= 0f) 1f else -1f
        return CameraPreset(
            id = "focus_$objectId",
            eye = Position(
                x = anchor.x + side * radius * 0.72f,
                y = anchor.y + elevation,
                z = anchor.z + radius * 0.82f,
            ),
            target = Position(anchor.x, anchor.y.coerceAtLeast(0.6f), anchor.z),
            minRadius = (radius * 0.55f).coerceAtLeast(1.8f),
            maxRadius = radius * 2.7f,
            fovDegrees = 42f,
        )
    }

    fun topViewForObject(objectId: String?): CameraPreset {
        val instance = StarterEstateLayout.instance(objectId)
        val anchor = instance?.cameraAnchor ?: instance?.position ?: com.superapp.progressgame.assets.Vec3(0f, 1.1f, -2.0f)
        val radius = when (objectId) {
            "mansion_main" -> 15.5f
            "fountain_main" -> 12.5f
            "entrance_gate" -> 10.0f
            else -> if (objectId == null) 18.0f else 8.5f
        }
        return CameraPreset(
            id = "top_${objectId ?: "world"}",
            eye = Position(x = anchor.x + 0.16f, y = anchor.y + radius, z = anchor.z + 0.10f),
            target = Position(anchor.x, anchor.y.coerceAtLeast(0.25f), anchor.z),
            minRadius = (radius * 0.45f).coerceAtLeast(3.0f),
            maxRadius = radius * 1.9f,
            fovDegrees = 50f,
            transitionMillis = 720L,
        )
    }

    fun byId(id: String?): CameraPreset = when (id) {
        EntranceFront.id -> EntranceFront
        EntranceApproach.id -> EntranceApproach
        EntrancePass.id -> EntrancePass
        FountainReveal.id -> FountainReveal
        MansionReveal.id -> MansionReveal
        Hero.id -> Hero
        Overview.id -> Overview
        WideShot.id -> WideShot
        Fountain.id -> Fountain
        FountainTop.id -> FountainTop
        Mansion.id -> Mansion
        Entrance.id -> Entrance
        Celebration.id -> Celebration
        else -> Hero
    }
}
