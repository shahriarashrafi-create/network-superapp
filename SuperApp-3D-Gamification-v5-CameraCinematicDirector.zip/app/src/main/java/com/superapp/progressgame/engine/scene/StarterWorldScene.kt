package com.superapp.progressgame.engine.scene

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import com.superapp.progressgame.assets.AssetCatalog
import com.superapp.progressgame.assets.AssetCategory
import com.superapp.progressgame.assets.AssetInstance
import com.superapp.progressgame.assets.StarterEstateLayout
import io.github.sceneview.SceneScope
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.math.Size

@Composable
fun SceneScope.StarterWorldScene(selectedObjectId: String?) {
    val grass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF356746), metallic = 0f, roughness = 0.98f)
    }
    val grassDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF2D573A), metallic = 0f, roughness = 0.99f)
    }
    val pathStone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFA99A87), metallic = 0f, roughness = 0.78f)
    }
    val pathAccent = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF8E806D), metallic = 0f, roughness = 0.80f)
    }
    val plazaStone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFC7B397), metallic = 0f, roughness = 0.74f)
    }
    val wall = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFC8C0B5), metallic = 0f, roughness = 0.70f)
    }
    val wallAccent = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFA49787), metallic = 0f, roughness = 0.72f)
    }
    val roof = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5E6366), metallic = 0.08f, roughness = 0.58f)
    }
    val glass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF347F9C), metallic = 0.16f, roughness = 0.18f)
    }
    val wood = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF7A4D36), metallic = 0f, roughness = 0.84f)
    }
    val woodDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF45281E), metallic = 0f, roughness = 0.90f)
    }
    val metal = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF202B31), metallic = 0.88f, roughness = 0.26f)
    }
    val leaf = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF2A6840), metallic = 0f, roughness = 0.95f)
    }
    val leafMid = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3D7C4E), metallic = 0f, roughness = 0.95f)
    }
    val leafLight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF579361), metallic = 0f, roughness = 0.94f)
    }
    val trunk = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF4A3326), metallic = 0f, roughness = 0.96f)
    }
    val water = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3C8FAA), metallic = 0.12f, roughness = 0.12f)
    }
    val waterHighlight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF83CCE0), metallic = 0.10f, roughness = 0.05f)
    }
    val lampGlow = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFFFFD19A))
    }
    val selection = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFF61D8FF))
    }

    // V4.2: oversize the far terrain beyond every playable camera bound so the
    // world no longer reads as a finite rectangular platform at the horizon.
    CubeNode(
        size = Size(x = 150f, y = 0.05f, z = 150f),
        materialInstance = grassDark,
        position = Position(x = 0f, y = -0.12f, z = -4f),
        apply = { name = "terrain_far"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 62f, y = 0.07f, z = 60f),
        materialInstance = grass,
        position = Position(x = 0f, y = -0.01f, z = -2f),
        apply = { name = "terrain_main"; isTouchable = false }
    )

    // Authored flat zones around gameplay landmarks.
    CylinderNode(
        radius = 3.8f,
        height = 0.055f,
        materialInstance = plazaStone,
        position = Position(x = 0f, y = 0.045f, z = -1.2f),
        apply = { name = "fountain_plaza"; isTouchable = false }
    )
    TorusNode(
        majorRadius = 3.72f,
        minorRadius = 0.045f,
        materialInstance = pathAccent,
        position = Position(x = 0f, y = 0.095f, z = -1.2f),
        apply = { name = "fountain_plaza_edge"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 11.8f, y = 0.045f, z = 6.2f),
        materialInstance = grass,
        position = Position(x = 0f, y = 0.018f, z = -9.6f),
        apply = { name = "mansion_ground_zone"; isTouchable = false }
    )

    // Continuous path with a thin darker underlay. This gives the path a readable
    // edge without returning to floating tile geometry.
    CubeNode(
        size = Size(x = 2.82f, y = 0.025f, z = 18.9f),
        materialInstance = pathAccent,
        position = Position(x = 0f, y = 0.025f, z = 5.05f),
        apply = { name = "path_main_border"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 2.56f, y = 0.045f, z = 18.6f),
        materialInstance = pathStone,
        position = Position(x = 0f, y = 0.055f, z = 5.05f),
        apply = { name = "path_main_base"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 2.82f, y = 0.025f, z = 5.15f),
        materialInstance = pathAccent,
        position = Position(x = 0f, y = 0.025f, z = -5.65f),
        apply = { name = "path_mansion_border"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 2.56f, y = 0.045f, z = 4.9f),
        materialInstance = pathStone,
        position = Position(x = 0f, y = 0.055f, z = -5.65f),
        apply = { name = "path_mansion_base"; isTouchable = false }
    )
    listOf(9.4f, 7.3f, 5.2f, 3.1f, 1.0f, -3.8f, -5.3f, -6.8f).forEachIndexed { index, z ->
        CubeNode(
            size = Size(x = 2.18f, y = 0.018f, z = 0.055f),
            materialInstance = pathAccent,
            position = Position(x = 0f, y = 0.083f, z = z),
            apply = { name = "path_seam_$index"; isTouchable = false }
        )
    }


    renderGate(
        id = "entrance_gate",
        x = 0f,
        z = 11.0f,
        stone = plazaStone,
        accent = wallAccent,
        lampGlow = lampGlow,
        metal = metal,
    )

    renderFountain(
        id = "fountain_main",
        x = 0f,
        z = -1.2f,
        stone = pathStone,
        accent = plazaStone,
        water = water,
        waterHighlight = waterHighlight,
    )

    renderMansion(
        id = "mansion_main",
        x = 0f,
        z = -9.3f,
        wall = wall,
        wallAccent = wallAccent,
        roof = roof,
        glass = glass,
        woodDark = woodDark,
        stone = plazaStone,
    )

    StarterEstateLayout.trees.forEach { instance ->
        val definition = AssetCatalog.require(instance.assetId)
        renderTree(
            instance = instance,
            rendererKey = definition.proceduralRendererKey,
            trunk = trunk,
            leaf = leaf,
            leafMid = leafMid,
            leafLight = leafLight,
        )
    }

    StarterEstateLayout.benches.forEach { instance ->
        renderBench(instance = instance, wood = wood, metal = metal)
    }

    StarterEstateLayout.plants.forEachIndexed { index, instance ->
        renderPlant(
            instance = instance,
            style = index % 4,
            leaf = leaf,
            leafMid = leafMid,
            leafLight = leafLight,
        )
    }

    StarterEstateLayout.lamps.forEachIndexed { index, instance ->
        renderLamp(
            instance = instance,
            style = index % 3,
            metal = metal,
            lampGlow = lampGlow,
        )
    }

    val selectionMotion = rememberInfiniteTransition(label = "selection_motion")
    val selectionPulse by selectionMotion.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 820),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "selection_pulse",
    )
    selectionMarker(selectedObjectId)?.let { marker ->
        TorusNode(
            majorRadius = marker.radius * selectionPulse,
            minorRadius = 0.052f,
            materialInstance = selection,
            position = Position(x = marker.x, y = 0.15f, z = marker.z),
            apply = { name = "selection_ring"; isTouchable = false }
        )
    }
}

@Composable
private fun SceneScope.renderGate(
    id: String,
    x: Float,
    z: Float,
    stone: com.google.android.filament.MaterialInstance,
    accent: com.google.android.filament.MaterialInstance,
    lampGlow: com.google.android.filament.MaterialInstance,
    metal: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z)) {
        listOf(-1.72f, 1.72f).forEachIndexed { index, px ->
            CubeNode(
                size = Size(x = 0.40f, y = 2.44f, z = 0.48f),
                materialInstance = stone,
                position = Position(x = px, y = 1.22f),
                apply = { name = "${id}_pillar_$index" }
            )
            CubeNode(
                size = Size(x = 0.56f, y = 0.14f, z = 0.60f),
                materialInstance = accent,
                position = Position(x = px, y = 2.48f),
                apply = { name = "${id}_cap_$index" }
            )
            CylinderNode(
                radius = 0.042f,
                height = 0.36f,
                materialInstance = metal,
                position = Position(x = px, y = 2.74f),
                apply = { name = "${id}_lamp_post_$index" }
            )
            SphereNode(
                radius = 0.095f,
                materialInstance = lampGlow,
                position = Position(x = px, y = 2.93f),
                apply = { name = "${id}_lamp_glow_$index" }
            )
            CubeNode(
                size = Size(x = 0.66f, y = 0.12f, z = 0.70f),
                materialInstance = accent,
                position = Position(x = px, y = 0.06f),
                apply = { name = "${id}_base_$index" }
            )
        }
        CubeNode(
            size = Size(x = 3.82f, y = 0.22f, z = 0.48f),
            materialInstance = stone,
            position = Position(y = 2.43f),
            apply = { name = "${id}_beam" }
        )
    }
}

@Composable
private fun SceneScope.renderFountain(
    id: String,
    x: Float,
    z: Float,
    stone: com.google.android.filament.MaterialInstance,
    accent: com.google.android.filament.MaterialInstance,
    water: com.google.android.filament.MaterialInstance,
    waterHighlight: com.google.android.filament.MaterialInstance,
) {
    val waterMotion = rememberInfiniteTransition(label = "fountain_water")
    val ripple by waterMotion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800),
            repeatMode = RepeatMode.Restart,
        ),
        label = "ripple",
    )
    val sprayLift by waterMotion.animateFloat(
        initialValue = 0f,
        targetValue = 0.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "spray",
    )

    Node(position = Position(x = x, y = 0f, z = z)) {
        CylinderNode(radius = 2.08f, height = 0.28f, materialInstance = stone, position = Position(y = 0.14f), apply = { name = "${id}_base" })
        CylinderNode(radius = 1.72f, height = 0.095f, materialInstance = water, position = Position(y = 0.34f), apply = { name = "${id}_water" })
        TorusNode(majorRadius = 1.72f, minorRadius = 0.052f, materialInstance = accent, position = Position(y = 0.405f), apply = { name = "${id}_rim" })
        TorusNode(majorRadius = 0.62f + ripple * 0.70f, minorRadius = 0.018f, materialInstance = waterHighlight, position = Position(y = 0.405f), apply = { name = "${id}_ripple"; isTouchable = false })
        CylinderNode(radius = 0.25f, height = 1.34f, materialInstance = stone, position = Position(y = 1.00f), apply = { name = "${id}_column" })
        CylinderNode(radius = 0.74f, height = 0.15f, materialInstance = stone, position = Position(y = 1.39f), apply = { name = "${id}_bowl" })
        CylinderNode(radius = 0.52f, height = 0.07f, materialInstance = water, position = Position(y = 1.50f), apply = { name = "${id}_upper_water" })
        TorusNode(majorRadius = 0.22f + ripple * 0.18f, minorRadius = 0.012f, materialInstance = waterHighlight, position = Position(y = 1.555f), apply = { name = "${id}_upper_ripple"; isTouchable = false })
        SphereNode(radius = 0.10f, materialInstance = waterHighlight, position = Position(y = 1.86f + sprayLift), apply = { name = "${id}_spray_top" })
        listOf(-0.34f, 0f, 0.34f).forEachIndexed { index, dx ->
            SphereNode(
                radius = 0.050f,
                materialInstance = waterHighlight,
                position = Position(x = dx, y = 1.68f - index * 0.05f + sprayLift * 0.55f, z = 0.10f),
                apply = { name = "${id}_droplet_$index" }
            )
        }
    }
}

@Composable
private fun SceneScope.renderMansion(
    id: String,
    x: Float,
    z: Float,
    wall: com.google.android.filament.MaterialInstance,
    wallAccent: com.google.android.filament.MaterialInstance,
    roof: com.google.android.filament.MaterialInstance,
    glass: com.google.android.filament.MaterialInstance,
    woodDark: com.google.android.filament.MaterialInstance,
    stone: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z)) {
        CubeNode(size = Size(8.9f, 2.8f, 3.7f), materialInstance = wall, position = Position(y = 1.4f), apply = { name = "${id}_body" })
        CubeNode(size = Size(9.5f, 0.20f, 4.1f), materialInstance = roof, position = Position(y = 2.92f), apply = { name = "${id}_roof" })

        // Low roof pavilion replaces the raw rooftop cube from earlier versions.
        CubeNode(size = Size(4.25f, 0.52f, 1.62f), materialInstance = wallAccent, position = Position(x = 0f, y = 3.25f, z = -0.16f), apply = { name = "${id}_roof_pavilion" })
        listOf(-0.92f, 0f, 0.92f).forEachIndexed { index, wx ->
            CubeNode(size = Size(0.58f, 0.28f, 0.05f), materialInstance = glass, position = Position(x = wx, y = 3.25f, z = 0.67f), apply = { name = "${id}_clerestory_$index" })
        }
        CubeNode(size = Size(4.60f, 0.11f, 1.84f), materialInstance = roof, position = Position(x = 0f, y = 3.57f, z = -0.16f), apply = { name = "${id}_pavilion_roof" })
        CubeNode(size = Size(9.15f, 0.18f, 3.88f), materialInstance = wallAccent, position = Position(y = 0.10f, z = -0.02f), apply = { name = "${id}_plinth" })

        CubeNode(size = Size(1.18f, 2.02f, 0.10f), materialInstance = woodDark, position = Position(y = 1.03f, z = 1.90f), apply = { name = "${id}_door" })
        CubeNode(size = Size(1.52f, 2.28f, 0.12f), materialInstance = wallAccent, position = Position(y = 1.15f, z = 1.86f), apply = { name = "${id}_door_frame" })
        CubeNode(size = Size(1.18f, 2.02f, 0.13f), materialInstance = woodDark, position = Position(y = 1.03f, z = 1.94f), apply = { name = "${id}_door_face" })

        listOf(-3.1f, -1.55f, 1.55f, 3.1f).forEachIndexed { index, wx ->
            CubeNode(size = Size(1.22f, 1.48f, 0.12f), materialInstance = wallAccent, position = Position(x = wx, y = 1.45f, z = 1.86f), apply = { name = "${id}_window_frame_$index" })
            CubeNode(size = Size(1.02f, 1.26f, 0.08f), materialInstance = glass, position = Position(x = wx, y = 1.45f, z = 1.93f), apply = { name = "${id}_window_$index" })
        }

        CubeNode(size = Size(3.45f, 0.13f, 1.72f), materialInstance = stone, position = Position(y = 0.09f, z = 2.48f), apply = { name = "${id}_terrace" })
        listOf(-1.32f, 1.32f).forEachIndexed { index, px ->
            CylinderNode(radius = 0.14f, height = 2.12f, materialInstance = wallAccent, position = Position(x = px, y = 1.06f, z = 2.60f), apply = { name = "${id}_column_$index" })
        }
        CubeNode(size = Size(3.55f, 0.15f, 1.70f), materialInstance = roof, position = Position(y = 2.18f, z = 2.60f), apply = { name = "${id}_canopy" })

        listOf(2.74f, 3.12f, 3.50f).forEachIndexed { index, pz ->
            CubeNode(size = Size(2.7f - index * 0.28f, 0.10f, 0.34f), materialInstance = stone, position = Position(y = 0.06f + index * 0.05f, z = pz), apply = { name = "${id}_step_$index" })
        }

        // V4.2 side and rear facade details keep the mansion authored from every playable angle.
        listOf(-0.95f, 0.95f).forEachIndexed { index, localZ ->
            listOf(-4.46f, 4.46f).forEachIndexed { sideIndex, localX ->
                CubeNode(
                    size = Size(0.10f, 1.32f, 0.98f),
                    materialInstance = wallAccent,
                    position = Position(x = localX, y = 1.44f, z = localZ),
                    apply = { name = "${id}_side_frame_${sideIndex}_$index"; isTouchable = false }
                )
                CubeNode(
                    size = Size(0.07f, 1.12f, 0.78f),
                    materialInstance = glass,
                    position = Position(x = if (localX < 0f) localX - 0.055f else localX + 0.055f, y = 1.44f, z = localZ),
                    apply = { name = "${id}_side_window_${sideIndex}_$index"; isTouchable = false }
                )
            }
        }
        listOf(-2.75f, -0.92f, 0.92f, 2.75f).forEachIndexed { index, localX ->
            CubeNode(
                size = Size(1.05f, 1.30f, 0.10f),
                materialInstance = wallAccent,
                position = Position(x = localX, y = 1.42f, z = -1.86f),
                apply = { name = "${id}_rear_frame_$index"; isTouchable = false }
            )
            CubeNode(
                size = Size(0.87f, 1.10f, 0.07f),
                materialInstance = glass,
                position = Position(x = localX, y = 1.42f, z = -1.92f),
                apply = { name = "${id}_rear_window_$index"; isTouchable = false }
            )
        }
    }
}

@Composable
private fun SceneScope.renderTree(
    instance: AssetInstance,
    rendererKey: String,
    trunk: com.google.android.filament.MaterialInstance,
    leaf: com.google.android.filament.MaterialInstance,
    leafMid: com.google.android.filament.MaterialInstance,
    leafLight: com.google.android.filament.MaterialInstance,
) {
    val p = instance.position
    val crown = when ((rendererKey.hashCode() and Int.MAX_VALUE) % 3) {
        0 -> leaf
        1 -> leafMid
        else -> leafLight
    }
    Node(position = Position(p.x, 0f, p.z), rotation = Rotation(y = instance.rotationDegrees.y), scale = Scale(instance.scale)) {
        CylinderNode(radius = 0.20f, height = 2.20f, materialInstance = trunk, position = Position(y = 1.10f), apply = { name = "${instance.instanceId}_trunk" })
        when {
            rendererKey.contains("pine") || rendererKey.contains("cypress") -> {
                ConeNode(radius = 1.02f, height = 2.05f, materialInstance = crown, position = Position(y = 2.25f), apply = { name = "${instance.instanceId}_crown_a" })
                ConeNode(radius = 0.74f, height = 1.65f, materialInstance = crown, position = Position(y = 3.10f), apply = { name = "${instance.instanceId}_crown_b" })
            }
            rendererKey.contains("flat") -> {
                SphereNode(radius = 0.82f, materialInstance = crown, position = Position(y = 2.18f), scale = Scale(1.35f, 0.72f, 1.20f), apply = { name = "${instance.instanceId}_crown_a" })
                SphereNode(radius = 0.52f, materialInstance = crown, position = Position(x = 0.35f, y = 2.55f), scale = Scale(1.15f, 0.78f, 1.0f), apply = { name = "${instance.instanceId}_crown_b" })
            }
            else -> {
                SphereNode(radius = 0.76f, materialInstance = crown, position = Position(x = -0.28f, y = 2.10f), scale = Scale(1.15f, 1.0f, 1.0f), apply = { name = "${instance.instanceId}_crown_a" })
                SphereNode(radius = 0.74f, materialInstance = crown, position = Position(x = 0.34f, y = 2.22f), scale = Scale(1.08f, 1.02f, 1.0f), apply = { name = "${instance.instanceId}_crown_b" })
                SphereNode(radius = 0.58f, materialInstance = crown, position = Position(y = 2.88f), apply = { name = "${instance.instanceId}_crown_c" })
            }
        }
    }
}

@Composable
private fun SceneScope.renderBench(
    instance: AssetInstance,
    wood: com.google.android.filament.MaterialInstance,
    metal: com.google.android.filament.MaterialInstance,
) {
    val p = instance.position
    Node(position = Position(p.x, 0f, p.z), rotation = Rotation(y = instance.rotationDegrees.y)) {
        listOf(-0.56f, 0f, 0.56f).forEachIndexed { index, plankZ ->
            CubeNode(size = Size(1.78f, 0.08f, 0.15f), materialInstance = wood, position = Position(y = 0.52f, z = plankZ * 0.42f), apply = { name = "${instance.instanceId}_seat_$index" })
        }
        listOf(0.54f, 0.90f, 1.26f).forEachIndexed { index, py ->
            CubeNode(size = Size(1.78f, 0.09f, 0.11f), materialInstance = wood, position = Position(y = py, z = -0.30f), apply = { name = "${instance.instanceId}_back_$index" })
        }
        listOf(-0.67f, 0.67f).forEachIndexed { index, lx ->
            CubeNode(size = Size(0.10f, 0.55f, 0.10f), materialInstance = metal, position = Position(x = lx, y = 0.27f), apply = { name = "${instance.instanceId}_leg_$index" })
            CubeNode(size = Size(0.10f, 0.52f, 0.10f), materialInstance = metal, position = Position(x = lx, y = 0.92f, z = -0.28f), apply = { name = "${instance.instanceId}_back_leg_$index" })
        }
    }
}

@Composable
private fun SceneScope.renderPlant(
    instance: AssetInstance,
    style: Int,
    leaf: com.google.android.filament.MaterialInstance,
    leafMid: com.google.android.filament.MaterialInstance,
    leafLight: com.google.android.filament.MaterialInstance,
) {
    val p = instance.position
    val material = when (style % 3) { 0 -> leaf; 1 -> leafMid; else -> leafLight }
    Node(position = Position(p.x, 0f, p.z), rotation = Rotation(y = instance.rotationDegrees.y), scale = Scale(instance.scale)) {
        SphereNode(radius = 0.38f, materialInstance = material, position = Position(x = -0.28f, y = 0.32f), scale = Scale(1.1f, 0.72f, 1.0f), apply = { name = "${instance.instanceId}_a" })
        SphereNode(radius = 0.42f, materialInstance = material, position = Position(x = 0.18f, y = 0.36f), scale = Scale(1.15f, 0.78f, 1.0f), apply = { name = "${instance.instanceId}_b" })
        SphereNode(radius = 0.28f, materialInstance = material, position = Position(x = 0.50f, y = 0.26f, z = 0.06f), scale = Scale(1.0f, 0.72f, 1.0f), apply = { name = "${instance.instanceId}_c" })
    }
}

@Composable
private fun SceneScope.renderLamp(
    instance: AssetInstance,
    style: Int,
    metal: com.google.android.filament.MaterialInstance,
    lampGlow: com.google.android.filament.MaterialInstance,
) {
    val p = instance.position
    Node(position = Position(p.x, 0f, p.z)) {
        CylinderNode(radius = 0.10f, height = 0.10f, materialInstance = metal, position = Position(y = 0.05f), apply = { name = "${instance.instanceId}_base" })
        CylinderNode(radius = 0.052f, height = 1.66f, materialInstance = metal, position = Position(y = 0.88f), apply = { name = "${instance.instanceId}_post" })
        CubeNode(size = Size(0.36f, 0.09f, 0.12f), materialInstance = metal, position = Position(x = if (style % 2 == 0) 0.11f else -0.11f, y = 1.70f), apply = { name = "${instance.instanceId}_arm" })
        CylinderNode(radius = 0.11f, height = 0.13f, materialInstance = metal, position = Position(y = 1.80f), apply = { name = "${instance.instanceId}_housing" })
        SphereNode(radius = 0.095f, materialInstance = lampGlow, position = Position(y = 1.90f), apply = { name = "${instance.instanceId}_glow" })
    }
}

private fun selectionMarker(id: String?): SelectionMarker? {
    val instance = StarterEstateLayout.instance(id) ?: return null
    val definition = AssetCatalog.require(instance.assetId)
    val radius = when (definition.category) {
        AssetCategory.BUILDING -> 4.9f
        AssetCategory.FOUNTAIN -> 2.25f
        AssetCategory.GATE -> 1.9f
        AssetCategory.TREE -> 1.15f * instance.scale
        AssetCategory.BENCH -> 1.05f
        AssetCategory.LAMP -> 0.48f
        AssetCategory.PLANT -> 0.72f
        else -> 0.85f
    }
    return SelectionMarker(instance.position.x, instance.position.z, radius)
}

private data class SelectionMarker(val x: Float, val z: Float, val radius: Float)
