package com.superapp.progressgame.assets

object AssetCatalog {
    private fun tree(id: String, name: String, renderer: String) = AssetDefinition(
        id = id,
        category = AssetCategory.TREE,
        displayName = name,
        supportedStates = setOf(AssetState.SMALL, AssetState.NORMAL, AssetState.GROWN, AssetState.LEGENDARY),
        collision = CollisionDefinition(CollisionKind.CAPSULE, Vec3(1.6f, 4.2f, 1.6f), Vec3(0f, 2.1f, 0f)),
        proceduralRendererKey = renderer,
    )

    private fun bench(id: String, renderer: String) = AssetDefinition(
        id = id,
        category = AssetCategory.BENCH,
        displayName = id.replace('_', ' '),
        collision = CollisionDefinition(CollisionKind.BOX, Vec3(1.9f, 1.1f, 0.8f), Vec3(0f, 0.55f, 0f)),
        proceduralRendererKey = renderer,
    )

    private fun plant(id: String, renderer: String) = AssetDefinition(
        id = id,
        category = AssetCategory.PLANT,
        displayName = id.replace('_', ' '),
        collision = CollisionDefinition(CollisionKind.SPHERE, Vec3(1.2f, 0.8f, 1.2f), Vec3(0f, 0.4f, 0f)),
        proceduralRendererKey = renderer,
    )

    private fun lamp(id: String, renderer: String) = AssetDefinition(
        id = id,
        category = AssetCategory.LAMP,
        displayName = id.replace('_', ' '),
        supportedStates = setOf(AssetState.OFF, AssetState.ON, AssetState.NORMAL, AssetState.PREMIUM),
        collision = CollisionDefinition(CollisionKind.CAPSULE, Vec3(0.45f, 2.5f, 0.45f), Vec3(0f, 1.25f, 0f)),
        proceduralRendererKey = renderer,
    )

    val definitions: List<AssetDefinition> = buildList {
        addAll(listOf(
            tree("tree_oak_01", "Oak 01", "tree_broadleaf_a"),
            tree("tree_oak_02", "Oak 02", "tree_broadleaf_b"),
            tree("tree_maple_01", "Maple 01", "tree_broadleaf_c"),
            tree("tree_cypress_01", "Cypress 01", "tree_cypress"),
            tree("tree_pine_01", "Pine 01", "tree_pine_a"),
            tree("tree_pine_02", "Pine 02", "tree_pine_b"),
            tree("tree_decorative_01", "Decorative 01", "tree_decorative_a"),
            tree("tree_decorative_02", "Decorative 02", "tree_decorative_b"),
            tree("tree_birch_01", "Birch 01", "tree_broadleaf_small"),
            tree("tree_olive_01", "Olive 01", "tree_broadleaf_flat"),
            tree("tree_garden_01", "Garden 01", "tree_garden_a"),
            tree("tree_garden_02", "Garden 02", "tree_garden_b"),
        ))

        repeat(8) { index -> add(bench("bench_${(index + 1).toString().padStart(2, '0')}", "bench_${index % 3}")) }
        repeat(10) { index -> add(plant("plant_${(index + 1).toString().padStart(2, '0')}", "plant_${index % 4}")) }
        repeat(8) { index -> add(lamp("lamp_${(index + 1).toString().padStart(2, '0')}", "lamp_${index % 3}")) }

        repeat(6) { index ->
            add(AssetDefinition(
                id = "fountain_${(index + 1).toString().padStart(2, '0')}",
                category = AssetCategory.FOUNTAIN,
                displayName = "Fountain ${index + 1}",
                supportedStates = setOf(AssetState.OFF, AssetState.NORMAL, AssetState.UPGRADED, AssetState.PREMIUM),
                collision = CollisionDefinition(CollisionKind.BOX, Vec3(4.8f, 2.4f, 4.8f), Vec3(0f, 1.2f, 0f)),
                proceduralRendererKey = "fountain_${index % 2}",
            ))
        }

        repeat(6) { index -> add(simple("fence_${(index + 1).toString().padStart(2, '0')}", AssetCategory.FENCE, "fence_${index % 2}")) }
        repeat(5) { index -> add(simple("gate_${(index + 1).toString().padStart(2, '0')}", AssetCategory.GATE, "gate_${index % 2}")) }
        repeat(6) { index -> add(simple("pool_${(index + 1).toString().padStart(2, '0')}", AssetCategory.POOL, "pool_${index % 2}")) }
        repeat(8) { index -> add(simple("path_${(index + 1).toString().padStart(2, '0')}", AssetCategory.PATH, "path_${index % 3}", selectable = false)) }
        repeat(10) { index -> add(simple("building_${(index + 1).toString().padStart(2, '0')}", AssetCategory.BUILDING, "building_${index % 3}")) }

        add(simple("gazebo_01", AssetCategory.GAZEBO, "gazebo_0"))
        add(simple("bridge_01", AssetCategory.BRIDGE, "bridge_0"))
        add(simple("waterfall_01", AssetCategory.WATERFALL, "waterfall_0"))
        add(simple("table_01", AssetCategory.TABLE, "table_0"))
        add(simple("chair_01", AssetCategory.CHAIR, "chair_0"))
        add(simple("decoration_rock_01", AssetCategory.DECORATION, "rock_0", selectable = false))
    }

    private fun simple(
        id: String,
        category: AssetCategory,
        renderer: String,
        selectable: Boolean = true,
    ) = AssetDefinition(
        id = id,
        category = category,
        displayName = id.replace('_', ' '),
        selectable = selectable,
        proceduralRendererKey = renderer,
    )

    private val byId = definitions.associateBy { it.id }

    fun get(id: String): AssetDefinition? = byId[id]
    fun require(id: String): AssetDefinition = byId.getValue(id)
    fun byCategory(category: AssetCategory): List<AssetDefinition> = definitions.filter { it.category == category }

    fun validate(): List<String> {
        val errors = mutableListOf<String>()
        definitions.groupBy { it.id }.filterValues { it.size > 1 }.keys.forEach { errors += "duplicate asset id: $it" }
        definitions.filter { it.proceduralRendererKey.isBlank() }.forEach { errors += "missing renderer key: ${it.id}" }
        definitions.filter { it.defaultScale <= 0f }.forEach { errors += "invalid scale: ${it.id}" }
        return errors
    }
}

