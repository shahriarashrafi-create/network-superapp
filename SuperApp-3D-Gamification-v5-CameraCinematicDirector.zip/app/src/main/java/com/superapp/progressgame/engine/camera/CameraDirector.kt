package com.superapp.progressgame.engine.camera

/**
 * V5 camera authoring layer. SceneView's manipulator performs the actual smooth glide
 * between these authored poses; this class owns sequencing and cinematic semantics.
 */
object CameraDirector {
    val entranceSequence = listOf(
        CameraPresets.EntranceFront,
        CameraPresets.EntranceApproach,
        CameraPresets.EntrancePass,
        CameraPresets.FountainReveal,
        CameraPresets.MansionReveal,
        CameraPresets.Hero,
    )

    val travelSequence = listOf(
        CameraPresets.Hero,
        CameraPresets.Overview,
        CameraPresets.WideShot,
        CameraPresets.FountainReveal,
        CameraPresets.MansionReveal,
        CameraPresets.Hero,
    )

    val revealSequence = listOf(
        CameraPresets.Overview,
        CameraPresets.FountainReveal,
        CameraPresets.MansionReveal,
        CameraPresets.Hero,
    )

    val celebrationSequence = listOf(
        CameraPresets.FountainReveal,
        CameraPresets.Celebration,
        CameraPresets.WideShot,
        CameraPresets.Hero,
    )
}
