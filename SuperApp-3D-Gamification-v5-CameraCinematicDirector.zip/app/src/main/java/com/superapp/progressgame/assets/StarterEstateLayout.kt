package com.superapp.progressgame.assets

object StarterEstateLayout {
    val trees = listOf(
        AssetInstance("tree_w_01", "tree_oak_01", Vec3(-9.6f, 0f, 7.4f), Vec3(0f, 14f, 0f), scale = 0.84f),
        AssetInstance("tree_w_02", "tree_garden_01", Vec3(-11.3f, 0f, 1.6f), Vec3(0f, -18f, 0f), scale = 0.94f),
        AssetInstance("tree_w_03", "tree_pine_01", Vec3(-9.6f, 0f, -4.9f), Vec3(0f, 8f, 0f), scale = 0.86f),
        AssetInstance("tree_w_04", "tree_maple_01", Vec3(-11.7f, 0f, -10.7f), Vec3(0f, -12f, 0f), scale = 0.96f),
        AssetInstance("tree_e_01", "tree_oak_02", Vec3(9.2f, 0f, 7.2f), Vec3(0f, -11f, 0f), scale = 0.86f),
        AssetInstance("tree_e_02", "tree_garden_02", Vec3(11.1f, 0f, 1.5f), Vec3(0f, 20f, 0f), scale = 0.93f),
        AssetInstance("tree_e_03", "tree_pine_02", Vec3(9.7f, 0f, -4.8f), Vec3(0f, -7f, 0f), scale = 0.86f),
        AssetInstance("tree_e_04", "tree_decorative_01", Vec3(11.8f, 0f, -10.6f), Vec3(0f, 17f, 0f), scale = 0.96f),
    )

    // Four purposeful benches: two for the plaza, two for the quieter garden edge.
    val benches = listOf(
        AssetInstance("bench_w_01", "bench_01", Vec3(-5.25f, 0f, 1.55f), Vec3(0f, 22f, 0f)),
        AssetInstance("bench_e_01", "bench_02", Vec3(5.25f, 0f, 1.55f), Vec3(0f, -22f, 0f)),
        AssetInstance("bench_w_02", "bench_03", Vec3(-5.45f, 0f, -5.15f), Vec3(0f, 14f, 0f)),
        AssetInstance("bench_e_02", "bench_01", Vec3(5.45f, 0f, -5.15f), Vec3(0f, -14f, 0f)),
    )

    val plants = listOf(
        AssetInstance("plant_01", "plant_01", Vec3(-3.8f, 0f, -1.35f), Vec3(0f, 8f, 0f), scale = 0.88f),
        AssetInstance("plant_02", "plant_02", Vec3(3.8f, 0f, -1.35f), Vec3(0f, -10f, 0f), scale = 0.90f),
        AssetInstance("plant_03", "plant_03", Vec3(-4.9f, 0f, -7.1f), Vec3(0f, 15f, 0f), scale = 0.92f),
        AssetInstance("plant_04", "plant_04", Vec3(4.9f, 0f, -7.1f), Vec3(0f, -14f, 0f), scale = 0.94f),
        AssetInstance("plant_05", "plant_05", Vec3(-6.5f, 0f, 5.4f), Vec3(0f, 24f, 0f), scale = 0.78f),
        AssetInstance("plant_06", "plant_06", Vec3(6.5f, 0f, 5.4f), Vec3(0f, -20f, 0f), scale = 0.80f),
    )

    // V4.2: four lamps define the main axis. Decorative clutter near the hero objects is reduced.
    val lamps = listOf(
        AssetInstance("lamp_01", "lamp_01", Vec3(-3.05f, 0f, 5.10f)),
        AssetInstance("lamp_02", "lamp_02", Vec3(3.05f, 0f, 5.10f)),
        AssetInstance("lamp_03", "lamp_03", Vec3(-3.00f, 0f, -4.35f)),
        AssetInstance("lamp_04", "lamp_01", Vec3(3.00f, 0f, -4.35f)),
    )

    val allInteractive = trees + benches + plants + lamps + listOf(
        AssetInstance("fountain_main", "fountain_01", Vec3(0f, 0f, -1.2f), cameraAnchor = Vec3(0f, 1.1f, -1.2f)),
        AssetInstance("entrance_gate", "gate_01", Vec3(0f, 0f, 11.0f), cameraAnchor = Vec3(0f, 1.2f, 10.5f)),
        AssetInstance("mansion_main", "building_01", Vec3(0f, 0f, -9.3f), cameraAnchor = Vec3(0f, 2.0f, -8.6f)),
    )

    private val byInstanceId = allInteractive.associateBy { it.instanceId }

    fun instance(id: String?): AssetInstance? = id?.let(byInstanceId::get)
}
