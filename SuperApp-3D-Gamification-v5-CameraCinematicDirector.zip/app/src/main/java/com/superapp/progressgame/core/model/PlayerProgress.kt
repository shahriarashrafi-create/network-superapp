package com.superapp.progressgame.core.model

data class PlayerProgress(
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 0,
    val activeRegionId: String = "starter_estate",
    val regionProgressPercent: Int = 0,
)
