package com.superapp.progressgame.core.di

import android.content.Context
import com.superapp.progressgame.core.storage.FoundationPreferences
import com.superapp.progressgame.core.storage.LocalProgressRepository
import com.superapp.progressgame.core.storage.ProgressRepository

class AppContainer(context: Context) {
    val preferences = FoundationPreferences(context)
    val progressRepository: ProgressRepository = LocalProgressRepository(context)
}
