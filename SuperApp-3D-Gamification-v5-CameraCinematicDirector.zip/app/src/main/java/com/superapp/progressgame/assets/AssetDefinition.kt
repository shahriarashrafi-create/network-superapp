package com.superapp.progressgame.assets

enum class AssetCategory {
    TREE,
    PLANT,
    BENCH,
    LAMP,
    FENCE,
    GATE,
    FOUNTAIN,
    POOL,
    PATH,
    BUILDING,
    GAZEBO,
    BRIDGE,
    WATERFALL,
    TABLE,
    CHAIR,
    DECORATION,
}

enum class AssetState {
    OFF,
    NORMAL,
    UPGRADED,
    PREMIUM,
    SMALL,
    GROWN,
    LEGENDARY,
    FOUNDATION,
    CONSTRUCTION,
    ON,
}

enum class CollisionKind {
    NONE,
    BOX,
    SPHERE,
    CAPSULE,
}

data class Vec3(
    val x: Float,
    val y: Float,
    val z: Float,
)

data class CollisionDefinition(
    val kind: CollisionKind,
    val size: Vec3,
    val offset: Vec3 = Vec3(0f, 0f, 0f),
)

data class LodDefinition(
    val level: Int,
    val maxDistanceMeters: Float,
    val qualityScale: Float,
)

data class AssetDefinition(
    val id: String,
    val category: AssetCategory,
    val displayName: String,
    val defaultScale: Float = 1f,
    val pivotToGroundMeters: Float = 0f,
    val selectable: Boolean = true,
    val focusable: Boolean = true,
    val supportedStates: Set<AssetState> = setOf(AssetState.NORMAL),
    val collision: CollisionDefinition = CollisionDefinition(
        kind = CollisionKind.NONE,
        size = Vec3(0f, 0f, 0f),
    ),
    val lods: List<LodDefinition> = listOf(
        LodDefinition(level = 0, maxDistanceMeters = 14f, qualityScale = 1f),
        LodDefinition(level = 1, maxDistanceMeters = 28f, qualityScale = 0.65f),
        LodDefinition(level = 2, maxDistanceMeters = 60f, qualityScale = 0.35f),
    ),
    val proceduralRendererKey: String,
)

data class AssetInstance(
    val instanceId: String,
    val assetId: String,
    val position: Vec3,
    val rotationDegrees: Vec3 = Vec3(0f, 0f, 0f),
    val scale: Float = 1f,
    val state: AssetState = AssetState.NORMAL,
    val cameraAnchor: Vec3? = null,
)
