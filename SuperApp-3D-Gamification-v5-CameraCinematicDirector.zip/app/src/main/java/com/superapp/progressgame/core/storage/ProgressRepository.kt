package com.superapp.progressgame.core.storage

import com.superapp.progressgame.core.model.PlayerProgress

interface ProgressRepository {
    fun load(): PlayerProgress
    fun save(progress: PlayerProgress)
    fun reset(): PlayerProgress
}
