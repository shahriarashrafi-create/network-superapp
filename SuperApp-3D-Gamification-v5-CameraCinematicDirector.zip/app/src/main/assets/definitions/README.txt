Version 2 asset pipeline placeholder. Real reusable assets enter in V4; V2 uses procedural SceneView geometry.
