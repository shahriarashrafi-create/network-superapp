# Version 2 real-3D core: no project-specific shrinking rules are required yet.
# SceneView / Filament consumer rules are supplied by their dependencies.
