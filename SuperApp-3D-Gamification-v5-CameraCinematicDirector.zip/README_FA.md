# Progress World — V4

این ZIP نسخهٔ V4 پروژهٔ گیمیفیکیشن سه‌بعدی است و شامل دو بسته تغییر اصلی می‌شود:

1. **V3.2 Interaction + Visual Foundation Fix**
   - اصلاح Selection و قابل لمس شدن اجزای اصلی Mansion/Fountain/Gate/Tree/Bench/Plant/Lamp
   - شناسهٔ پایدار برای هر آبجکت قابل تعامل
   - Selection Ring به‌جای تعویض متریال آبجکت
   - محدودیت واقعی‌تر Camera برای Pitch/Distance و ناحیهٔ بازی
   - Camera Safety برای جلوگیری از ورود دوربین به Footprint آبجکت‌های بزرگ
   - Terrain یکپارچه‌تر، حذف حلقهٔ قهوه‌ای و حذف moundهای بزرگ
   - Path پیوسته با جزئیات سنگی روی آن
   - نور و پالت کم‌نورتر و طبیعی‌تر
   - بازطراحی اولیه Mansion، Gate، Fountain، Tree، Plant، Bench و Lamp

2. **V4 Asset System**
   - AssetDefinition و AssetInstance
   - AssetCatalog مرکزی
   - Asset State metadata
   - Collision metadata
   - LOD metadata
   - StarterEstateLayout دیتا-محور
   - Asset manifest JSON
   - Style Guide واحد: Stylized Premium 3D
   - 85 تعریف Asset پایه برای توسعه Regionهای بعدی

Package ثابت است:
`com.superapp.progressgame`

Version Code:
`9`

Version Name:
`4.0.0-asset-system`

APKهای بعدی باید همین Package و Keystore را حفظ کنند تا روی نسخه قبلی Update شوند.

## Version 5 — Camera & Cinematic Director

نسخه ۵ کنترل دوربین را از حالت ساده به یک Director مستقل ارتقا می‌دهد: Orbit آزاد ۳۶۰ درجه، نمای نزدیک به Top-Down، Focus Orbit روی آبجکت انتخاب‌شده، نمای کلی، Top View، Dynamic FOV، سکانس ورودی، Travel/Reveal/Celebration، Skip Cinematic، Camera Safety/Obstruction و ذخیره وضعیت دوربین.

کنترل‌های اصلی داخل World:
- یک انگشت: Orbit
- دو انگشت: Pan
- Pinch: Dolly/Zoom
- Double Tap روی آبجکت: Focus Orbit
- Map: Top View روی آبجکت انتخاب‌شده یا کل World
- Target: Focus آبجکت انتخاب‌شده
- Movie: Replay Entrance Cinematic
- Refresh: Cinematic Travel
