# Architecture — V4

## Runtime layers

`MainActivity -> GameFoundationApp -> WorldShellScreen -> SceneView/Filament -> StarterWorldScene`

## Engine
- `engine/camera/CameraPreset.kt`
- `engine/camera/CameraSafety.kt`
- `engine/scene/StarterWorldScene.kt`
- `engine/scene/RendererStats.kt`

## Asset System
- `assets/AssetDefinition.kt`
- `assets/AssetCatalog.kt`
- `assets/StarterEstateLayout.kt`
- `assets/definitions/asset_manifest_v1.json`

Asset Definition و Asset Instance از هم جدا هستند؛ در نتیجه یک تعریف Tree/Bench/Lamp می‌تواند بارها با Position/Rotation/Scale/State متفاوت استفاده شود.

## Interaction
Meshهای متعلق به یک Object با prefix شناسهٔ همان Object نام‌گذاری می‌شوند. `WorldObjectCatalog.normalize()` هر Mesh hit شده را به ID منطقی آبجکت تبدیل می‌کند.

## Camera
Game camera دارای preset-specific radius و pitch limits است. `CameraSafety` علاوه بر محدودیت فاصله، Camera را از footprint ساختمان، فواره، دروازه و درخت‌های اصلی بیرون نگه می‌دارد.

## Persistence
Package، signing config و progress save schema دست نخورده مانده‌اند. World schema در V4 به 3 و Asset schema به 1 رسیده است.
