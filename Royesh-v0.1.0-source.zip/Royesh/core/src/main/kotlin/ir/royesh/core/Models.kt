package ir.royesh.core

import java.util.UUID

enum class Stage(val label: String) {
    NEW("جدید"), CONTACTED("ارتباط برقرارشده"), INVITED("دعوت‌شده"), PRESENTED("معرفی‌شده"), FOLLOWUP("در حال پیگیری"), JOINED("عضوشده"), LATER("فعلاً نه")
}
data class Person(val id: String = UUID.randomUUID().toString(), val name: String, val phone: String = "", val stage: Stage = Stage.NEW)
data class Task(val id: String = UUID.randomUUID().toString(), val title: String, val personId: String? = null, val due: String, val priority: Int = 1, val done: Boolean = false)
data class Action(val id: String = UUID.randomUUID().toString(), val taskId: String, val personId: String?, val title: String, val result: String, val occurredAt: String, val xp: Int = 10)
data class Profile(val name: String = "", val dailyGoal: Int = 3)
data class AppState(val profile: Profile = Profile(), val people: List<Person> = emptyList(), val tasks: List<Task> = emptyList(), val actions: List<Action> = emptyList()) {
    val xp: Int get() = actions.sumOf { it.xp }
    val level: Int get() = xp / 100 + 1
    fun todayCount(date: String): Int = actions.count { it.occurredAt.take(10) == date }
    fun nextTask(): Task? = tasks.filterNot { it.done }.sortedWith(compareBy<Task> { it.due }.thenByDescending { it.priority }).firstOrNull()
    fun complete(taskId: String, result: String, occurredAt: String, nextTitle: String = "", nextDue: String = ""): AppState {
        require(result.isNotBlank()) { "نتیجه را بنویس" }
        require(nextTitle.isBlank() || runCatching { java.time.LocalDate.parse(nextDue) }.isSuccess)
        val task = tasks.firstOrNull { it.id == taskId } ?: return this
        if (task.done || actions.any { it.taskId == taskId }) return this
        val next = if (nextTitle.isNotBlank()) listOf(Task(title = nextTitle.trim(), personId = task.personId, due = nextDue)) else emptyList()
        return copy(tasks = tasks.map { if (it.id == taskId) it.copy(done = true) else it } + next,
            actions = actions + Action(taskId = taskId, personId = task.personId, title = task.title, result = result.trim(), occurredAt = occurredAt))
    }
    fun undo(taskId: String): AppState = copy(tasks = tasks.map { if (it.id == taskId) it.copy(done = false) else it }, actions = actions.filterNot { it.taskId == taskId })
}
