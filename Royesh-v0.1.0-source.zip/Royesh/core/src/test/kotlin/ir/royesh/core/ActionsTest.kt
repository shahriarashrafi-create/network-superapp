package ir.royesh.core

import org.junit.Assert.*
import org.junit.Test

class ActionsTest {
    private val start = AppState(tasks = listOf(Task(id = "t1", title = "پیگیری", due = "2026-10-18")))
    @Test fun resultCompletesTaskAndCreatesOneActivity() {
        val state = start.complete("t1", "هماهنگ شد", "2026-10-18T12:00:00", "جلسه", "2026-10-19")
        assertTrue(state.tasks.first().done)
        assertEquals(2, state.tasks.size)
        assertEquals(1, state.actions.size)
        assertEquals(1, state.todayCount("2026-10-18"))
        assertEquals(0, state.todayCount("2026-10-19"))
    }
    @Test fun duplicateHasNoSecondReward() {
        val once = start.complete("t1", "پاسخ نداد", "2026-10-18T12:00:00")
        assertEquals(once, once.complete("t1", "دوباره", "2026-10-18T12:01:00"))
        assertEquals(10, once.xp)
    }
    @Test(expected = IllegalArgumentException::class) fun emptyResultRejected() { start.complete("t1", "  ", "2026-10-18T12:00:00") }
    @Test fun undoReversesLocalReward() {
        val state = start.complete("t1", "ثبت", "2026-10-18T12:00:00").undo("t1")
        assertEquals(0, state.xp)
        assertFalse(state.tasks.first().done)
    }
    @Test fun earliestDeadlineThenPriorityWins() {
        val s = AppState(tasks = listOf(Task(title="بعدی", due="2026-10-19", priority=3), Task(title="مهم", due="2026-10-18",priority=3),Task(title="عادی",due="2026-10-18")))
        assertEquals("مهم", s.nextTask()?.title)
    }
}
