package ir.royesh.app.data

import android.content.Context
import ir.royesh.core.*
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("royesh-v1", Context.MODE_PRIVATE)
    fun load(): AppState = prefs.getString("state", null)?.let(::decode) ?: AppState()
    fun save(state: AppState) { check(prefs.edit().putString("state", encode(state)).commit()) { "ذخیره‌سازی انجام نشد" } }
    fun encode(s: AppState): String = JSONObject().apply {
        put("schema", 1)
        put("profile", JSONObject().put("name", s.profile.name).put("dailyGoal", s.profile.dailyGoal))
        put("people", JSONArray().apply { s.people.forEach { p -> put(JSONObject().put("id", p.id).put("name", p.name).put("phone", p.phone).put("stage", p.stage.name)) } })
        put("tasks", JSONArray().apply { s.tasks.forEach { t -> put(JSONObject().put("id", t.id).put("title", t.title).put("personId", t.personId ?: JSONObject.NULL).put("due", t.due).put("priority", t.priority).put("done", t.done)) } })
        put("actions", JSONArray().apply { s.actions.forEach { a -> put(JSONObject().put("id", a.id).put("taskId", a.taskId).put("personId", a.personId ?: JSONObject.NULL).put("title", a.title).put("result", a.result).put("occurredAt", a.occurredAt).put("xp", a.xp)) } })
    }.toString(2)
    private fun decode(raw: String): AppState {
        val j = JSONObject(raw)
        require(j.getInt("schema") == 1)
        fun rows(key: String): List<JSONObject> = j.getJSONArray(key).let { a -> (0 until a.length()).map(a::getJSONObject) }
        fun JSONObject.person(): String? = if (isNull("personId")) null else getString("personId")
        val p = j.getJSONObject("profile")
        return AppState(Profile(p.getString("name"), p.getInt("dailyGoal")),
            rows("people").map { Person(it.getString("id"), it.getString("name"), it.getString("phone"), Stage.valueOf(it.getString("stage"))) },
            rows("tasks").map { Task(it.getString("id"), it.getString("title"), it.person(), it.getString("due"), it.getInt("priority"), it.getBoolean("done")) },
            rows("actions").map { Action(it.getString("id"), it.getString("taskId"), it.person(), it.getString("title"), it.getString("result"), it.getString("occurredAt"), it.getInt("xp")) })
    }
}
