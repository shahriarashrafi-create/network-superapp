package ir.royesh.app

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.royesh.app.data.LocalStore
import ir.royesh.core.*
import java.time.LocalDate
import java.time.LocalDateTime

private val Lime = Color(0xFFCEEF79)
private val Navy = Color(0xFF101E2C)

class MainActivity : ComponentActivity() {
    private lateinit var store: LocalStore
    private var state by mutableStateOf(AppState())
    private var loadError by mutableStateOf(false)
    private val export = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { contentResolver.openOutputStream(uri)!!.use { it.write(store.encode(state).toByteArray()) } }
            .onSuccess { message("نسخهٔ پشتیبان ذخیره شد") }.onFailure { message("ذخیرهٔ فایل انجام نشد") }
    }
    private fun message(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    private fun update(value: AppState) {
        runCatching { store.save(value) }.onSuccess { state = value }.onFailure { message("ذخیره‌سازی انجام نشد؛ دوباره تلاش کن") }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LocalStore(this)
        runCatching { store.load() }.onSuccess { state = it }.onFailure { loadError = true }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Lime, background = Navy, surface = Color(0xFF1B2D3C), onPrimary = Navy)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    if (loadError) Surface(Modifier.fillMaxSize()) { Column(Modifier.padding(24.dp)) {
                        Text("خواندن اطلاعات ذخیره‌شده ممکن نشد")
                        Text("برای جلوگیری از بازنویسی، ورود متوقف شده است. اطلاعات برنامه را پاک نکن.")
                    } } else Royesh()
                }
            }
        }
    }
    private fun pickDate(date: String, picked: (String) -> Unit) {
        val d = LocalDate.parse(date)
        DatePickerDialog(this, { _, y, m, day -> picked(LocalDate.of(y, m + 1, day).toString()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }
    @Composable private fun Royesh() {
        var tab by remember { mutableIntStateOf(0) }
        var dialog by remember { mutableStateOf("") }
        var selectedTask by remember { mutableStateOf<Task?>(null) }
        var selectedPerson by remember { mutableStateOf<Person?>(null) }
        val today = LocalDate.now().toString()
        val count = state.todayCount(today)
        if (state.profile.name.isBlank()) {
            ProfileDialog("به رویش خوش آمدی", false, { name, goal -> update(state.copy(profile = Profile(name, goal))) }, {})
        }
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Color(0xFF152534)) {
                listOf("خانه", "اقدام‌ها", "مخاطبان", "رشد").forEachIndexed { i, title ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂", "✓", "◎", "✦")[i], fontSize = 24.sp) }, label = { Text(title) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("رویش", color = Lime, style = MaterialTheme.typography.headlineMedium); Text("قدم‌های کوچک، رشد ماندگار", color = Color(0xFFAFC2CE)) }
                    TextButton(onClick = { dialog = "settings" }) { Text("پروفایل") }
                }
                when (tab) {
                    0 -> {
                        Text("سلام ${state.profile.name} 🌱", style = MaterialTheme.typography.headlineSmall)
                        Text("امروز برای رشدت یک قدم بردار.")
                        Panel("اقدام بعدی تو") {
                            val next = state.nextTask()
                            if (next == null) { Text("هنوز اقدامی نداری؛ اولین قدم را خودت انتخاب کن."); Button(onClick = { dialog = "task" }) { Text("+ ساخت اولین اقدام") } }
                            else { Text(next.title, style = MaterialTheme.typography.titleLarge); Text("موعد: ${next.due} · ${personName(next.personId)}"); Button(onClick = { selectedTask = next }) { Text("ثبت نتیجهٔ اقدام") } }
                        }
                        Panel("هدف امروز · $count از ${state.profile.dailyGoal} اقدام") {
                            LinearProgressIndicator(progress = { (count.toFloat() / state.profile.dailyGoal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                            Text(if (count >= state.profile.dailyGoal) "هدف امروز کامل شد؛ آفرین به استمرار تو!" else "هر اقدام همراه با نتیجه، یک قدم واقعی در مسیر توست.")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { selectedPerson = null; dialog = "task" }) { Text("+ اقدام") }
                            OutlinedButton(onClick = { dialog = "person" }) { Text("+ مخاطب") }
                        }
                        Panel("گزارش کوتاه") { Text("${state.people.size} مخاطب  •  ${state.tasks.count { !it.done }} اقدام باز"); Text("${state.tasks.count { !it.done && it.due < today }} اقدام عقب‌افتاده") }
                        if (state.actions.isNotEmpty()) Panel("آخرین نتیجه‌ها") { state.actions.takeLast(3).reversed().forEach { Text("${it.title}\n${it.result}"); HorizontalDivider() } }
                    }
                    1 -> {
                        var filter by remember { mutableIntStateOf(0) }
                        Text("مرکز اقدام", style = MaterialTheme.typography.headlineSmall)
                        Button(onClick = { selectedPerson = null; dialog = "task" }) { Text("+ اقدام جدید") }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("باز", "امروز", "انجام‌شده").forEachIndexed { i, s -> FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(s) }) } }
                        val tasks = state.tasks.filter { when (filter) { 1 -> !it.done && it.due <= today; 2 -> it.done; else -> !it.done } }.sortedWith(compareBy<Task> { it.due }.thenByDescending { it.priority })
                        if (tasks.isEmpty()) Text("اینجا فعلاً اقدامی نیست. یک قدم کوچک تعریف کن.")
                        tasks.forEach { task -> Panel(task.title) {
                            Text("${personName(task.personId)} · ${task.due}" + if (task.priority == 2) " · مهم" else "")
                            if (!task.done) Button(onClick = { selectedTask = task }) { Text("ثبت نتیجه") } else Text(state.actions.firstOrNull { it.taskId == task.id }?.result ?: "انجام‌شده", color = Lime)
                        } }
                    }
                    2 -> {
                        var search by remember { mutableStateOf("") }
                        Text("مخاطبان من", style = MaterialTheme.typography.headlineSmall)
                        OutlinedTextField(search, { search = it }, label = { Text("جست‌وجوی نام یا شماره") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { dialog = "person" }) { Text("+ مخاطب جدید") }
                        if (state.people.isEmpty()) Text("اولین مخاطبت را اضافه کن و پیگیری را به یک اقدام تبدیل کن.")
                        state.people.filter { it.name.contains(search, true) || it.phone.contains(search) }.forEach { p -> Panel(p.name) {
                            Text("${p.stage.label}  ·  ${p.phone}")
                            TextButton(onClick = { selectedPerson = p; dialog = "personDetail" }) { Text("پرونده و پیگیری") }
                        } }
                    }
                    3 -> {
                        Text("مسیر رویش تو", style = MaterialTheme.typography.headlineSmall)
                        Panel("سطح ${state.level} · ${state.xp} XP") {
                            LinearProgressIndicator(progress = { (state.xp % 100) / 100f }, modifier = Modifier.fillMaxWidth())
                            Text("هر ۱۰۰ امتیاز، یک سطح رشد شخصی")
                            Text("امتیاز آزمایشی محلی: هر اقدام با نتیجه ۱۰ XP؛ این امتیاز رتبهٔ رسمی سازمان نیست.", style = MaterialTheme.typography.bodySmall)
                        }
                        val days = state.actions.map { it.occurredAt.take(10) }.toSet()
                        var streak = 0
                        var cursor = LocalDate.now()
                        if (cursor.toString() !in days) cursor = cursor.minusDays(1)
                        while (cursor.toString() in days) { streak++; cursor = cursor.minusDays(1) }
                        Panel("برج ثبات") { Text("$streak روز زنجیرهٔ فعال"); Text("نقطه‌های بعدی: ۳، ۷، ۱۴ و ۳۰ روز") }
                        listOf("اولین ارتباط" to state.people.isNotEmpty(), "اولین قدم ثبت‌شده" to state.actions.isNotEmpty(), "ده اقدام نتیجه‌دار" to (state.actions.size >= 10), "سه روز استمرار" to (streak >= 3)).forEach { (title, earned) -> Panel(if (earned) "✦ $title" else "○ $title") { Text(if (earned) "به مجموعهٔ تو اضافه شد" else "با فعالیت واقعی باز می‌شود") } }
                    }
                }
                Text("رویش ۰.۱ · اطلاعات فقط روی همین دستگاه ذخیره می‌شود", style = MaterialTheme.typography.bodySmall, color = Color(0xFF93AABB))
            }
        }
        if (dialog == "settings") ProfileDialog("پروفایل و هدف روزانه", true, { n, g -> update(state.copy(profile = Profile(n, g))); dialog = "" }, { dialog = "" }, { export.launch("royesh-backup-${LocalDate.now()}.json") })
        if (dialog == "person") {
            var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
            Form("مخاطب جدید", name.isNotBlank(), { update(state.copy(people = state.people + Person(name = name.trim(), phone = phone.trim()))); dialog = "" }, { dialog = "" }) {
                Field(name, { name = it }, "نام مخاطب"); Field(phone, { phone = it }, "شماره تماس (اختیاری)")
            }
        }
        if (dialog == "personDetail" && selectedPerson != null) {
            val person = state.people.first { it.id == selectedPerson!!.id }
            AlertDialog(onDismissRequest = { dialog = "" }, title = { Text(person.name) }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(person.phone); Text("مرحلهٔ ارتباط:")
                Stage.entries.forEach { stage -> FilterChip(selected = person.stage == stage, onClick = { update(state.copy(people = state.people.map { if (it.id == person.id) it.copy(stage = stage) else it })) }, label = { Text(stage.label) }) }
                Text("${state.tasks.count { it.personId == person.id && !it.done }} پیگیری باز")
                state.actions.filter { it.personId == person.id }.takeLast(5).reversed().forEach { Text("${it.title}: ${it.result}") }
            } }, confirmButton = { TextButton(onClick = { dialog = "task" }) { Text("ساخت پیگیری") } }, dismissButton = { TextButton(onClick = { dialog = ""; selectedPerson = null }) { Text("بستن") } })
        }
        if (dialog == "task") {
            var title by remember { mutableStateOf("") }; var due by remember { mutableStateOf(today) }; var important by remember { mutableStateOf(false) }
            var personId by remember { mutableStateOf(selectedPerson?.id) }
            Form("اقدام جدید", title.isNotBlank(), { update(state.copy(tasks = state.tasks + Task(title = title.trim(), personId = personId, due = due, priority = if (important) 2 else 1))); dialog = ""; selectedPerson = null }, { dialog = ""; selectedPerson = null }) {
                Field(title, { title = it }, "چه کاری انجام می‌دهی؟")
                TextButton(onClick = { pickDate(due) { due = it } }) { Text("موعد: $due") }
                Row { Checkbox(important, { important = it }); Text("اولویت بالا") }
                Text("اتصال به مخاطب (اختیاری)")
                FilterChip(personId == null, { personId = null }, label = { Text("اقدام شخصی") })
                state.people.forEach { p -> FilterChip(personId == p.id, { personId = p.id }, label = { Text(p.name) }) }
            }
        }
        selectedTask?.let { task ->
            var result by remember(task.id) { mutableStateOf("") }; var next by remember(task.id) { mutableStateOf("") }; var due by remember(task.id) { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
            Form("نتیجهٔ ${task.title}", result.isNotBlank(), {
                update(state.complete(task.id, result, LocalDateTime.now().toString(), next, due)); selectedTask = null
            }, { selectedTask = null }) {
                Field(result, { result = it }, "چه نتیجه‌ای گرفتی؟")
                Field(next, { next = it }, "پیگیری بعدی (اختیاری)")
                if (next.isNotBlank()) TextButton(onClick = { pickDate(due) { due = it } }) { Text("موعد پیگیری: $due") }
                Text("۱۰ امتیاز محلی پس از ثبت نتیجه؛ هر اقدام فقط یک بار.")
            }
        }
    }
    private fun personName(id: String?): String = state.people.firstOrNull { it.id == id }?.name ?: "اقدام شخصی"
    @Composable private fun ProfileDialog(title: String, dismissible: Boolean, save: (String, Int) -> Unit, dismiss: () -> Unit, backup: (() -> Unit)? = null) {
        var name by remember { mutableStateOf(state.profile.name) }; var goal by remember { mutableIntStateOf(state.profile.dailyGoal) }
        Form(title, name.isNotBlank(), { save(name.trim(), goal) }, dismiss, dismissible) {
            Field(name, { name = it }, "نام تو")
            Text("هدف روزانه: $goal اقدام")
            Slider(value = goal.toFloat(), onValueChange = { goal = it.toInt() }, valueRange = 1f..10f, steps = 8)
            Text("شروع کوچک بهتر از برنامهٔ سنگین است.")
            backup?.let { TextButton(onClick = it) { Text("خروجی پشتیبان JSON") }; Text("پشتیبان را بیرون از گوشی نگه دار؛ بازیابی در این نسخه پیاده نشده است.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable private fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2D3C))) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(title, color = Lime, style = MaterialTheme.typography.titleMedium); content() }
    }
}
@Composable private fun Field(value: String, changed: (String) -> Unit, label: String) {
    OutlinedTextField(value, changed, label = { Text(label) }, modifier = Modifier.fillMaxWidth())
}
@Composable private fun Form(title: String, valid: Boolean, save: () -> Unit, dismiss: () -> Unit, dismissible: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(onDismissRequest = { if (dismissible) dismiss() }, title = { Text(title) }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) }, confirmButton = { TextButton(onClick = save, enabled = valid) { Text("ذخیره") } }, dismissButton = { if (dismissible) TextButton(onClick = dismiss) { Text("انصراف") } })
}
