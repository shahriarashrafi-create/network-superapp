package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

private data class PathStep(val title: String, val subtitle: String, val state: Int)

private val pathSteps = listOf(
    PathStep("روتین‌های پایه", "ساخت عادت‌های روزانه موفقیت", 1),
    PathStep("معرفی محصول", "آشنایی کامل با محصول", 1),
    PathStep("ارتباط‌سازی", "ایجاد و گسترش ارتباطات مؤثر", -1),
    PathStep("دعوت و پیش‌مشاوره", "مرحله فعلی مسیر", 2),
    PathStep("Follow-up", "پیگیری حرفه‌ای و مستمر", 0),
    PathStep("فروش و سفارش", "تبدیل علاقه‌مند به مشتری", 0),
    PathStep("درختواره", "ساخت تیم و تکثیر موفقیت", 0),
    PathStep("توسعه فردی", "رشد مهارت‌ها و شخصیت", 0)
)

@Composable
fun ProgressScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    var showAll by remember { mutableStateOf(false) }

    if (showAll) {
        FullProgressPath(contentPadding = contentPadding, onBack = { showAll = false })
    } else {
        CurrentProgressView(contentPadding = contentPadding, onBack = onBack, onShowAll = { showAll = true })
    }
}

@Composable
private fun CurrentProgressView(contentPadding: PaddingValues, onBack: () -> Unit, onShowAll: () -> Unit) {
    val visible = pathSteps.subList(2, 5)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuperColors.Background)
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
    ) {
        ProgressHeader(onBack = onBack)
        Spacer(Modifier.height(8.dp))
        ProgressLevelStrip()
        Spacer(Modifier.height(10.dp))

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            visible.forEachIndexed { index, step ->
                val number = index + 3
                PathStepCard(modifier = Modifier.weight(if (step.state == 2) 1.25f else 1f), number = number, step = step)
            }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onShowAll,
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = SuperShapes.Small,
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
        ) {
            Text("مشاهده کل مسیر ۸ مرحله‌ای", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FullProgressPath(contentPadding: PaddingValues, onBack: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SuperColors.Background),
        contentPadding = PaddingValues(
            start = SuperDimens.ScreenPadding,
            end = SuperDimens.ScreenPadding,
            top = contentPadding.calculateTopPadding() + 8.dp,
            bottom = contentPadding.calculateBottomPadding() + 18.dp
        ),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item { ProgressHeader(onBack = onBack) }
        item { ProgressLevelStrip() }
        items(pathSteps.size) { index ->
            PathStepCard(modifier = Modifier.fillMaxWidth().height(82.dp), number = index + 1, step = pathSteps[index])
        }
    }
}

@Composable
private fun ProgressHeader(onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Text)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text("مسیر پیشرفت", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
            Text("مرحله ۴ از ۸ • تمرکز روی قدم فعلی", color = SuperColors.TextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ProgressLevelStrip() {
    Card(
        modifier = Modifier.fillMaxWidth().height(64.dp),
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("سطح ۴", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text("مسیر لیدر", color = SuperColors.Gold, fontSize = 9.5.sp)
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("۷۳۰ / ۱۰۰۰ XP", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("مرحله فعلی: دعوت و پیش‌مشاوره", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("۱۲ روز", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text("متوالی", color = SuperColors.Orange, fontSize = 9.5.sp)
            }
        }
    }
}

@Composable
private fun PathStepCard(modifier: Modifier, number: Int, step: PathStep) {
    val accent = when (step.state) {
        1 -> SuperColors.Green
        -1 -> SuperColors.Red
        2 -> SuperColors.Blue
        else -> SuperColors.TextSecondary
    }
    val background = when (step.state) {
        1 -> SuperColors.GreenSoft
        -1 -> SuperColors.RedSoft
        2 -> SuperColors.BlueSoft
        else -> Color.White
    }
    val icon = when (step.state) {
        1 -> Icons.Outlined.Check
        -1 -> Icons.Outlined.Close
        0 -> Icons.Outlined.Lock
        else -> Icons.Outlined.Flag
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = background),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == 2) 2.dp else 1.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(42.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text("$number. ${step.title}", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 10.5.sp)
            }
            Text(
                when (step.state) {
                    1 -> "تکمیل شد"
                    -1 -> "ناموفق"
                    2 -> "فعلی"
                    else -> "قفل"
                },
                color = accent,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
