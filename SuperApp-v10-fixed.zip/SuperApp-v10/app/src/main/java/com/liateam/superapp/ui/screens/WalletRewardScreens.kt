package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.CoinStarAsset
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens

@Composable
private fun SimpleHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Spacer(Modifier.weight(1f))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.size(48.dp))
    }
}

@Composable
fun WalletScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp
                )
        ) {
            SimpleHeader("کیف پول سکه", onBack)
            Surface(Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    CoinStarAsset(size = 44.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("۶۹۵ سکه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Text("دریافت کل ۸۴۰  •  خرج‌شده ۱۴۵", color = SuperColors.TextSecondary, fontSize = 8.8.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("تراکنش‌های اخیر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            listOf(
                Triple("صندوق پاداش", "+۵", "امروز"),
                Triple("تکمیل آموزش", "+۳", "امروز"),
                Triple("خرید پاداش", "-۲۰", "دیروز"),
                Triple("تأیید فعالیت", "+۲", "دیروز")
            ).forEach { (title, amount, date) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(7.dp).background(if (amount.startsWith("+")) SuperColors.Green else SuperColors.Orange, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        Text(date, color = SuperColors.TextSecondary, fontSize = 7.8.sp)
                    }
                    Text(amount, color = if (amount.startsWith("+")) SuperColors.Green else SuperColors.Orange, fontWeight = FontWeight.Black, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun RewardStoreScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val rewards = listOf(
        Triple("Badge ویژه", "۱۲۰ سکه", false),
        Triple("تم پروفایل", "۱۸۰ سکه", false),
        Triple("پاداش سطح بعد", "۲۵۰ سکه", true)
    )
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp
                )
        ) {
            SimpleHeader("فروشگاه پاداش", onBack)
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(SuperColors.GoldSoft, RoundedCornerShape(16.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CoinStarAsset(size = 34.dp)
                Spacer(Modifier.width(8.dp))
                Text("موجودی ۶۹۵ سکه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            rewards.forEach { (title, price, locked) ->
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    color = Color.White,
                    shape = RoundedCornerShape(15.dp),
                    shadowElevation = 1.dp
                ) {
                    Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(36.dp).background(SuperColors.BlueSoft, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.CardGiftcard, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(20.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
                            Text(price, color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
                        }
                        Icon(
                            if (locked) Icons.Outlined.Lock else Icons.Outlined.CheckCircleOutline,
                            contentDescription = null,
                            tint = if (locked) Color(0xFFAAB6C5) else SuperColors.Green,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
