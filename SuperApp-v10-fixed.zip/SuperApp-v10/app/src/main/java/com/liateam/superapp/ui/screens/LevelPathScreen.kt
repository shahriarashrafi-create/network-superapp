package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.LevelEmblem
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens

private data class LevelUi(val level: Int, val xp: Int, val reward: String, val unlocked: Boolean)

@Composable
fun LevelPathScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val currentLevel = 3
    val levels = (1..10).map { level ->
        LevelUi(level, xp = level * 170, reward = when {
            level % 5 == 0 -> "نشان ویژه"
            level % 2 == 0 -> "+50 سکه"
            else -> "ابزار جدید"
        }, unlocked = level <= currentLevel)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp
                )
        ) {
            Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                }
                Spacer(Modifier.weight(1f))
                Text("مسیر سطح‌ها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(48.dp))
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shape = RoundedCornerShape(18.dp),
                shadowElevation = 2.dp
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LevelEmblem(level = currentLevel, size = 46.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("سطح ۳ • در مسیر لیدر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.sp)
                            Text("240 / 500 XP", color = SuperColors.TextSecondary, fontSize = 9.sp)
                        }
                        Text("260 XP تا سطح ۴", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    }
                    Spacer(Modifier.height(9.dp))
                    LinearProgressIndicator(
                        progress = { 0.48f },
                        modifier = Modifier.fillMaxWidth().height(6.dp),
                        color = SuperColors.Blue,
                        trackColor = SuperColors.BlueSoft
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(levels) { item ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = if (item.level == currentLevel) SuperColors.BlueSoft2 else Color.White,
                        shape = RoundedCornerShape(15.dp),
                        shadowElevation = if (item.level == currentLevel) 2.dp else 1.dp
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LevelEmblem(level = item.level, size = 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("سطح ${item.level}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                Text("${item.xp} XP  •  ${item.reward}", color = SuperColors.TextSecondary, fontSize = 8.4.sp)
                            }
                            if (item.level < currentLevel) {
                                Icon(Icons.Outlined.TaskAlt, contentDescription = null, tint = SuperColors.Green, modifier = Modifier.size(18.dp))
                            } else if (item.level > currentLevel) {
                                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color(0xFFAAB6C5), modifier = Modifier.size(17.dp))
                            } else {
                                Box(Modifier.size(8.dp).background(SuperColors.Blue, CircleShape))
                            }
                        }
                    }
                }
            }
        }
    }
}
