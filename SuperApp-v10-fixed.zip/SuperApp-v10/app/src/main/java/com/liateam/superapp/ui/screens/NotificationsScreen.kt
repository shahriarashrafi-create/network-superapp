package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.model.HomeDestination

enum class NoticePriority { INFO, ACTION, CRITICAL }

private data class NoticeUi(
    val group: String,
    val category: String,
    val title: String,
    val subtitle: String,
    val time: String,
    val actionLabel: String? = null,
    val priority: NoticePriority = NoticePriority.INFO,
    val unread: Boolean = true,
    val icon: ImageVector,
    val destination: HomeDestination? = null
)

@Composable
fun NotificationsScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    var selected by remember { mutableStateOf("همه") }
    val notices = remember {
        listOf(
            NoticeUi("امروز", "اقدام", "۳ مشتری نیاز به پیگیری دارند", "Next Action برای امروز آماده است", "۱۰ دقیقه پیش", "مشاهده", NoticePriority.ACTION, true, Icons.Outlined.TaskAlt, HomeDestination.CUSTOMERS),
            NoticeUi("امروز", "تیم", "یک فعالیت برای تأیید فرستاده شد", "بررسی کوتاه و تأیید یا رد", "۳۵ دقیقه پیش", "بررسی", NoticePriority.ACTION, true, Icons.Outlined.Groups, HomeDestination.LEADER_CENTER),
            NoticeUi("امروز", "فروش", "سفارش جدید ثبت شد", "وضعیت سفارش را بررسی کن", "۱ ساعت پیش", "سفارش", NoticePriority.INFO, false, Icons.Outlined.ReceiptLong, HomeDestination.ORDERS),
            NoticeUi("دیروز", "آموزش", "یک درس جدید برایت باز شد", "مسیر آموزشی سطح فعلی", "دیروز", "شروع", NoticePriority.INFO, true, Icons.Outlined.School, HomeDestination.ACADEMY),
            NoticeUi("دیروز", "سیستم", "هشدار کمبو", "کمتر از ۵ دقیقه تا پایان کمبو", "دیروز", null, NoticePriority.CRITICAL, false, Icons.Outlined.WarningAmber, HomeDestination.FOCUS),
            NoticeUi("این هفته", "دستاورد", "نشان جدید گرفتی", "اولین فروش این هفته", "۲ روز پیش", "مشاهده", NoticePriority.INFO, false, Icons.Outlined.CheckCircleOutline, HomeDestination.ACHIEVEMENTS),
            NoticeUi("این هفته", "رویداد", "رویداد تیم فردا برگزار می‌شود", "یادآوری حضور", "۳ روز پیش", "رویداد", NoticePriority.INFO, false, Icons.Outlined.Campaign, HomeDestination.EVENTS)
        )
    }
    val filters = listOf("همه", "نیازمند اقدام", "تیم", "فروش", "آموزش", "رویداد", "سیستم")
    val filtered = notices.filter {
        when (selected) {
            "همه" -> true
            "نیازمند اقدام" -> it.priority != NoticePriority.INFO
            else -> it.category == selected
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp
                )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().height(48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .shadow(2.dp, RoundedCornerShape(12.dp), clip = false)
                        .background(Color.White, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                    }
                }
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("اعلان‌ها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
                    Text("۳ مورد نیازمند اقدام", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onOpenDestination(HomeDestination.SETTINGS) }) {
                    Icon(Icons.Outlined.Settings, contentDescription = "تنظیمات", tint = SuperColors.Navy)
                }
            }

            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                filters.forEach { filter ->
                    val active = selected == filter
                    Surface(
                        modifier = Modifier.clickable { selected = filter },
                        color = if (active) SuperColors.Blue else Color.White,
                        shape = RoundedCornerShape(999.dp),
                        shadowElevation = if (active) 0.dp else 1.dp
                    ) {
                        Text(
                            filter,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = if (active) Color.White else SuperColors.TextSecondary,
                            fontWeight = if (active) FontWeight.Black else FontWeight.Bold,
                            fontSize = 9.2.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(5.dp),
                contentPadding = PaddingValues(bottom = 10.dp)
            ) {
                val groups = listOf("امروز", "دیروز", "این هفته")
                groups.forEach { group ->
                    val groupItems = filtered.filter { it.group == group }
                    if (groupItems.isNotEmpty()) {
                        item(key = "header_$group") {
                            Text(
                                group,
                                color = SuperColors.TextSecondary,
                                fontWeight = FontWeight.Black,
                                fontSize = 9.5.sp,
                                modifier = Modifier.padding(top = 7.dp, bottom = 2.dp)
                            )
                        }
                        items(groupItems, key = { "${it.group}_${it.title}" }) { notice ->
                            NotificationRow(notice) {
                                notice.destination?.let(onOpenDestination)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(notice: NoticeUi, onClick: () -> Unit) {
    val accent = when (notice.priority) {
        NoticePriority.INFO -> SuperColors.Blue
        NoticePriority.ACTION -> SuperColors.Orange
        NoticePriority.CRITICAL -> SuperColors.Red
    }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        color = if (notice.unread) Color(0xFFFCFEFF) else Color.White,
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(accent.copy(alpha = 0.10f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(notice.icon, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(9.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (notice.unread) {
                        Box(Modifier.size(6.dp).background(SuperColors.Blue, CircleShape))
                        Spacer(Modifier.width(5.dp))
                    }
                    Text(
                        notice.title,
                        color = SuperColors.Navy,
                        fontWeight = FontWeight.Black,
                        fontSize = 10.7.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    notice.subtitle,
                    color = SuperColors.TextSecondary,
                    fontWeight = FontWeight.Medium,
                    fontSize = 8.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(notice.time, color = Color(0xFF9AA8BA), fontSize = 7.5.sp)
            }
            if (notice.actionLabel != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    notice.actionLabel,
                    color = accent,
                    fontWeight = FontWeight.Black,
                    fontSize = 8.7.sp,
                    modifier = Modifier
                        .background(accent.copy(alpha = 0.09f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 9.dp, vertical = 6.dp)
                )
            }
        }
    }
}
