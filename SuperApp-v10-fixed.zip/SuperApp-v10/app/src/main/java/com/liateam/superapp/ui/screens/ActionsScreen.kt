package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskSource
import com.liateam.superapp.ui.model.TaskStatus

@Composable
fun ActionsScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onTaskStatus: (Int, TaskStatus) -> Unit,
    onOpenProgress: () -> Unit
) {
    var selectedSource by remember { mutableStateOf(TaskSource.TEAM) }
    val filtered = tasks.filter { it.source == selectedSource }.take(3)
    val next = tasks.firstOrNull { it.status == TaskStatus.TODO }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuperColors.Background)
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 9.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
    ) {
        Text("اقدام‌ها", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
        Text("فقط کاری که الان باید انجام شود", color = SuperColors.TextSecondary, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))

        if (next != null) {
            CompactNextAction(next = next)
            Spacer(Modifier.height(8.dp))
        }

        CompactProgressStrip(onOpenProgress)
        Spacer(Modifier.height(8.dp))

        SourceTabs(selectedSource = selectedSource, onSelect = { selectedSource = it })
        Spacer(Modifier.height(8.dp))

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            filtered.forEach { task ->
                CompactActionTaskCard(
                    modifier = Modifier.weight(1f),
                    task = task,
                    onTaskStatus = onTaskStatus
                )
            }
            repeat((3 - filtered.size).coerceAtLeast(0)) {
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CompactNextAction(next: AppTask) {
    Card(
        modifier = Modifier.fillMaxWidth().height(112.dp),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text("قدم بعدی", color = SuperColors.Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(next.title, color = SuperColors.Text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(next.subtitle, color = SuperColors.TextSecondary, fontSize = 10.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Button(
                onClick = {},
                modifier = Modifier.height(44.dp),
                shape = SuperShapes.Small,
                colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
            ) {
                Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("شروع", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CompactProgressStrip(onOpenProgress: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().height(68.dp).clickable(onClick = onOpenProgress),
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(38.dp).background(SuperColors.BlueSoft, SuperShapes.Small),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Timeline, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(21.dp))
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 9.dp)) {
                Text("مسیر پیشرفت", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("دعوت و پیش‌مشاوره • مرحله ۴ از ۸", color = SuperColors.TextSecondary, fontSize = 10.sp)
            }
            Text("مشاهده", color = SuperColors.Blue, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SourceTabs(selectedSource: TaskSource, onSelect: (TaskSource) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        TaskSource.entries.forEach { source ->
            val selected = selectedSource == source
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .background(if (selected) SuperColors.BlueSoft else Color.White, SuperShapes.Small)
                    .then(
                        if (!selected) Modifier.clickable { onSelect(source) }
                        else Modifier.clickable { onSelect(source) }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    source.label,
                    color = if (selected) SuperColors.Blue else SuperColors.TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun CompactActionTaskCard(
    modifier: Modifier,
    task: AppTask,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    val accent = when (task.status) {
        TaskStatus.DONE -> SuperColors.Green
        TaskStatus.FAILED -> SuperColors.Red
        TaskStatus.TODO -> SuperColors.Blue
    }
    val container = when (task.status) {
        TaskStatus.DONE -> SuperColors.GreenSoft
        TaskStatus.FAILED -> SuperColors.RedSoft
        TaskStatus.TODO -> Color.White
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = container),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(36.dp).background(if (task.status == TaskStatus.TODO) SuperColors.BlueSoft else Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
                }
                Column(modifier = Modifier.weight(1f).padding(horizontal = 9.dp)) {
                    Text(task.title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(task.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (task.points > 0) {
                    Text("+${task.points} XP", color = Color(0xFF946400), fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                MiniStatusButton(SuperColors.GreenSoft, SuperColors.Green, Icons.Outlined.Check, "انجام شد") {
                    onTaskStatus(task.id, TaskStatus.DONE)
                }
                MiniStatusButton(SuperColors.RedSoft, SuperColors.Red, Icons.Outlined.Close, "انجام نشد") {
                    onTaskStatus(task.id, TaskStatus.FAILED)
                }
                MiniStatusButton(SuperColors.NeutralSoft, SuperColors.TextSecondary, Icons.Outlined.Refresh, "بازنشانی") {
                    onTaskStatus(task.id, TaskStatus.TODO)
                }
                Spacer(Modifier.weight(1f))
                Box(modifier = Modifier.background(SuperColors.NeutralSoft, SuperShapes.Pill).padding(horizontal = 8.dp, vertical = 5.dp)) {
                    Text(
                        when (task.status) {
                            TaskStatus.DONE -> "انجام شد"
                            TaskStatus.FAILED -> "انجام نشد"
                            TaskStatus.TODO -> "در انتظار"
                        },
                        color = accent,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniStatusButton(
    background: Color,
    tint: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier.size(36.dp).background(background, SuperShapes.Small)
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(20.dp))
    }
}
