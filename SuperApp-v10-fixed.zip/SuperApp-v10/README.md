# Super App — v1.8.0 / Build 10

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## Build 10 highlights
- Home pager dots corrected: page 1 starts from the left and the active dot advances to the right.
- Slim Legacy-inspired gamification strip: Level / XP / Coin / Combo.
- Level emblem is code-generated and visually changes across levels.
- Minimal Level bottom sheet + full level path with previous/current/next levels.
- Coin uses a star-style reward asset; minimal wallet + reward store are included.
- Combo replaces streak and follows the Legacy rules: 30-minute window, 3 → ×2, 7 → ×3, 5-minute warning concept.
- Combo sheet shows remaining actions when inactive and remaining time / next multiplier when active.
- Minimal Notification Center with filters, grouping, priority accents and deep links.
- Bottom navigation is shorter, floating and safe-area aware.
- Back policy: sheets/dialogs dismiss first, internal pages pop logically, bottom tabs return to Home, Home uses double-back-to-exit, and screen state is preserved with SaveableStateHolder.

## Visual policy
No decorative bitmap/background images are used. UI is built with Compose, Canvas, shapes, gradients, vector/material icons and code-generated assets.

## App identity
- applicationId: `com.liateam.superapp`
- versionCode: `10`
- versionName: `1.8.0`
- existing signing keystore preserved for in-place updates.
