# SuperApp 3D Gamification — Version 2 / Real 3D Core

این ZIP دومین نسخهٔ پروژهٔ مستقل گیمیفیکیشن سه‌بعدی است و روی Foundation تاییدشدهٔ V1 ساخته شده است.

## چیزی که در V2 واقعی شده است

- Android Native / Kotlin / Jetpack Compose
- Landscape Fullscreen / Immersive
- Package ثابت: `com.superapp.progressgame`
- همان Signing Key برای Update روی نسخهٔ قبلی
- Version Code = 5
- Save Schema = 2
- World Schema = 2
- Renderer واقعی سه‌بعدی: SceneView 4.32.0 + Google Filament
- فضای واقعی X/Y/Z
- Camera واقعی سه‌بعدی
- Orbit / Pan / Pinch Zoom
- Tap برای انتخاب Object
- Double Tap برای Focus روی Object
- Reset Camera به Overview
- Camera Preset برای Fountain / Mansion / Entrance / Garden
- Scene Graph واقعی
- Terrain سه‌بعدی پایه
- Mansion سه‌بعدی کدمحور
- Fountain سه‌بعدی کدمحور
- Tree / Bench / Lamp / Plant / Path سه‌بعدی
- PBR Material پایه برای Grass / Stone / Wood / Metal / Glass / Water
- Main Light + Fill Light و پایهٔ Shadow
- Highlight هدف انتخاب‌شده
- HUD کوچک بازی
- Mission FAB کوچک با Focus روی Fountain
- Debug Overlay اختیاری: FPS / Object Count / Estimated Triangles / Camera XYZ / Hit ID
- Camera preset و Selected Object در Local Storage باقی می‌مانند
- Asset Pipeline آماده برای GLB / Materials / Textures / Environments / Definitions
- حذف داشبورد فنی V1 از تجربهٔ اصلی و انتقال اطلاعات فنی به Developer Status

## تست دستی V2 روی گوشی

1. وارد دنیا شو.
2. با یک انگشت Camera را Orbit کن.
3. با دو انگشت Pan کن.
4. Pinch Zoom را امتحان کن.
5. روی Fountain / Mansion / Tree / Bench بزن تا Highlight شود.
6. دوبار روی Object بزن تا Camera روی آن Focus شود.
7. دکمهٔ مرکز/Reset را بزن تا به Overview برگردد.
8. Mission FAB پایین صفحه را بزن؛ Camera باید روی Fountain Focus کند.
9. از Settings، Debug Overlay را روشن کن و FPS / Camera XYZ را ببین.

## Build در GitHub

ZIP را مستقیم در Root Repository قرار بده. Workflow موجود پروژه آن را Extract می‌کند و اجرا می‌کند:

```bash
./gradlew assembleDebug --stacktrace --no-daemon
```

APK در مسیر استاندارد زیر ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

## Toolchain

- Gradle 8.13
- Android Gradle Plugin 8.13.2
- Kotlin 2.4.10
- Compose BOM 2026.06.01
- compileSdk 36
- targetSdk 36
- JDK workflow: 17
- SceneView 4.32.0

## مرز V2

V2 عمداً Asset Library کامل، Weather، Water Shader پیشرفته، NPC، Avatar و World Builder را وارد نمی‌کند. معماری برای آن‌ها آماده است و طبق نقشهٔ 16 نسخه‌ای در مراحل بعدی روی همین هسته توسعه پیدا می‌کند.
