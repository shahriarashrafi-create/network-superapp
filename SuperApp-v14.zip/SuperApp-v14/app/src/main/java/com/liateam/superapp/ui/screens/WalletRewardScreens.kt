package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.CoinStarAsset
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

@Composable
private fun SimpleHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy) }
        Spacer(Modifier.weight(1f))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(Modifier.weight(1f))
        Spacer(Modifier.size(48.dp))
    }
}

private data class WalletTx(val title: String, val amount: String, val period: String, val incoming: Boolean)

@Composable
fun WalletScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    var filter by remember { mutableStateOf("همه") }
    val transactions = listOf(
        WalletTx("صندوق پاداش", "+۵", "امروز • ۱۴:۲۰", true),
        WalletTx("تکمیل آموزش", "+۳", "امروز • ۱۰:۴۵", true),
        WalletTx("خرید پاداش", "−۲۰", "دیروز • ۱۸:۱۰", false),
        WalletTx("تأیید فعالیت", "+۲", "دیروز • ۱۲:۳۰", true),
        WalletTx("مأموریت هفتگی", "+۱۰", "این هفته", true)
    )
    val visible = transactions.filter { filter == "همه" || (filter == "دریافت" && it.incoming) || (filter == "خرج" && !it.incoming) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))) {
        Column(
            modifier = Modifier.fillMaxSize().padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 4.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
        ) {
            SimpleHeader("کیف پول سکه", onBack)
            Surface(Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(17.dp), shadowElevation = 1.dp) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CoinStarAsset(size = 42.dp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("۶۹۵ سکه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            Text("+22٪ نسبت به هفته قبل", color = SuperColors.Green, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        WalletKpi("امروز", "+۷", SuperColors.Green, Modifier.weight(1f))
                        WalletKpi("این هفته", "+۳۴", SuperColors.Blue, Modifier.weight(1f))
                        WalletKpi("این ماه", "+۱۴۸", SuperColors.Purple, Modifier.weight(1f))
                        WalletKpi("خرج هفته", "−۱۲", SuperColors.Orange, Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Surface(Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(15.dp), shadowElevation = 0.5.dp) {
                Column(Modifier.padding(horizontal = 11.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("روند ۷ روز", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        Spacer(Modifier.weight(1f))
                        Text("دریافت 34 • خرج 12", color = SuperColors.TextSecondary, fontSize = 7.8.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    CoinTrendChart(Modifier.fillMaxWidth().height(42.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("همه", "دریافت", "خرج").forEach { item ->
                    val active = filter == item
                    Text(
                        item,
                        color = if (active) Color.White else SuperColors.TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.5.sp,
                        modifier = Modifier.clickable { filter = item }.background(if (active) SuperColors.Blue else Color.White, SuperShapes.Pill).padding(horizontal = 11.dp, vertical = 6.dp)
                    )
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("تراکنش‌ها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
            Spacer(Modifier.height(2.dp))
            if (visible.isEmpty()) {
                Box(Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                    Text("تراکنشی در این بازه نیست", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                }
            } else {
                visible.forEach { tx -> WalletTransactionRow(tx) }
            }
        }
    }
}

@Composable
private fun WalletKpi(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = color.copy(alpha = 0.07f), shape = RoundedCornerShape(11.dp)) {
        Column(Modifier.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 9.sp)
            Text(label, color = SuperColors.TextSecondary, fontSize = 6.9.sp)
        }
    }
}

@Composable
private fun CoinTrendChart(modifier: Modifier = Modifier) {
    val values = listOf(8f, 14f, 12f, 20f, 18f, 27f, 34f)
    Canvas(modifier) {
        val max = 36f
        val gap = size.width / (values.size - 1)
        var last: Offset? = null
        values.forEachIndexed { i, v ->
            val p = Offset(i * gap, size.height - (v / max) * size.height * 0.86f - size.height * 0.07f)
            last?.let { drawLine(SuperColors.Blue, it, p, strokeWidth = 4f, cap = StrokeCap.Round) }
            drawCircle(SuperColors.Blue, radius = 4f, center = p)
            last = p
        }
    }
}

@Composable
private fun WalletTransactionRow(tx: WalletTx) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(if (tx.incoming) SuperColors.Green else SuperColors.Orange, CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(tx.title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            Text(tx.period, color = SuperColors.TextSecondary, fontSize = 7.2.sp)
        }
        Text(tx.amount, color = if (tx.incoming) SuperColors.Green else SuperColors.Orange, fontWeight = FontWeight.Black, fontSize = 10.sp)
    }
}

@Composable
fun RewardStoreScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val rewards = listOf(
        Triple("Badge ویژه", "۱۲۰ سکه", false),
        Triple("تم پروفایل", "۱۸۰ سکه", false),
        Triple("پاداش سطح بعد", "۲۵۰ سکه", true)
    )
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))) {
        Column(
            modifier = Modifier.fillMaxSize().padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 4.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
        ) {
            SimpleHeader("فروشگاه پاداش", onBack)
            Surface(Modifier.fillMaxWidth(), color = SuperColors.GoldSoft, shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CoinStarAsset(size = 32.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("۶۹۵ Coin", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("۳ پاداش قابل خرید", color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 8.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        WalletKpi("قابل خرید", "3", SuperColors.Green, Modifier.weight(1f))
                        WalletKpi("خرید قبلی", "2", SuperColors.Blue, Modifier.weight(1f))
                        WalletKpi("خرج این ماه", "145", SuperColors.Orange, Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(9.dp))
            rewards.forEach { (title, price, locked) ->
                Surface(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), color = Color.White, shape = RoundedCornerShape(14.dp), shadowElevation = 0.5.dp) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Outlined.CardGiftcard, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.sp)
                            Text(price, color = SuperColors.TextSecondary, fontSize = 8.sp)
                        }
                        Icon(if (locked) Icons.Outlined.Lock else Icons.Outlined.CheckCircleOutline, contentDescription = null, tint = if (locked) Color(0xFFAAB6C5) else SuperColors.Green, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
