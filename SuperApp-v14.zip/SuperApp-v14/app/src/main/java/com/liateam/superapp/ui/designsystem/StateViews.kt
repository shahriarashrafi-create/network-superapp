package com.liateam.superapp.ui.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SuperEmptyState(title: String, message: String, modifier: Modifier = Modifier) {
    SuperStateCard(modifier) {
        Box(Modifier.size(50.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Inbox, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.height(9.dp))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(message, color = SuperColors.TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SuperLoadingState(message: String = "در حال آماده‌سازی…", modifier: Modifier = Modifier) {
    SuperStateCard(modifier) {
        CircularProgressIndicator(color = SuperColors.Blue, strokeWidth = 3.dp, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(10.dp))
        Text(message, color = SuperColors.TextSecondary, fontWeight = FontWeight.Medium, fontSize = 11.sp)
    }
}

@Composable
fun SuperErrorState(title: String, message: String, onRetry: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    SuperStateCard(modifier) {
        Box(Modifier.size(50.dp).background(SuperColors.RedSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.ErrorOutline, contentDescription = null, tint = SuperColors.Red, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.height(9.dp))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Text(message, color = SuperColors.TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center)
        if (onRetry != null) {
            Spacer(Modifier.height(10.dp))
            Button(onClick = onRetry, shape = SuperShapes.Pill) { Text("تلاش دوباره") }
        }
    }
}

@Composable
private fun SuperStateCard(modifier: Modifier, content: @Composable () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(20.dp))
            .padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) { content() }
}
