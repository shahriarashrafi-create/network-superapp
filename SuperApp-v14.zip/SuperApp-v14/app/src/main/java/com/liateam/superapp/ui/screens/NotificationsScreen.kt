package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.model.HomeDestination

enum class NoticePriority { INFO, ACTION, CRITICAL }

private data class NoticeUi(
    val group: String,
    val category: String,
    val title: String,
    val subtitle: String,
    val time: String,
    val actionLabel: String? = null,
    val priority: NoticePriority = NoticePriority.INFO,
    val unread: Boolean = true,
    val icon: ImageVector,
    val destination: HomeDestination? = null
)

@Composable
fun NotificationsScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    var selected by remember { mutableStateOf("همه") }
    val notices = remember {
        listOf(
            NoticeUi("امروز", "نیازمند اقدام", "۳ مشتری نیاز به پیگیری دارند", "اقدام بعدی امروز آماده است", "۱۰ دقیقه پیش", "مشاهده", NoticePriority.ACTION, true, Icons.Outlined.TaskAlt, HomeDestination.CUSTOMERS),
            NoticeUi("امروز", "تیم", "یک فعالیت برای تأیید فرستاده شد", "بررسی کوتاه و تأیید یا رد", "۳۵ دقیقه پیش", "بررسی", NoticePriority.ACTION, true, Icons.Outlined.Groups, HomeDestination.LEADER_CENTER),
            NoticeUi("امروز", "فروش", "سفارش جدید ثبت شد", "وضعیت سفارش را بررسی کن", "۱ ساعت پیش", "مشاهده", NoticePriority.INFO, true, Icons.Outlined.ReceiptLong, HomeDestination.ORDERS),
            NoticeUi("دیروز", "آموزش", "یک درس جدید برایت باز شد", "مسیر آموزشی سطح فعلی", "دیروز", "شروع", NoticePriority.INFO, true, Icons.Outlined.School, HomeDestination.ACADEMY),
            NoticeUi("دیروز", "سیستم", "هشدار کمبو", "کمتر از ۵ دقیقه تا پایان کمبو", "دیروز", "مشاهده", NoticePriority.CRITICAL, true, Icons.Outlined.WarningAmber, HomeDestination.FOCUS),
            NoticeUi("این هفته", "دستاورد", "نشان جدید گرفتی", "اولین فروش این هفته", "۲ روز پیش", "مشاهده", NoticePriority.INFO, false, Icons.Outlined.CheckCircleOutline, HomeDestination.ACHIEVEMENTS),
            NoticeUi("این هفته", "رویداد", "رویداد تیم فردا برگزار می‌شود", "یادآوری حضور", "۳ روز پیش", "جزئیات", NoticePriority.INFO, false, Icons.Outlined.Campaign, HomeDestination.EVENTS)
        )
    }
    val filters = listOf("همه", "نیازمند اقدام", "تیم", "فروش", "آموزش", "رویداد", "سیستم")
    fun countFor(filter: String): Int = notices.count {
        when (filter) {
            "همه" -> true
            "نیازمند اقدام" -> it.priority != NoticePriority.INFO
            else -> it.category == filter
        }
    }
    val filtered = notices.filter {
        when (selected) {
            "همه" -> true
            "نیازمند اقدام" -> it.priority != NoticePriority.INFO
            else -> it.category == selected
        }
    }
    val unreadCount = notices.count { it.unread }
    val actionCount = notices.count { it.priority != NoticePriority.INFO }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 4.dp,
                    bottom = contentPadding.calculateBottomPadding() + 8.dp
                )
        ) {
            Row(modifier = Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(36.dp).shadow(1.dp, RoundedCornerShape(11.dp), clip = false).background(Color.White, RoundedCornerShape(11.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                    }
                }
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("اعلان‌ها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("$unreadCount خوانده‌نشده • $actionCount نیازمند اقدام", color = SuperColors.TextSecondary, fontSize = 8.3.sp)
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { onOpenDestination(HomeDestination.SETTINGS) }) {
                    Icon(Icons.Outlined.Settings, contentDescription = "تنظیمات", tint = SuperColors.Navy)
                }
            }

            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                filters.forEach { filter ->
                    val active = selected == filter
                    Surface(
                        modifier = Modifier.clickable { selected = filter },
                        color = if (active) SuperColors.Blue else Color.White,
                        shape = RoundedCornerShape(999.dp),
                        shadowElevation = if (active) 0.dp else 0.5.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(filter, color = if (active) Color.White else SuperColors.TextSecondary, fontWeight = if (active) FontWeight.Black else FontWeight.Bold, fontSize = 8.7.sp, maxLines = 1)
                            val count = countFor(filter)
                            if (count > 0) {
                                Text(count.toString(), color = if (active) Color.White.copy(alpha = 0.86f) else SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 7.5.sp)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(6.dp))
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("اعلان جدیدی نیست", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Text("وقتی چیزی نیاز به توجه داشته باشد اینجا می‌بینی", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    listOf("امروز", "دیروز", "این هفته").forEach { group ->
                        val groupItems = filtered.filter { it.group == group }
                        if (groupItems.isNotEmpty()) {
                            item(key = "header_$group") {
                                Text(group, color = SuperColors.TextSecondary, fontWeight = FontWeight.Black, fontSize = 8.8.sp, modifier = Modifier.padding(top = 6.dp, bottom = 1.dp))
                            }
                            items(groupItems, key = { "${it.group}_${it.title}" }) { notice ->
                                NotificationRow(notice) { notice.destination?.let(onOpenDestination) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(notice: NoticeUi, onClick: () -> Unit) {
    val accent = when (notice.priority) {
        NoticePriority.INFO -> SuperColors.Blue
        NoticePriority.ACTION -> SuperColors.Orange
        NoticePriority.CRITICAL -> SuperColors.Red
    }
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (notice.unread) Color(0xFFF7FBFF) else Color.White,
        shadowElevation = 0.5.dp,
        border = androidx.compose.foundation.BorderStroke(0.6.dp, if (notice.unread) SuperColors.BorderBlue.copy(alpha = 0.55f) else SuperColors.Border.copy(alpha = 0.45f))
    ) {
        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(31.dp).background(accent.copy(alpha = 0.09f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(notice.icon, contentDescription = null, tint = accent, modifier = Modifier.size(17.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (notice.unread) {
                        Box(Modifier.size(5.dp).background(SuperColors.Blue, CircleShape))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(notice.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(notice.subtitle, color = SuperColors.TextSecondary, fontWeight = FontWeight.Medium, fontSize = 8.1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(notice.time, color = Color(0xFF96A5B8), fontSize = 7.sp)
            }
            if (notice.actionLabel != null) {
                Spacer(Modifier.width(7.dp))
                Text(
                    notice.actionLabel,
                    color = accent,
                    fontWeight = FontWeight.Black,
                    fontSize = 8.2.sp,
                    modifier = Modifier.background(accent.copy(alpha = 0.08f), RoundedCornerShape(999.dp)).padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
        }
    }
}
