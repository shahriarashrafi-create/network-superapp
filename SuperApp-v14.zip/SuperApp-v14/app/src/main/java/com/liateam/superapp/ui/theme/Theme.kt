package com.liateam.superapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors

private val SuperAppColors = lightColorScheme(
    primary = SuperColors.Blue,
    onPrimary = Color.White,
    secondary = SuperColors.Purple,
    background = SuperColors.Background,
    surface = Color.White,
    onBackground = SuperColors.Text,
    onSurface = SuperColors.Text,
    error = SuperColors.Red
)

private val SuperTypography = Typography(
    bodyLarge = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 14.sp,
        lineHeight = 21.sp
    ),
    titleLarge = androidx.compose.ui.text.TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    )
)

@Composable
fun SuperAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SuperAppColors,
        typography = SuperTypography,
        content = content
    )
}
