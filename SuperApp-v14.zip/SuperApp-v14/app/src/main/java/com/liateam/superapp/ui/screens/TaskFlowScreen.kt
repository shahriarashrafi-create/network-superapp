package com.liateam.superapp.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskStatus
import kotlinx.coroutines.delay

private enum class TaskFlowPhase { DETAIL, FOCUS, COMPLETE }

private data class TaskSubtask(
    val title: String,
    val hint: String,
    val iconType: Int,
    val required: Boolean = true
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskFlowScreen(
    contentPadding: PaddingValues,
    task: AppTask,
    onBack: () -> Unit,
    onStatusChange: (TaskStatus) -> Unit,
    onOpenCrm: () -> Unit,
    onContinueToNext: () -> Unit
) {
    var phase by remember { mutableStateOf(TaskFlowPhase.DETAIL) }
    var selectedMinutes by remember { mutableIntStateOf(15) }
    var showResultSheet by remember { mutableStateOf(false) }
    val completed = remember { mutableStateListOf(false, false, false) }

    BackHandler(enabled = true) {
        when {
            showResultSheet -> showResultSheet = false
            phase == TaskFlowPhase.FOCUS -> phase = TaskFlowPhase.DETAIL
            phase == TaskFlowPhase.COMPLETE -> onContinueToNext()
            else -> onBack()
        }
    }

    when (phase) {
        TaskFlowPhase.DETAIL -> TaskDetailContent(
            contentPadding = contentPadding,
            task = task,
            completed = completed,
            selectedMinutes = selectedMinutes,
            onSelectedMinutes = { selectedMinutes = it },
            onToggleSubtask = { index -> completed[index] = !completed[index] },
            onOpenCrm = onOpenCrm,
            onStartFocus = { phase = TaskFlowPhase.FOCUS },
            onBack = onBack
        )

        TaskFlowPhase.FOCUS -> FocusContent(
            task = task,
            minutes = selectedMinutes,
            onBack = { phase = TaskFlowPhase.DETAIL },
            onFinish = { showResultSheet = true }
        )

        TaskFlowPhase.COMPLETE -> CompletionContent(
            contentPadding = contentPadding,
            task = task,
            onContinue = onContinueToNext
        )
    }

    if (showResultSheet) {
        ModalBottomSheet(
            onDismissRequest = { showResultSheet = false },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)
        ) {
            ResultSheet(
                onDone = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.DONE)
                    phase = TaskFlowPhase.COMPLETE
                },
                onLater = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.TODO)
                    onBack()
                },
                onFail = {
                    showResultSheet = false
                    onStatusChange(TaskStatus.FAILED)
                    onBack()
                }
            )
        }
    }
}

@Composable
private fun TaskDetailContent(
    contentPadding: PaddingValues,
    task: AppTask,
    completed: List<Boolean>,
    selectedMinutes: Int,
    onSelectedMinutes: (Int) -> Unit,
    onToggleSubtask: (Int) -> Unit,
    onOpenCrm: () -> Unit,
    onStartFocus: () -> Unit,
    onBack: () -> Unit
) {
    val subtasks = remember(task.id) {
        listOf(
            TaskSubtask("انتخاب یک مخاطب مناسب", "از لیست مشتریان یا ارتباطات", 0),
            TaskSubtask("شروع یک گفت‌وگوی کوتاه", "ساده، طبیعی و بدون فشار", 1),
            TaskSubtask("ثبت نتیجه در CRM", "نتیجه و اقدام بعدی را ثبت کن", 2)
        )
    }
    val doneCount = completed.count { it }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuperColors.Background)
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = contentPadding.calculateTopPadding() + 6.dp,
                bottom = contentPadding.calculateBottomPadding() + 10.dp
            )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
            }
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text("جزئیات اقدام", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 21.sp)
                Text("قبل از شروع، قدم‌ها را ببین", color = SuperColors.TextSecondary, fontSize = 10.sp)
            }
        }

        Spacer(Modifier.height(7.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).background(SuperColors.BlueSoft, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(task.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text(task.subtitle, color = SuperColors.TextSecondary, fontSize = 10.5.sp, maxLines = 2)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    SmallReward("+${task.points.coerceAtLeast(20)} XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallReward("+2 سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    SmallReward("$selectedMinutes دقیقه", SuperColors.Purple, SuperColors.PurpleSoft)
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(17.dp),
            colors = CardDefaults.cardColors(containerColor = SuperColors.GoldSoft),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lightbulb, contentDescription = null, tint = SuperColors.GoldDeep, modifier = Modifier.size(20.dp))
                Column(Modifier.padding(horizontal = 8.dp)) {
                    Text("چرا این اقدام مهم است؟", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    Text("هر گفت‌وگوی جدید یک فرصت واقعی برای رشد فروش و شبکه می‌سازد.", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("زیرکارها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text("$doneCount / ${subtasks.size} تکمیل", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
        }
        Spacer(Modifier.height(5.dp))
        LinearProgressIndicator(
            progress = { doneCount / subtasks.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
            color = SuperColors.Blue,
            trackColor = SuperColors.BlueSoft
        )
        Spacer(Modifier.height(7.dp))

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            subtasks.forEachIndexed { index, item ->
                SubtaskRow(
                    modifier = Modifier.weight(1f),
                    item = item,
                    checked = completed[index],
                    onToggle = { onToggleSubtask(index) },
                    onOpenCrm = if (index == 0 || index == 2) onOpenCrm else null
                )
            }
        }

        Spacer(Modifier.height(9.dp))
        Text("زمان پیشنهادی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf(15, 30, 45).forEach { minutes ->
                TimeChoice(
                    text = "$minutes دقیقه",
                    selected = selectedMinutes == minutes,
                    onClick = { onSelectedMinutes(minutes) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onStartFocus,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
        ) {
            Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(5.dp))
            Text("شروع تمرکز", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SubtaskRow(
    modifier: Modifier,
    item: TaskSubtask,
    checked: Boolean,
    onToggle: () -> Unit,
    onOpenCrm: (() -> Unit)?
) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onToggle),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (checked) SuperColors.GreenSoft else Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.6.dp)
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .background(if (checked) SuperColors.Green else SuperColors.BlueSoft, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (checked) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                } else {
                    Icon(
                        when (item.iconType) {
                            0 -> Icons.Outlined.Person
                            1 -> Icons.Outlined.ChatBubbleOutline
                            else -> Icons.Outlined.Description
                        },
                        contentDescription = null,
                        tint = SuperColors.Blue,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 9.dp)) {
                Text(item.title, color = SuperColors.Navy, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, maxLines = 1)
                Text(item.hint, color = SuperColors.TextSecondary, fontSize = 8.7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (onOpenCrm != null) {
                Text(
                    "CRM",
                    color = SuperColors.Blue,
                    fontWeight = FontWeight.Black,
                    fontSize = 8.8.sp,
                    modifier = Modifier
                        .background(SuperColors.BlueSoft, SuperShapes.Pill)
                        .clickable { onOpenCrm() }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun TimeChoice(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(
        modifier = modifier
            .height(36.dp)
            .background(if (selected) SuperColors.BlueSoft else Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, if (selected) SuperColors.Blue.copy(alpha = 0.45f) else SuperColors.Border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) SuperColors.Blue else SuperColors.TextSecondary, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
    }
}

@Composable
private fun FocusContent(task: AppTask, minutes: Int, onBack: () -> Unit, onFinish: () -> Unit) {
    var secondsRemaining by remember(minutes) { mutableIntStateOf(minutes * 60) }
    var running by remember { mutableStateOf(true) }

    LaunchedEffect(running, secondsRemaining) {
        if (running && secondsRemaining > 0) {
            delay(1000)
            secondsRemaining -= 1
        } else if (secondsRemaining <= 0) {
            onFinish()
        }
    }

    val mins = secondsRemaining / 60
    val secs = secondsRemaining % 60
    val progress = if (minutes > 0) 1f - (secondsRemaining / (minutes * 60f)) else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF113A76), Color(0xFF0B2D61), Color(0xFF071F49))
                )
            )
            .padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(42.dp).background(Color.White.copy(alpha = 0.10f), CircleShape)) {
                Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = Color.White)
            }
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("حالت تمرکز", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text(task.title, color = Color.White.copy(alpha = 0.72f), fontSize = 10.sp)
            }
            IconButton(onClick = {}, modifier = Modifier.size(42.dp).background(Color.White.copy(alpha = 0.10f), CircleShape)) {
                Icon(Icons.Outlined.MusicNote, contentDescription = "موسیقی", tint = Color.White)
            }
        }

        Spacer(Modifier.weight(0.7f))
        Box(contentAlignment = Alignment.Center) {
            androidx.compose.material3.CircularProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.size(208.dp),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.18f),
                strokeWidth = 11.dp
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "%02d:%02d".format(mins, secs),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 44.sp
                )
                Text(if (running) "در حال تمرکز" else "مکث", color = Color.White.copy(alpha = 0.68f), fontSize = 10.sp)
            }
        }

        Spacer(Modifier.height(24.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.08f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).background(Color.White.copy(alpha = 0.10f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = Color.White)
                }
                Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                    Text("در حال انجام", color = Color.White.copy(alpha = 0.62f), fontSize = 8.5.sp)
                    Text(task.title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                }
                Text("+${task.points.coerceAtLeast(20)} XP", color = Color(0xFFFFD45A), fontWeight = FontWeight.Black, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("هر گفت‌وگوی جدید، یک فرصت جدید است.", color = Color.White.copy(alpha = 0.72f), fontSize = 10.sp)
        Spacer(Modifier.weight(1f))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { running = !running },
                modifier = Modifier.size(58.dp).background(Color.White.copy(alpha = 0.14f), CircleShape)
            ) {
                Icon(if (running) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
            Button(
                onClick = onFinish,
                modifier = Modifier.height(52.dp).width(180.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                Text("پایان و ثبت نتیجه", color = SuperColors.BlueDeep, fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ResultSheet(onDone: () -> Unit, onLater: () -> Unit, onFail: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(54.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Check, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("نتیجه این اقدام؟", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 19.sp)
        Text("یکی را انتخاب کن؛ وضعیت و پاداش بر همین اساس ثبت می‌شود.", color = SuperColors.TextSecondary, fontSize = 9.5.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onDone,
            modifier = Modifier.fillMaxWidth().height(44.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Green)
        ) { Text("انجام شد", fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(7.dp))
        OutlinedButton(onClick = onLater, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(14.dp)) {
            Text("ادامه بعداً", color = SuperColors.Blue, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(7.dp))
        OutlinedButton(onClick = onFail, modifier = Modifier.fillMaxWidth().height(42.dp), shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Outlined.Close, contentDescription = null, tint = SuperColors.Red, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text("ناموفق", color = SuperColors.Red, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CompletionContent(contentPadding: PaddingValues, task: AppTask, onContinue: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color.White, SuperColors.BlueSoft2)))
            .padding(
                start = 18.dp,
                end = 18.dp,
                top = contentPadding.calculateTopPadding() + 26.dp,
                bottom = contentPadding.calculateBottomPadding() + 18.dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.5f))
        Box(Modifier.size(82.dp).background(SuperColors.GreenSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Check, contentDescription = null, tint = SuperColors.Green, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("آفرین!", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Text("${task.title} با موفقیت انجام شد", color = SuperColors.TextSecondary, fontSize = 11.sp)
        Spacer(Modifier.height(18.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatRewardCard("+${task.points.coerceAtLeast(20)}", "XP", SuperColors.Blue, SuperColors.BlueSoft, Modifier.weight(1f))
            StatRewardCard("+2", "سکه", SuperColors.GoldDeep, SuperColors.GoldSoft, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("وضعیت کمبو", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("2 / 3", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
                Spacer(Modifier.height(7.dp))
                LinearProgressIndicator(
                    progress = { 2f / 3f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = SuperColors.BlueSoft
                )
                Spacer(Modifier.height(6.dp))
                Text("۱ اقدام دیگه تا فعال شدن کمبو ×2", color = SuperColors.TextSecondary, fontSize = 9.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2)
        ) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Person, contentDescription = null, tint = SuperColors.Blue)
                Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                    Text("کجا ثبت شد؟", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    Text("این اقدام در CRM و مسیر پیشرفت ثبت شد.", color = SuperColors.TextSecondary, fontSize = 9.sp)
                }
            }
        }
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onContinue,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
        ) {
            Text("ادامه به قدم بعدی", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SmallReward(text: String, color: Color, background: Color) {
    Box(Modifier.background(background, SuperShapes.Pill).padding(horizontal = 9.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 8.8.sp)
    }
}

@Composable
private fun StatRewardCard(title: String, subtitle: String, color: Color, background: Color, modifier: Modifier) {
    Card(modifier = modifier.height(78.dp), shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = background)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(title, color = color, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(subtitle, color = SuperColors.TextSecondary, fontSize = 9.sp)
        }
    }
}
