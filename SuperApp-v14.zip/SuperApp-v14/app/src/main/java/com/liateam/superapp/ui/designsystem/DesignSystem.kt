package com.liateam.superapp.ui.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Legacy-inspired light design system for the Super App. */
object SuperColors {
    val Blue = Color(0xFF1976F3)
    val BlueStrong = Color(0xFF0D6FE8)
    val BlueDeep = Color(0xFF0B58C8)
    val BlueSoft = Color(0xFFEAF4FF)
    val BlueSoft2 = Color(0xFFF7FAFF)
    val Sky = Color(0xFF68BCFF)

    val Navy = Color(0xFF0B1F4D)
    val Text = Color(0xFF0B1838)
    val TextSecondary = Color(0xFF71809A)
    val Border = Color(0xFFDCE8F7)
    val BorderBlue = Color(0xFFBFDDF6)
    val Background = Color(0xFFF7FAFF)
    val Surface = Color.White

    val Green = Color(0xFF20B57A)
    val GreenSoft = Color(0xFFE8F8F1)
    val Red = Color(0xFFE84545)
    val RedSoft = Color(0xFFFFEEEE)
    val Orange = Color(0xFFFF8A22)
    val OrangeSoft = Color(0xFFFFF2DE)
    val Purple = Color(0xFF7657E8)
    val PurpleSoft = Color(0xFFF1EDFF)

    val Gold = Color(0xFFF5B82E)
    val GoldBright = Color(0xFFFFD85A)
    val GoldDeep = Color(0xFFC9850C)
    val GoldSoft = Color(0xFFFFF4D2)
    val NeutralSoft = Color(0xFFF1F5FA)
}

object SuperDimens {
    val ScreenPadding = 16.dp
    val CardRadius = 22.dp
    val SmallRadius = 16.dp
    val PillRadius = 999.dp
}

object SuperShapes {
    val Card = RoundedCornerShape(SuperDimens.CardRadius)
    val Small = RoundedCornerShape(SuperDimens.SmallRadius)
    val Pill = RoundedCornerShape(SuperDimens.PillRadius)
}
