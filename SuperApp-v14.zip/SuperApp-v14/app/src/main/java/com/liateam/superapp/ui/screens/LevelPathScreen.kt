package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.LevelEmblem
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

private data class LevelUi(
    val level: Int,
    val xp: Int,
    val reward: String,
    val unlock: String,
    val unlocked: Boolean
)

@Composable
fun LevelPathScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val currentLevel = 3
    var selectedLevel by remember { mutableStateOf(currentLevel) }
    val levels = (1..10).map { level ->
        LevelUi(
            level = level,
            xp = level * 170,
            reward = when {
                level % 5 == 0 -> "نشان ویژه"
                level % 2 == 0 -> "+50 Coin"
                else -> "Badge جدید"
            },
            unlock = when {
                level == 4 -> "یک مأموریت جدید"
                level == 5 -> "پاداش ویژه"
                level >= 6 -> "ابزار پیشرفته"
                else -> "قابلیت پایه"
            },
            unlocked = level <= currentLevel
        )
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SuperColors.Background, Color.White, SuperColors.BlueSoft2)))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 4.dp,
                bottom = contentPadding.calculateBottomPadding() + 8.dp
            )
        ) {
            Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy) }
                Spacer(Modifier.weight(1f))
                Text("مسیر سطح‌ها", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                Spacer(Modifier.size(48.dp))
            }

            Surface(modifier = Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(17.dp), shadowElevation = 1.dp) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LevelEmblem(level = currentLevel, size = 43.dp)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("سطح ۳ • در مسیر لیدر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                            Text("240 / 500 XP • 48٪", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                        }
                        Text("260 XP تا سطح ۴", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 8.6.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    LinearProgressIndicator(progress = { 0.48f }, modifier = Modifier.fillMaxWidth().height(6.dp), color = SuperColors.Blue, trackColor = SuperColors.BlueSoft)
                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        StatChip("امروز", "+40 XP", SuperColors.Blue, Modifier.weight(1f))
                        StatChip("این هفته", "+140 XP", SuperColors.Green, Modifier.weight(1f))
                        StatChip("میانگین", "28 روزانه", SuperColors.Purple, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("+18٪ نسبت به هفته قبل", color = SuperColors.Green, fontWeight = FontWeight.Bold, fontSize = 7.8.sp)
                }
            }

            Spacer(Modifier.height(8.dp))
            val selected = levels.first { it.level == selectedLevel }
            Surface(modifier = Modifier.fillMaxWidth(), color = SuperColors.BlueSoft2, shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("سطح ${selected.level}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 9.4.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${selected.reward} • ${selected.unlock}", color = if (selected.level <= currentLevel) SuperColors.Green else SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 8.1.sp)
                }
            }

            Spacer(Modifier.height(7.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(levels) { item ->
                    LevelRow(item = item, currentLevel = currentLevel, selected = item.level == selectedLevel) {
                        selectedLevel = item.level
                    }
                }
            }
        }
    }
}

@Composable
private fun StatChip(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = color.copy(alpha = 0.07f), shape = RoundedCornerShape(11.dp)) {
        Column(Modifier.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 8.8.sp)
            Text(label, color = SuperColors.TextSecondary, fontSize = 7.sp)
        }
    }
}

@Composable
private fun LevelRow(item: LevelUi, currentLevel: Int, selected: Boolean, onClick: () -> Unit) {
    val passed = item.level < currentLevel
    val current = item.level == currentLevel
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = when {
            selected -> SuperColors.BlueSoft2
            else -> Color.White
        },
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 0.5.dp,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 1.dp else 0.5.dp,
            if (selected) SuperColors.Blue.copy(alpha = 0.30f) else SuperColors.Border.copy(alpha = 0.45f)
        )
    ) {
        Row(Modifier.padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                LevelEmblem(level = item.level, size = if (current) 36.dp else 32.dp)
                if (selected) Box(Modifier.size(if (current) 40.dp else 36.dp).background(Color.Transparent, CircleShape))
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text("سطح ${item.level}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.2.sp)
                Text("${item.xp} XP • ${item.reward}", color = SuperColors.TextSecondary, fontSize = 7.8.sp)
            }
            when {
                passed -> Icon(Icons.Outlined.TaskAlt, contentDescription = null, tint = SuperColors.Green, modifier = Modifier.size(17.dp))
                current -> Text("فعلی", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 8.sp, modifier = Modifier.background(SuperColors.BlueSoft, SuperShapes.Pill).padding(horizontal = 7.dp, vertical = 4.dp))
                else -> Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color(0xFFAAB6C5), modifier = Modifier.size(16.dp))
            }
        }
    }
}
