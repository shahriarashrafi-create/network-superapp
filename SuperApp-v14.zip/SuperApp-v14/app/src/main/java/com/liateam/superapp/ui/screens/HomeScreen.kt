package com.liateam.superapp.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.designsystem.SuperUserAvatar
import com.liateam.superapp.ui.designsystem.LevelEmblem
import com.liateam.superapp.ui.designsystem.CoinStarAsset
import com.liateam.superapp.ui.designsystem.ComboAsset
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.MotivationalQuotes
import com.liateam.superapp.ui.model.homeDestinations

private data class ShortcutVisual(
    val icon: ImageVector,
    val accent: Color,
    val accent2: Color,
    val soft: Color
)

private enum class HomeSheet { LEVEL, COIN, COMBO }

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onStartNextAction: (Int) -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val nextAction = tasks.firstOrNull { it.status.name == "TODO" } ?: tasks.first()
    val quote = remember { MotivationalQuotes.all.random() }
    var openSheet by remember { mutableStateOf<HomeSheet?>(null) }
    val comboCount = (1 + tasks.count { it.status.name == "DONE" }).coerceAtMost(7)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF6FBFF), Color.White, Color(0xFFF8FBFF))
                )
            )
    ) {
        HomeAmbientBackground()

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val compact = maxHeight < 650.dp
            val headerGap = if (compact) 4.dp else 8.dp
            val sectionGap = if (compact) 7.dp else 11.dp
            val missionHeight = if (compact) 112.dp else 126.dp
            val journeyHeight = if (compact) 78.dp else 102.dp
            val shortcutsHeight = if (compact) 184.dp else 202.dp

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        start = SuperDimens.ScreenPadding,
                        end = SuperDimens.ScreenPadding,
                        top = contentPadding.calculateTopPadding() + 2.dp,
                        bottom = contentPadding.calculateBottomPadding() + 2.dp
                    )
            ) {
                HomeHeader(
                    quote = quote,
                    onNotifications = { onOpenDestination(HomeDestination.NOTIFICATIONS) },
                    onProfile = { onOpenDestination(HomeDestination.PROFILE) }
                )
                Spacer(Modifier.height(headerGap))
                StatusStrip(
                    comboCount = comboCount,
                    onLevelClick = { openSheet = HomeSheet.LEVEL },
                    onCoinClick = { openSheet = HomeSheet.COIN },
                    onComboClick = { openSheet = HomeSheet.COMBO }
                )
                Spacer(Modifier.height(sectionGap))

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth().height(missionHeight),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RewardChestWidget(
                            modifier = Modifier.weight(0.27f).fillMaxHeight(),
                            onClick = { onOpenDestination(HomeDestination.REWARD_STORE) }
                        )
                        NextActionHero(
                            modifier = Modifier.weight(0.73f).fillMaxHeight(),
                            task = nextAction,
                            onStart = { onStartNextAction(nextAction.id) }
                        )
                    }
                }

                Spacer(Modifier.height(if (compact) 5.dp else 8.dp))
                GamifiedJourneyPath(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(journeyHeight)
                )
                Spacer(Modifier.weight(1f))
                ShortcutPager(
                    modifier = Modifier.height(shortcutsHeight),
                    onOpenDestination = onOpenDestination
                )
            }
        }

        when (openSheet) {
            HomeSheet.LEVEL -> LevelBottomSheet(
                onDismiss = { openSheet = null },
                onOpenPath = {
                    openSheet = null
                    onOpenDestination(HomeDestination.LEVEL_PATH)
                }
            )
            HomeSheet.COIN -> CoinBottomSheet(
                onDismiss = { openSheet = null },
                onWallet = {
                    openSheet = null
                    onOpenDestination(HomeDestination.WALLET)
                },
                onStore = {
                    openSheet = null
                    onOpenDestination(HomeDestination.REWARD_STORE)
                }
            )
            HomeSheet.COMBO -> ComboBottomSheet(
                comboCount = comboCount,
                onDismiss = { openSheet = null }
            )
            null -> Unit
        }
    }
}

@Composable
private fun HomeAmbientBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
            color = Color(0xFF8CCBFF).copy(alpha = 0.17f),
            radius = size.width * 0.34f,
            center = Offset(size.width * 0.93f, size.height * 0.08f)
        )
        drawCircle(
            color = Color(0xFFD6EDFF).copy(alpha = 0.36f),
            radius = size.width * 0.30f,
            center = Offset(size.width * 0.06f, size.height * 0.015f)
        )
        drawCircle(
            color = Color(0xFFE9F6FF).copy(alpha = 0.38f),
            radius = size.width * 0.24f,
            center = Offset(size.width * 0.96f, size.height * 0.76f)
        )
    }
}

@Composable
private fun HomeHeader(
    quote: String,
    onNotifications: () -> Unit,
    onProfile: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(modifier = Modifier.fillMaxWidth().height(58.dp)) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(42.dp)
                    .shadow(4.dp, RoundedCornerShape(15.dp), clip = false)
                    .background(Color.White, RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onNotifications, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        Icons.Outlined.NotificationsNone,
                        contentDescription = "اعلان‌ها",
                        tint = SuperColors.Navy,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 4.dp, end = 4.dp)
                        .size(7.dp)
                        .background(Color(0xFFFF3D57), CircleShape)
                )
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column(
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.68f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "شهریار",
                        color = SuperColors.Navy,
                        fontWeight = FontWeight.Black,
                        fontSize = 25.sp,
                        lineHeight = 26.sp,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    AdaptiveMotivationText(quote)
                }
            }

            Box(
                modifier = Modifier.align(Alignment.CenterEnd).size(48.dp),
                contentAlignment = Alignment.Center
            ) {
                SuperUserAvatar(size = 48.dp)
                IconButton(onClick = onProfile, modifier = Modifier.fillMaxSize()) { }
            }
        }
    }
}

@Composable
private fun AdaptiveMotivationText(quote: String) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val widthPerChar = maxWidth.value / quote.length.coerceAtLeast(1)
        val font = when {
            widthPerChar >= 12f -> 12.sp
            widthPerChar >= 9f -> 11.2.sp
            widthPerChar >= 7f -> 10.4.sp
            widthPerChar >= 5.5f -> 9.6.sp
            else -> 8.8.sp
        }
        Text(
            text = quote,
            color = SuperColors.TextSecondary,
            fontSize = font,
            lineHeight = font,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun StatusStrip(
    comboCount: Int,
    onLevelClick: () -> Unit,
    onCoinClick: () -> Unit,
    onComboClick: () -> Unit
) {
    val xpProgress by animateFloatAsState(targetValue = 0.48f, animationSpec = tween(650), label = "homeXp")
    val comboActive = comboCount >= 3
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .shadow(3.dp, RoundedCornerShape(19.dp), clip = false),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(19.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .border(0.7.dp, SuperColors.BorderBlue.copy(alpha = 0.54f), RoundedCornerShape(19.dp))
                    .padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RankStat(Modifier.weight(1.0f).clickable(onClick = onLevelClick))
                Hairline()
                Row(
                    modifier = Modifier.weight(1.55f).fillMaxHeight().clickable(onClick = onLevelClick),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(27.dp).background(Color(0xFFE3F2FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Bolt, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(5.dp))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("240 / 500", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.6.sp)
                            Spacer(Modifier.weight(1f))
                            Text("48٪", color = SuperColors.BlueDeep, fontWeight = FontWeight.Black, fontSize = 8.3.sp)
                        }
                        Spacer(Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { xpProgress },
                            modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                            color = SuperColors.Blue,
                            trackColor = Color(0xFFDCEAF8)
                        )
                    }
                }
                Hairline()
                CoinStat(Modifier.weight(0.82f).clickable(onClick = onCoinClick))
                Hairline()
                ComboStat(
                    modifier = Modifier.weight(0.98f).clickable(onClick = onComboClick),
                    comboCount = comboCount,
                    active = comboActive
                )
            }
        }
    }
}

@Composable
private fun RankStat(modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        LevelEmblem(level = 3, size = 28.dp)
        Spacer(Modifier.width(4.dp))
        Text("سطح ۳", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.6.sp, maxLines = 1)
    }
}

@Composable
private fun CoinStat(modifier: Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        CoinStarAsset(size = 25.dp)
        Spacer(Modifier.width(4.dp))
        Text("۶۹۵", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.7.sp)
    }
}

@Composable
private fun ComboStat(modifier: Modifier, comboCount: Int, active: Boolean) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        ComboAsset(size = 24.dp, active = active)
        Spacer(Modifier.width(4.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text(
                if (active) "×${if (comboCount >= 7) 3 else 2}" else "$comboCount / 3",
                color = if (active) SuperColors.Orange else SuperColors.Navy,
                fontWeight = FontWeight.Black,
                fontSize = 10.3.sp,
                maxLines = 1
            )
            Text("کمبو", color = if (active) SuperColors.Orange else SuperColors.TextSecondary, fontWeight = FontWeight.Bold, fontSize = 7.sp)
        }
    }
}

@Composable
private fun Hairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .width(1.dp)
            .height(23.dp)
            .background(SuperColors.Border.copy(alpha = 0.60f))
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LevelBottomSheet(onDismiss: () -> Unit, onOpenPath: () -> Unit) {
    var selectedLevel by remember { mutableStateOf(3) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LevelEmblem(level = 3, size = 48.dp)
            Spacer(Modifier.height(5.dp))
            Text("سطح ۳", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Text("در مسیر لیدر", color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("240 / 500 XP", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
                Text("260 XP تا سطح ۴", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            }
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(
                progress = { 0.48f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.BlueSoft
            )
            Spacer(Modifier.height(9.dp))
            Text(
                "امروز +40 XP   •   این هفته +140 XP   •   میانگین روزانه 28",
                color = SuperColors.TextSecondary,
                fontWeight = FontWeight.Medium,
                fontSize = 8.4.sp,
                maxLines = 1
            )
            Spacer(Modifier.height(11.dp))
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    (1..5).forEach { level ->
                        LevelStep(
                            level = level,
                            passed = level < 3,
                            current = level == 3,
                            selected = level == selectedLevel,
                            onClick = { selectedLevel = level }
                        )
                        if (level < 5) LevelConnector(done = level < 3)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SuperColors.BlueSoft2,
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                    Text(
                        when {
                            selectedLevel < 3 -> "سطح $selectedLevel تکمیل شده • پاداش دریافت شده"
                            selectedLevel == 3 -> "سطح فعلی • 260 XP تا مرحله بعد"
                            else -> "سطح $selectedLevel • برای باز شدن به XP بیشتری نیاز داری"
                        },
                        color = SuperColors.Navy,
                        fontSize = 9.4.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MiniPill("+50 Coin", SuperColors.GoldDeep, SuperColors.GoldSoft)
                        MiniPill("Badge جدید", SuperColors.Purple, SuperColors.PurpleSoft)
                        if (selectedLevel >= 4) MiniPill("Unlock", SuperColors.Blue, SuperColors.BlueSoft)
                    }
                }
            }
            Spacer(Modifier.height(11.dp))
            Button(
                onClick = onOpenPath,
                modifier = Modifier.fillMaxWidth().height(42.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
            ) {
                Text("مشاهده مسیر کامل سطح‌ها", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.8.sp)
            }
        }
    }
}

@Composable
private fun MiniPill(text: String, color: Color, background: Color) {
    Text(
        text,
        color = color,
        fontWeight = FontWeight.Black,
        fontSize = 7.8.sp,
        modifier = Modifier.background(background, SuperShapes.Pill).padding(horizontal = 8.dp, vertical = 4.dp)
    )
}

@Composable
private fun LevelStep(
    level: Int,
    passed: Boolean,
    current: Boolean = false,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            LevelEmblem(level = level, size = if (current) 35.dp else 29.dp)
            if (selected) {
                Box(Modifier.size(if (current) 39.dp else 33.dp).border(1.5.dp, SuperColors.Blue, CircleShape))
            }
        }
        Text(
            level.toString(),
            color = if (passed || current) SuperColors.Navy else SuperColors.TextSecondary,
            fontWeight = if (current) FontWeight.Black else FontWeight.Bold,
            fontSize = 8.sp
        )
    }
}

@Composable
private fun LevelConnector(done: Boolean) {
    Box(Modifier.width(20.dp).height(2.dp).background(if (done) SuperColors.Blue else SuperColors.Border, CircleShape))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CoinBottomSheet(onDismiss: () -> Unit, onWallet: () -> Unit, onStore: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 26.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CoinStarAsset(size = 40.dp)
                Spacer(Modifier.width(9.dp))
                Column {
                    Text("۶۹۵ سکه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("موجودی قابل خرج", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                }
            }
            Spacer(Modifier.height(11.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                MiniStat("امروز", "+۷", SuperColors.Green, Modifier.weight(1f))
                MiniStat("این هفته", "+۳۴", SuperColors.Green, Modifier.weight(1f))
                MiniStat("خرج هفته", "−۱۲", SuperColors.Orange, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            MiniTransaction("معرفی یک نفر", "+۲", "امروز")
            MiniTransaction("تکمیل آموزش", "+۳", "امروز")
            MiniTransaction("صندوق پاداش", "+۵", "دیروز")
            Spacer(Modifier.height(11.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onWallet,
                    modifier = Modifier.weight(1f).height(40.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("کیف پول", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp) }
                Button(
                    onClick = onStore,
                    modifier = Modifier.weight(1f).height(40.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.GoldSoft)
                ) { Text("فروشگاه پاداش", color = SuperColors.GoldDeep, fontWeight = FontWeight.Black, fontSize = 10.sp) }
            }
            Spacer(Modifier.height(8.dp))
            Text("راه‌های دریافت: مأموریت، آموزش، تأیید فعالیت و صندوق پاداش", color = SuperColors.TextSecondary, fontSize = 8.2.sp, maxLines = 1)
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, color = color.copy(alpha = 0.07f), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 10.sp)
            Text(label, color = SuperColors.TextSecondary, fontSize = 7.4.sp)
        }
    }
}

@Composable
private fun MiniTransaction(title: String, amount: String, period: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).background(SuperColors.Gold, CircleShape))
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = SuperColors.Text, fontWeight = FontWeight.Medium, fontSize = 9.5.sp)
            Text(period, color = SuperColors.TextSecondary, fontSize = 7.sp)
        }
        Text(amount, color = if (amount.startsWith("−")) SuperColors.Orange else SuperColors.Green, fontWeight = FontWeight.Black, fontSize = 10.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ComboBottomSheet(comboCount: Int, onDismiss: () -> Unit) {
    val active = comboCount >= 3
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ComboAsset(size = 44.dp, active = active)
            Spacer(Modifier.height(6.dp))
            Text(if (active) "×${if (comboCount >= 7) 3 else 2}" else "کمبو", color = if (active) SuperColors.Orange else SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = if (active) 25.sp else 17.sp)
            if (!active) {
                val remaining = (3 - comboCount).coerceAtLeast(0)
                Text("$remaining اقدام دیگه تا فعال شدن کمبو", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (comboCount / 3f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = SuperColors.BlueSoft
                )
            } else {
                Text("24:18 باقی‌مانده", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text("$comboCount از ۷ اقدام • ${(7 - comboCount).coerceAtLeast(0)} اقدام تا ×3", color = SuperColors.TextSecondary, fontSize = 8.8.sp)
            }
            Spacer(Modifier.height(11.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                MiniStat("وضعیت", "$comboCount/3", if (active) SuperColors.Orange else SuperColors.Blue, Modifier.weight(1f))
                MiniStat("رکورد امروز", "×3", SuperColors.Purple, Modifier.weight(1f))
                MiniStat("پاداش امروز", "+40 XP", SuperColors.Green, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Text("۳ اقدام → ×2   •   ۷ اقدام → ×3", color = SuperColors.TextSecondary, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Text("بهترین کمبو این هفته ×3 • ۳ بار فعال شده", color = SuperColors.TextSecondary, fontSize = 8.sp)
            if (active) Text("۵ دقیقه آخر با هشدار نارنجی مشخص می‌شود", color = SuperColors.Orange, fontSize = 8.sp)
        }
    }
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier.shadow(5.dp, RoundedCornerShape(22.dp), clip = false),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        listOf(Color.White, Color(0xFFF4FAFF), Color(0xFFEAF5FF))
                    )
                )
                .border(0.9.dp, Color(0xFFAED8FA), RoundedCornerShape(22.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.72f),
                    radius = size.height * 0.68f,
                    center = Offset(size.width * 0.22f, size.height * 0.54f)
                )
            }
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoalPathIllustration(modifier = Modifier.width(78.dp).fillMaxHeight())
                    Spacer(Modifier.width(5.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            modifier = Modifier.weight(1f).fillMaxHeight(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.End
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("قدم بعدی", color = SuperColors.BlueDeep, fontWeight = FontWeight.Black, fontSize = 9.5.sp)
                                Spacer(Modifier.width(5.dp))
                                Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(15.dp))
                            }
                            Spacer(Modifier.height(2.dp))
                            Text(
                                task.title,
                                color = SuperColors.Navy,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                task.subtitle,
                                color = SuperColors.TextSecondary,
                                fontWeight = FontWeight.Medium,
                                fontSize = 8.6.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(7.dp))
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    RewardChip("+20", SuperColors.BlueDeep, Color(0xFFE8F4FF))
                                    RewardChip("+2", SuperColors.GoldDeep, SuperColors.GoldSoft)
                                    Button(
                                        onClick = onStart,
                                        modifier = Modifier.height(34.dp).width(72.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.BlueStrong)
                                    ) {
                                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(2.dp))
                                        Text("شروع", color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RewardChip(text: String, accent: Color, background: Color) {
    Box(
        modifier = Modifier
            .height(30.dp)
            .background(background, SuperShapes.Pill)
            .border(1.dp, accent.copy(alpha = 0.20f), SuperShapes.Pill)
            .padding(horizontal = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = accent, fontWeight = FontWeight.Black, fontSize = 8.5.sp, maxLines = 1)
    }
}

@Composable
private fun GoalPathIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawCircle(Color(0xFFCFEAFF).copy(alpha = 0.62f), radius = h * 0.43f, center = Offset(w * 0.58f, h * 0.53f))

        fun cube(cx: Float, cy: Float, s: Float, top: Color, left: Color, right: Color) {
            val topPath = Path().apply {
                moveTo(cx, cy - s * 0.45f)
                lineTo(cx + s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx - s * 0.55f, cy - s * 0.15f)
                close()
            }
            val leftPath = Path().apply {
                moveTo(cx - s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx, cy + s * 0.72f)
                lineTo(cx - s * 0.55f, cy + s * 0.42f)
                close()
            }
            val rightPath = Path().apply {
                moveTo(cx + s * 0.55f, cy - s * 0.15f)
                lineTo(cx, cy + s * 0.15f)
                lineTo(cx, cy + s * 0.72f)
                lineTo(cx + s * 0.55f, cy + s * 0.42f)
                close()
            }
            drawPath(topPath, top)
            drawPath(leftPath, left)
            drawPath(rightPath, right)
        }

        cube(w * 0.25f, h * 0.65f, h * 0.23f, Color.White, Color(0xFFD6E8FB), Color(0xFFE8F3FF))
        cube(w * 0.46f, h * 0.56f, h * 0.25f, Color(0xFF55B5FF), SuperColors.BlueStrong, Color(0xFF3599EF))
        cube(w * 0.66f, h * 0.47f, h * 0.28f, Color.White, Color(0xFFD9EAFB), Color(0xFFF4FAFF))
        cube(w * 0.80f, h * 0.31f, h * 0.31f, SuperColors.GoldBright, SuperColors.Gold, Color(0xFFEAA215))

        val arrow = Path().apply {
            moveTo(w * 0.17f, h * 0.58f)
            cubicTo(w * 0.31f, h * 0.50f, w * 0.39f, h * 0.35f, w * 0.55f, h * 0.30f)
        }
        drawPath(arrow, SuperColors.Blue, style = Stroke(width = 7f, cap = StrokeCap.Round))
        val arrowHead = Path().apply {
            moveTo(w * 0.55f, h * 0.30f)
            lineTo(w * 0.48f, h * 0.27f)
            lineTo(w * 0.52f, h * 0.38f)
            close()
        }
        drawPath(arrowHead, SuperColors.Blue)

        drawLine(SuperColors.GoldDeep, Offset(w * 0.80f, h * 0.12f), Offset(w * 0.80f, h * 0.29f), strokeWidth = 4f, cap = StrokeCap.Round)
        val flag = Path().apply {
            moveTo(w * 0.80f, h * 0.12f)
            lineTo(w * 0.93f, h * 0.15f)
            lineTo(w * 0.80f, h * 0.20f)
            close()
        }
        drawPath(flag, SuperColors.Gold)

        cube(w * 0.34f, h * 0.24f, h * 0.09f, Color(0xFFFFE99B), SuperColors.GoldBright, SuperColors.Gold)
        cube(w * 0.58f, h * 0.20f, h * 0.08f, Color(0xFFB8DFFF), Color(0xFF76B9F2), SuperColors.Blue)
    }
}

@Composable
private fun RewardChestWidget(modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(22.dp), clip = false)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFFFFEFA), Color(0xFFFFF7DE), Color(0xFFFFFCF5))
                    )
                )
                .border(0.9.dp, Color(0xFFF3D587), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(
                    color = SuperColors.GoldBright.copy(alpha = 0.16f),
                    radius = size.width * 0.52f,
                    center = Offset(size.width * 0.50f, size.height * 0.44f)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                ChestIllustration(modifier = Modifier.width(70.dp).height(72.dp))
                Box(
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.94f), SuperShapes.Pill)
                        .border(0.8.dp, SuperColors.Gold.copy(alpha = 0.56f), SuperShapes.Pill)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("1:24:15", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 9.5.sp)
                }
            }
        }
    }
}

@Composable
private fun ChestIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawCircle(SuperColors.Gold.copy(alpha = 0.14f), radius = minOf(w, h) * 0.46f, center = Offset(w * 0.50f, h * 0.52f))

        val bodyLeft = w * 0.16f
        val bodyTop = h * 0.42f
        val bodyWidth = w * 0.68f
        val bodyHeight = h * 0.34f
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFC743), Color(0xFFF39A13))),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFFE477), Color(0xFFFFB829))),
            topLeft = Offset(bodyLeft, h * 0.25f),
            size = Size(bodyWidth, h * 0.28f),
            cornerRadius = CornerRadius(18f, 18f)
        )
        drawRoundRect(
            color = Color(0xFF74461E),
            topLeft = Offset(bodyLeft, h * 0.48f),
            size = Size(bodyWidth, h * 0.09f),
            cornerRadius = CornerRadius(7f, 7f)
        )
        drawRoundRect(
            color = SuperColors.GoldBright,
            topLeft = Offset(w * 0.43f, h * 0.44f),
            size = Size(w * 0.14f, h * 0.22f),
            cornerRadius = CornerRadius(6f, 6f)
        )
        drawCircle(Color.White.copy(alpha = 0.82f), radius = w * 0.045f, center = Offset(w * 0.32f, h * 0.31f))
        drawCircle(Color.White.copy(alpha = 0.90f), radius = w * 0.032f, center = Offset(w * 0.72f, h * 0.19f))
        drawLine(SuperColors.GoldBright, Offset(w * 0.08f, h * 0.27f), Offset(w * 0.02f, h * 0.17f), 3f, StrokeCap.Round)
        drawLine(SuperColors.GoldBright, Offset(w * 0.92f, h * 0.30f), Offset(w * 0.98f, h * 0.20f), 3f, StrokeCap.Round)
    }
}

@Composable
private fun GamifiedJourneyPath(modifier: Modifier = Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Soft landscape made entirely with Compose Canvas.
            drawOval(
                color = Color(0xFFDDF3E9).copy(alpha = 0.72f),
                topLeft = Offset(-w * 0.10f, h * 0.55f),
                size = Size(w * 0.42f, h * 0.58f)
            )
            drawOval(
                color = Color(0xFFDCEFFF).copy(alpha = 0.82f),
                topLeft = Offset(w * 0.66f, h * 0.43f),
                size = Size(w * 0.44f, h * 0.64f)
            )
            drawOval(
                color = Color.White.copy(alpha = 0.90f),
                topLeft = Offset(w * 0.31f, h * 0.02f),
                size = Size(w * 0.18f, h * 0.16f)
            )
            drawOval(
                color = Color.White.copy(alpha = 0.86f),
                topLeft = Offset(w * 0.55f, h * 0.12f),
                size = Size(w * 0.14f, h * 0.12f)
            )

            val route = Path().apply {
                moveTo(w * 0.12f, h * 0.70f)
                cubicTo(
                    w * 0.30f, h * 0.88f,
                    w * 0.50f, h * 0.50f,
                    w * 0.66f, h * 0.67f
                )
                cubicTo(
                    w * 0.76f, h * 0.75f,
                    w * 0.82f, h * 0.42f,
                    w * 0.91f, h * 0.38f
                )
            }
            drawPath(
                path = route,
                color = SuperColors.Blue.copy(alpha = 0.62f),
                style = Stroke(
                    width = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 7.dp.toPx()))
                )
            )

            // Current checkpoint pedestal.
            drawCircle(Color(0xFFD8ECFF), radius = 22.dp.toPx(), center = Offset(w * 0.12f, h * 0.70f))
            drawCircle(SuperColors.Blue, radius = 14.dp.toPx(), center = Offset(w * 0.12f, h * 0.70f))
            drawCircle(Color.White, radius = 4.dp.toPx(), center = Offset(w * 0.12f, h * 0.70f))

            // Completed checkpoint.
            drawCircle(Color.White, radius = 19.dp.toPx(), center = Offset(w * 0.47f, h * 0.58f))
            drawCircle(SuperColors.GreenSoft, radius = 15.dp.toPx(), center = Offset(w * 0.47f, h * 0.58f))
            drawCircle(SuperColors.Green, radius = 7.dp.toPx(), center = Offset(w * 0.47f, h * 0.58f))
            drawLine(
                color = Color.White,
                start = Offset(w * 0.445f, h * 0.58f),
                end = Offset(w * 0.463f, h * 0.60f),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Color.White,
                start = Offset(w * 0.463f, h * 0.60f),
                end = Offset(w * 0.495f, h * 0.55f),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Locked checkpoint.
            drawCircle(Color.White, radius = 19.dp.toPx(), center = Offset(w * 0.68f, h * 0.67f))
            drawCircle(Color(0xFFE9EFF6), radius = 15.dp.toPx(), center = Offset(w * 0.68f, h * 0.67f))
            drawCircle(Color(0xFF93A7BC), radius = 5.dp.toPx(), center = Offset(w * 0.68f, h * 0.67f))

            // Target island / flag.
            drawOval(
                color = Color(0xFFFFEAB4),
                topLeft = Offset(w * 0.835f, h * 0.45f),
                size = Size(w * 0.13f, h * 0.18f)
            )
            drawLine(
                color = SuperColors.GoldDeep,
                start = Offset(w * 0.90f, h * 0.51f),
                end = Offset(w * 0.90f, h * 0.20f),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            val flag = Path().apply {
                moveTo(w * 0.90f, h * 0.20f)
                lineTo(w * 0.965f, h * 0.245f)
                lineTo(w * 0.90f, h * 0.29f)
                close()
            }
            drawPath(flag, SuperColors.Gold)

            // Tiny game-world accents.
            drawCircle(SuperColors.Green.copy(alpha = 0.55f), radius = 4.dp.toPx(), center = Offset(w * 0.05f, h * 0.66f))
            drawCircle(SuperColors.Green.copy(alpha = 0.45f), radius = 5.dp.toPx(), center = Offset(w * 0.82f, h * 0.58f))
            drawCircle(SuperColors.Sky.copy(alpha = 0.42f), radius = 3.dp.toPx(), center = Offset(w * 0.36f, h * 0.24f))
        }

        Surface(
            modifier = Modifier.align(Alignment.TopStart).padding(start = 9.dp, top = 2.dp),
            color = SuperColors.Blue,
            shape = SuperShapes.Pill,
            shadowElevation = 1.dp
        ) {
            Text(
                "شما اینجایید",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 7.7.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                maxLines = 1
            )
        }

        Surface(
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 7.dp, top = 1.dp),
            color = SuperColors.GoldSoft,
            shape = SuperShapes.Pill
        ) {
            Text(
                "هدف بعدی",
                color = SuperColors.GoldDeep,
                fontWeight = FontWeight.Black,
                fontSize = 7.7.sp,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ShortcutPager(
    modifier: Modifier,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val pages = remember { homeDestinations().chunked(6) }
    val pagerState = rememberPagerState(pageCount = { pages.size })

    Column(modifier = modifier.fillMaxWidth()) {
        BoxWithConstraints(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val pageWidth = maxWidth - 12.dp
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    pageSize = PageSize.Fixed(pageWidth),
                    pageSpacing = 8.dp,
                    contentPadding = PaddingValues(start = 0.dp, end = 12.dp),
                    beyondViewportPageCount = 1
                ) { page ->
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ShortcutGrid(
                            destinations = pages[page],
                            onOpenDestination = onOpenDestination
                        )
                    }
                }
            }

            if (pagerState.currentPage < pages.lastIndex) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .width(12.dp)
                        .background(Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.50f))))
                )
            }
        }

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier.fillMaxWidth().height(16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(pages.size) { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(if (index == pagerState.currentPage) 8.dp else 5.dp)
                            .background(
                                if (index == pagerState.currentPage) SuperColors.Blue else Color(0xFFD8E6F3),
                                CircleShape
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun ShortcutGrid(
    destinations: List<HomeDestination>,
    onOpenDestination: (HomeDestination) -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val tileWidth = ((maxWidth - 16.dp) / 3).coerceAtMost(96.dp)
        val top = destinations.take(3)
        val bottom = destinations.drop(3)
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(1.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                top.forEach { destination ->
                    ShortcutTile(
                        modifier = Modifier.width(tileWidth),
                        destination = destination,
                        onClick = { onOpenDestination(destination) }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically
            ) {
                bottom.forEach { destination ->
                    ShortcutTile(
                        modifier = Modifier.width(tileWidth),
                        destination = destination,
                        onClick = { onOpenDestination(destination) }
                    )
                }
                repeat(3 - bottom.size) { Spacer(Modifier.width(tileWidth)) }
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    modifier: Modifier,
    destination: HomeDestination,
    onClick: () -> Unit
) {
    val visual = shortcutVisual(destination)
    val metric = shortcutMetric(destination)
    Column(
        modifier = modifier
            .padding(horizontal = 4.dp, vertical = 3.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.size(68.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(visual.soft.copy(alpha = 0.78f), radius = size.minDimension * 0.47f)
                drawCircle(visual.accent.copy(alpha = 0.06f), radius = size.minDimension * 0.36f)
                drawCircle(Color.White.copy(alpha = 0.76f), radius = size.minDimension * 0.29f)
            }
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .shadow(2.dp, CircleShape, clip = false)
                    .background(Color.White, CircleShape)
                    .border(1.dp, visual.accent.copy(alpha = 0.22f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(26.dp))
            }
            if (metric != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .background(visual.accent, CircleShape)
                        .border(1.5.dp, Color.White, CircleShape)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(metric, color = Color.White, fontWeight = FontWeight.Black, fontSize = 7.5.sp, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(3.dp))
        Text(
            destination.title,
            color = SuperColors.Navy,
            fontWeight = FontWeight.Black,
            fontSize = 9.8.sp,
            maxLines = 1,
            textAlign = TextAlign.Center,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun shortcutMetric(destination: HomeDestination): String? = when (destination) {
    HomeDestination.PROGRESS -> "48٪"
    HomeDestination.NETWORK -> "+2"
    HomeDestination.ACADEMY -> "60٪"
    HomeDestination.MY_WEEK -> "5"
    HomeDestination.ACTIONS -> "4"
    HomeDestination.CUSTOMERS -> "3"
    HomeDestination.SALES -> "135M"
    HomeDestination.EVENTS -> "1 نزدیک"
    HomeDestination.LIBRARY -> "2 ادامه"
    HomeDestination.GOALS -> "27٪"
    HomeDestination.RANK_REWARDS -> "سطح 3"
    HomeDestination.NOTIFICATIONS -> "5 جدید"
    HomeDestination.ORDERS -> "2 باز"
    HomeDestination.ACHIEVEMENTS -> "7 نشان"
    else -> null
}

@Composable
private fun ShortcutIllustration(destination: HomeDestination, visual: ShortcutVisual) {
    MinimalShortcutIllustration(visual = visual)
}

@Composable
private fun MinimalShortcutIllustration(visual: ShortcutVisual) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawOval(visual.soft.copy(alpha = 0.72f), Offset(w * 0.14f, h * 0.60f), Size(w * 0.72f, h * 0.22f))
            drawCircle(visual.accent2.copy(alpha = 0.10f), radius = h * 0.18f, center = Offset(w * 0.72f, h * 0.30f))
            drawCircle(visual.accent.copy(alpha = 0.08f), radius = h * 0.13f, center = Offset(w * 0.31f, h * 0.34f))
        }
        Box(
            modifier = Modifier
                .size(47.dp)
                .shadow(3.dp, CircleShape, clip = false)
                .background(Color.White, CircleShape)
                .border(1.dp, visual.accent.copy(alpha = 0.20f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun CastleIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFDFF4FF), Offset(w * 0.12f, h * 0.70f), Size(w * 0.76f, h * 0.20f))
        drawRoundRect(Color.White, Offset(w * 0.20f, h * 0.48f), Size(w * 0.60f, h * 0.30f), CornerRadius(12f))
        listOf(0.24f, 0.50f, 0.76f).forEach { x ->
            drawRoundRect(Color(0xFF5CAAF5), Offset(w * (x - 0.09f), h * 0.32f), Size(w * 0.18f, h * 0.40f), CornerRadius(8f))
            val roof = Path().apply {
                moveTo(w * x, h * 0.16f)
                lineTo(w * (x - 0.12f), h * 0.35f)
                lineTo(w * (x + 0.12f), h * 0.35f)
                close()
            }
            drawPath(roof, Color(0xFF236FD6))
            drawLine(SuperColors.GoldDeep, Offset(w * x, h * 0.14f), Offset(w * x, h * 0.07f), 2.5f)
            val flag = Path().apply {
                moveTo(w * x, h * 0.07f)
                lineTo(w * (x + 0.09f), h * 0.09f)
                lineTo(w * x, h * 0.13f)
                close()
            }
            drawPath(flag, SuperColors.Gold)
        }
        drawRoundRect(SuperColors.BlueDeep, Offset(w * 0.43f, h * 0.56f), Size(w * 0.14f, h * 0.22f), CornerRadius(18f, 18f))
        drawCircle(Color(0xFFBFE8FF).copy(alpha = 0.65f), radius = w * 0.08f, center = Offset(w * 0.50f, h * 0.75f))
    }
}

@Composable
private fun TreeIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFD9F5E9), Offset(w * 0.12f, h * 0.72f), Size(w * 0.76f, h * 0.17f))
        drawRoundRect(Color(0xFF9B5D2E), Offset(w * 0.46f, h * 0.43f), Size(w * 0.10f, h * 0.34f), CornerRadius(8f))
        drawCircle(Color(0xFF2FB176), radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.38f))
        drawCircle(Color(0xFF46C789), radius = w * 0.16f, center = Offset(w * 0.35f, h * 0.43f))
        drawCircle(Color(0xFF56D59A), radius = w * 0.15f, center = Offset(w * 0.65f, h * 0.43f))
        drawCircle(Color(0xFF238E61), radius = w * 0.14f, center = Offset(w * 0.50f, h * 0.25f))
        repeat(5) { i ->
            val x = w * (0.20f + i * 0.15f)
            val color = if (i % 2 == 0) Color(0xFF1C8A60) else Color(0xFF35A978)
            val p = Path().apply {
                moveTo(x, h * 0.69f)
                lineTo(x - w * 0.05f, h * 0.82f)
                lineTo(x + w * 0.05f, h * 0.82f)
                close()
            }
            drawPath(p, color)
        }
    }
}

@Composable
private fun AcademyIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        for (i in 0..3) {
            drawRoundRect(
                color = if (i % 2 == 0) Color.White else Color(0xFFE9F3FF),
                topLeft = Offset(w * (0.22f + i * 0.08f), h * (0.69f - i * 0.10f)),
                size = Size(w * 0.46f, h * 0.12f),
                cornerRadius = CornerRadius(8f)
            )
        }
        val cap = Path().apply {
            moveTo(w * 0.50f, h * 0.20f)
            lineTo(w * 0.80f, h * 0.33f)
            lineTo(w * 0.50f, h * 0.46f)
            lineTo(w * 0.20f, h * 0.33f)
            close()
        }
        drawPath(cap, Color(0xFF205DC2))
        drawRoundRect(Color(0xFF154898), Offset(w * 0.36f, h * 0.39f), Size(w * 0.28f, h * 0.12f), CornerRadius(5f))
        drawLine(SuperColors.Gold, Offset(w * 0.76f, h * 0.34f), Offset(w * 0.76f, h * 0.56f), 3f, StrokeCap.Round)
        drawCircle(SuperColors.GoldBright, radius = w * 0.025f, center = Offset(w * 0.76f, h * 0.58f))
    }
}

@Composable
private fun GlobeIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w * 0.48f, h * 0.47f)
        val r = minOf(w, h) * 0.28f
        drawCircle(Color(0xFF3B93E9), radius = r, center = c)
        drawCircle(Color(0xFF0E6FD1), radius = r, center = c, style = Stroke(width = 4f))
        drawArc(Color(0xFFB7E4FF), -70f, 140f, false, Offset(c.x - r * 0.75f, c.y - r), Size(r * 1.5f, r * 2f), style = Stroke(width = 3f))
        drawArc(Color(0xFFB7E4FF), 110f, 140f, false, Offset(c.x - r, c.y - r * 0.7f), Size(r * 2f, r * 1.4f), style = Stroke(width = 3f))
        val land = Path().apply {
            moveTo(c.x - r * 0.55f, c.y - r * 0.25f)
            lineTo(c.x - r * 0.05f, c.y - r * 0.55f)
            lineTo(c.x + r * 0.35f, c.y - r * 0.15f)
            lineTo(c.x + r * 0.10f, c.y + r * 0.10f)
            lineTo(c.x - r * 0.30f, c.y + r * 0.18f)
            close()
        }
        drawPath(land, Color(0xFF57C57D))
        drawArc(SuperColors.Gold, 200f, 235f, false, Offset(c.x - r * 1.28f, c.y - r * 0.86f), Size(r * 2.6f, r * 1.75f), style = Stroke(width = 3f))
        val plane = Path().apply {
            moveTo(w * 0.78f, h * 0.20f)
            lineTo(w * 0.91f, h * 0.17f)
            lineTo(w * 0.82f, h * 0.27f)
            lineTo(w * 0.79f, h * 0.37f)
            lineTo(w * 0.74f, h * 0.27f)
            close()
        }
        drawPath(plane, Color(0xFF246EC8))
    }
}

@Composable
private fun ClipboardIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawRoundRect(Color(0xFFFFC84A), Offset(w * 0.27f, h * 0.18f), Size(w * 0.48f, h * 0.64f), CornerRadius(13f))
        drawRoundRect(Color.White, Offset(w * 0.31f, h * 0.24f), Size(w * 0.40f, h * 0.53f), CornerRadius(10f))
        drawRoundRect(Color(0xFF2E78D4), Offset(w * 0.41f, h * 0.13f), Size(w * 0.20f, h * 0.12f), CornerRadius(9f))
        for (i in 0..2) {
            val y = h * (0.38f + i * 0.14f)
            drawRoundRect(Color(0xFFE9F3FF), Offset(w * 0.38f, y - h * 0.04f), Size(w * 0.09f, h * 0.08f), CornerRadius(4f))
            drawLine(SuperColors.Blue, Offset(w * 0.39f, y), Offset(w * 0.42f, y + h * 0.02f), 2.5f, StrokeCap.Round)
            drawLine(SuperColors.Blue, Offset(w * 0.42f, y + h * 0.02f), Offset(w * 0.46f, y - h * 0.025f), 2.5f, StrokeCap.Round)
            drawLine(Color(0xFF86A6C7), Offset(w * 0.51f, y), Offset(w * 0.65f, y), 3f, StrokeCap.Round)
        }
        drawLine(Color(0xFFEC8F21), Offset(w * 0.72f, h * 0.30f), Offset(w * 0.62f, h * 0.72f), 7f, StrokeCap.Round)
        drawLine(Color(0xFFF6B548), Offset(w * 0.70f, h * 0.30f), Offset(w * 0.60f, h * 0.72f), 3f, StrokeCap.Round)
    }
}

@Composable
private fun PeopleIllustration(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawOval(Color(0xFFE8F3FF), Offset(w * 0.12f, h * 0.70f), Size(w * 0.76f, h * 0.16f))
        val xs = listOf(0.31f, 0.50f, 0.69f)
        val colors = listOf(Color(0xFF4D92E7), Color(0xFF1B6BCB), Color(0xFFF1A33B))
        xs.forEachIndexed { index, x ->
            drawCircle(Color(0xFFFFD0AE), radius = w * 0.08f, center = Offset(w * x, h * (0.37f + if (index == 1) -0.04f else 0f)))
            drawRoundRect(colors[index], Offset(w * (x - 0.09f), h * (0.49f + if (index == 1) -0.04f else 0f)), Size(w * 0.18f, h * 0.25f), CornerRadius(18f, 18f))
            val hairY = h * (0.31f + if (index == 1) -0.04f else 0f)
            drawArc(Color(0xFF263B55), 180f, 180f, true, Offset(w * (x - 0.08f), hairY), Size(w * 0.16f, w * 0.12f))
        }
        drawRoundRect(Color(0xFFFFF0D7), Offset(w * 0.68f, h * 0.21f), Size(w * 0.18f, h * 0.12f), CornerRadius(8f))
        drawCircle(SuperColors.Gold, radius = w * 0.025f, center = Offset(w * 0.78f, h * 0.27f))
    }
}

@Composable
private fun GenericShortcutIllustration(visual: ShortcutVisual) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawOval(visual.soft, Offset(w * 0.15f, h * 0.63f), Size(w * 0.70f, h * 0.20f))
            val pedestal = Path().apply {
                moveTo(w * 0.27f, h * 0.63f)
                lineTo(w * 0.50f, h * 0.52f)
                lineTo(w * 0.73f, h * 0.63f)
                lineTo(w * 0.50f, h * 0.76f)
                close()
            }
            drawPath(pedestal, visual.accent.copy(alpha = 0.18f))
            drawCircle(visual.accent2.copy(alpha = 0.13f), radius = h * 0.16f, center = Offset(w * 0.72f, h * 0.28f))
        }
        Box(
            modifier = Modifier
                .size(43.dp)
                .shadow(3.dp, CircleShape, clip = false)
                .background(Color.White, CircleShape)
                .border(1.dp, visual.accent.copy(alpha = 0.22f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun CodeAvatar(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawCircle(Color(0xFFD7EDFF), radius = minOf(w, h) * 0.48f, center = center)
        drawCircle(Color(0xFFFFCFAC), radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.43f))
        drawArc(Color(0xFF243B5A), 180f, 180f, true, Offset(w * 0.26f, h * 0.18f), Size(w * 0.48f, h * 0.33f))
        drawRoundRect(SuperColors.Blue, Offset(w * 0.27f, h * 0.66f), Size(w * 0.46f, h * 0.28f), CornerRadius(18f, 18f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.43f, h * 0.43f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.57f, h * 0.43f))
        drawArc(Color(0xFFE48A6A), 15f, 150f, false, Offset(w * 0.42f, h * 0.49f), Size(w * 0.16f, h * 0.09f), style = Stroke(width = 2f, cap = StrokeCap.Round))
    }
}

@Composable
private fun CrownMini(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * 0.10f, size.height * 0.72f)
            lineTo(size.width * 0.22f, size.height * 0.25f)
            lineTo(size.width * 0.46f, size.height * 0.53f)
            lineTo(size.width * 0.62f, size.height * 0.18f)
            lineTo(size.width * 0.88f, size.height * 0.68f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun CrownBadge(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawCircle(Color(0xFFFFF6D8), radius = minOf(size.width, size.height) * 0.48f, center = center)
        val p = Path().apply {
            moveTo(size.width * 0.12f, size.height * 0.70f)
            lineTo(size.width * 0.20f, size.height * 0.30f)
            lineTo(size.width * 0.42f, size.height * 0.50f)
            lineTo(size.width * 0.55f, size.height * 0.20f)
            lineTo(size.width * 0.72f, size.height * 0.50f)
            lineTo(size.width * 0.88f, size.height * 0.28f)
            lineTo(size.width * 0.84f, size.height * 0.74f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(SuperColors.GoldBright, SuperColors.Gold)))
        drawRoundRect(SuperColors.GoldDeep, Offset(size.width * 0.18f, size.height * 0.72f), Size(size.width * 0.67f, size.height * 0.11f), CornerRadius(4f))
    }
}

@Composable
private fun CoinIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawCircle(SuperColors.GoldBright, radius = minOf(size.width, size.height) * 0.45f, center = center)
        drawCircle(SuperColors.GoldDeep, radius = minOf(size.width, size.height) * 0.45f, center = center, style = Stroke(width = 2.5f))
        drawCircle(Color(0xFFFFE885), radius = minOf(size.width, size.height) * 0.29f, center = center)
        drawCircle(SuperColors.Gold, radius = minOf(size.width, size.height) * 0.10f, center = center)
    }
}

@Composable
private fun FlameIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * 0.52f, size.height * 0.08f)
            cubicTo(size.width * 0.70f, size.height * 0.34f, size.width * 0.90f, size.height * 0.43f, size.width * 0.80f, size.height * 0.70f)
            cubicTo(size.width * 0.70f, size.height * 0.95f, size.width * 0.28f, size.height * 0.96f, size.width * 0.18f, size.height * 0.70f)
            cubicTo(size.width * 0.10f, size.height * 0.48f, size.width * 0.30f, size.height * 0.34f, size.width * 0.38f, size.height * 0.16f)
            cubicTo(size.width * 0.42f, size.height * 0.30f, size.width * 0.50f, size.height * 0.34f, size.width * 0.52f, size.height * 0.08f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(Color(0xFFFF7A24), Color(0xFFFFB21E))))
        drawCircle(Color(0xFFFFE26A), radius = size.width * 0.12f, center = Offset(size.width * 0.51f, size.height * 0.68f))
    }
}

private fun shortcutVisual(destination: HomeDestination): ShortcutVisual = when (destination) {
    HomeDestination.PROGRESS -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.Sky, SuperColors.BlueSoft)
    HomeDestination.NETWORK -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, Color(0xFF59C995), SuperColors.GreenSoft)
    HomeDestination.ACADEMY -> ShortcutVisual(Icons.Outlined.School, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.MY_WEEK -> ShortcutVisual(Icons.Outlined.CalendarMonth, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.ACTIONS -> ShortcutVisual(Icons.Outlined.TaskAlt, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.CUSTOMERS -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Orange, SuperColors.Gold, SuperColors.OrangeSoft)
    HomeDestination.LEADER_CENTER -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.BlueDeep, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.GOALS -> ShortcutVisual(Icons.Outlined.TrackChanges, SuperColors.Red, SuperColors.Orange, SuperColors.RedSoft)
    HomeDestination.RANK_REWARDS -> ShortcutVisual(Icons.Outlined.EmojiEvents, SuperColors.GoldDeep, SuperColors.GoldBright, SuperColors.GoldSoft)
    HomeDestination.EVENTS -> ShortcutVisual(Icons.Outlined.Event, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.LIBRARY -> ShortcutVisual(Icons.Outlined.MenuBook, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.SALES -> ShortcutVisual(Icons.Outlined.ShoppingCart, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.REPORTS -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.PERSONAL_STORE -> ShortcutVisual(Icons.Outlined.Storefront, SuperColors.Orange, SuperColors.Purple, SuperColors.OrangeSoft)
    HomeDestination.PROFILE -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.SETTINGS -> ShortcutVisual(Icons.Outlined.Settings, SuperColors.TextSecondary, SuperColors.Blue, SuperColors.NeutralSoft)
    HomeDestination.SEARCH -> ShortcutVisual(Icons.Outlined.Search, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.NOTIFICATIONS -> ShortcutVisual(Icons.Outlined.NotificationsNone, SuperColors.Red, SuperColors.Gold, SuperColors.RedSoft)
    HomeDestination.FOCUS -> ShortcutVisual(Icons.Outlined.Timer, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TREE -> ShortcutVisual(Icons.Outlined.AccountTree, SuperColors.Green, SuperColors.Blue, SuperColors.GreenSoft)
    HomeDestination.PROFILE_360 -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.Purple, SuperColors.BlueSoft)
    HomeDestination.GROUPS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Orange, SuperColors.Green, SuperColors.OrangeSoft)
    HomeDestination.CHANNELS -> ShortcutVisual(Icons.Outlined.ChatBubbleOutline, SuperColors.Purple, SuperColors.Blue, SuperColors.PurpleSoft)
    HomeDestination.TEAM_MEMBERS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.Gold, SuperColors.GreenSoft)
    HomeDestination.DREAM_BOARD -> ShortcutVisual(Icons.Outlined.Flag, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.ACHIEVEMENTS -> ShortcutVisual(Icons.Outlined.WorkspacePremium, SuperColors.GoldDeep, SuperColors.Purple, SuperColors.GoldSoft)
    HomeDestination.LEADERBOARD -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.REWARD_STORE -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
    HomeDestination.WEBSITE -> ShortcutVisual(Icons.Outlined.Language, SuperColors.Blue, SuperColors.Green, SuperColors.BlueSoft)
    HomeDestination.ORDERS -> ShortcutVisual(Icons.Outlined.ReceiptLong, SuperColors.Green, SuperColors.Orange, SuperColors.GreenSoft)
    HomeDestination.LEVEL_PATH -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.Gold, SuperColors.BlueSoft)
    HomeDestination.WALLET -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.GoldDeep, SuperColors.Blue, SuperColors.GoldSoft)
}
