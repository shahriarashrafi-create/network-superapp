package com.liateam.superapp.ui.designsystem

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/** Code-only gamification assets. No bitmap or decorative image files are used. */
@Composable
fun LevelEmblem(level: Int, size: Dp, modifier: Modifier = Modifier) {
    val palette = when (level.coerceAtLeast(1)) {
        1 -> Triple(Color(0xFFB86B3E), Color(0xFFE1A27A), Color(0xFFFFE1C7))
        2 -> Triple(Color(0xFF78879A), Color(0xFFB5C1CE), Color(0xFFF0F4F8))
        3 -> Triple(Color(0xFFC9850C), Color(0xFFFFD85A), Color(0xFFFFF4D2))
        4 -> Triple(Color(0xFF0D6FE8), Color(0xFF68BCFF), Color(0xFFEAF4FF))
        5 -> Triple(Color(0xFF6848D8), Color(0xFF9A82F2), Color(0xFFF1EDFF))
        6 -> Triple(Color(0xFF198A68), Color(0xFF47C697), Color(0xFFE8F8F1))
        7 -> Triple(Color(0xFFC45918), Color(0xFFFFA24A), Color(0xFFFFF2DE))
        8 -> Triple(Color(0xFF23428A), Color(0xFF5B78D6), Color(0xFFE8EDFF))
        9 -> Triple(Color(0xFF772C79), Color(0xFFBD6AC1), Color(0xFFF8EAF9))
        else -> Triple(Color(0xFF8A5B00), Color(0xFFFFC947), Color(0xFFFFF2B2))
    }

    Box(
        modifier = modifier
            .size(size)
            .background(palette.third, CircleShape)
            .border(1.dp, palette.second.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val peaks = when {
                level <= 2 -> 3
                level <= 5 -> 4
                else -> 5
            }
            val crown = Path().apply {
                moveTo(w * 0.19f, h * 0.64f)
                lineTo(w * 0.13f, h * 0.32f)
                for (i in 0 until peaks) {
                    val x = w * (0.20f + i * (0.60f / (peaks - 1).coerceAtLeast(1)))
                    val y = if (i % 2 == 0) h * 0.22f else h * 0.35f
                    lineTo(x, y)
                }
                lineTo(w * 0.87f, h * 0.32f)
                lineTo(w * 0.81f, h * 0.64f)
                close()
            }
            drawPath(crown, brush = Brush.verticalGradient(listOf(palette.second, palette.first)))
            drawRoundRect(
                color = palette.first,
                topLeft = Offset(w * 0.20f, h * 0.61f),
                size = Size(w * 0.60f, h * 0.14f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.05f)
            )
            val gemCount = (level.coerceIn(1, 5))
            repeat(gemCount) { index ->
                val x = w * (0.30f + index * (0.40f / (gemCount - 1).coerceAtLeast(1)))
                drawCircle(
                    color = when ((level + index) % 3) {
                        0 -> Color(0xFF2D8BFF)
                        1 -> Color(0xFFEF5B72)
                        else -> Color.White
                    },
                    radius = w * 0.035f,
                    center = Offset(x, h * 0.67f)
                )
            }
            if (level >= 7) {
                drawCircle(Color.White.copy(alpha = 0.70f), radius = w * 0.055f, center = Offset(w * 0.78f, h * 0.20f))
                drawLine(Color.White, Offset(w * 0.78f, h * 0.11f), Offset(w * 0.78f, h * 0.29f), strokeWidth = w * 0.018f, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
fun CoinStarAsset(size: Dp, modifier: Modifier = Modifier) {
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val r = this.size.minDimension * 0.45f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFFF8C9), SuperColors.GoldBright, SuperColors.Gold),
                    center = Offset(c.x * 0.78f, c.y * 0.72f),
                    radius = r * 1.35f
                ),
                radius = r,
                center = c
            )
            drawCircle(SuperColors.GoldDeep.copy(alpha = 0.45f), radius = r, center = c, style = Stroke(width = this.size.minDimension * 0.045f))
            drawCircle(Color.White.copy(alpha = 0.36f), radius = r * 0.74f, center = c, style = Stroke(width = this.size.minDimension * 0.025f))

            val outer = r * 0.46f
            val inner = outer * 0.48f
            val points = 5
            val star = Path()
            repeat(points * 2) { i ->
                val angle = (-Math.PI / 2 + i * Math.PI / points).toFloat()
                val rr = if (i % 2 == 0) outer else inner
                val x = c.x + cos(angle.toDouble()).toFloat() * rr
                val y = c.y + sin(angle.toDouble()).toFloat() * rr
                if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
            }
            star.close()
            drawPath(star, color = Color.White.copy(alpha = 0.96f))
            drawCircle(Color.White.copy(alpha = 0.72f), radius = r * 0.11f, center = Offset(c.x - r * 0.34f, c.y - r * 0.34f))
        }
    }
}

@Composable
fun ComboAsset(size: Dp, modifier: Modifier = Modifier, active: Boolean = false) {
    val accent = if (active) Color(0xFFFF7A1A) else SuperColors.Blue
    val soft = if (active) Color(0xFFFFF0DE) else SuperColors.BlueSoft
    Box(
        modifier = modifier
            .size(size)
            .background(soft, CircleShape)
            .border(1.dp, accent.copy(alpha = 0.22f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val bolt = Path().apply {
                moveTo(w * 0.57f, h * 0.13f)
                lineTo(w * 0.29f, h * 0.53f)
                lineTo(w * 0.48f, h * 0.53f)
                lineTo(w * 0.39f, h * 0.86f)
                lineTo(w * 0.72f, h * 0.43f)
                lineTo(w * 0.54f, h * 0.43f)
                close()
            }
            drawPath(bolt, brush = Brush.verticalGradient(listOf(if (active) Color(0xFFFFC04B) else SuperColors.Sky, accent)))
            drawArc(
                color = accent.copy(alpha = 0.55f),
                startAngle = -50f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = Offset(w * 0.12f, h * 0.12f),
                size = Size(w * 0.76f, h * 0.76f),
                style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
            )
        }
    }
}
