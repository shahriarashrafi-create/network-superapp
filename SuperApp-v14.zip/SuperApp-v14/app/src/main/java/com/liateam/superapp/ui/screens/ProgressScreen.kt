package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

private enum class PathState { DONE, FAILED, CURRENT, LOCKED, NEUTRAL }

private data class PathStep(
    val title: String,
    val subtitle: String,
    val rewardXp: Int,
    val rewardCoin: Int,
    val state: PathState,
    val unlockCondition: String = "مرحله قبلی را کامل کن"
)

private val pathSteps = listOf(
    PathStep("آشنایی و ذهنیت", "پایه‌های شروع حرفه‌ای", 30, 3, PathState.DONE),
    PathStep("ارتباط‌سازی", "ساخت لیست و شروع گفت‌وگو", 40, 4, PathState.DONE),
    PathStep("دعوت یک نفر", "گفت‌وگوی کوتاه با یک مخاطب جدید", 20, 2, PathState.CURRENT),
    PathStep("معرفی محصول", "معرفی ساده و درست محصول", 25, 3, PathState.LOCKED, "دعوت فعلی را انجام بده"),
    PathStep("پیگیری حرفه‌ای", "Follow-up با اقدام بعدی روشن", 25, 3, PathState.LOCKED),
    PathStep("اولین مشتری", "ثبت اولین خرید موفق", 40, 5, PathState.LOCKED),
    PathStep("ساخت تیم", "ثبت عضو و شروع مسیر حمایتی", 50, 6, PathState.LOCKED),
    PathStep("تکثیر و رهبری", "کمک به تیم برای تکرار مسیر", 70, 8, PathState.LOCKED)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onStartCurrent: () -> Unit = {}
) {
    var selected by remember { mutableStateOf<PathStep?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(SuperColors.Background),
        contentPadding = PaddingValues(
            start = SuperDimens.ScreenPadding,
            end = SuperDimens.ScreenPadding,
            top = contentPadding.calculateTopPadding() + 7.dp,
            bottom = contentPadding.calculateBottomPadding() + 18.dp
        ),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { ProgressHeader(onBack) }
        item { ProgressStats() }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("مسیر اصلی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text("این هفته +2 مرحله", color = SuperColors.Green, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            }
        }
        items(pathSteps.size) { index ->
            ZigzagStepCard(
                index = index,
                step = pathSteps[index],
                onClick = { selected = pathSteps[index] },
                onStart = if (pathSteps[index].state == PathState.CURRENT) onStartCurrent else null
            )
        }
        item { MilestoneCard() }
    }

    selected?.let { step ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
        ) {
            PathStepSheet(
                step = step,
                onClose = { selected = null },
                onStart = {
                    selected = null
                    onStartCurrent()
                }
            )
        }
    }
}

@Composable
private fun ProgressHeader(onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(42.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("مسیر پیشرفت", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 23.sp)
            Text("قدم فعلی را انجام بده و مسیر را باز کن", color = SuperColors.TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ProgressStats() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                MiniPathStat("3 / 8", "مرحله", SuperColors.Blue, Modifier.weight(1f))
                MiniPathStat("38٪", "پیشرفت", SuperColors.Green, Modifier.weight(1f))
                MiniPathStat("+180", "XP این هفته", SuperColors.GoldDeep, Modifier.weight(1f))
                MiniPathStat("3", "روز فعالیت", SuperColors.Purple, Modifier.weight(1f))
            }
            Spacer(Modifier.height(9.dp))
            LinearProgressIndicator(
                progress = { 0.38f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.BlueSoft
            )
        }
    }
}

@Composable
private fun MiniPathStat(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Text(label, color = SuperColors.TextSecondary, fontSize = 7.5.sp, maxLines = 1)
    }
}

@Composable
private fun ZigzagStepCard(
    index: Int,
    step: PathStep,
    onClick: () -> Unit,
    onStart: (() -> Unit)?
) {
    val accent = pathAccent(step.state)
    val background = pathBackground(step.state)
    val leftShift = index % 2 == 0

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (leftShift) Arrangement.Start else Arrangement.End
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.91f)
                .then(if (leftShift) Modifier.padding(end = 24.dp) else Modifier.padding(start = 24.dp))
                .clickable(onClick = onClick)
                .then(
                    if (step.state == PathState.CURRENT) Modifier.border(1.4.dp, SuperColors.Blue.copy(alpha = 0.65f), RoundedCornerShape(18.dp))
                    else Modifier
                ),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = background),
            elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 2.dp else 0.8.dp)
        ) {
            Row(Modifier.padding(horizontal = 11.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).background(Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(pathIcon(step.state), contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
                }
                Column(modifier = Modifier.weight(1f).padding(horizontal = 9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", color = accent, fontWeight = FontWeight.Black, fontSize = 10.sp)
                        Spacer(Modifier.width(5.dp))
                        Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp, maxLines = 1)
                    }
                    Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
                        SmallPathChip("+${step.rewardCoin} سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
                    }
                }
                if (onStart != null) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.height(34.dp),
                        contentPadding = PaddingValues(horizontal = 9.dp),
                        shape = RoundedCornerShape(11.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("شروع", fontSize = 8.5.sp, fontWeight = FontWeight.Black)
                    }
                } else {
                    Text(pathLabel(step.state), color = accent, fontSize = 8.8.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun SmallPathChip(text: String, color: Color, background: Color) {
    Box(Modifier.background(background, SuperShapes.Pill).padding(horizontal = 6.dp, vertical = 3.dp)) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 7.3.sp)
    }
}

@Composable
private fun MilestoneCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SuperColors.GoldSoft),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.GoldDeep)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text("Milestone بعدی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text("تکمیل این مسیر → Badge + Reward + باز شدن مسیر بعدی", color = SuperColors.TextSecondary, fontSize = 8.7.sp)
            }
        }
    }
}

@Composable
private fun PathStepSheet(step: PathStep, onClose: () -> Unit, onStart: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(pathBackground(step.state), CircleShape), contentAlignment = Alignment.Center) {
                Icon(pathIcon(step.state), contentDescription = null, tint = pathAccent(step.state), modifier = Modifier.size(24.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            }
        }
        Spacer(Modifier.height(11.dp))
        Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 10.5.sp)
        Spacer(Modifier.height(11.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
            SmallPathChip("+${step.rewardCoin} سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
        }
        if (step.state == PathState.LOCKED) {
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2), shape = RoundedCornerShape(14.dp)) {
                Text("شرط باز شدن: ${step.unlockCondition}", modifier = Modifier.padding(11.dp), color = SuperColors.TextSecondary, fontSize = 9.5.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        when (step.state) {
            PathState.CURRENT -> Button(
                onClick = onStart,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
            ) { Text("شروع / ادامه", fontWeight = FontWeight.Black) }

            PathState.FAILED -> OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Outlined.Refresh, contentDescription = null, tint = SuperColors.Red)
                Spacer(Modifier.width(5.dp))
                Text("بازنشانی و تلاش دوباره", color = SuperColors.Red, fontWeight = FontWeight.Bold)
            }

            else -> OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth().height(44.dp), shape = RoundedCornerShape(14.dp)) {
                Text("بستن", color = SuperColors.Blue, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun pathAccent(state: PathState): Color = when (state) {
    PathState.DONE -> SuperColors.Green
    PathState.FAILED -> SuperColors.Red
    PathState.CURRENT -> SuperColors.Blue
    PathState.LOCKED -> Color(0xFF9AA8BA)
    PathState.NEUTRAL -> SuperColors.TextSecondary
}

private fun pathBackground(state: PathState): Color = when (state) {
    PathState.DONE -> SuperColors.GreenSoft
    PathState.FAILED -> SuperColors.RedSoft
    PathState.CURRENT -> SuperColors.BlueSoft
    PathState.LOCKED -> Color.White
    PathState.NEUTRAL -> Color.White
}

private fun pathIcon(state: PathState): ImageVector = when (state) {
    PathState.DONE -> Icons.Outlined.Check
    PathState.FAILED -> Icons.Outlined.Close
    PathState.CURRENT -> Icons.Outlined.Flag
    PathState.LOCKED -> Icons.Outlined.Lock
    PathState.NEUTRAL -> Icons.Outlined.Flag
}

private fun pathLabel(state: PathState): String = when (state) {
    PathState.DONE -> "تکمیل شد"
    PathState.FAILED -> "ناموفق"
    PathState.CURRENT -> "فعلی"
    PathState.LOCKED -> "قفل"
    PathState.NEUTRAL -> "بدون وضعیت"
}
