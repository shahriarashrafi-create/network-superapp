import java.util.zip.ZipFile

plugins { id("com.android.application"); kotlin("android") }

// Keep the installed v0.1 development signature. Never silently replace its key.
val signingKey = rootProject.file("signing/royesh-development.jks")
if (!signingKey.exists()) {
    val workspace = System.getenv("GITHUB_WORKSPACE")?.let(::File)
    val archives = workspace?.walkTopDown()?.filter { it.isFile && it.extension.equals("zip", true) && ".git" !in it.toPath().map { p -> p.toString() } }?.toList().orEmpty()
    val keys = archives.mapNotNull { archive ->
        runCatching { ZipFile(archive).use { zip ->
            val entry = zip.entries().asSequence().firstOrNull { it.name.endsWith("signing/royesh-development.jks") && it.size in 1..20000 }
            entry?.let { zip.getInputStream(it).use { stream -> stream.readBytes() } }
        } }.getOrNull()
    }
    if (keys.isNotEmpty()) {
        check(keys.all { it.contentEquals(keys.first()) }) { "Different Royesh development keys found. Keep the original v0.1 ZIP only." }
        signingKey.parentFile.mkdirs(); signingKey.writeBytes(keys.first())
    }
}
check(signingKey.exists()) { "Original development key missing. Keep the v0.1 source ZIP in the GitHub repository, or copy its signing/royesh-development.jks here. See README.md." }

android {
    namespace = "ir.royesh.app"
    compileSdk = 35
    defaultConfig { applicationId = "ir.royesh.app"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "0.2.0" }
    signingConfigs { getByName("debug") { storeFile = signingKey; storePassword = "android"; keyAlias = "royesh-development"; keyPassword = "android" } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.15" }
}
dependencies {
    implementation(project(":core"))
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
}
