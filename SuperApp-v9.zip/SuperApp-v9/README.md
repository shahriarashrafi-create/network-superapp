# SuperApp v9

Build 9 / version 1.7.0.

This iteration polishes the Legacy-inspired Home and Profile experience:
- unified minimal shortcut assets across all 30 Home links
- shared minimal user avatar component
- softer Legacy blue / navy / gold visual system
- tighter Home spacing and reward/action cards
- polished horizontal 5-page shortcut pager
- cleaner Profile assets and achievement icons
- lighter card shadows and stronger typography consistency
- compact safe-area bottom navigation
- polished placeholder destinations for unfinished modules

UI artwork is built with Jetpack Compose, Material vectors, Canvas, shapes and gradients. No decorative bitmap/background images are included.
