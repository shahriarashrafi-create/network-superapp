package com.liateam.superapp.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.designsystem.SuperUserAvatar
import com.liateam.superapp.ui.model.HomeDestination

@Composable
fun ProfileScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF8FCFF), Color.White, Color(0xFFF3F9FF))
                )
            )
    ) {
        ProfileAmbientBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = SuperDimens.ScreenPadding,
                    end = SuperDimens.ScreenPadding,
                    top = contentPadding.calculateTopPadding() + 5.dp,
                    bottom = contentPadding.calculateBottomPadding() + 12.dp
                )
                .verticalScroll(rememberScrollState())
        ) {
            ProfileTopBar(
                onBack = onBack,
                onSettings = { onOpenDestination(HomeDestination.SETTINGS) }
            )
            Spacer(Modifier.height(8.dp))
            ProfileHero()
            Spacer(Modifier.height(9.dp))
            AchievementPreview(onClick = { onOpenDestination(HomeDestination.ACHIEVEMENTS) })
            Spacer(Modifier.height(9.dp))
            PersonalStats()
            Spacer(Modifier.height(9.dp))
            GoalAndRankRow(
                onGoal = { onOpenDestination(HomeDestination.GOALS) },
                onRank = { onOpenDestination(HomeDestination.RANK_REWARDS) }
            )
            Spacer(Modifier.height(9.dp))
            EducationCard(onClick = { onOpenDestination(HomeDestination.ACADEMY) })
            Spacer(Modifier.height(9.dp))
            PersonalLinks(onOpenDestination = onOpenDestination)
            Spacer(Modifier.height(9.dp))
            AccountSettings(onOpenDestination = onOpenDestination)
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun ProfileAmbientBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        drawCircle(
            Color(0xFFBDE2FF).copy(alpha = 0.19f),
            radius = size.width * 0.33f,
            center = Offset(size.width * 0.92f, size.height * 0.07f)
        )
        drawCircle(
            Color(0xFFE1F2FF).copy(alpha = 0.28f),
            radius = size.width * 0.28f,
            center = Offset(size.width * 0.05f, size.height * 0.02f)
        )
    }
}

@Composable
private fun ProfileTopBar(onBack: () -> Unit, onSettings: () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth().height(44.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .shadow(3.dp, RoundedCornerShape(12.dp), clip = false)
                    .background(Color.White, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onBack, modifier = Modifier.fillMaxSize()) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy, modifier = Modifier.size(21.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Text("پروفایل من", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .shadow(3.dp, RoundedCornerShape(12.dp), clip = false)
                    .background(Color.White, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onSettings, modifier = Modifier.fillMaxSize()) {
                    Icon(Icons.Outlined.Settings, contentDescription = "تنظیمات", tint = SuperColors.Navy, modifier = Modifier.size(21.dp))
                }
            }
        }
    }
}

@Composable
private fun ProfileHero() {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(4.dp, RoundedCornerShape(24.dp), clip = false),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(Color.White, Color(0xFFF1F8FF), Color(0xFFE7F4FF))
                    )
                )
                .border(0.9.dp, Color(0xFFC4E2FA), RoundedCornerShape(24.dp))
                .padding(13.dp)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(86.dp), contentAlignment = Alignment.Center) {
                        SuperUserAvatar(size = 82.dp)
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .size(24.dp)
                                .background(Color.White, CircleShape)
                                .border(1.dp, SuperColors.BorderBlue, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Edit, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(14.dp))
                        }
                    }

                    Spacer(Modifier.width(12.dp))

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                            Text("شهریار", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 21.sp)
                            Text("همین حالا از شک عبور کن", color = SuperColors.TextSecondary, fontSize = 9.5.sp, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                                IdentityChip(Icons.Outlined.Groups, "تیم من", SuperColors.Blue)
                                IdentityChip(Icons.Outlined.Person, "حامی من", SuperColors.Green)
                            }
                        }
                    }

                    Spacer(Modifier.width(9.dp))
                    RankBadge()
                }
            }

            Spacer(Modifier.height(11.dp))
            ProfileResourceStrip()
        }
    }
}

@Composable
private fun IdentityChip(icon: ImageVector, text: String, accent: Color) {
    Row(
        modifier = Modifier
            .background(Color.White.copy(alpha = 0.72f), SuperShapes.Pill)
            .padding(horizontal = 7.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(3.dp))
        Text(text, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 8.7.sp, maxLines = 1)
    }
}

@Composable
private fun RankBadge() {
    Column(
        modifier = Modifier
            .width(88.dp)
            .background(Color.White.copy(alpha = 0.78f), RoundedCornerShape(18.dp))
            .border(0.8.dp, SuperColors.Border.copy(alpha = 0.75f), RoundedCornerShape(18.dp))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(43.dp)
                .background(SuperColors.GoldSoft, CircleShape)
                .border(1.dp, SuperColors.Gold.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.WorkspacePremium, contentDescription = null, tint = SuperColors.GoldDeep, modifier = Modifier.size(25.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text("سطح ۳", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.sp)
        Text("مسیر لیدر", color = SuperColors.GoldDeep, fontWeight = FontWeight.Bold, fontSize = 7.8.sp)
    }
}

@Composable
private fun ProfileResourceStrip() {
    val xpProgress by animateFloatAsState(targetValue = 0.48f, animationSpec = tween(700), label = "profileXp")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .background(Color.White.copy(alpha = 0.88f), RoundedCornerShape(17.dp))
                .border(0.8.dp, SuperColors.Border.copy(alpha = 0.75f), RoundedCornerShape(17.dp))
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.4f), verticalArrangement = Arrangement.Center) {
                Text("240 / 500 XP", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { xpProgress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = Color(0xFFE1ECF8)
                )
            }
            ResourceDivider()
            ProfileMiniResource(Icons.Outlined.EmojiEvents, "۶۹۵", "سکه", SuperColors.GoldDeep, Modifier.weight(0.72f))
            ResourceDivider()
            ProfileMiniResource(Icons.Outlined.Flag, "۷", "روز متوالی", SuperColors.Orange, Modifier.weight(0.82f))
            ResourceDivider()
            ProfileMiniResource(Icons.Outlined.Assessment, "68%", "تا سطح بعد", SuperColors.Blue, Modifier.weight(0.86f))
        }
    }
}

@Composable
private fun ProfileMiniResource(icon: ImageVector, value: String, label: String, accent: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(3.dp))
            Text(value, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
        }
        Text(label, color = SuperColors.TextSecondary, fontWeight = FontWeight.Medium, fontSize = 7.5.sp, maxLines = 1)
    }
}

@Composable
private fun ResourceDivider() {
    Box(modifier = Modifier.padding(horizontal = 7.dp).width(1.dp).height(28.dp).background(SuperColors.Border))
}

@Composable
private fun AchievementPreview(onClick: () -> Unit) {
    SectionCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("دستاوردهای اخیر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
            Spacer(Modifier.weight(1f))
            Text(
                "مشاهده همه",
                color = SuperColors.Blue,
                fontWeight = FontWeight.Black,
                fontSize = 9.5.sp,
                modifier = Modifier.clickable(onClick = onClick)
            )
        }
        Spacer(Modifier.height(9.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                AchievementBadge(Icons.Outlined.WorkspacePremium, "شروع قدرتمند", SuperColors.Blue)
                AchievementBadge(Icons.Outlined.TaskAlt, "۱۰ اقدام", SuperColors.Green)
                AchievementBadge(Icons.Outlined.Groups, "۵ مشتری", SuperColors.Purple)
                AchievementBadge(Icons.Outlined.MenuBook, "تکمیل دوره", Color(0xFF23A96D))
                AchievementBadge(Icons.Outlined.EmojiEvents, "اولین فروش", SuperColors.Orange)
            }
        }
    }
}

@Composable
private fun AchievementBadge(icon: ImageVector, title: String, accent: Color) {
    Column(modifier = Modifier.width(61.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(43.dp)
                .background(accent.copy(alpha = 0.10f), CircleShape)
                .border(1.dp, accent.copy(alpha = 0.24f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(3.dp))
        Text(title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 7.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
private fun PersonalStats() {
    SectionCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("آمار من", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
            Spacer(Modifier.weight(1f))
            Text("این ماه", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
        }
        Spacer(Modifier.height(8.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                PersonalStat("28", "اقدامات", Icons.Outlined.TaskAlt, SuperColors.Blue, Modifier.weight(1f))
                PersonalStat("12", "مشتری فعال", Icons.Outlined.Groups, SuperColors.Blue, Modifier.weight(1f))
                PersonalStat("135M", "فروش ماه", Icons.Outlined.Assessment, SuperColors.Green, Modifier.weight(1f))
                PersonalStat("42", "افراد شبکه", Icons.Outlined.Groups, SuperColors.BlueDeep, Modifier.weight(1f))
                PersonalStat("5", "دوره کامل", Icons.Outlined.MenuBook, SuperColors.Purple, Modifier.weight(1f))
                PersonalStat("7", "هدف انجام‌شده", Icons.Outlined.TrackChanges, SuperColors.Green, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PersonalStat(value: String, label: String, icon: ImageVector, accent: Color, modifier: Modifier) {
    Column(
        modifier = modifier
            .background(accent.copy(alpha = 0.055f), RoundedCornerShape(12.dp))
            .padding(vertical = 7.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(3.dp))
        Text(value, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.5.sp)
        Text(label, color = SuperColors.TextSecondary, fontWeight = FontWeight.Medium, fontSize = 6.8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun GoalAndRankRow(onGoal: () -> Unit, onRank: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ProgressFeatureCard(
            modifier = Modifier.weight(1f),
            title = "هدف فعلی",
            main = "درآمد ماهانه 500M",
            detail = "135M / 500M",
            progress = 0.27f,
            accent = SuperColors.Blue,
            icon = Icons.Outlined.TrackChanges,
            onClick = onGoal
        )
        ProgressFeatureCard(
            modifier = Modifier.weight(1f),
            title = "مسیر رتبه بعدی",
            main = "سطح ۴ — لیدر ارشد",
            detail = "۳ اقدام باقی مانده",
            progress = 0.68f,
            accent = SuperColors.Purple,
            icon = Icons.Outlined.WorkspacePremium,
            onClick = onRank
        )
    }
}

@Composable
private fun ProgressFeatureCard(
    modifier: Modifier,
    title: String,
    main: String,
    detail: String,
    progress: Float,
    accent: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.shadow(3.dp, RoundedCornerShape(19.dp), clip = false),
        onClick = onClick,
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(0.8.dp, SuperColors.Border, RoundedCornerShape(19.dp))
                .padding(11.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(5.dp))
                Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.5.sp, maxLines = 1)
            }
            Spacer(Modifier.height(7.dp))
            Text(main, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 10.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = accent,
                trackColor = accent.copy(alpha = 0.12f)
            )
            Spacer(Modifier.height(5.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(detail, color = SuperColors.TextSecondary, fontSize = 7.5.sp, maxLines = 1)
                Text("${(progress * 100).toInt()}%", color = accent, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
            }
        }
    }
}

@Composable
private fun EducationCard(onClick: () -> Unit) {
    SectionCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("آموزش من", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
            Spacer(Modifier.weight(1f))
            Text("ورود به آموزش", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.5.sp, modifier = Modifier.clickable(onClick = onClick))
        }
        Spacer(Modifier.height(8.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                LearningIllustration(Modifier.size(width = 74.dp, height = 65.dp))
                Spacer(Modifier.width(8.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                        Text("جادوی کار پاره‌وقت", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        Text("فصل ۳ از ۱۰", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                        Spacer(Modifier.height(7.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LinearProgressIndicator(
                                progress = { 0.60f },
                                modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                                color = SuperColors.Blue,
                                trackColor = Color(0xFFE1ECF8)
                            )
                            Spacer(Modifier.width(7.dp))
                            Text("60%", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Button(
                    onClick = onClick,
                    modifier = Modifier.height(34.dp).width(68.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue),
                    contentPadding = PaddingValues(horizontal = 7.dp)
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                    Text("ادامه", color = Color.White, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
                }
            }
        }
    }
}

@Composable
private fun LearningIllustration(modifier: Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(SuperColors.PurpleSoft, CircleShape)
                .border(1.dp, SuperColors.Purple.copy(alpha = 0.20f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.MenuBook, contentDescription = null, tint = SuperColors.Purple, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun PersonalLinks(onOpenDestination: (HomeDestination) -> Unit) {
    SectionCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("لینک‌های من", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
            Spacer(Modifier.weight(1f))
            Text("مدیریت لینک‌ها", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.5.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            LinkTile(Icons.Outlined.Link, "لینک معرفی", "کپی لینک", SuperColors.Blue, Modifier.weight(1f)) { onOpenDestination(HomeDestination.PERSONAL_STORE) }
            LinkTile(Icons.Outlined.Storefront, "فروشگاه من", "لینک شخصی", SuperColors.Purple, Modifier.weight(1f)) { onOpenDestination(HomeDestination.PERSONAL_STORE) }
            LinkTile(Icons.Outlined.QrCode2, "QR کد", "اشتراک‌گذاری", SuperColors.BlueDeep, Modifier.weight(1f)) { onOpenDestination(HomeDestination.WEBSITE) }
            LinkTile(Icons.Outlined.Share, "اشتراک‌گذاری", "ارسال لینک", SuperColors.Green, Modifier.weight(1f)) { onOpenDestination(HomeDestination.WEBSITE) }
        }
    }
}

@Composable
private fun LinkTile(icon: ImageVector, title: String, subtitle: String, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .background(accent.copy(alpha = 0.055f), RoundedCornerShape(13.dp))
            .border(0.7.dp, accent.copy(alpha = 0.13f), RoundedCornerShape(13.dp))
            .padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 8.1.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = SuperColors.TextSecondary, fontSize = 6.8.sp, maxLines = 1)
    }
}

@Composable
private fun AccountSettings(onOpenDestination: (HomeDestination) -> Unit) {
    SectionCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Settings, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(6.dp))
            Text("تنظیمات و حساب کاربری", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.5.sp)
        }
        Spacer(Modifier.height(9.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SettingTile(Icons.Outlined.Person, "اطلاعات شخصی", "ویرایش", Modifier.weight(1f)) { onOpenDestination(HomeDestination.SETTINGS) }
            SettingTile(Icons.Outlined.Security, "امنیت", "رمز و دستگاه", Modifier.weight(1f)) { onOpenDestination(HomeDestination.SETTINGS) }
            SettingTile(Icons.Outlined.NotificationsNone, "اعلان‌ها", "مدیریت", Modifier.weight(1f)) { onOpenDestination(HomeDestination.NOTIFICATIONS) }
            SettingTile(Icons.Outlined.Language, "زبان و ظاهر", "تنظیمات", Modifier.weight(1f)) { onOpenDestination(HomeDestination.SETTINGS) }
        }
    }
}

@Composable
private fun SettingTile(icon: ImageVector, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .background(SuperColors.BlueSoft2, RoundedCornerShape(13.dp))
            .padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.size(28.dp).background(SuperColors.BlueSoft, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(17.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 7.8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(subtitle, color = SuperColors.TextSecondary, fontSize = 6.6.sp, maxLines = 1)
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().shadow(2.dp, RoundedCornerShape(20.dp), clip = false),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(0.8.dp, SuperColors.Border.copy(alpha = 0.75f), RoundedCornerShape(20.dp))
                .padding(12.dp),
            content = content
        )
    }
}

@Composable
private fun ProfileAvatar(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        drawCircle(Color(0xFFD7EDFF), radius = minOf(w, h) * 0.49f, center = center)
        drawCircle(Color(0xFFFFCFAC), radius = w * 0.22f, center = Offset(w * 0.50f, h * 0.43f))
        drawArc(Color(0xFF243B5A), 180f, 180f, true, Offset(w * 0.25f, h * 0.17f), Size(w * 0.50f, h * 0.34f))
        drawRoundRect(SuperColors.Blue, Offset(w * 0.25f, h * 0.66f), Size(w * 0.50f, h * 0.29f), CornerRadius(20f, 20f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.43f, h * 0.43f))
        drawCircle(Color(0xFF243B5A), radius = w * 0.022f, center = Offset(w * 0.57f, h * 0.43f))
        drawArc(Color(0xFFE48A6A), 15f, 150f, false, Offset(w * 0.42f, h * 0.49f), Size(w * 0.16f, h * 0.09f), style = Stroke(width = 2.3f, cap = StrokeCap.Round))
    }
}

@Composable
private fun ProfileCrown(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val p = Path().apply {
            moveTo(size.width * 0.10f, size.height * 0.72f)
            lineTo(size.width * 0.22f, size.height * 0.25f)
            lineTo(size.width * 0.46f, size.height * 0.53f)
            lineTo(size.width * 0.62f, size.height * 0.18f)
            lineTo(size.width * 0.88f, size.height * 0.68f)
            close()
        }
        drawPath(p, Color.White)
    }
}

@Composable
private fun HexRankIcon(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val c = center
        val r = size.minDimension * 0.46f
        val p = Path()
        for (i in 0..5) {
            val angle = Math.toRadians((60.0 * i) - 30.0)
            val x = c.x + (r * kotlin.math.cos(angle)).toFloat()
            val y = c.y + (r * kotlin.math.sin(angle)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        drawPath(p, Brush.verticalGradient(listOf(SuperColors.GoldBright, SuperColors.Gold)))
        drawPath(p, SuperColors.GoldDeep, style = Stroke(width = 3f))
        val crown = Path().apply {
            moveTo(size.width * 0.25f, size.height * 0.63f)
            lineTo(size.width * 0.30f, size.height * 0.38f)
            lineTo(size.width * 0.45f, size.height * 0.51f)
            lineTo(size.width * 0.55f, size.height * 0.31f)
            lineTo(size.width * 0.68f, size.height * 0.51f)
            lineTo(size.width * 0.77f, size.height * 0.38f)
            lineTo(size.width * 0.73f, size.height * 0.66f)
            close()
        }
        drawPath(crown, Color.White)
    }
}
