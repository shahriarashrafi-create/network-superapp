package app.networksuper.ui.progress

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.mutableStateListOf

/** Shared source of truth for Progress Path and Home. */
enum class StageStatus { COMPLETED, FAILED, CURRENT, UPCOMING }

data class ProgressStage(
    val id: Long,
    val number: Int,
    val title: String,
    val status: StageStatus
)

object ProgressPathStore {
    private const val PREFS_NAME = "progress_path_v1"
    private const val KEY_STAGES = "stages"

    private val defaultStages = listOf(
        ProgressStage(12L, 12, "نقطه اوج", StageStatus.UPCOMING),
        ProgressStage(11L, 11, "رهبری تیم", StageStatus.UPCOMING),
        ProgressStage(10L, 10, "ساخت عادت", StageStatus.UPCOMING),
        ProgressStage(9L, 9, "توسعه مهارت‌ها", StageStatus.UPCOMING),
        ProgressStage(8L, 8, "ارتباط با مشتری", StageStatus.UPCOMING),
        ProgressStage(7L, 7, "مهارت ارتباطی", StageStatus.UPCOMING),
        ProgressStage(6L, 6, "ورزش روزانه", StageStatus.CURRENT),
        ProgressStage(5L, 5, "مطالعه و یادگیری", StageStatus.COMPLETED),
        ProgressStage(4L, 4, "مدیریت مالی", StageStatus.COMPLETED),
        ProgressStage(3L, 3, "برنامه‌ریزی هفتگی", StageStatus.COMPLETED),
        ProgressStage(2L, 2, "هدف‌گذاری", StageStatus.COMPLETED),
        ProgressStage(1L, 1, "چشم‌انداز شخصی", StageStatus.COMPLETED)
    )

    val stages = mutableStateListOf<ProgressStage>().apply { addAll(defaultStages) }

    private var prefs: SharedPreferences? = null

    fun initialize(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val stored = prefs?.getString(KEY_STAGES, null)
        val parsed = stored?.let(::decodeStages).orEmpty()
        if (parsed.isNotEmpty()) {
            replaceWithRenumbered(parsed.sortedBy { it.number }, persistAfter = false)
            persist()
        } else {
            replaceWithRenumbered(defaultStages.sortedBy { it.number }, persistAfter = false)
            persist()
        }
    }

    fun currentStage(): ProgressStage? = stages.firstOrNull { it.status == StageStatus.CURRENT }

    fun currentOrdinal(): Int {
        val current = currentStage() ?: return 0
        val ascending = stages.sortedBy { it.number }
        return ascending.indexOfFirst { it.id == current.id }.let { if (it >= 0) it + 1 else 0 }
    }

    /** Number of selectable positions for the add/edit sheet. */
    fun positionCount(isNew: Boolean): Int = (stages.size + if (isNew) 1 else 0).coerceAtLeast(1)

    /** Insert a new card at [position]. Existing cards are shifted and all positions stay contiguous. */
    fun addStage(title: String, position: Int) {
        if (title.isBlank()) return
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        val nextId = (stages.maxOfOrNull { it.id } ?: 0L) + 1L
        ordered.add(
            insertionIndex,
            ProgressStage(
                id = nextId,
                number = position,
                title = title.trim(),
                status = StageStatus.UPCOMING
            )
        )
        replaceWithRenumbered(ordered)
    }

    /** Move the card to [position] instead of rejecting an already occupied position. */
    fun editStage(id: Long, title: String, position: Int) {
        if (title.isBlank()) return
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val oldIndex = ordered.indexOfFirst { it.id == id }
        if (oldIndex < 0) return

        val updated = ordered.removeAt(oldIndex).copy(title = title.trim())
        val insertionIndex = (position - 1).coerceIn(0, ordered.size)
        ordered.add(insertionIndex, updated)
        replaceWithRenumbered(ordered)
    }

    /** Delete a card and close the numbering gap automatically. */
    fun deleteStage(id: Long) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val target = ordered.removeAt(targetIndex)

        if (target.status == StageStatus.CURRENT && ordered.none { it.status == StageStatus.CURRENT }) {
            val nextIndex = ordered.indices
                .drop(targetIndex.coerceAtMost(ordered.size))
                .firstOrNull { ordered[it].status == StageStatus.UPCOMING }
                ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING }.takeIf { it >= 0 }
            if (nextIndex != null) {
                ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
            }
        }
        replaceWithRenumbered(ordered)
    }

    fun setCurrent(id: Long) {
        val target = stages.firstOrNull { it.id == id } ?: return
        for (index in stages.indices) {
            val stage = stages[index]
            stages[index] = when {
                stage.id == target.id -> stage.copy(status = StageStatus.CURRENT)
                stage.status == StageStatus.CURRENT -> stage.copy(status = StageStatus.UPCOMING)
                else -> stage
            }
        }
        persist()
    }

    fun markCompleted(id: Long) = markResult(id, StageStatus.COMPLETED)

    fun markFailed(id: Long) = markResult(id, StageStatus.FAILED)

    private fun markResult(id: Long, result: StageStatus) {
        val ordered = stages.sortedBy { it.number }.toMutableList()
        val targetIndex = ordered.indexOfFirst { it.id == id }
        if (targetIndex < 0) return
        val wasCurrent = ordered[targetIndex].status == StageStatus.CURRENT
        ordered[targetIndex] = ordered[targetIndex].copy(status = result)

        if (wasCurrent && ordered.none { it.status == StageStatus.CURRENT }) {
            val nextIndex = ordered.indices
                .drop(targetIndex + 1)
                .firstOrNull { ordered[it].status == StageStatus.UPCOMING }
                ?: ordered.indexOfFirst { it.status == StageStatus.UPCOMING }.takeIf { it >= 0 }
            if (nextIndex != null) {
                ordered[nextIndex] = ordered[nextIndex].copy(status = StageStatus.CURRENT)
            }
        }
        replaceWithRenumbered(ordered)
    }

    private fun replaceWithRenumbered(
        ascendingItems: List<ProgressStage>,
        persistAfter: Boolean = true
    ) {
        val normalizedAscending = ascendingItems.mapIndexed { index, stage ->
            stage.copy(number = index + 1)
        }
        stages.clear()
        stages.addAll(normalizedAscending.sortedByDescending { it.number })
        if (persistAfter) persist()
    }

    private fun persist() {
        prefs?.edit()?.putString(KEY_STAGES, encodeStages(stages))?.apply()
    }

    private fun encodeStages(items: List<ProgressStage>): String = items.joinToString("|") { stage ->
        val encodedTitle = Base64.encodeToString(stage.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        listOf(stage.id, stage.number, stage.status.name, encodedTitle).joinToString(",")
    }

    private fun decodeStages(raw: String): List<ProgressStage> = raw
        .split('|')
        .mapNotNull { token ->
            val parts = token.split(',', limit = 4)
            if (parts.size != 4) return@mapNotNull null
            runCatching {
                ProgressStage(
                    id = parts[0].toLong(),
                    number = parts[1].toInt(),
                    status = StageStatus.valueOf(parts[2]),
                    title = String(Base64.decode(parts[3], Base64.NO_WRAP), Charsets.UTF_8)
                )
            }.getOrNull()
        }
}
