package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import app.networksuper.ui.theme.*

private val stageSpacing = 184.dp
private val stageCardHeight = 94.dp
private val worldTopPadding = 66.dp

@Composable
fun ProgressPathContent(modifier: Modifier = Modifier) {
    val stages = ProgressPathStore.stages
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    var pathViewportHeightPx by remember { mutableStateOf(0) }
    var selectedStageId by remember { mutableStateOf<Long?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val currentIndex = stages.indexOfFirst { it.status == StageStatus.CURRENT }.coerceAtLeast(0)

    // Keep the existing route direction: later stages stay above the current stage,
    // while earlier/completed stages continue below it and are reached by scrolling down.
    // On entry, place the current card as the lowest fully visible card in the viewport.
    LaunchedEffect(currentIndex, stages.size, pathViewportHeightPx) {
        if (pathViewportHeightPx <= 0) return@LaunchedEffect

        val currentTopPx = with(density) {
            (worldTopPadding + stageSpacing * currentIndex.toFloat()).toPx()
        }
        val currentCardHeightPx = with(density) { stageCardHeight.toPx() }
        val bottomBreathingRoomPx = with(density) { 24.dp.toPx() }
        val desiredCurrentTopPx =
            (pathViewportHeightPx - currentCardHeightPx - bottomBreathingRoomPx).coerceAtLeast(0f)
        val target = (currentTopPx - desiredCurrentTopPx).toInt().coerceAtLeast(0)

        scrollState.scrollTo(target)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        ProgressPathHeader()
        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFFF7FBFF))
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .onSizeChanged { pathViewportHeightPx = it.height }
                    .verticalScroll(scrollState)
            ) {
                val availableWidth = maxWidth
                val worldHeight = worldTopPadding * 2f +
                    stageSpacing * (stages.size.coerceAtLeast(1) - 1).toFloat() +
                    stageCardHeight + 70.dp
                val cardWidth = availableWidth * 0.61f

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(worldHeight)
                ) {
                    ProgressWorldBackdrop(Modifier.matchParentSize())
                    ProgressRoad(
                        modifier = Modifier.matchParentSize(),
                        count = stages.size
                    )

                    stages.forEachIndexed { index, stage ->
                        val isCardOnRight = index % 2 == 0
                        val cardTop = worldTopPadding + stageSpacing * index.toFloat()

                        StageCard(
                            stage = stage,
                            onClick = { selectedStageId = stage.id },
                            modifier = Modifier
                                .align(if (isCardOnRight) Alignment.TopEnd else Alignment.TopStart)
                                .offset(
                                    x = if (isCardOnRight) (-10).dp else 10.dp,
                                    y = cardTop
                                )
                                .width(cardWidth)
                                .height(stageCardHeight)
                        )
                    }
                }
            }

            Canvas(Modifier.matchParentSize()) {
                val fadeHeight = 22.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color(0xFFF7FBFF),
                        1f to Color.Transparent,
                        startY = 0f,
                        endY = fadeHeight
                    ),
                    size = Size(size.width, fadeHeight)
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        1f to Color(0xFFF7FBFF),
                        startY = size.height - fadeHeight,
                        endY = size.height
                    ),
                    topLeft = Offset(0f, size.height - fadeHeight),
                    size = Size(size.width, fadeHeight)
                )
            }

            Surface(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .align(AbsoluteAlignment.BottomRight)
                    .padding(14.dp)
                    .size(44.dp)
                    .shadow(6.dp, CircleShape),
                shape = CircleShape,
                color = PrimaryBlue,
                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "افزودن کارت",
                        tint = Color.White,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }

    ProgressStageInteractionDialog(
        stageId = selectedStageId,
        onDismiss = { selectedStageId = null }
    )

    if (showAddDialog) {
        StageEditorDialog(
            editingStage = null,
            onDismiss = { showAddDialog = false },
            onSave = { title, position ->
                ProgressPathStore.addStage(title, position)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun ProgressPathHeader() {
    val stages = ProgressPathStore.stages
    val current = ProgressPathStore.currentStage()
    val ordinal = ProgressPathStore.currentOrdinal()
    val total = stages.size.coerceAtLeast(1)
    val progress = (ordinal.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val percent = (progress * 100).toInt()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                3.dp,
                RoundedCornerShape(22.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.06f),
                spotColor = PrimaryBlue.copy(alpha = 0.07f)
            ),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEAF2FC))
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(15.dp),
                    color = SoftBlue,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.18f))
                ) {
                    Text(
                        text = if (current != null) "مرحله ${current.number} از ${stages.size}" else "بدون مرحله فعلی",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        color = PrimaryBlueDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Text(
                        text = "مسیر پیشرفت",
                        color = Navy,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .shadow(3.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color.White, Color(0xFFFFF2C8))))
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EmojiEvents,
                            contentDescription = null,
                            tint = RewardGold,
                            modifier = Modifier.size(23.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDDEAF9))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF29B8EF), Color(0xFF0E6FFF))
                                )
                            )
                    )
                }

                Text(
                    text = "$percent%",
                    color = PrimaryBlue,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun ProgressWorldBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFF9FCFF), Color(0xFFF1F8FF), Color(0xFFF8FBFF))
            )
        )

        fun mountain(baseY: Float, x: Float, width: Float, height: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(x, baseY)
                lineTo(x + width * 0.50f, baseY - height)
                lineTo(x + width, baseY)
                close()
            }
            drawPath(p, Color(0xFFB8D9F6).copy(alpha = alpha))
        }

        val band = 330.dp.toPx()
        var y = 250.dp.toPx()
        var row = 0
        while (y < h + band) {
            val shift = if (row % 2 == 0) 0f else w * 0.12f
            mountain(y, -w * 0.08f + shift, w * 0.60f, 115.dp.toPx(), 0.23f)
            mountain(y + 16.dp.toPx(), w * 0.40f + shift, w * 0.56f, 95.dp.toPx(), 0.16f)

            drawCircle(
                color = Color.White.copy(alpha = 0.88f),
                radius = 22.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.78f else 0.20f, y - 120.dp.toPx())
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.82f),
                radius = 16.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.83f else 0.25f, y - 118.dp.toPx())
            )

            val treeX = w * if (row % 2 == 0) 0.12f else 0.86f
            drawRoundRect(
                color = Color(0xFF8BC2D9).copy(alpha = 0.30f),
                topLeft = Offset(treeX - 2.dp.toPx(), y - 70.dp.toPx()),
                size = Size(4.dp.toPx(), 31.dp.toPx()),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            val tree = Path().apply {
                moveTo(treeX, y - 118.dp.toPx())
                lineTo(treeX - 15.dp.toPx(), y - 68.dp.toPx())
                lineTo(treeX + 15.dp.toPx(), y - 68.dp.toPx())
                close()
            }
            drawPath(tree, Color(0xFF64BCD3).copy(alpha = 0.30f))

            y += band
            row++
        }
    }
}

@Composable
private fun ProgressRoad(count: Int, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (count <= 0) return@Canvas

        val nodeYs = List(count) { index ->
            (worldTopPadding + stageSpacing * index.toFloat() + stageCardHeight / 2f).toPx()
        }
        val nodeXs = List(count) { index ->
            size.width * if (index % 2 == 0) 0.36f else 0.64f
        }

        val roadPath = Path().apply {
            moveTo(nodeXs.first(), nodeYs.first() - 82.dp.toPx())
            lineTo(nodeXs.first(), nodeYs.first())
            for (i in 0 until count - 1) {
                val x0 = nodeXs[i]
                val y0 = nodeYs[i]
                val x1 = nodeXs[i + 1]
                val y1 = nodeYs[i + 1]
                val midY = (y0 + y1) / 2f
                cubicTo(x0, midY, x1, midY, x1, y1)
            }
            lineTo(nodeXs.last(), nodeYs.last() + 84.dp.toPx())
        }

        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.95f),
            style = Stroke(width = 54.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color(0xFF8BCBFF).copy(alpha = 0.22f),
            style = Stroke(width = 48.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFF7EC5FF), Color(0xFF4AA4FA), Color(0xFF8ACBFF))
            ),
            style = Stroke(width = 38.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.94f),
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(13.dp.toPx(), 13.dp.toPx()))
            )
        )
    }
}

@Composable
private fun StageCard(
    stage: ProgressStage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val completed = stage.status == StageStatus.COMPLETED
    val failed = stage.status == StageStatus.FAILED
    val accent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.FAILED -> FailRed
        StageStatus.UPCOMING -> PrimaryBlue
    }
    val contentAlpha = if (stage.status == StageStatus.UPCOMING) 0.72f else 1f

    Box(modifier = modifier) {
        Surface(
            onClick = onClick,
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    if (current) 9.dp else 3.dp,
                    RoundedCornerShape(23.dp),
                    ambientColor = accent.copy(alpha = if (current) 0.18f else 0.06f),
                    spotColor = accent.copy(alpha = if (current) 0.20f else 0.08f)
                ),
            shape = RoundedCornerShape(23.dp),
            color = Color.White.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.82f else 0.98f),
            border = androidx.compose.foundation.BorderStroke(
                if (current) 2.dp else 1.dp,
                when {
                    current -> PrimaryBlue
                    completed -> SuccessGreen.copy(alpha = 0.22f)
                    failed -> FailRed.copy(alpha = 0.24f)
                    else -> PrimaryBlue.copy(alpha = 0.13f)
                }
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stage.title,
                    color = Navy.copy(alpha = contentAlpha),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        StageStatusBadge(
            stage = stage,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-9).dp, y = (-12).dp)
        )
    }
}

@Composable
fun StageStatusBadge(
    stage: ProgressStage,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    when (stage.status) {
        StageStatus.CURRENT -> {
            Surface(
                modifier = modifier,
                shape = RoundedCornerShape(14.dp),
                color = PrimaryBlue,
                shadowElevation = if (compact) 1.dp else 3.dp
            ) {
                Text(
                    text = "مرحله فعلی",
                    modifier = Modifier.padding(
                        horizontal = if (compact) 8.dp else 12.dp,
                        vertical = if (compact) 4.dp else 6.dp
                    ),
                    color = Color.White,
                    fontSize = if (compact) 9.sp else 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }

        StageStatus.COMPLETED -> StatusCircle(
            icon = Icons.Rounded.Check,
            color = SuccessGreen,
            description = "انجام شده",
            modifier = modifier,
            compact = compact
        )

        StageStatus.FAILED -> StatusCircle(
            icon = Icons.Rounded.Close,
            color = FailRed,
            description = "انجام نشده",
            modifier = modifier,
            compact = compact
        )

        StageStatus.UPCOMING -> {
            val size = if (compact) 29.dp else 36.dp
            Surface(
                modifier = modifier.size(size),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = if (compact) 1.dp else 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFB9C7DA))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = stage.number.toString(),
                        color = Navy.copy(alpha = 0.78f),
                        fontSize = if (compact) 11.sp else 13.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusCircle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    description: String,
    modifier: Modifier,
    compact: Boolean
) {
    val size = if (compact) 29.dp else 36.dp
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = color,
        shadowElevation = if (compact) 1.dp else 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = Color.White,
                modifier = Modifier.size(if (compact) 18.dp else 21.dp)
            )
        }
    }
}


@Composable
fun ProgressStageInteractionDialog(
    stageId: Long?,
    onDismiss: () -> Unit
) {
    if (stageId == null) return
    val stage = ProgressPathStore.stages.firstOrNull { it.id == stageId } ?: return
    var editing by remember(stageId) { mutableStateOf(false) }
    var confirmingDelete by remember(stageId) { mutableStateOf(false) }

    when {
        confirmingDelete -> DeleteStageDialog(
            stage = stage,
            onDismiss = { confirmingDelete = false },
            onConfirm = {
                ProgressPathStore.deleteStage(stage.id)
                onDismiss()
            }
        )

        editing -> StageEditorDialog(
            editingStage = stage,
            onDismiss = { editing = false },
            onSave = { title, position ->
                ProgressPathStore.editStage(stage.id, title, position)
                onDismiss()
            },
            onMakeCurrent = {
                ProgressPathStore.setCurrent(stage.id)
                onDismiss()
            },
            onCompleted = {
                ProgressPathStore.markCompleted(stage.id)
                onDismiss()
            },
            onFailed = {
                ProgressPathStore.markFailed(stage.id)
                onDismiss()
            },
            onDelete = {
                editing = false
                confirmingDelete = true
            }
        )

        else -> StageQuickDialog(
            stage = stage,
            onDismiss = onDismiss,
            onEdit = { editing = true }
        )
    }
}

@Composable
private fun StageQuickDialog(
    stage: ProgressStage,
    onDismiss: () -> Unit,
    onEdit: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .shadow(16.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color(0xFF075BD3),
                            Color(0xFF0879EA),
                            Color(0xFF1594F8)
                        )
                    )
                )
        ) {
            StageQuickBackdrop(Modifier.matchParentSize())

            Surface(
                onClick = onEdit,
                modifier = Modifier
                    .align(AbsoluteAlignment.TopLeft)
                    .padding(12.dp)
                    .size(38.dp),
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.96f),
                shadowElevation = 3.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "ویرایش",
                        tint = PrimaryBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-24).dp)
                    .fillMaxWidth(0.76f)
                    .height(58.dp),
                shape = RoundedCornerShape(19.dp),
                color = Color.White.copy(alpha = 0.98f),
                shadowElevation = 4.dp
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stage.title,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        textAlign = TextAlign.Center,
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Surface(
                onClick = { },
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 54.dp)
                    .fillMaxWidth(0.58f)
                    .height(48.dp),
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1478F3),
                border = androidx.compose.foundation.BorderStroke(
                    2.dp,
                    Color.White.copy(alpha = 0.96f)
                ),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "شروع",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(Modifier.width(7.dp))
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StageQuickBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        for (i in -1..7) {
            val x = w * (0.02f + i * 0.16f)
            drawLine(
                color = Color.White.copy(alpha = 0.09f),
                start = Offset(x, 0f),
                end = Offset(x - h * 0.25f, h),
                strokeWidth = 2f
            )
        }

        for (row in 0..2) {
            for (col in 0..4) {
                val left = w * (0.06f + col * 0.20f) + if (row % 2 == 1) w * 0.06f else 0f
                val top = h * (0.13f + row * 0.27f)
                drawRoundRect(
                    color = Color.White.copy(alpha = if ((row + col) % 3 == 0) 0.12f else 0.07f),
                    topLeft = Offset(left, top),
                    size = Size(w * 0.14f, w * 0.14f),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 3f)
                )
            }
        }

        drawCircle(
            color = Color.White.copy(alpha = 0.07f),
            radius = w * 0.22f,
            center = Offset(w * 0.14f, h * 0.78f)
        )
        drawCircle(
            color = Color(0xFF9FDBFF).copy(alpha = 0.09f),
            radius = w * 0.18f,
            center = Offset(w * 0.82f, h * 0.18f)
        )
    }
}

@Composable
private fun StageEditorDialog(
    editingStage: ProgressStage?,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit,
    onMakeCurrent: (() -> Unit)? = null,
    onCompleted: (() -> Unit)? = null,
    onFailed: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    val isNew = editingStage == null
    val maxPosition = ProgressPathStore.positionCount(isNew)
    var title by remember(editingStage?.id) { mutableStateOf(editingStage?.title.orEmpty()) }
    var selectedPosition by remember(editingStage?.id, maxPosition) {
        mutableIntStateOf((editingStage?.number ?: maxPosition).coerceIn(1, maxPosition))
    }
    var showPositions by remember(editingStage?.id) { mutableStateOf(false) }
    val valid = title.isNotBlank() && selectedPosition in 1..maxPosition

    ProgressDialogShell(onDismiss = onDismiss) {
        Text(
            text = if (editingStage == null) "افزودن کارت جدید" else "ویرایش کارت",
            modifier = Modifier.fillMaxWidth(),
            color = Navy,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        MiniRoadDecoration()
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("نام کارت") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryBlue,
                focusedLabelColor = PrimaryBlue
            )
        )
        Spacer(Modifier.height(10.dp))

        PositionSelector(
            selectedPosition = selectedPosition,
            maxPosition = maxPosition,
            expanded = showPositions,
            onToggle = { showPositions = !showPositions },
            onSelect = {
                selectedPosition = it
                showPositions = false
            }
        )

        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("انصراف")
            }
            Button(
                onClick = { if (valid) onSave(title.trim(), selectedPosition) },
                enabled = valid,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(if (editingStage == null) "اضافه کردن" else "ذخیره", fontWeight = FontWeight.ExtraBold)
            }
        }

        if (editingStage != null) {
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = PrimaryBlue.copy(alpha = 0.10f))
            Spacer(Modifier.height(12.dp))
            Text(
                text = "وضعیت کارت",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Right,
                color = Muted,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                EditorStatusButton(
                    text = "مرحله فعلی",
                    icon = Icons.Rounded.NearMe,
                    color = PrimaryBlue,
                    onClick = onMakeCurrent ?: {},
                    modifier = Modifier.weight(1f)
                )
                EditorStatusButton(
                    text = "انجام شد",
                    icon = Icons.Rounded.Check,
                    color = SuccessGreen,
                    onClick = onCompleted ?: {},
                    modifier = Modifier.weight(1f)
                )
                EditorStatusButton(
                    text = "انجام نشد",
                    icon = Icons.Rounded.Close,
                    color = FailRed,
                    onClick = onFailed ?: {},
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            TextButton(
                onClick = onDelete ?: {},
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed)
                Spacer(Modifier.width(5.dp))
                Text("حذف کارت", color = FailRed, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PositionSelector(
    selectedPosition: Int,
    maxPosition: Int,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSelect: (Int) -> Unit
) {
    Surface(
        onClick = onToggle,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
            if (expanded) 1.6.dp else 1.dp,
            if (expanded) PrimaryBlue else Muted.copy(alpha = 0.65f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = PrimaryBlue
            )
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "جایگاه",
                    color = if (expanded) PrimaryBlue else Muted,
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    text = selectedPosition.toString(),
                    color = Navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (expanded) {
        Spacer(Modifier.height(8.dp))
        val rows = ((maxPosition + 4) / 5).coerceAtLeast(1)
        val gridHeight = (rows * 49).coerceAtMost(205).dp
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = SoftBlue.copy(alpha = 0.33f),
            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.15f))
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(gridHeight)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items((1..maxPosition).toList(), key = { it }) { position ->
                    val selected = position == selectedPosition
                    Surface(
                        onClick = { onSelect(position) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp),
                        shape = RoundedCornerShape(11.dp),
                        color = if (selected) PrimaryBlue else Color.White,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) PrimaryBlue else PrimaryBlue.copy(alpha = 0.16f)
                        ),
                        shadowElevation = if (selected) 2.dp else 0.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = position.toString(),
                                color = if (selected) Color.White else Navy,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorStatusButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(15.dp),
        color = color.copy(alpha = 0.09f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.22f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.height(2.dp))
            Text(
                text = text,
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MiniRoadDecoration() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth(0.70f)
                .height(42.dp)
        ) {
            val path = Path().apply {
                moveTo(size.width * 0.08f, size.height * 0.58f)
                cubicTo(
                    size.width * 0.32f, size.height * 0.16f,
                    size.width * 0.64f, size.height * 0.80f,
                    size.width * 0.92f, size.height * 0.44f
                )
            }
            drawPath(
                path,
                Color(0xFFDCECFB),
                style = Stroke(22.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path,
                Color(0xFF55AEF7),
                style = Stroke(16.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path,
                Color.White,
                style = Stroke(
                    2.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 8.dp.toPx()))
                )
            )
        }
    }
}

@Composable
private fun DeleteStageDialog(
    stage: ProgressStage,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White,
        title = {
            Text("حذف کارت؟", color = Navy, fontWeight = FontWeight.Black)
        },
        text = {
            Text("«${stage.title}» از مسیر پیشرفت حذف می‌شود.", color = Muted)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = FailRed),
                shape = RoundedCornerShape(14.dp)
            ) { Text("حذف") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
private fun ProgressDialogShell(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFFFBFDFF),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.18f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                content = content
            )
        }
    }
}
