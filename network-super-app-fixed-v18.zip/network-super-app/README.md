# Network Super App

پروتوتایپ اندروید صفحه Home برای سوپر اپ نتورک مارکتینگ، بر اساس تصمیم‌های طراحی نهایی این گفتگو.

## وضعیت فعلی

نسخه فعلی شامل Home نهایی V7 با Jetpack Compose است:

- هدر RTL Premium با Profile Glow، Rank، XP Capsule، Combo و Reward Gift
- کارت «قدم بعدی» با بک‌گراند هندسی کاملاً کدنویسی‌شده
- «امروز من» به شکل برنامه ساعت‌محور و اسکرول افقی RTL
- «مسیر پیشرفت» به شکل تسک‌های افقی با ترتیب کاربر
- Bottom Navigation گیمیفای‌شده با انیمیشن انتخاب تب
- تایپوگرافی مرکزی و متناسب در کل Design System
- وضعیت Done/Pending در کارت‌های «امروز من» و «مسیر پیشرفت»
- Home بدون اسکرول عمودی
- تصویر مرجع طراحی در `docs/home-reference.png`
- مشخصات فارسی Home در `docs/HOME_SPEC_FA.md`

## تکنولوژی

- Kotlin
- Jetpack Compose
- Material 3
- RTL-first UI
- Min SDK 26 / Target SDK 35

## اجرا

پروژه را با Android Studio باز کنید و Gradle Sync را اجرا کنید. سپس ماژول `app` را روی Emulator یا دستگاه اندروید اجرا کنید.

> در این نسخه داده‌ها Mock هستند و هنوز Backend، احراز هویت و دیتابیس متصل نشده‌اند.

## ساختار

```text
app/src/main/java/app/networksuper/
├── MainActivity.kt
├── ui/home/HomeScreen.kt
└── ui/theme/
    └── Type.kt

docs/
├── HOME_SPEC_FA.md
└── home-reference.png
```

## قدم بعدی پیشنهادی

Home در V7 نهایی و Locked شده است. قدم بعدی: مدل‌های داده و Navigation واقعی اضافه شوند و سپس صفحات «مسیر پیشرفت»، «لیست مشتریان»، «لیست شبکه‌سازی» و «بیشتر» به همین Design System پیاده‌سازی شوند.


### Home V8
Final sync pass: shared Today/Progress component, centered Next Action CTA, unified geometric background, right-shifted combo/reward, clearer scroll previews.

### Progress Path V13
- صفحه مستقل «مسیر پیشرفت» به Bottom Navigation متصل شد.
- جاده S-شکل با Canvas، خط‌چین، Glow و انحنای بیشتر کاملاً کدنویسی‌شده است.
- کارت‌ها یک‌درمیان چپ/راست، بزرگ‌تر و با فاصله عمودی بیشتر هستند.
- Current / Completed / Upcoming استایل مستقل دارند و مرحله فعلی برجسته است.
- پس‌زمینه کوه، ابر و درخت مینیمال نیز کاملاً با کد رسم می‌شود و Asset تصویری ندارد.


## v16 — Progress Path interactions
- Progress cards are slightly smaller and closer together; card title scale matches Home progress cards.
- Home `Next Action` is driven by the current Progress Path stage.
- Tap any Progress Path card for Edit / Set Current / Done / Failed / Delete actions.
- Small + button at the physical bottom-right opens a themed Add Card dialog.
- Add/Edit dialog supports title and unique stage number.
- Progress Path changes persist locally with SharedPreferences.
- Home Progress section reads from the same shared stage source and mirrors status badges.
- Completing/failing the current stage automatically promotes the next upcoming stage.
