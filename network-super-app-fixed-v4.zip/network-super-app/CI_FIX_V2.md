# CI Fix V2

This version removes the placeholder `gradle-wrapper.jar` entirely.
`gradle/actions/setup-gradle` validates wrapper JAR files and rejects unknown or fake JARs before the build starts.

The project keeps a `gradlew` launcher that uses an installed `gradle` command when available and otherwise downloads Gradle 8.9 at runtime.
