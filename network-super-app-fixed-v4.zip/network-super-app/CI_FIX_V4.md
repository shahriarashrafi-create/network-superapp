# Home UI update V4

This version applies only the two approved Home changes:

1. Header changed to a compact two-row layout:
   - Row 1: profile + greeting + Builder rank on the right, combo + reward chest on the left.
   - Row 2: `2480 XP` + XP progress bar.
   - No extra XP-to-next-level text.

2. In the "Next Action" card, `پیگیری با علی رضایی` is kept on one line.
   - The white inner card remains unchanged in concept.
   - No changes were made to the Today or Progress sections.
