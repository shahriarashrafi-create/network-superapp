package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.*

@Composable
internal fun ProgressWorldBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFF9FCFF), Color(0xFFF1F8FF), Color(0xFFF8FBFF))
            )
        )

        fun mountain(baseY: Float, x: Float, width: Float, height: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(x, baseY)
                lineTo(x + width * 0.50f, baseY - height)
                lineTo(x + width, baseY)
                close()
            }
            drawPath(p, Color(0xFFB8D9F6).copy(alpha = alpha))
        }

        val band = 330.dp.toPx()
        var y = 250.dp.toPx()
        var row = 0
        while (y < h + band) {
            val shift = if (row % 2 == 0) 0f else w * 0.12f
            mountain(y, -w * 0.08f + shift, w * 0.60f, 115.dp.toPx(), 0.23f)
            mountain(y + 16.dp.toPx(), w * 0.40f + shift, w * 0.56f, 95.dp.toPx(), 0.16f)

            drawCircle(
                color = Color.White.copy(alpha = 0.88f),
                radius = 22.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.78f else 0.20f, y - 120.dp.toPx())
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.82f),
                radius = 16.dp.toPx(),
                center = Offset(w * if (row % 2 == 0) 0.83f else 0.25f, y - 118.dp.toPx())
            )

            val treeX = w * if (row % 2 == 0) 0.12f else 0.86f
            drawRoundRect(
                color = Color(0xFF8BC2D9).copy(alpha = 0.30f),
                topLeft = Offset(treeX - 2.dp.toPx(), y - 70.dp.toPx()),
                size = Size(4.dp.toPx(), 31.dp.toPx()),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
            val tree = Path().apply {
                moveTo(treeX, y - 118.dp.toPx())
                lineTo(treeX - 15.dp.toPx(), y - 68.dp.toPx())
                lineTo(treeX + 15.dp.toPx(), y - 68.dp.toPx())
                close()
            }
            drawPath(tree, Color(0xFF64BCD3).copy(alpha = 0.30f))

            y += band
            row++
        }
    }
}

@Composable
internal fun ProgressRoad(count: Int, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (count <= 0) return@Canvas

        val nodeYs = List(count) { index ->
            (WorldTopPadding + StageSpacing * index.toFloat() + StageCardHeight / 2f).toPx()
        }
        val nodeXs = List(count) { index ->
            size.width * if (index % 2 == 0) 0.36f else 0.64f
        }

        val roadPath = Path().apply {
            moveTo(nodeXs.first(), nodeYs.first() - 82.dp.toPx())
            lineTo(nodeXs.first(), nodeYs.first())
            for (i in 0 until count - 1) {
                val x0 = nodeXs[i]
                val y0 = nodeYs[i]
                val x1 = nodeXs[i + 1]
                val y1 = nodeYs[i + 1]
                val midY = (y0 + y1) / 2f
                cubicTo(x0, midY, x1, midY, x1, y1)
            }
            lineTo(nodeXs.last(), nodeYs.last() + 84.dp.toPx())
        }

        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.95f),
            style = Stroke(width = 54.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color(0xFF8BCBFF).copy(alpha = 0.22f),
            style = Stroke(width = 48.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            brush = Brush.verticalGradient(
                listOf(Color(0xFF7EC5FF), Color(0xFF4AA4FA), Color(0xFF8ACBFF))
            ),
            style = Stroke(width = 38.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = roadPath,
            color = Color.White.copy(alpha = 0.94f),
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(13.dp.toPx(), 13.dp.toPx()))
            )
        )
    }
}

@Composable
internal fun StageCard(
    stage: ProgressStage,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val current = stage.status == StageStatus.CURRENT
    val completed = stage.status == StageStatus.COMPLETED
    val failed = stage.status == StageStatus.FAILED
    val accent = when (stage.status) {
        StageStatus.CURRENT -> PrimaryBlue
        StageStatus.COMPLETED -> SuccessGreen
        StageStatus.FAILED -> FailRed
        StageStatus.UPCOMING -> PrimaryBlue
    }
    val contentAlpha = if (stage.status == StageStatus.UPCOMING) 0.72f else 1f

    Box(modifier = modifier) {
        Surface(
            onClick = onClick,
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    if (current) 9.dp else 3.dp,
                    RoundedCornerShape(23.dp),
                    ambientColor = accent.copy(alpha = if (current) 0.18f else 0.06f),
                    spotColor = accent.copy(alpha = if (current) 0.20f else 0.08f)
                ),
            shape = RoundedCornerShape(23.dp),
            color = Color.White.copy(alpha = if (stage.status == StageStatus.UPCOMING) 0.82f else 0.98f),
            border = androidx.compose.foundation.BorderStroke(
                if (current) 2.dp else 1.dp,
                when {
                    current -> PrimaryBlue
                    completed -> SuccessGreen.copy(alpha = 0.22f)
                    failed -> FailRed.copy(alpha = 0.24f)
                    else -> PrimaryBlue.copy(alpha = 0.13f)
                }
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stage.title,
                    color = Navy.copy(alpha = contentAlpha),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        StageStatusBadge(
            stage = stage,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = (-9).dp, y = (-12).dp)
        )
    }
}

@Composable
fun StageStatusBadge(
    stage: ProgressStage,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    when (stage.status) {
        StageStatus.CURRENT -> {
            Surface(
                modifier = modifier,
                shape = RoundedCornerShape(14.dp),
                color = PrimaryBlue,
                shadowElevation = if (compact) 1.dp else 3.dp
            ) {
                Text(
                    text = when (stage.missionStatus) {
                        MissionStatus.ACTIVE -> stringResource(R.string.mission_active)
                        MissionStatus.EXPIRED -> stringResource(R.string.mission_expired_badge)
                        else -> stringResource(R.string.current_stage)
                    },
                    modifier = Modifier.padding(
                        horizontal = if (compact) 8.dp else 12.dp,
                        vertical = if (compact) 4.dp else 6.dp
                    ),
                    color = Color.White,
                    fontSize = if (compact) NetworkTextSize.Micro else NetworkTextSize.Label,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1
                )
            }
        }

        StageStatus.COMPLETED -> StatusCircle(
            icon = Icons.Rounded.Check,
            color = SuccessGreen,
            description = stringResource(R.string.done),
            modifier = modifier,
            compact = compact
        )

        StageStatus.FAILED -> StatusCircle(
            icon = Icons.Rounded.Close,
            color = FailRed,
            description = stringResource(R.string.not_done),
            modifier = modifier,
            compact = compact
        )

        StageStatus.UPCOMING -> {
            val size = if (compact) 29.dp else 36.dp
            Surface(
                modifier = modifier.size(size),
                shape = CircleShape,
                color = Color.White,
                shadowElevation = if (compact) 1.dp else 2.dp,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFB9C7DA))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = stage.number.toString(),
                        color = Navy.copy(alpha = 0.78f),
                        fontSize = if (compact) NetworkTextSize.CompactLabel else NetworkTextSize.Body,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusCircle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    description: String,
    modifier: Modifier,
    compact: Boolean
) {
    val size = if (compact) 29.dp else 36.dp
    Surface(
        modifier = modifier.size(size),
        shape = CircleShape,
        color = color,
        shadowElevation = if (compact) 1.dp else 3.dp,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = Color.White,
                modifier = Modifier.size(if (compact) 18.dp else 21.dp)
            )
        }
    }
}


