package app.networksuper.ui.progress

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Notes
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Route
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.networksuper.R
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.FailRed
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.PrimaryBlueDark
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen
import app.networksuper.ui.theme.SurfaceOutline
import app.networksuper.ui.theme.WarningOrange
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun MissionDetailScreen(
    stageId: Long,
    onBack: () -> Unit,
    onOpenNextStage: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val stage = ProgressPathStore.stages.firstOrNull { it.id == stageId }
    if (stage == null) {
        LaunchedEffect(stageId) { onBack() }
        return
    }

    var showEditor by remember(stageId) { mutableStateOf(false) }
    var showNote by remember(stageId) { mutableStateOf(false) }
    var confirmFailed by remember(stageId) { mutableStateOf(false) }
    var confirmRestore by remember(stageId) { mutableStateOf(false) }
    var nowMillis by remember(stageId) { mutableLongStateOf(System.currentTimeMillis()) }

    val totalStages = ProgressPathStore.stages.size.coerceAtLeast(1)
    val pathOrdinal = ProgressPathStore.currentOrdinal().coerceIn(0, totalStages)
    val pathProgress = pathOrdinal.toFloat() / totalStages.toFloat()
    val remainingMillis = MissionRules.remainingMillis(stage, nowMillis)

    LaunchedEffect(stageId, stage.missionStatus, stage.endAtMillis) {
        if (stage.missionStatus == MissionStatus.ACTIVE) {
            while (true) {
                nowMillis = System.currentTimeMillis()
                ProgressPathStore.markExpiredIfNeeded(stageId, nowMillis)
                if (ProgressPathStore.stage(stageId)?.missionStatus != MissionStatus.ACTIVE) break
                delay(1_000L)
            }
        } else {
            nowMillis = System.currentTimeMillis()
        }
    }

    BackHandler(onBack = onBack)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        DetailToolbar(
            stage = stage,
            totalStages = totalStages,
            pathProgress = pathProgress,
            onBack = onBack,
            onEdit = { showEditor = true },
            onNote = { showNote = true }
        )

        Spacer(Modifier.height(8.dp))
        StageIdentityCard(stage = stage, totalStages = totalStages)
        Spacer(Modifier.height(8.dp))

        when (stage.missionStatus) {
            MissionStatus.COMPLETED -> SuccessContent(
                stage = stage,
                pathProgress = pathProgress,
                onNextStage = {
                    val next = ProgressPathStore.currentStage()?.takeIf { it.id != stage.id }
                    if (next != null) onOpenNextStage(next.id) else onBack()
                },
                onBackToPath = onBack,
                onRestore = { confirmRestore = true },
                modifier = Modifier.weight(1f)
            )

            MissionStatus.FAILED -> FailedContent(
                stage = stage,
                onRetry = { ProgressPathStore.retryMission(stage.id) },
                onRestore = { confirmRestore = true },
                modifier = Modifier.weight(1f)
            )

            else -> {
                TimerCard(stage = stage, remainingMillis = remainingMillis)
                Spacer(Modifier.height(8.dp))

                ChecklistCard(
                    stage = stage,
                    enabled = stage.missionStatus == MissionStatus.ACTIVE || stage.missionStatus == MissionStatus.EXPIRED,
                    onCheckedChange = { itemId, checked ->
                        ProgressPathStore.toggleChecklistItem(stage.id, itemId, checked)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )

                Spacer(Modifier.height(8.dp))

                if (stage.missionStatus == MissionStatus.NOT_STARTED) {
                    val canStart = stage.status == StageStatus.CURRENT
                    if (!canStart) {
                        Text(
                            text = stringResource(R.string.mission_locked_message),
                            modifier = Modifier.fillMaxWidth(),
                            color = Muted,
                            style = MaterialTheme.typography.labelLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(5.dp))
                    }
                    StartButton(
                        onClick = { ProgressPathStore.startMission(stage.id) },
                        enabled = canStart,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    ResultActions(
                        stage = stage,
                        onDone = { ProgressPathStore.completeMission(stage.id) },
                        onFailed = { confirmFailed = true },
                        onRestore = { confirmRestore = true }
                    )
                }
            }
        }
    }

    if (showEditor) {
        StageSetupDialog(
            stage = stage,
            positionCount = ProgressPathStore.positionCount(isNew = false),
            onDismiss = { showEditor = false },
            onSave = { title, position, duration, checklist ->
                ProgressPathStore.updateStageSetup(stage.id, title, position, duration, checklist)
                showEditor = false
            },
            onDelete = {
                ProgressPathStore.deleteStage(stage.id)
                showEditor = false
                onBack()
            }
        )
    }

    if (showNote) {
        NoteDialog(
            stageId = stage.id,
            committedNote = stage.note,
            draftNote = stage.noteDraft,
            stageTitle = stage.title,
            onDismiss = { showNote = false }
        )
    }

    if (confirmFailed) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Close,
            iconColor = FailRed,
            title = stringResource(R.string.mission_fail_confirm_title),
            message = stringResource(R.string.mission_fail_confirm_message),
            confirmText = stringResource(R.string.mission_fail_confirm_action),
            onDismiss = { confirmFailed = false },
            onConfirm = {
                ProgressPathStore.failMission(stage.id)
                confirmFailed = false
            }
        )
    }

    if (confirmRestore) {
        ConfirmActionDialog(
            icon = Icons.Rounded.Restore,
            iconColor = PrimaryBlue,
            title = stringResource(R.string.mission_restore_confirm_title),
            message = stringResource(R.string.mission_restore_confirm_message),
            confirmText = stringResource(R.string.mission_restore_confirm_action),
            onDismiss = { confirmRestore = false },
            onConfirm = {
                ProgressPathStore.restoreMission(stage.id)
                confirmRestore = false
            }
        )
    }
}

@Composable
private fun DetailToolbar(
    stage: ProgressStage,
    totalStages: Int,
    pathProgress: Float,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onNote: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 2.dp
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 9.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                SmallIconButton(
                    icon = Icons.Rounded.ArrowForward,
                    description = stringResource(R.string.action_back),
                    onClick = onBack
                )
                Text(
                    text = stringResource(R.string.stage_of, stage.number, totalStages),
                    modifier = Modifier.weight(1f),
                    color = Muted,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Box {
                    SmallIconButton(
                        icon = Icons.Rounded.Notes,
                        description = stringResource(R.string.mission_note),
                        onClick = onNote
                    )
                    if (stage.note.isNotBlank() || !stage.noteDraft.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(8.dp)
                                .background(SuccessGreen, CircleShape)
                                .border(1.dp, Color.White, CircleShape)
                        )
                    }
                }
                SmallIconButton(
                    icon = Icons.Rounded.Edit,
                    description = stringResource(R.string.action_edit),
                    onClick = onEdit
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(
                    progress = pathProgress.coerceIn(0f, 1f),
                    modifier = Modifier
                        .weight(1f)
                        .height(7.dp)
                        .clip(CircleShape),
                    color = PrimaryBlue,
                    trackColor = SoftBlue
                )
                Spacer(Modifier.width(9.dp))
                Text(
                    text = "${(pathProgress * 100).roundToInt()}٪",
                    color = PrimaryBlue,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun SmallIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier.size(44.dp),
        shape = CircleShape,
        color = SoftBlue.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.12f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = description, tint = Navy, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun StageIdentityCard(stage: ProgressStage, totalStages: Int) {
    val statusText = when (stage.missionStatus) {
        MissionStatus.NOT_STARTED -> if (stage.status == StageStatus.UPCOMING) {
            stringResource(R.string.mission_status_locked)
        } else {
            stringResource(R.string.mission_status_ready)
        }
        MissionStatus.ACTIVE -> stringResource(R.string.mission_active)
        MissionStatus.EXPIRED -> stringResource(R.string.mission_expired_badge)
        MissionStatus.COMPLETED -> stringResource(R.string.done)
        MissionStatus.FAILED -> stringResource(R.string.not_done)
    }
    val statusColor = when (stage.missionStatus) {
        MissionStatus.ACTIVE -> PrimaryBlue
        MissionStatus.EXPIRED -> WarningOrange
        MissionStatus.COMPLETED -> SuccessGreen
        MissionStatus.FAILED -> FailRed
        MissionStatus.NOT_STARTED -> if (stage.status == StageStatus.UPCOMING) Muted else PrimaryBlue
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = stage.title,
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = stringResource(R.string.stage_of, stage.number, totalStages),
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Surface(
                shape = RoundedCornerShape(11.dp),
                color = statusColor.copy(alpha = 0.10f)
            ) {
                Text(
                    text = statusText,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                    color = statusColor,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

@Composable
private fun TimerCard(stage: ProgressStage, remainingMillis: Long) {
    val totalMillis = stage.durationMinutes.coerceAtLeast(1) * 60_000L
    val rawFraction = (remainingMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f)
    val fraction by animateFloatAsState(rawFraction, tween(350), label = "timerProgress")
    val timerColorTarget = when {
        stage.missionStatus == MissionStatus.EXPIRED -> FailRed
        stage.missionStatus != MissionStatus.ACTIVE -> PrimaryBlue
        fraction <= 0.05f -> FailRed
        fraction <= 0.20f -> WarningOrange
        else -> PrimaryBlue
    }
    val timerColor by animateColorAsState(timerColorTarget, label = "timerColor")
    val pulseTransition = rememberInfiniteTransition(label = "timerPulse")
    val pulse by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "timerPulseScale"
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(23.dp),
        color = if (stage.missionStatus == MissionStatus.EXPIRED) {
            FailRed.copy(alpha = 0.06f)
        } else {
            Color.White
        },
        border = BorderStroke(1.2.dp, timerColor.copy(alpha = 0.18f)),
        shadowElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier
                    .size(46.dp)
                    .scale(if (stage.missionStatus == MissionStatus.ACTIVE) pulse else 1f),
                shape = CircleShape,
                color = timerColor.copy(alpha = 0.11f),
                border = BorderStroke(1.dp, timerColor.copy(alpha = 0.16f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (stage.missionStatus == MissionStatus.EXPIRED) Icons.Rounded.WarningAmber else Icons.Rounded.Timer,
                        contentDescription = null,
                        tint = timerColor,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(
                text = when (stage.missionStatus) {
                    MissionStatus.ACTIVE -> stringResource(R.string.mission_time_remaining)
                    MissionStatus.EXPIRED -> stringResource(R.string.mission_time_finished)
                    else -> stringResource(R.string.mission_duration)
                },
                color = Muted,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            AnimatedContent(targetState = remainingMillis, label = "countdown") { millis ->
                Text(
                    text = formatDuration(millis),
                    color = timerColor,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(CircleShape)
                    .background(timerColor.copy(alpha = 0.09f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(timerColor.copy(alpha = 0.70f), timerColor, PrimaryBlueDark)
                            )
                        )
                )
            }
            if (stage.missionStatus == MissionStatus.EXPIRED) {
                Spacer(Modifier.height(7.dp))
                Text(
                    text = stringResource(R.string.mission_expired_message),
                    color = FailRed,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun ChecklistCard(
    stage: ProgressStage,
    enabled: Boolean,
    onCheckedChange: (Long, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val completed = MissionRules.completedCount(stage.checklist)
    val fraction = MissionRules.completionFraction(stage.checklist)
    val animatedFraction by animateFloatAsState(fraction, label = "checklistProgress")

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(23.dp),
        color = Color.White,
        border = BorderStroke(1.dp, SurfaceOutline),
        shadowElevation = 2.dp
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.mission_checklist),
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = stringResource(R.string.mission_checklist_progress, completed, stage.checklist.size),
                        color = Muted,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                Text(
                    text = "${(fraction * 100).roundToInt()}٪",
                    color = SuccessGreen,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(Modifier.height(7.dp))
            LinearProgressIndicator(
                progress = animatedFraction,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(CircleShape),
                color = SuccessGreen,
                trackColor = SuccessGreen.copy(alpha = 0.10f)
            )
            Spacer(Modifier.height(7.dp))

            if (stage.checklist.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = stringResource(R.string.mission_no_checklist),
                        color = Muted,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(stage.checklist, key = { it.id }) { item ->
                        ChecklistRow(
                            item = item,
                            enabled = enabled,
                            onCheckedChange = { checked -> onCheckedChange(item.id, checked) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChecklistRow(
    item: MissionChecklistItem,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val scale by animateFloatAsState(if (item.checked) 1.04f else 1f, label = "checkScale")
    Surface(
        onClick = { if (enabled) onCheckedChange(!item.checked) },
        enabled = enabled,
        shape = RoundedCornerShape(15.dp),
        color = if (item.checked) SuccessGreen.copy(alpha = 0.07f) else AppBackground.copy(alpha = 0.62f),
        border = BorderStroke(1.dp, if (item.checked) SuccessGreen.copy(alpha = 0.22f) else SurfaceOutline)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = item.checked,
                onCheckedChange = if (enabled) onCheckedChange else null,
                modifier = Modifier.scale(scale),
                colors = CheckboxDefaults.colors(
                    checkedColor = SuccessGreen,
                    uncheckedColor = Muted.copy(alpha = 0.55f)
                )
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = item.text,
                modifier = Modifier.weight(1f),
                color = if (enabled) Navy else Muted,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (item.required) FontWeight.Bold else FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.width(7.dp))
            Surface(
                shape = RoundedCornerShape(9.dp),
                color = if (item.required) FailRed.copy(alpha = 0.09f) else SoftBlue
            ) {
                Text(
                    text = if (item.required) stringResource(R.string.mission_required) else stringResource(R.string.mission_optional),
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                    color = if (item.required) FailRed else Muted,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StartButton(
    onClick: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "startPulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.018f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "startScale"
    )
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(58.dp)
            .scale(if (enabled) scale else 1f),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
    ) {
        Icon(Icons.Rounded.Timer, contentDescription = null, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.mission_start), fontWeight = FontWeight.Black)
    }
}

@Composable
private fun ResultActions(
    stage: ProgressStage,
    onDone: () -> Unit,
    onFailed: () -> Unit,
    onRestore: () -> Unit
) {
    val remainingRequired = MissionRules.remainingRequired(stage.checklist)
    val canDone = remainingRequired == 0

    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        if (!canDone) {
            Text(
                text = stringResource(R.string.mission_required_remaining, remainingRequired),
                modifier = Modifier.fillMaxWidth(),
                color = FailRed,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Surface(
                onClick = onRestore,
                modifier = Modifier.size(50.dp),
                shape = RoundedCornerShape(16.dp),
                color = SoftBlue,
                border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.16f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.Rounded.Restore,
                        contentDescription = stringResource(R.string.mission_restore),
                        tint = PrimaryBlue,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
            OutlinedButton(
                onClick = onFailed,
                modifier = Modifier
                    .weight(0.82f)
                    .height(50.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, FailRed.copy(alpha = 0.35f))
            ) {
                Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(5.dp))
                Text(stringResource(R.string.mark_failed), color = FailRed, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onDone,
                enabled = canDone,
                modifier = Modifier
                    .weight(1.55f)
                    .height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SuccessGreen,
                    disabledContainerColor = Muted.copy(alpha = 0.18f)
                )
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(29.dp))
                Spacer(Modifier.width(7.dp))
                Text(stringResource(R.string.mark_done), fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun FailedContent(
    stage: ProgressStage,
    onRetry: () -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            border = BorderStroke(1.dp, FailRed.copy(alpha = 0.16f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(modifier = Modifier.size(76.dp), shape = CircleShape, color = FailRed.copy(alpha = 0.10f)) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, contentDescription = null, tint = FailRed, modifier = Modifier.size(39.dp))
                    }
                }
                Spacer(Modifier.height(13.dp))
                Text(
                    text = stringResource(R.string.mission_failed_title),
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    text = stage.title,
                    color = Muted,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.mission_failed_message),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(stringResource(R.string.mission_retry), fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onRestore,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Restore, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.mission_restore), fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    text = stringResource(R.string.mission_note_preserved),
                    color = Muted,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

@Composable
private fun SuccessContent(
    stage: ProgressStage,
    pathProgress: Float,
    onNextStage: () -> Unit,
    onBackToPath: () -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(28.dp),
            color = Color.White,
            border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.18f)),
            shadowElevation = 3.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(modifier = Modifier.size(78.dp), shape = CircleShape, color = SuccessGreen) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(45.dp))
                    }
                }
                Spacer(Modifier.height(13.dp))
                Text(
                    text = stringResource(R.string.mission_success_title),
                    color = Navy,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stage.title,
                    color = Muted,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(14.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(17.dp),
                    color = SuccessGreen.copy(alpha = 0.06f)
                ) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row {
                            Text(stringResource(R.string.mission_path_progress), color = Muted, modifier = Modifier.weight(1f))
                            Text("${(pathProgress * 100).roundToInt()}٪", color = SuccessGreen, fontWeight = FontWeight.Black)
                        }
                        LinearProgressIndicator(
                            progress = pathProgress.coerceIn(0f, 1f),
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                            color = SuccessGreen,
                            trackColor = SuccessGreen.copy(alpha = 0.12f)
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onNextStage,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                ) {
                    Text(stringResource(R.string.mission_next_stage), fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Rounded.ArrowBack, contentDescription = null)
                }
                Spacer(Modifier.height(7.dp))
                OutlinedButton(
                    onClick = onBackToPath,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Route, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.mission_back_to_path), fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onRestore) {
                    Icon(Icons.Rounded.Restore, contentDescription = null, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.mission_restore), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ConfirmActionDialog(
    icon: ImageVector,
    iconColor: Color,
    title: String,
    message: String,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(modifier = Modifier.size(52.dp), shape = CircleShape, color = iconColor.copy(alpha = 0.10f)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(28.dp))
                }
            }
        },
        title = { Text(title, color = Navy, fontWeight = FontWeight.Black, textAlign = TextAlign.Center) },
        text = { Text(message, color = Muted, textAlign = TextAlign.Center) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = iconColor),
                shape = RoundedCornerShape(14.dp)
            ) { Text(confirmText, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel), color = Muted) }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White
    )
}

@Composable
private fun NoteDialog(
    stageId: Long,
    committedNote: String,
    draftNote: String?,
    stageTitle: String,
    onDismiss: () -> Unit
) {
    var text by remember(stageId) { mutableStateOf(draftNote ?: committedNote) }
    var committedText by remember(stageId) { mutableStateOf(committedNote) }
    var showExitPrompt by remember(stageId) { mutableStateOf(false) }
    var draftSaved by remember(stageId) { mutableStateOf(true) }

    fun requestClose() {
        if (text != committedText) showExitPrompt = true else onDismiss()
    }

    BackHandler { requestClose() }

    Dialog(
        onDismissRequest = { requestClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFFFFCF3),
            border = BorderStroke(1.dp, RewardGold.copy(alpha = 0.18f))
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { requestClose() }) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_close), tint = Navy)
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = stringResource(R.string.mission_note_title),
                            color = Navy,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = stageTitle,
                            color = Muted,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton(
                        onClick = {
                            ProgressPathStore.commitNote(stageId, text)
                            committedText = text
                            draftSaved = true
                        }
                    ) {
                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.action_save), fontWeight = FontWeight.Black)
                    }
                }
                Spacer(Modifier.height(7.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { value ->
                        text = value
                        draftSaved = false
                        ProgressPathStore.updateNoteDraft(stageId, value)
                        draftSaved = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    placeholder = { Text(stringResource(R.string.mission_note_hint)) },
                    shape = RoundedCornerShape(18.dp)
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (draftSaved) Icons.Rounded.Check else Icons.Rounded.Sync,
                        contentDescription = null,
                        tint = if (draftSaved) SuccessGreen else Muted,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (text == committedText) {
                            stringResource(R.string.mission_note_saved)
                        } else {
                            stringResource(R.string.mission_note_saving)
                        },
                        color = if (text == committedText) SuccessGreen else Muted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        if (showExitPrompt) {
            AlertDialog(
                onDismissRequest = { showExitPrompt = false },
                title = {
                    Text(
                        stringResource(R.string.mission_note_exit_title),
                        color = Navy,
                        fontWeight = FontWeight.Black
                    )
                },
                text = { Text(stringResource(R.string.mission_note_exit_message), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            ProgressPathStore.commitNote(stageId, text)
                            committedText = text
                            showExitPrompt = false
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) { Text(stringResource(R.string.action_save)) }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            ProgressPathStore.discardNoteDraft(stageId)
                            showExitPrompt = false
                            onDismiss()
                        }) {
                            Text(stringResource(R.string.action_discard), color = FailRed)
                        }
                        TextButton(onClick = { showExitPrompt = false }) {
                            Text(stringResource(R.string.action_cancel), color = Muted)
                        }
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }
    }
}

@Composable
private fun StageSetupDialog(
    stage: ProgressStage,
    positionCount: Int,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int, List<MissionChecklistItem>) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember(stage.id) { mutableStateOf(stage.title) }
    var selectedPosition by remember(stage.id) { mutableIntStateOf(stage.number.coerceIn(1, positionCount)) }
    var selectedDuration by remember(stage.id) { mutableIntStateOf(stage.durationMinutes) }
    var durationExpanded by remember(stage.id) { mutableStateOf(false) }
    var positionExpanded by remember(stage.id) { mutableStateOf(false) }
    var pendingDeleteItemId by remember(stage.id) { mutableStateOf<Long?>(null) }
    var confirmDeleteCard by remember(stage.id) { mutableStateOf(false) }
    val checklistItems = remember(stage.id) {
        mutableStateListOf<MissionChecklistItem>().apply { addAll(stage.checklist) }
    }
    var nextLocalId by remember(stage.id) {
        mutableLongStateOf((stage.checklist.maxOfOrNull { it.id } ?: stage.id * 10_000L) + 1L)
    }
    val density = LocalDensity.current
    val dragThresholdPx = with(density) { 26.dp.toPx() }
    val durationOptions = listOf(5, 10, 15, 20, 30)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = AppBackground,
            border = BorderStroke(1.dp, SurfaceOutline)
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_close), tint = Navy)
                    }
                    Text(
                        text = stringResource(R.string.mission_edit_title),
                        modifier = Modifier.weight(1f),
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    IconButton(onClick = { confirmDeleteCard = true }) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = stringResource(R.string.delete_card),
                            tint = FailRed
                        )
                    }
                }
                Spacer(Modifier.height(5.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(stringResource(R.string.card_name)) },
                    singleLine = true,
                    shape = RoundedCornerShape(15.dp)
                )

                Spacer(Modifier.height(7.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, SurfaceOutline)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.position),
                            modifier = Modifier.weight(1f),
                            color = Navy,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Box {
                            OutlinedButton(
                                onClick = { positionExpanded = true },
                                modifier = Modifier.height(40.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(stringResource(R.string.edit_position_value, selectedPosition))
                                Spacer(Modifier.width(3.dp))
                                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                            DropdownMenu(
                                expanded = positionExpanded,
                                onDismissRequest = { positionExpanded = false }
                            ) {
                                (1..positionCount).forEach { position ->
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.edit_position_value, position)) },
                                        onClick = {
                                            selectedPosition = position
                                            positionExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(7.dp))
                Surface(
                    onClick = { durationExpanded = !durationExpanded },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, SurfaceOutline)
                ) {
                    Column(Modifier.padding(horizontal = 11.dp, vertical = 7.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Timer, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(
                                text = stringResource(R.string.mission_default_duration),
                                modifier = Modifier.weight(1f),
                                color = Navy,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = stringResource(R.string.mission_minutes_value, selectedDuration),
                                color = PrimaryBlue,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(Modifier.width(3.dp))
                            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, tint = Muted, modifier = Modifier.size(18.dp))
                        }
                        if (durationExpanded) {
                            Spacer(Modifier.height(7.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                durationOptions.forEach { option ->
                                    FilterChip(
                                        selected = selectedDuration == option,
                                        onClick = {
                                            selectedDuration = option
                                            durationExpanded = false
                                        },
                                        modifier = Modifier.weight(1f),
                                        label = {
                                            Text(
                                                text = stringResource(R.string.mission_minutes_value, option),
                                                maxLines = 1,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = SoftBlue,
                                            selectedLabelColor = PrimaryBlueDark
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.mission_checklist),
                        modifier = Modifier.weight(1f),
                        color = Navy,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    Surface(
                        onClick = {
                            checklistItems.add(
                                MissionChecklistItem(
                                    id = nextLocalId++,
                                    text = "",
                                    required = false
                                )
                            )
                        },
                        modifier = Modifier.size(38.dp),
                        shape = CircleShape,
                        color = SoftBlue
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Rounded.Add,
                                contentDescription = stringResource(R.string.mission_add_item),
                                tint = PrimaryBlue,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(5.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(checklistItems, key = { it.id }) { item ->
                        val index = checklistItems.indexOfFirst { it.id == item.id }
                        var dragDistance by remember(item.id) { mutableFloatStateOf(0f) }
                        Surface(
                            modifier = Modifier.pointerInput(item.id, checklistItems.size) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragDistance = 0f },
                                    onDragEnd = { dragDistance = 0f },
                                    onDragCancel = { dragDistance = 0f },
                                    onDrag = { _, dragAmount ->
                                        dragDistance += dragAmount.y
                                        val currentIndex = checklistItems.indexOfFirst { it.id == item.id }
                                        if (dragDistance > dragThresholdPx && currentIndex < checklistItems.lastIndex) {
                                            val moved = checklistItems.removeAt(currentIndex)
                                            checklistItems.add(currentIndex + 1, moved)
                                            dragDistance = 0f
                                        } else if (dragDistance < -dragThresholdPx && currentIndex > 0) {
                                            val moved = checklistItems.removeAt(currentIndex)
                                            checklistItems.add(currentIndex - 1, moved)
                                            dragDistance = 0f
                                        }
                                    }
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, SurfaceOutline)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Rounded.DragIndicator,
                                    contentDescription = stringResource(R.string.mission_reorder),
                                    tint = Muted,
                                    modifier = Modifier.size(25.dp)
                                )
                                Spacer(Modifier.width(3.dp))
                                OutlinedTextField(
                                    value = item.text,
                                    onValueChange = { value ->
                                        if (index >= 0) checklistItems[index] = item.copy(text = value)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 50.dp),
                                    placeholder = { Text(stringResource(R.string.mission_item_hint)) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                FilterChip(
                                    selected = item.required,
                                    onClick = {
                                        if (index >= 0) checklistItems[index] = item.copy(required = !item.required)
                                    },
                                    label = {
                                        Text(
                                            if (item.required) stringResource(R.string.mission_required) else stringResource(R.string.mission_optional),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    leadingIcon = if (item.required) {
                                        { Icon(Icons.Rounded.PriorityHigh, contentDescription = null, modifier = Modifier.size(15.dp)) }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = FailRed.copy(alpha = 0.08f),
                                        selectedLabelColor = FailRed,
                                        selectedLeadingIconColor = FailRed
                                    )
                                )
                                IconButton(
                                    onClick = {
                                        if (index >= 0) {
                                            if (item.checked) pendingDeleteItemId = item.id
                                            else checklistItems.removeAt(index)
                                        }
                                    },
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.Delete,
                                        contentDescription = stringResource(R.string.action_delete),
                                        tint = FailRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(7.dp))
                Button(
                    onClick = {
                        onSave(title, selectedPosition, selectedDuration, checklistItems.toList())
                    },
                    enabled = title.isNotBlank() && checklistItems.any { it.text.isNotBlank() },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(17.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.action_save), fontWeight = FontWeight.Black)
                }
            }
        }

        if (pendingDeleteItemId != null) {
            AlertDialog(
                onDismissRequest = { pendingDeleteItemId = null },
                title = { Text(stringResource(R.string.mission_delete_checked_title), color = Navy, fontWeight = FontWeight.Black) },
                text = { Text(stringResource(R.string.mission_delete_checked_message), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            val target = pendingDeleteItemId
                            if (target != null) checklistItems.removeAll { it.id == target }
                            pendingDeleteItemId = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FailRed)
                    ) { Text(stringResource(R.string.action_delete)) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDeleteItemId = null }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }

        if (confirmDeleteCard) {
            AlertDialog(
                onDismissRequest = { confirmDeleteCard = false },
                icon = { Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed) },
                title = { Text(stringResource(R.string.delete_card_question), color = Navy, fontWeight = FontWeight.Black) },
                text = { Text(stringResource(R.string.delete_card_message, stage.title), color = Muted) },
                confirmButton = {
                    Button(
                        onClick = {
                            confirmDeleteCard = false
                            onDelete()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FailRed)
                    ) { Text(stringResource(R.string.action_delete)) }
                },
                dismissButton = {
                    TextButton(onClick = { confirmDeleteCard = false }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                },
                shape = RoundedCornerShape(22.dp),
                containerColor = Color.White
            )
        }
    }
}

private fun formatDuration(millis: Long): String {
    val totalSeconds = (millis.coerceAtLeast(0L) + 999L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0) {
        "%02d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }
}
