package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import app.networksuper.R
import app.networksuper.ui.theme.*

@Composable
internal fun StageEditorDialog(
    editingStage: ProgressStage?,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit,
    onMakeCurrent: (() -> Unit)? = null,
    onCompleted: (() -> Unit)? = null,
    onFailed: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null
) {
    val isNew = editingStage == null
    val maxPosition = ProgressPathStore.positionCount(isNew)
    var title by remember(editingStage?.id) { mutableStateOf(editingStage?.title.orEmpty()) }
    var selectedPosition by remember(editingStage?.id, maxPosition) {
        mutableIntStateOf((editingStage?.number ?: maxPosition).coerceIn(1, maxPosition))
    }
    var showPositions by remember(editingStage?.id) { mutableStateOf(false) }
    val valid = title.isNotBlank() && selectedPosition in 1..maxPosition

    ProgressDialogShell(onDismiss = onDismiss) {
        Text(
            text = if (editingStage == null) stringResource(R.string.add_new_card) else stringResource(R.string.edit_card),
            modifier = Modifier.fillMaxWidth(),
            color = Navy,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        MiniRoadDecoration()
        Spacer(Modifier.height(14.dp))

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.card_name)) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = PrimaryBlue,
                focusedLabelColor = PrimaryBlue
            )
        )
        Spacer(Modifier.height(10.dp))

        PositionSelector(
            selectedPosition = selectedPosition,
            maxPosition = maxPosition,
            expanded = showPositions,
            onToggle = { showPositions = !showPositions },
            onSelect = {
                selectedPosition = it
                showPositions = false
            }
        )

        Spacer(Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onDismiss,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(stringResource(R.string.action_cancel))
            }
            Button(
                onClick = { if (valid) onSave(title.trim(), selectedPosition) },
                enabled = valid,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(if (editingStage == null) stringResource(R.string.action_add) else stringResource(R.string.action_save), fontWeight = FontWeight.ExtraBold)
            }
        }

        if (editingStage != null && (onMakeCurrent != null || onCompleted != null || onFailed != null || onDelete != null)) {
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = PrimaryBlue.copy(alpha = 0.10f))
            Spacer(Modifier.height(12.dp))

            if (onMakeCurrent != null || onCompleted != null || onFailed != null) {
                Text(
                    text = stringResource(R.string.card_status),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right,
                    color = Muted,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    if (onMakeCurrent != null) {
                        EditorStatusButton(
                            text = stringResource(R.string.current_stage),
                            icon = Icons.Rounded.NearMe,
                            color = PrimaryBlue,
                            onClick = onMakeCurrent,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (onCompleted != null) {
                        EditorStatusButton(
                            text = stringResource(R.string.mark_done),
                            icon = Icons.Rounded.Check,
                            color = SuccessGreen,
                            onClick = onCompleted,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (onFailed != null) {
                        EditorStatusButton(
                            text = stringResource(R.string.mark_failed),
                            icon = Icons.Rounded.Close,
                            color = FailRed,
                            onClick = onFailed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (onDelete != null) {
                TextButton(
                    onClick = onDelete,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = null, tint = FailRed)
                    Spacer(Modifier.width(5.dp))
                    Text(stringResource(R.string.delete_card), color = FailRed, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PositionSelector(
    selectedPosition: Int,
    maxPosition: Int,
    expanded: Boolean,
    onToggle: () -> Unit,
    onSelect: (Int) -> Unit
) {
    Surface(
        onClick = onToggle,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
            if (expanded) 1.6.dp else 1.dp,
            if (expanded) PrimaryBlue else Muted.copy(alpha = 0.65f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = null,
                tint = PrimaryBlue
            )
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = stringResource(R.string.position),
                    color = if (expanded) PrimaryBlue else Muted,
                    style = MaterialTheme.typography.labelMedium
                )
                Text(
                    text = selectedPosition.toString(),
                    color = Navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (expanded) {
        Spacer(Modifier.height(8.dp))
        val rows = ((maxPosition + 4) / 5).coerceAtLeast(1)
        val gridHeight = (rows * 49).coerceAtMost(205).dp
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = SoftBlue.copy(alpha = 0.33f),
            border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.15f))
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(gridHeight)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp),
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items((1..maxPosition).toList(), key = { it }) { position ->
                    val selected = position == selectedPosition
                    Surface(
                        onClick = { onSelect(position) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp),
                        shape = RoundedCornerShape(11.dp),
                        color = if (selected) PrimaryBlue else Color.White,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) PrimaryBlue else PrimaryBlue.copy(alpha = 0.16f)
                        ),
                        shadowElevation = if (selected) 2.dp else 0.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = position.toString(),
                                color = if (selected) Color.White else Navy,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorStatusButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(15.dp),
        color = color.copy(alpha = 0.09f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.22f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.height(2.dp))
            Text(
                text = text,
                color = color,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MiniRoadDecoration() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth(0.70f)
                .height(42.dp)
        ) {
            val path = Path().apply {
                moveTo(size.width * 0.08f, size.height * 0.58f)
                cubicTo(
                    size.width * 0.32f, size.height * 0.16f,
                    size.width * 0.64f, size.height * 0.80f,
                    size.width * 0.92f, size.height * 0.44f
                )
            }
            drawPath(
                path,
                Color(0xFFDCECFB),
                style = Stroke(22.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path,
                Color(0xFF55AEF7),
                style = Stroke(16.dp.toPx(), cap = StrokeCap.Round)
            )
            drawPath(
                path,
                Color.White,
                style = Stroke(
                    2.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 8.dp.toPx()))
                )
            )
        }
    }
}

@Composable
private fun DeleteStageDialog(
    stage: ProgressStage,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White,
        title = {
            Text(stringResource(R.string.delete_card_question), color = Navy, fontWeight = FontWeight.Black)
        },
        text = {
            Text(stringResource(R.string.delete_card_message, stage.title), color = Muted)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = FailRed),
                shape = RoundedCornerShape(14.dp)
            ) { Text(stringResource(R.string.action_delete)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        }
    )
}

@Composable
private fun ProgressDialogShell(
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(16.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFFFBFDFF),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryBlue.copy(alpha = 0.18f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                content = content
            )
        }
    }
}
