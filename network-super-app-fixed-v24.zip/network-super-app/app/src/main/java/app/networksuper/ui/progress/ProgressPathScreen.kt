package app.networksuper.ui.progress

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.networksuper.R
import app.networksuper.ui.theme.*

@Composable
fun ProgressPathContent(
    modifier: Modifier = Modifier,
    onOpenMission: (Long) -> Unit = {}
) {
    val stages = ProgressPathStore.stages
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    var pathViewportHeightPx by remember { mutableStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }

    val currentIndex = stages.indexOfFirst { it.status == StageStatus.CURRENT }.coerceAtLeast(0)

    // Keep the existing route direction: later stages stay above the current stage,
    // while earlier/completed stages continue below it and are reached by scrolling down.
    // On entry, place the current card as the lowest fully visible card in the viewport.
    LaunchedEffect(currentIndex, stages.size, pathViewportHeightPx) {
        if (pathViewportHeightPx <= 0) return@LaunchedEffect

        val currentTopPx = with(density) {
            (WorldTopPadding + StageSpacing * currentIndex.toFloat()).toPx()
        }
        val currentCardHeightPx = with(density) { StageCardHeight.toPx() }
        val bottomBreathingRoomPx = with(density) { 24.dp.toPx() }
        val desiredCurrentTopPx =
            (pathViewportHeightPx - currentCardHeightPx - bottomBreathingRoomPx).coerceAtLeast(0f)
        val target = (currentTopPx - desiredCurrentTopPx).toInt().coerceAtLeast(0)

        scrollState.scrollTo(target)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        ProgressPathHeader()
        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xFFF7FBFF))
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .onSizeChanged { pathViewportHeightPx = it.height }
                    .verticalScroll(scrollState)
            ) {
                val availableWidth = maxWidth
                val worldHeight = WorldTopPadding * 2f +
                    StageSpacing * (stages.size.coerceAtLeast(1) - 1).toFloat() +
                    StageCardHeight + 70.dp
                val cardWidth = availableWidth * 0.61f

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(worldHeight)
                ) {
                    ProgressWorldBackdrop(Modifier.matchParentSize())
                    ProgressRoad(
                        modifier = Modifier.matchParentSize(),
                        count = stages.size
                    )

                    stages.forEachIndexed { index, stage ->
                        val isEndSide = index % 2 == 0
                        val cardTop = WorldTopPadding + StageSpacing * index.toFloat()

                        StageCard(
                            stage = stage,
                            onClick = { onOpenMission(stage.id) },
                            modifier = Modifier
                                .align(if (isEndSide) Alignment.TopEnd else Alignment.TopStart)
                                .offset(
                                    x = if (isEndSide) (-10).dp else 10.dp,
                                    y = cardTop
                                )
                                .width(cardWidth)
                                .height(StageCardHeight)
                        )
                    }
                }
            }

            Canvas(Modifier.matchParentSize()) {
                val fadeHeight = 22.dp.toPx()
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color(0xFFF7FBFF),
                        1f to Color.Transparent,
                        startY = 0f,
                        endY = fadeHeight
                    ),
                    size = Size(size.width, fadeHeight)
                )
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        1f to Color(0xFFF7FBFF),
                        startY = size.height - fadeHeight,
                        endY = size.height
                    ),
                    topLeft = Offset(0f, size.height - fadeHeight),
                    size = Size(size.width, fadeHeight)
                )
            }

            Surface(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .align(AbsoluteAlignment.BottomRight)
                    .padding(14.dp)
                    .size(44.dp)
                    .shadow(6.dp, CircleShape),
                shape = CircleShape,
                color = PrimaryBlue,
                border = androidx.compose.foundation.BorderStroke(2.dp, Color.White)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = stringResource(R.string.add_card),
                        tint = Color.White,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }
        }
    }


    if (showAddDialog) {
        StageEditorDialog(
            editingStage = null,
            onDismiss = { showAddDialog = false },
            onSave = { title, position ->
                ProgressPathStore.addStage(title, position)
                showAddDialog = false
            }
        )
    }
}

