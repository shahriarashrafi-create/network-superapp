package app.networksuper.ui.progress

import org.junit.Assert.assertEquals
import org.junit.Test

class ProgressPathRulesTest {
    @Test
    fun completedPathReportsOneHundredPercentOrdinal() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.COMPLETED),
            ProgressStage(2, 2, "B", StageStatus.FAILED),
            ProgressStage(3, 3, "C", StageStatus.COMPLETED)
        )

        assertEquals(3, ProgressPathRules.currentOrdinal(items))
    }

    @Test
    fun currentStageReportsItsOneBasedPosition() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.COMPLETED),
            ProgressStage(2, 2, "B", StageStatus.CURRENT),
            ProgressStage(3, 3, "C", StageStatus.UPCOMING)
        )

        assertEquals(2, ProgressPathRules.currentOrdinal(items))
    }

    @Test
    fun normalizeKeepsSingleCurrentAndContiguousNumbers() {
        val normalized = ProgressPathRules.normalize(
            listOf(
                ProgressStage(3, 30, " C ", StageStatus.CURRENT),
                ProgressStage(1, 10, " A ", StageStatus.CURRENT),
                ProgressStage(2, 20, " B ", StageStatus.UPCOMING)
            )
        )

        assertEquals(listOf(1, 2, 3), normalized.map { it.number })
        assertEquals(listOf("A", "B", "C"), normalized.map { it.title })
        assertEquals(1, normalized.count { it.status == StageStatus.CURRENT })
    }
    @Test
    fun rollbackResultRestoresTargetAndAllFutureCards() {
        val items = listOf(
            ProgressStage(1, 1, "A", StageStatus.COMPLETED, missionStatus = MissionStatus.COMPLETED),
            ProgressStage(2, 2, "B", StageStatus.COMPLETED, missionStatus = MissionStatus.COMPLETED, note = "keep"),
            ProgressStage(3, 3, "C", StageStatus.CURRENT, missionStatus = MissionStatus.ACTIVE, checklist = listOf(MissionChecklistItem(31, "x", true, true))),
            ProgressStage(4, 4, "D", StageStatus.UPCOMING, missionStatus = MissionStatus.NOT_STARTED)
        )

        val rolled = ProgressPathRules.rollbackTo(items, 2)

        assertEquals(StageStatus.COMPLETED, rolled[0].status)
        assertEquals(StageStatus.CURRENT, rolled[1].status)
        assertEquals(MissionStatus.NOT_STARTED, rolled[1].missionStatus)
        assertEquals("keep", rolled[1].note)
        assertEquals(StageStatus.UPCOMING, rolled[2].status)
        assertEquals(MissionStatus.NOT_STARTED, rolled[2].missionStatus)
        assertEquals(false, rolled[2].checklist.single().checked)
        assertEquals(StageStatus.UPCOMING, rolled[3].status)
    }

}
