# SuperApp v12

Android Kotlin + Jetpack Compose prototype for the Network Marketing Super App.

## v12 focus
- Home Next Action opens a real task flow.
- Task details with subtasks, CRM deep-link entry, time presets and rewards.
- Full-screen Focus Mode with countdown, pause, optional music affordance and finish flow.
- Result sheet: Done / Later / Fail.
- Completion state with XP, Coin and Combo feedback, then Next Action.
- Progress Path redesigned as a vertical zigzag-like staged journey with stats, Done/Fail/Current/Locked states, rewards and step details.
- Current path step can launch directly into the task flow.
- Existing Home, Profile, Notifications, Level, Coin, Combo, Wallet, Reward Store and 30-link pager are retained.
- UI remains code/vector/canvas based; no decorative bitmap background is used.

Application ID and signing configuration are intentionally preserved for in-place APK updates.

## v2.3.0 / Build 15
- Home redesigned as a spacious gamified hub: compact mission card + adjacent reward chest widget.
- Six shortcut cards replaced by minimal orb launchers while retaining 30 destinations across five pages.
- Stronger Blue/Navy/Gold contrast, slim status strip, code-only Canvas/Vector assets, and no decorative bitmap backgrounds.


## Build 15
- Home gamified journey path rendered entirely with Compose Canvas.
- Shortcut hub tightened and anchored closer to bottom navigation.
- No bitmap/photo decorative assets added.


## v2.3.0 / Build 15
- Home polish: حذف 48٪، XP یکپارچه، مسیر Home جمع‌وجورتر، Shortcutهای فشرده‌تر و نزدیک‌تر به Bottom Nav.
- Progress Path rebuilt as a gamified zigzag journey with state-colored route, current node, locked nodes, milestones, rewards, map/list modes and step bottom sheets.
- All decorative visuals remain Compose/Canvas/Vector based; no raster background image was added.
