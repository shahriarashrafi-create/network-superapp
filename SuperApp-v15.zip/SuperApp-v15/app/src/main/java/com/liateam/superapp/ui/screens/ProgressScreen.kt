package com.liateam.superapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import kotlinx.coroutines.launch

private enum class PathState { DONE, FAILED, CURRENT, LOCKED, NEUTRAL }

private data class PathStep(
    val title: String,
    val subtitle: String,
    val rewardXp: Int,
    val rewardCoin: Int,
    val state: PathState,
    val unlockCondition: String = "مرحله قبلی را کامل کن",
    val progressText: String? = null,
    val duration: String = "۵ دقیقه",
    val nextTitle: String? = null
)

private val pathSteps = listOf(
    PathStep("آشنایی و ذهنیت", "پایه‌های شروع حرفه‌ای", 30, 3, PathState.DONE, duration = "۸ دقیقه"),
    PathStep("ارتباط‌سازی", "ساخت لیست و شروع گفت‌وگو", 40, 4, PathState.DONE, duration = "۱۲ دقیقه"),
    PathStep("دعوت یک نفر", "گفت‌وگوی کوتاه با یک مخاطب جدید", 20, 2, PathState.CURRENT, progressText = "۱ از ۳ زیرکار", nextTitle = "معرفی محصول"),
    PathStep("معرفی محصول", "معرفی ساده و درست محصول", 25, 3, PathState.LOCKED, "مرحله دعوت را کامل کن", nextTitle = "پیگیری حرفه‌ای"),
    PathStep("پیگیری حرفه‌ای", "Follow-up با اقدام بعدی روشن", 25, 3, PathState.LOCKED, "معرفی محصول را کامل کن"),
    PathStep("اولین مشتری", "ثبت اولین خرید موفق", 40, 5, PathState.LOCKED, "پیگیری حرفه‌ای را کامل کن"),
    PathStep("ساخت تیم", "ثبت عضو و شروع مسیر حمایتی", 50, 6, PathState.LOCKED, "اولین مشتری را ثبت کن"),
    PathStep("تکثیر و رهبری", "کمک به تیم برای تکرار مسیر", 70, 8, PathState.LOCKED, "ساخت تیم را کامل کن")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onStartCurrent: () -> Unit = {}
) {
    var selected by remember { mutableStateOf<PathStep?>(null) }
    var mapMode by remember { mutableStateOf(true) }
    val listState = rememberLazyListState()
    val currentIndex = pathSteps.indexOfFirst { it.state == PathState.CURRENT }.coerceAtLeast(0)
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        // Header remains visible initially; a short auto-position brings the active step into view.
        if (currentIndex >= 2) listState.scrollToItem(4 + currentIndex, 14)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7FAFE))
    ) {
        ProgressGridBackground()

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 6.dp,
                bottom = contentPadding.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            item { ProgressHeader(onBack) }
            item { ProgressSummary() }
            item { CurrentStageHero(onStartCurrent) }
            item { ProgressModeSwitch(mapMode = mapMode, onMapMode = { mapMode = it }) }

            if (mapMode) {
                pathSteps.forEachIndexed { index, step ->
                    item(key = "map_step_$index") {
                        JourneyStepRow(
                            index = index,
                            step = step,
                            previousState = pathSteps.getOrNull(index - 1)?.state,
                            nextState = pathSteps.getOrNull(index + 1)?.state,
                            onClick = { selected = step },
                            onStart = if (step.state == PathState.CURRENT) onStartCurrent else null
                        )
                    }
                    if (index == 3) {
                        item(key = "milestone_mid") {
                            MilestoneCheckpoint(
                                title = "جایزه میانی",
                                subtitle = "۴ مرحله • +۵۰ سکه • نشان مسیر",
                                progress = 0.75f
                            )
                        }
                    }
                }
            } else {
                pathSteps.forEachIndexed { index, step ->
                    item(key = "list_step_$index") {
                        CompactListStep(
                            index = index,
                            step = step,
                            onClick = { selected = step },
                            onStart = if (step.state == PathState.CURRENT) onStartCurrent else null
                        )
                    }
                }
            }

            item {
                MilestoneCheckpoint(
                    title = "Milestone نهایی",
                    subtitle = "Badge + Reward + باز شدن مسیر بعدی",
                    progress = 0.38f,
                    final = true
                )
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(
                    end = SuperDimens.ScreenPadding,
                    bottom = contentPadding.calculateBottomPadding() + 10.dp
                )
                .clickable { scope.launch { listState.animateScrollToItem(4 + currentIndex, 14) } },
            color = Color.White.copy(alpha = 0.96f),
            shape = SuperShapes.Pill,
            shadowElevation = 3.dp
        ) {
            Text(
                "مرحله من",
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                color = SuperColors.Blue,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp
            )
        }
    }

    selected?.let { step ->
        ModalBottomSheet(
            onDismissRequest = { selected = null },
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 25.dp, topEnd = 25.dp)
        ) {
            PathStepSheet(
                step = step,
                onClose = { selected = null },
                onStart = {
                    selected = null
                    onStartCurrent()
                }
            )
        }
    }
}

@Composable
private fun ProgressGridBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val grid = 36.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            drawLine(Color(0xFF87A8C8).copy(alpha = 0.045f), Offset(x, 0f), Offset(x, size.height), 1f)
            x += grid
        }
        var y = 0f
        while (y <= size.height) {
            drawLine(Color(0xFF87A8C8).copy(alpha = 0.045f), Offset(0f, y), Offset(size.width, y), 1f)
            y += grid
        }
        drawCircle(Color(0xFF5FA8FF).copy(alpha = 0.055f), radius = size.width * 0.28f, center = Offset(size.width * 0.90f, size.height * 0.18f))
        drawCircle(Color(0xFF35C58A).copy(alpha = 0.045f), radius = size.width * 0.24f, center = Offset(size.width * 0.08f, size.height * 0.62f))
    }
}

@Composable
private fun ProgressHeader(onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("مسیر پیشرفت", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 23.sp)
            Text("از کجا آمدی، الان کجایی و جایزه بعدی کجاست", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
        }
    }
}

@Composable
private fun ProgressSummary() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.98f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                MiniPathStat("3 / 8", "مرحله فعلی", SuperColors.Blue, Modifier.weight(1f))
                MiniPathStat("38٪", "پیشرفت مسیر", SuperColors.Green, Modifier.weight(1f))
                MiniPathStat("+180", "XP این هفته", SuperColors.GoldDeep, Modifier.weight(1f))
                MiniPathStat("1", "مرحله تا جایزه", SuperColors.Purple, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Color(0xFFE4EEF8), CircleShape)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(0.38f)
                        .height(6.dp)
                        .background(SuperColors.Blue, CircleShape)
                )
            }
        }
    }
}

@Composable
private fun MiniPathStat(value: String, label: String, color: Color, modifier: Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontWeight = FontWeight.Black, fontSize = 12.5.sp)
        Text(label, color = SuperColors.TextSecondary, fontSize = 7.2.sp, maxLines = 1)
    }
}

@Composable
private fun CurrentStageHero(onStart: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(19.dp), clip = false)
            .border(1.2.dp, SuperColors.Blue.copy(alpha = 0.45f), RoundedCornerShape(19.dp)),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8FF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(42.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                Text("مرحله فعال • 3 از 8", color = SuperColors.BlueDeep, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
                Text("دعوت یک نفر", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text("۱ از ۳ زیرکار • ۵ دقیقه • بعد از این: معرفی محصول", color = SuperColors.TextSecondary, fontSize = 8.2.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    SmallPathChip("+20 XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallPathChip("+2 سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
                }
            }
            Button(
                onClick = onStart,
                modifier = Modifier.height(38.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
            ) {
                Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Text("شروع", fontSize = 9.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun ProgressModeSwitch(mapMode: Boolean, onMapMode: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("مسیر اصلی", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Spacer(Modifier.weight(1f))
        Surface(color = Color.White, shape = SuperShapes.Pill, shadowElevation = 1.dp) {
            Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                ModePill("مسیر", selected = mapMode, onClick = { onMapMode(true) })
                ModePill("لیست", selected = !mapMode, onClick = { onMapMode(false) })
            }
        }
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        color = if (selected) SuperColors.BlueSoft else Color.Transparent,
        shape = SuperShapes.Pill
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            color = if (selected) SuperColors.Blue else SuperColors.TextSecondary,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun JourneyStepRow(
    index: Int,
    step: PathStep,
    previousState: PathState?,
    nextState: PathState?,
    onClick: () -> Unit,
    onStart: (() -> Unit)?
) {
    val rowHeight = if (step.state == PathState.CURRENT) 122.dp else 108.dp
    val nodeShift = if (index % 2 == 0) (-18).dp else 18.dp
    val cardOnRight = index % 2 == 0

    Box(modifier = Modifier.fillMaxWidth().height(rowHeight)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val centerX = size.width / 2f
            val shift = 18.dp.toPx()
            val currentX = centerX + if (index % 2 == 0) -shift else shift
            val previousX = centerX + if ((index - 1).coerceAtLeast(0) % 2 == 0) -shift else shift
            val nextX = centerX + if ((index + 1) % 2 == 0) -shift else shift
            val midY = size.height / 2f

            if (index > 0) {
                val topPath = Path().apply {
                    moveTo(previousX, 0f)
                    cubicTo(previousX, size.height * 0.20f, currentX, size.height * 0.28f, currentX, midY)
                }
                drawJourneySegment(topPath, transitionColor(previousState, step.state), isLockedTransition(previousState, step.state))
            }
            if (index < pathSteps.lastIndex) {
                val bottomPath = Path().apply {
                    moveTo(currentX, midY)
                    cubicTo(currentX, size.height * 0.72f, nextX, size.height * 0.80f, nextX, size.height)
                }
                drawJourneySegment(bottomPath, transitionColor(step.state, nextState), isLockedTransition(step.state, nextState))
            }
        }

        JourneyStepCard(
            modifier = Modifier
                .align(if (cardOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                .fillMaxWidth(if (step.state == PathState.CURRENT) 0.46f else 0.43f),
            index = index,
            step = step,
            onClick = onClick,
            onStart = onStart
        )

        JourneyNode(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = nodeShift),
            state = step.state,
            number = index + 1
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawJourneySegment(
    path: Path,
    color: Color,
    dashed: Boolean
) {
    drawPath(
        path = path,
        color = color,
        style = Stroke(
            width = 5.dp.toPx(),
            cap = StrokeCap.Round,
            pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(9.dp.toPx(), 7.dp.toPx())) else null
        )
    )
}

private fun transitionColor(from: PathState?, to: PathState?): Color = when {
    from == PathState.FAILED || to == PathState.FAILED -> SuperColors.Red
    from == PathState.DONE && to == PathState.DONE -> SuperColors.Green
    from == PathState.DONE && to == PathState.CURRENT -> SuperColors.Blue
    from == PathState.CURRENT -> SuperColors.Blue
    else -> Color(0xFFB6C1CF)
}

private fun isLockedTransition(from: PathState?, to: PathState?): Boolean =
    from == PathState.LOCKED || to == PathState.LOCKED

@Composable
private fun JourneyNode(modifier: Modifier, state: PathState, number: Int) {
    val accent = pathAccent(state)
    val outer = when (state) {
        PathState.CURRENT -> SuperColors.GoldSoft
        PathState.DONE -> SuperColors.GreenSoft
        PathState.FAILED -> SuperColors.RedSoft
        else -> Color(0xFFE9EEF4)
    }
    Box(modifier = modifier.size(if (state == PathState.CURRENT) 48.dp else 42.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(outer, CircleShape))
        Box(
            Modifier
                .size(if (state == PathState.CURRENT) 34.dp else 30.dp)
                .background(if (state == PathState.LOCKED) Color(0xFFA4AFBD) else accent, CircleShape)
                .border(2.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                PathState.DONE -> Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                PathState.FAILED -> Icon(Icons.Outlined.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                PathState.LOCKED -> Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                else -> Text(number.toString(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun JourneyStepCard(
    modifier: Modifier,
    index: Int,
    step: PathStep,
    onClick: () -> Unit,
    onStart: (() -> Unit)?
) {
    val accent = pathAccent(step.state)
    val background = pathBackground(step.state)
    Card(
        modifier = modifier
            .clickable(onClick = onClick)
            .then(
                if (step.state == PathState.CURRENT) Modifier.border(1.2.dp, SuperColors.Blue.copy(alpha = 0.65f), RoundedCornerShape(17.dp))
                else Modifier
            ),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = background),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 3.dp else 0.5.dp)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = if (step.state == PathState.CURRENT) 10.dp else 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${index + 1}", color = accent, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
                Spacer(Modifier.width(4.dp))
                Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.3.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 7.7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))

            if (step.state == PathState.CURRENT && step.progressText != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(step.progressText, color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 7.2.sp)
                    Spacer(Modifier.weight(1f))
                    Text(step.duration, color = SuperColors.TextSecondary, fontSize = 7.sp)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { 0.34f },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = Color(0xFFDCEAF8)
                )
                Spacer(Modifier.height(5.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                    SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
                    SmallPathChip("+${step.rewardCoin}", SuperColors.GoldDeep, SuperColors.GoldSoft)
                }
                if (onStart != null) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.height(29.dp),
                        contentPadding = PaddingValues(horizontal = 7.dp),
                        shape = RoundedCornerShape(9.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(13.dp))
                        Text("شروع", fontSize = 7.5.sp, fontWeight = FontWeight.Black)
                    }
                } else {
                    Text(pathLabel(step.state), color = accent, fontWeight = FontWeight.Black, fontSize = 7.4.sp)
                }
            }

            if (step.state == PathState.LOCKED) {
                Spacer(Modifier.height(4.dp))
                Text(step.unlockCondition, color = Color(0xFF97A4B3), fontSize = 6.8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun CompactListStep(index: Int, step: PathStep, onClick: () -> Unit, onStart: (() -> Unit)?) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = pathBackground(step.state)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == PathState.CURRENT) 2.dp else 0.dp)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            JourneyNode(Modifier, step.state, index + 1)
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text("${index + 1}. ${step.title}", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 8.sp, maxLines = 1)
            }
            if (onStart != null) {
                Button(
                    onClick = onStart,
                    modifier = Modifier.height(32.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("شروع", fontSize = 8.sp, fontWeight = FontWeight.Black) }
            } else {
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 8.sp)
            }
        }
    }
}

@Composable
private fun MilestoneCheckpoint(
    title: String,
    subtitle: String,
    progress: Float,
    final: Boolean = false
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = if (final) Color(0xFFFFF2C8) else Color(0xFFFFF8E3)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (final) 2.dp else 0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (final) Icons.Outlined.Flag else Icons.Outlined.Star, contentDescription = null, tint = SuperColors.GoldDeep, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text(subtitle, color = SuperColors.TextSecondary, fontSize = 7.8.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color = SuperColors.Gold,
                    trackColor = Color.White
                )
            }
        }
    }
}

@Composable
private fun SmallPathChip(text: String, color: Color, background: Color) {
    Box(Modifier.background(background, SuperShapes.Pill).padding(horizontal = 6.dp, vertical = 3.dp)) {
        Text(text, color = color, fontWeight = FontWeight.Black, fontSize = 7.1.sp)
    }
}

@Composable
private fun PathStepSheet(step: PathStep, onClose: () -> Unit, onStart: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(pathBackground(step.state), CircleShape), contentAlignment = Alignment.Center) {
                Icon(pathIcon(step.state), contentDescription = null, tint = pathAccent(step.state), modifier = Modifier.size(24.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(step.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text(pathLabel(step.state), color = pathAccent(step.state), fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp)
        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallPathChip("+${step.rewardXp} XP", SuperColors.Blue, SuperColors.BlueSoft)
            SmallPathChip("+${step.rewardCoin} سکه", SuperColors.GoldDeep, SuperColors.GoldSoft)
            SmallPathChip(step.duration, SuperColors.Purple, Color(0xFFF1EAFE))
        }

        if (step.progressText != null) {
            Spacer(Modifier.height(10.dp))
            Text(step.progressText, color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.sp)
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(
                progress = { 0.34f },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.BlueSoft
            )
        }

        if (step.state == PathState.LOCKED) {
            Spacer(Modifier.height(10.dp))
            Card(colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2), shape = RoundedCornerShape(13.dp)) {
                Text("شرط باز شدن: ${step.unlockCondition}", modifier = Modifier.padding(10.dp), color = SuperColors.TextSecondary, fontSize = 9.sp)
            }
        }

        step.nextTitle?.let {
            Spacer(Modifier.height(9.dp))
            Text("بعد از این: $it", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
        }

        Spacer(Modifier.height(13.dp))
        when (step.state) {
            PathState.CURRENT -> {
                Button(
                    onClick = onStart,
                    modifier = Modifier.fillMaxWidth().height(43.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                ) { Text("شروع / ادامه", fontWeight = FontWeight.Black) }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuickAction("انجام شد", SuperColors.Green, Modifier.weight(1f), onClose)
                    QuickAction("بعداً", SuperColors.Blue, Modifier.weight(1f), onClose)
                    QuickAction("ناموفق", SuperColors.Red, Modifier.weight(1f), onClose)
                }
            }
            PathState.FAILED -> OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth().height(43.dp), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Outlined.Refresh, contentDescription = null, tint = SuperColors.Red)
                Spacer(Modifier.width(5.dp))
                Text("Reset و تلاش دوباره", color = SuperColors.Red, fontWeight = FontWeight.Bold)
            }
            else -> OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth().height(43.dp), shape = RoundedCornerShape(14.dp)) {
                Text("بستن", color = SuperColors.Blue, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickAction(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = color.copy(alpha = 0.08f),
        shape = RoundedCornerShape(11.dp)
    ) {
        Text(label, modifier = Modifier.padding(vertical = 8.dp), color = color, fontSize = 8.5.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
    }
}

private fun pathAccent(state: PathState): Color = when (state) {
    PathState.DONE -> SuperColors.Green
    PathState.FAILED -> SuperColors.Red
    PathState.CURRENT -> SuperColors.Blue
    PathState.LOCKED -> Color(0xFF97A4B3)
    PathState.NEUTRAL -> SuperColors.TextSecondary
}

private fun pathBackground(state: PathState): Color = when (state) {
    PathState.DONE -> Color(0xFFF0FBF6)
    PathState.FAILED -> Color(0xFFFFF3F3)
    PathState.CURRENT -> Color(0xFFF1F8FF)
    PathState.LOCKED -> Color.White.copy(alpha = 0.92f)
    PathState.NEUTRAL -> Color.White
}

private fun pathIcon(state: PathState): ImageVector = when (state) {
    PathState.DONE -> Icons.Outlined.Check
    PathState.FAILED -> Icons.Outlined.Close
    PathState.CURRENT -> Icons.Outlined.Flag
    PathState.LOCKED -> Icons.Outlined.Lock
    PathState.NEUTRAL -> Icons.Outlined.Flag
}

private fun pathLabel(state: PathState): String = when (state) {
    PathState.DONE -> "تکمیل شد"
    PathState.FAILED -> "ناموفق"
    PathState.CURRENT -> "مرحله فعال"
    PathState.LOCKED -> "قفل"
    PathState.NEUTRAL -> "بدون وضعیت"
}
