package com.superapp.progressgame.engine.scene

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import io.github.sceneview.SceneScope
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.math.Size

@Composable
fun SceneScope.StarterWorldScene(selectedObjectId: String?) {
    val lawn = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF7EA981), metallic = 0f, roughness = 0.96f)
    }
    val lawnDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF6A9770), metallic = 0f, roughness = 0.98f)
    }
    val soil = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF725B45), metallic = 0f, roughness = 0.98f)
    }
    val stone = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFDDD6CB), metallic = 0f, roughness = 0.72f)
    }
    val stoneWarm = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFD8C7AE), metallic = 0f, roughness = 0.76f)
    }
    val stoneDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF8F8E8B), metallic = 0.05f, roughness = 0.68f)
    }
    val wall = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFF1EEE8), metallic = 0f, roughness = 0.64f)
    }
    val wallAccent = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFD5CEC2), metallic = 0f, roughness = 0.66f)
    }
    val glass = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF6EB6D6), metallic = 0.14f, roughness = 0.14f)
    }
    val roof = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFA3A099), metallic = 0.1f, roughness = 0.58f)
    }
    val wood = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF8B5E40), metallic = 0f, roughness = 0.82f)
    }
    val woodDark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5C3F2D), metallic = 0f, roughness = 0.84f)
    }
    val metal = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF33414B), metallic = 0.85f, roughness = 0.24f)
    }
    val leaf = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF5AA56C), metallic = 0f, roughness = 0.92f)
    }
    val leafLight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF7BC58B), metallic = 0f, roughness = 0.92f)
    }
    val leafDeep = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF3E8652), metallic = 0f, roughness = 0.94f)
    }
    val trunk = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF6B442B), metallic = 0f, roughness = 0.95f)
    }
    val water = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF64BED8), metallic = 0.08f, roughness = 0.09f)
    }
    val waterSpark = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFFA8F3FF), metallic = 0.08f, roughness = 0.02f)
    }
    val lampGlow = remember(materialLoader) {
        materialLoader.createUnlitColorInstance(Color(0xFFFFE5AE))
    }
    val highlight = remember(materialLoader) {
        materialLoader.createColorInstance(Color(0xFF7CE2FF), metallic = 0.20f, roughness = 0.12f)
    }

    // Far foundation plane and primary walkable lawn.
    CubeNode(
        size = Size(x = 64f, y = 0.14f, z = 64f),
        materialInstance = soil,
        position = Position(x = 0f, y = -0.23f, z = -2f),
        apply = { name = "terrain_far"; isTouchable = false }
    )
    CubeNode(
        size = Size(x = 34f, y = 0.16f, z = 32f),
        materialInstance = lawn,
        position = Position(x = 0f, y = 0f, z = -1.4f),
        apply = { name = "terrain_main"; isTouchable = false }
    )

    // Perimeter berms to remove the flat-table feeling and give the scene natural boundaries.
    listOf(
        PerimeterMound(0f, -14.5f, 11.5f, 1.7f, 0.85f),
        PerimeterMound(0f, 11.5f, 12.5f, 1.3f, 0.85f),
        PerimeterMound(-13.0f, -1.5f, 10.5f, 1.2f, 1.0f),
        PerimeterMound(13.0f, -1.5f, 10.5f, 1.2f, 1.0f),
        PerimeterMound(-10.5f, -10f, 8.0f, 1.0f, 0.7f),
        PerimeterMound(10.5f, -10f, 8.0f, 1.0f, 0.7f),
    ).forEachIndexed { index, mound ->
        SphereNode(
            radius = mound.radius,
            materialInstance = if (index % 2 == 0) lawnDark else leafDeep,
            position = Position(x = mound.x, y = 0.18f, z = mound.z),
            scale = Scale(x = mound.scaleX, y = 0.22f, z = mound.scaleZ),
            apply = { name = "berm_$index"; isTouchable = false }
        )
    }

    // Entry plaza and gate moved slightly forward and reduced in dominance.
    CubeNode(
        size = Size(x = 5.2f, y = 0.08f, z = 1.5f),
        materialInstance = stoneWarm,
        position = Position(x = 0f, y = 0.04f, z = 10.4f),
        apply = { name = "entry_plaza"; isTouchable = false }
    )
    Node(position = Position(x = 0f, y = 0f, z = 10.9f)) {
        val gateMaterial = if (selectedObjectId == "entrance_gate") highlight else stoneWarm
        CubeNode(
            size = Size(x = 0.42f, y = 2.7f, z = 0.42f),
            materialInstance = gateMaterial,
            position = Position(x = -1.65f, y = 1.35f, z = 0f),
            apply = { name = "entrance_gate_left" }
        )
        CubeNode(
            size = Size(x = 0.42f, y = 2.7f, z = 0.42f),
            materialInstance = gateMaterial,
            position = Position(x = 1.65f, y = 1.35f, z = 0f),
            apply = { name = "entrance_gate_right" }
        )
        CubeNode(
            size = Size(x = 3.7f, y = 0.28f, z = 0.42f),
            materialInstance = gateMaterial,
            position = Position(x = 0f, y = 2.56f, z = 0f),
            apply = { name = "entrance_gate_top" }
        )
    }

    // Organic path from gate to fountain and terrace.
    listOf(
        Paver(0.0f, 8.8f, -2f), Paver(0.15f, 7.5f, -5f), Paver(0.35f, 6.1f, -8f),
        Paver(0.55f, 4.7f, -9f), Paver(0.35f, 3.3f, -6f), Paver(0.18f, 1.9f, -4f),
        Paver(0.02f, 0.55f, -2f), Paver(-0.05f, -0.75f, 0f), Paver(0f, -3.3f, 0f),
        Paver(0f, -4.5f, 0f), Paver(0f, -5.7f, 0f), Paver(0f, -6.8f, 0f),
    ).forEachIndexed { index, paver ->
        CubeNode(
            size = Size(x = 2.05f, y = 0.08f, z = 0.95f),
            materialInstance = if (index % 2 == 0) stone else stoneWarm,
            position = Position(x = paver.x, y = 0.04f, z = paver.z),
            rotation = Rotation(y = paver.rotationY),
            apply = { name = "path_$index"; isTouchable = false }
        )
    }

    // Central fountain hero object.
    Node(position = Position(x = 0f, y = 0f, z = -1.1f)) {
        val fountainMaterial = if (selectedObjectId == "fountain_main") highlight else stone
        CylinderNode(
            radius = 2.15f,
            height = 0.26f,
            materialInstance = fountainMaterial,
            position = Position(y = 0.13f),
            apply = { name = "fountain_main_base" }
        )
        CylinderNode(
            radius = 1.76f,
            height = 0.10f,
            materialInstance = water,
            position = Position(y = 0.32f),
            apply = { name = "fountain_main_pool" }
        )
        CylinderNode(
            radius = 0.34f,
            height = 1.55f,
            materialInstance = fountainMaterial,
            position = Position(y = 1.0f),
            apply = { name = "fountain_main_column" }
        )
        CylinderNode(
            radius = 0.92f,
            height = 0.16f,
            materialInstance = fountainMaterial,
            position = Position(y = 1.45f),
            apply = { name = "fountain_main_bowl" }
        )
        CylinderNode(
            radius = 0.62f,
            height = 0.08f,
            materialInstance = water,
            position = Position(y = 1.57f),
            apply = { name = "fountain_main_upper_pool" }
        )
        SphereNode(
            radius = 0.16f,
            materialInstance = waterSpark,
            position = Position(y = 2.02f),
            apply = { name = "fountain_main_splash" }
        )
        SphereNode(
            radius = 0.10f,
            materialInstance = waterSpark,
            position = Position(x = 0.48f, y = 1.72f, z = 0.1f),
            apply = { name = "fountain_main_droplet_a"; isTouchable = false }
        )
        SphereNode(
            radius = 0.08f,
            materialInstance = waterSpark,
            position = Position(x = -0.42f, y = 1.68f, z = -0.05f),
            apply = { name = "fountain_main_droplet_b"; isTouchable = false }
        )
    }

    // Mansion blockout upgraded with wings, frames and a terrace.
    Node(position = Position(x = 0f, y = 0f, z = -8.9f)) {
        val bodyMaterial = if (selectedObjectId == "mansion_main") highlight else wall
        CubeNode(
            size = Size(x = 8.6f, y = 2.9f, z = 4.1f),
            materialInstance = bodyMaterial,
            position = Position(x = 0f, y = 1.45f, z = 0f),
            apply = { name = "mansion_main_body" }
        )
        CubeNode(
            size = Size(x = 2.9f, y = 2.05f, z = 2.0f),
            materialInstance = wallAccent,
            position = Position(x = -2.15f, y = 3.8f, z = 0.35f),
            apply = { name = "mansion_main_upper" }
        )
        CubeNode(
            size = Size(x = 3.2f, y = 2.1f, z = 1.8f),
            materialInstance = wallAccent,
            position = Position(x = 2.4f, y = 1.92f, z = -0.35f),
            apply = { name = "mansion_main_side_wing"; isTouchable = false }
        )
        CubeNode(
            size = Size(x = 9.3f, y = 0.22f, z = 4.5f),
            materialInstance = roof,
            position = Position(x = 0f, y = 3.0f, z = 0f),
            apply = { name = "mansion_main_roof"; isTouchable = false }
        )
        CubeNode(
            size = Size(x = 3.6f, y = 0.18f, z = 1.95f),
            materialInstance = stoneWarm,
            position = Position(x = 0f, y = 0.09f, z = 2.78f),
            apply = { name = "mansion_main_steps"; isTouchable = false }
        )
        CubeNode(
            size = Size(x = 1.25f, y = 2.12f, z = 0.10f),
            materialInstance = woodDark,
            position = Position(x = 0f, y = 1.08f, z = 2.02f),
            apply = { name = "mansion_main_door" }
        )
        listOf(-3.0f, -1.55f, 1.55f, 3.0f).forEachIndexed { index, x ->
            CubeNode(
                size = Size(x = 1.08f, y = 1.38f, z = 0.08f),
                materialInstance = glass,
                position = Position(x = x, y = 1.58f, z = 2.02f),
                apply = { name = "mansion_main_window_$index"; isTouchable = false }
            )
            CubeNode(
                size = Size(x = 1.22f, y = 1.52f, z = 0.06f),
                materialInstance = wallAccent,
                position = Position(x = x, y = 1.58f, z = 2.0f),
                apply = { name = "mansion_main_frame_$index"; isTouchable = false }
            )
        }
        CubeNode(
            size = Size(x = 2.2f, y = 0.16f, z = 1.35f),
            materialInstance = stoneWarm,
            position = Position(x = 0f, y = 0.55f, z = 3.2f),
            apply = { name = "mansion_main_porch"; isTouchable = false }
        )
    }

    // Shrub clusters.
    listOf(
        PlantCluster(-3.8f, -0.7f, 0.55f), PlantCluster(3.8f, -0.65f, 0.52f),
        PlantCluster(-5.4f, 1.2f, 0.45f), PlantCluster(5.2f, 1.25f, 0.50f),
        PlantCluster(-4.6f, -5.9f, 0.62f), PlantCluster(4.8f, -5.8f, 0.62f),
    ).forEachIndexed { index, shrub ->
        SphereNode(
            radius = shrub.radius,
            materialInstance = if (index % 2 == 0) leaf else leafLight,
            position = Position(x = shrub.x, y = 0.32f, z = shrub.z),
            scale = Scale(x = 1.28f, y = 0.72f, z = 1.0f),
            apply = { name = "shrub_$index"; isTouchable = false }
        )
    }

    // Trees placed in varied clusters around the environment.
    listOf(
        TreePlacement("tree_w_01", -8.8f, 5.6f, 1.05f, 0),
        TreePlacement("tree_w_02", -10.0f, 1.8f, 1.20f, 1),
        TreePlacement("tree_w_03", -8.1f, -4.2f, 1.00f, 2),
        TreePlacement("tree_w_04", -10.8f, -8.5f, 1.30f, 0),
        TreePlacement("tree_e_01", 8.4f, 5.8f, 1.12f, 1),
        TreePlacement("tree_e_02", 10.1f, 1.0f, 1.20f, 2),
        TreePlacement("tree_e_03", 8.2f, -4.3f, 1.05f, 0),
        TreePlacement("tree_e_04", 10.9f, -8.4f, 1.35f, 1),
    ).forEach { tree ->
        renderTree(
            id = tree.id,
            x = tree.x,
            z = tree.z,
            scale = tree.scale,
            style = tree.style,
            selected = selectedObjectId == tree.id,
            trunk = trunk,
            leaf = leaf,
            leafLight = leafLight,
            leafDeep = leafDeep,
            highlight = highlight,
        )
    }

    renderBench("bench_w_01", -4.7f, 2.3f, 28f, selectedObjectId == "bench_w_01", wood, metal, highlight)
    renderBench("bench_e_01", 4.8f, 2.2f, -28f, selectedObjectId == "bench_e_01", wood, metal, highlight)
    renderBench("bench_w_02", -5.0f, -4.6f, 18f, false, wood, metal, highlight)
    renderBench("bench_e_02", 5.0f, -4.7f, -18f, false, wood, metal, highlight)

    listOf(
        Pair(-2.8f, 8.0f), Pair(2.8f, 8.0f),
        Pair(-2.5f, 4.2f), Pair(2.5f, 4.1f),
        Pair(-2.6f, 0.1f), Pair(2.6f, 0f),
        Pair(-2.7f, -4.3f), Pair(2.7f, -4.2f),
    ).forEachIndexed { index, (x, z) ->
        renderLamp(index = index, x = x, z = z, metal = metal, lampGlow = lampGlow)
    }
}

@Composable
private fun SceneScope.renderTree(
    id: String,
    x: Float,
    z: Float,
    scale: Float,
    style: Int,
    selected: Boolean,
    trunk: com.google.android.filament.MaterialInstance,
    leaf: com.google.android.filament.MaterialInstance,
    leafLight: com.google.android.filament.MaterialInstance,
    leafDeep: com.google.android.filament.MaterialInstance,
    highlight: com.google.android.filament.MaterialInstance,
) {
    val crownMaterial = if (selected) highlight else when (style % 3) {
        0 -> leaf
        1 -> leafLight
        else -> leafDeep
    }
    Node(position = Position(x = x, y = 0f, z = z), scale = Scale(scale)) {
        CylinderNode(
            radius = 0.26f,
            height = 2.5f,
            materialInstance = trunk,
            position = Position(y = 1.25f),
            apply = { name = "${id}_trunk" }
        )
        when (style % 3) {
            0 -> {
                ConeNode(
                    radius = 1.35f,
                    height = 2.3f,
                    materialInstance = crownMaterial,
                    position = Position(y = 2.45f),
                    apply = { name = "${id}_crown_a" }
                )
                ConeNode(
                    radius = 0.98f,
                    height = 2.0f,
                    materialInstance = crownMaterial,
                    position = Position(y = 3.4f),
                    apply = { name = "${id}_crown_b" }
                )
            }
            1 -> {
                SphereNode(
                    radius = 0.98f,
                    materialInstance = crownMaterial,
                    position = Position(y = 2.55f),
                    scale = Scale(x = 1.3f, y = 1.05f, z = 1.2f),
                    apply = { name = "${id}_crown_a" }
                )
                SphereNode(
                    radius = 0.72f,
                    materialInstance = crownMaterial,
                    position = Position(y = 3.55f, x = 0.15f),
                    scale = Scale(x = 1.0f, y = 1.1f, z = 1.0f),
                    apply = { name = "${id}_crown_b" }
                )
            }
            else -> {
                ConeNode(
                    radius = 1.12f,
                    height = 2.15f,
                    materialInstance = crownMaterial,
                    position = Position(y = 2.35f),
                    apply = { name = "${id}_crown_a" }
                )
                SphereNode(
                    radius = 0.68f,
                    materialInstance = crownMaterial,
                    position = Position(y = 3.35f),
                    scale = Scale(x = 1.15f, y = 1.0f, z = 1.1f),
                    apply = { name = "${id}_crown_b" }
                )
            }
        }
    }
}

@Composable
private fun SceneScope.renderBench(
    id: String,
    x: Float,
    z: Float,
    yaw: Float,
    selected: Boolean,
    wood: com.google.android.filament.MaterialInstance,
    metal: com.google.android.filament.MaterialInstance,
    highlight: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z), rotation = Rotation(y = yaw)) {
        val seatMaterial = if (selected) highlight else wood
        CubeNode(
            size = Size(x = 1.8f, y = 0.12f, z = 0.58f),
            materialInstance = seatMaterial,
            position = Position(y = 0.55f),
            apply = { name = "${id}_seat" }
        )
        CubeNode(
            size = Size(x = 1.8f, y = 0.62f, z = 0.12f),
            materialInstance = seatMaterial,
            position = Position(y = 0.9f, z = -0.24f),
            apply = { name = "${id}_back" }
        )
        listOf(-0.7f, 0.7f).forEachIndexed { index, legX ->
            CubeNode(
                size = Size(x = 0.10f, y = 0.55f, z = 0.10f),
                materialInstance = metal,
                position = Position(x = legX, y = 0.27f),
                apply = { name = "${id}_leg_$index" }
            )
        }
    }
}

@Composable
private fun SceneScope.renderLamp(
    index: Int,
    x: Float,
    z: Float,
    metal: com.google.android.filament.MaterialInstance,
    lampGlow: com.google.android.filament.MaterialInstance,
) {
    Node(position = Position(x = x, y = 0f, z = z)) {
        CylinderNode(
            radius = 0.08f,
            height = 2.1f,
            materialInstance = metal,
            position = Position(y = 1.05f),
            apply = { name = "lamp_${index}_post"; isTouchable = false }
        )
        SphereNode(
            radius = 0.20f,
            materialInstance = lampGlow,
            position = Position(y = 2.12f),
            apply = { name = "lamp_${index}_glow"; isTouchable = false }
        )
    }
}

private data class TreePlacement(
    val id: String,
    val x: Float,
    val z: Float,
    val scale: Float,
    val style: Int,
)

private data class Paver(
    val x: Float,
    val z: Float,
    val rotationY: Float,
)

private data class PlantCluster(
    val x: Float,
    val z: Float,
    val radius: Float,
)

private data class PerimeterMound(
    val x: Float,
    val z: Float,
    val radius: Float,
    val scaleX: Float,
    val scaleZ: Float,
)
