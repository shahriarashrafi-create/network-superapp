package app.networksuper.ui.progress

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen

private enum class StepState { DONE, CURRENT, UPCOMING }

private data class ProgressStep(
    val number: Int,
    val title: String,
    val icon: ImageVector,
    val state: StepState
)

private data class NavItem(
    val label: String,
    val icon: ImageVector
)

@Composable
fun ProgressScreen(onHome: () -> Unit = {}) {
    val currentStep = 6
    val stepsDescending = remember {
        listOf(
            12 to Pair("قله هدف", Icons.Rounded.Flag),
            11 to Pair("رهبری تیم", Icons.Rounded.WorkspacePremium),
            10 to Pair("اهداف بلندمدت", Icons.Rounded.TrackChanges),
            9 to Pair("توسعه مهارت‌ها", Icons.Rounded.AutoAwesome),
            8 to Pair("ارتباط با مشتری", Icons.Rounded.Groups),
            7 to Pair("مدیریت مالی", Icons.Rounded.Assignment),
            6 to Pair("ورزش روزانه", Icons.Rounded.FitnessCenter),
            5 to Pair("مطالعه و یادگیری", Icons.Rounded.MenuBook),
            4 to Pair("روتین صبح", Icons.Rounded.WbSunny),
            3 to Pair("ساخت عادت", Icons.Rounded.AutoAwesome),
            2 to Pair("شروع مسیر", Icons.Rounded.TrendingUp),
            1 to Pair("قدم اول", Icons.Rounded.Home)
        ).map { (number, info) ->
            ProgressStep(
                number = number,
                title = info.first,
                icon = info.second,
                state = when {
                    number < currentStep -> StepState.DONE
                    number == currentStep -> StepState.CURRENT
                    else -> StepState.UPCOMING
                }
            )
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppBackground,
            bottomBar = { ProgressBottomNav(onHome = onHome) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                ProgressHeader(
                    currentStep = currentStep,
                    totalSteps = stepsDescending.size,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                JourneyViewport(
                    steps = stepsDescending,
                    currentStep = currentStep,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ProgressHeader(
    currentStep: Int,
    totalSteps: Int,
    modifier: Modifier = Modifier
) {
    val progress = currentStep.toFloat() / totalSteps.toFloat()

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.90f))
            .border(1.dp, Color.White, RoundedCornerShape(24.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        HeaderBackdrop(Modifier.matchParentSize())

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SoftBlue,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            PrimaryBlue.copy(alpha = 0.18f)
                        )
                    ) {
                        Text(
                            text = "مرحله $currentStep از $totalSteps",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = PrimaryBlue,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Black
                        )
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PremiumHeaderIcon()
                            Text(
                                text = "مسیر پیشرفت",
                                color = Navy,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(9.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCE8F7))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progress)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)
                                    )
                                )
                        )
                        ProgressMilestones()
                    }
                    Text(
                        text = "${(progress * 100).toInt()}٪",
                        color = PrimaryBlue,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun ProgressMilestones() {
    Box(modifier = Modifier.fillMaxSize()) {
        listOf(0.25f, 0.50f, 0.75f).forEach { fraction ->
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxWidth(fraction)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .size(4.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.95f))
                )
            }
        }
    }
}

@Composable
private fun HeaderBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(0f, h * 0.05f)
            cubicTo(w * 0.20f, h * 0.28f, w * 0.34f, h * 0.02f, w * 0.55f, h * 0.18f)
            cubicTo(w * 0.74f, h * 0.34f, w * 0.87f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.50f)
            cubicTo(w * 0.78f, h * 0.36f, w * 0.62f, h * 0.55f, w * 0.43f, h * 0.40f)
            cubicTo(w * 0.23f, h * 0.25f, w * 0.10f, h * 0.45f, 0f, h * 0.31f)
            close()
        }
        drawPath(p, Color(0xFF9FD6FF).copy(alpha = 0.13f))
    }
}

@Composable
private fun PremiumHeaderIcon() {
    Box(
        modifier = Modifier
            .size(40.dp)
            .shadow(3.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White, RewardGold.copy(alpha = 0.14f))
                )
            )
            .border(1.dp, RewardGold.copy(alpha = 0.20f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.EmojiEvents,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(23.dp)
        )
    }
}

@Composable
private fun JourneyViewport(
    steps: List<ProgressStep>,
    currentStep: Int,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(26.dp))
            .background(Color.White.copy(alpha = 0.48f))
            .border(1.dp, Color.White.copy(alpha = 0.88f), RoundedCornerShape(26.dp))
    ) {
        JourneyBackdrop(Modifier.matchParentSize())

        // 3 full task cards + 20% of the card above and below.
        val rowHeight = maxHeight / 3.4f
        val density = LocalDensity.current
        val topPartialStep = (currentStep + 3).coerceAtMost(steps.maxOf { it.number })
        val firstVisibleIndex = steps.indexOfFirst { it.number == topPartialStep }.coerceAtLeast(0)
        val eightyPercentPx = with(density) { (rowHeight * 0.80f).roundToPx() }
        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = firstVisibleIndex,
            initialFirstVisibleItemScrollOffset = eightyPercentPx
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = true
        ) {
            itemsIndexed(
                items = steps,
                key = { _, item -> item.number }
            ) { _, step ->
                ProgressStepRow(
                    step = step,
                    cardOnRight = cardOnRight(step.number),
                    rowHeight = rowHeight,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Stronger edge fades communicate vertical scrolling while keeping only 20% peeking through.
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(rowHeight * 0.32f)
                .background(
                    Brush.verticalGradient(
                        0f to AppBackground.copy(alpha = 0.98f),
                        0.45f to AppBackground.copy(alpha = 0.58f),
                        1f to Color.Transparent
                    )
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(rowHeight * 0.32f)
                .background(
                    Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.55f to AppBackground.copy(alpha = 0.58f),
                        1f to AppBackground.copy(alpha = 0.98f)
                    )
                )
        )
    }
}

/**
 * Two cards stay on one side, then two on the other side.
 * When cards are on the right the road travels on the left, and vice versa.
 */
private fun cardOnRight(stepNumber: Int): Boolean = (((stepNumber - 1) / 2) % 2 == 0)

private fun roadLaneForStep(stepNumber: Int): Float = if (cardOnRight(stepNumber)) 0.36f else 0.64f

@Composable
private fun JourneyBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height

        fun hill(baseY: Float, peakX: Float, peakY: Float, width: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(peakX - width / 2f, baseY)
                lineTo(peakX, peakY)
                lineTo(peakX + width / 2f, baseY)
                close()
            }
            drawPath(p, Color(0xFF86C6FF).copy(alpha = alpha))
        }

        // Only a few very soft layers so the page stays in the Home visual system.
        hill(h * 0.28f, w * 0.18f, h * 0.14f, w * 0.56f, 0.055f)
        hill(h * 0.27f, w * 0.75f, h * 0.11f, w * 0.66f, 0.050f)
        hill(h * 0.64f, w * 0.74f, h * 0.49f, w * 0.62f, 0.045f)
        hill(h * 0.94f, w * 0.24f, h * 0.80f, w * 0.64f, 0.042f)

        drawCircle(
            color = PrimaryBlue.copy(alpha = 0.055f),
            radius = w * 0.15f,
            center = Offset(w * 0.92f, h * 0.11f)
        )
        drawCircle(
            color = SuccessGreen.copy(alpha = 0.040f),
            radius = w * 0.12f,
            center = Offset(w * 0.04f, h * 0.72f)
        )
    }
}

@Composable
private fun ProgressStepRow(
    step: ProgressStep,
    cardOnRight: Boolean,
    rowHeight: Dp,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.height(rowHeight)) {
        JourneyRoadSegment(
            step = step,
            modifier = Modifier.fillMaxSize()
        )

        StepCard(
            step = step,
            modifier = Modifier
                .align(if (cardOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                .fillMaxWidth(0.53f)
                .padding(horizontal = 7.dp)
        )

        StepNode(
            step = step,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(roadLaneForStep(step.number))
                .offset(x = 0.dp)
        )

        if (step.number % 5 == 0) {
            CheckpointBadge(
                modifier = Modifier
                    .align(if (cardOnRight) Alignment.TopStart else Alignment.TopEnd)
                    .padding(horizontal = 18.dp, vertical = 6.dp)
            )
        } else if (step.number % 3 == 0 && step.state != StepState.CURRENT) {
            RewardBadge(
                modifier = Modifier
                    .align(if (cardOnRight) Alignment.TopStart else Alignment.TopEnd)
                    .padding(horizontal = 22.dp, vertical = 10.dp)
            )
        }

        if (step.state == StepState.CURRENT) {
            CurrentSparkles(
                modifier = Modifier
                    .align(if (cardOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                    .fillMaxWidth(0.58f)
                    .height(116.dp)
            )
        }
    }
}

@Composable
private fun JourneyRoadSegment(
    step: ProgressStep,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val currentX = w * roadLaneForStep(step.number)
        val bottomNumber = (step.number - 1).coerceAtLeast(1)
        val topNumber = (step.number + 1).coerceAtMost(12)
        val bottomX = w * roadLaneForStep(bottomNumber)
        val topX = w * roadLaneForStep(topNumber)

        val road = Path().apply {
            moveTo(bottomX, h + 3f)
            cubicTo(
                bottomX,
                h * 0.76f,
                currentX,
                h * 0.70f,
                currentX,
                h * 0.50f
            )
            cubicTo(
                currentX,
                h * 0.30f,
                topX,
                h * 0.24f,
                topX,
                -3f
            )
        }

        // Wide white shoulder + stronger blue road = more game-map presence.
        drawPath(
            path = road,
            color = Color.White.copy(alpha = 0.98f),
            style = Stroke(width = 31.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = road,
            brush = Brush.verticalGradient(
                listOf(
                    PrimaryBlue.copy(alpha = if (step.state == StepState.UPCOMING) 0.24f else 0.52f),
                    Color(0xFF55B8FF).copy(alpha = if (step.state == StepState.UPCOMING) 0.40f else 0.78f),
                    PrimaryBlue.copy(alpha = if (step.state == StepState.UPCOMING) 0.24f else 0.52f)
                )
            ),
            style = Stroke(width = 20.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = road,
            color = Color.White.copy(alpha = 0.92f),
            style = Stroke(
                width = 2.5.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(
                    floatArrayOf(8.dp.toPx(), 9.dp.toPx()),
                    0f
                )
            )
        )

        // Short connector from the game node toward its task card.
        val node = Offset(currentX, h * 0.50f)
        val towardRight = cardOnRight(step.number)
        val endX = if (towardRight) w * 0.49f else w * 0.51f
        drawLine(
            color = PrimaryBlue.copy(alpha = if (step.state == StepState.UPCOMING) 0.12f else 0.24f),
            start = node,
            end = Offset(endX, node.y),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun StepNode(step: ProgressStep, modifier: Modifier = Modifier) {
    val pulseTransition = rememberInfiniteTransition(label = "currentNodePulse")
    val currentPulse by pulseTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1050),
            repeatMode = RepeatMode.Reverse
        ),
        label = "currentNodePulseValue"
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.CenterEnd
    ) {
        val nodeColor = when (step.state) {
            StepState.DONE -> SuccessGreen
            StepState.CURRENT -> PrimaryBlue
            StepState.UPCOMING -> Color.White
        }
        val borderColor = when (step.state) {
            StepState.DONE -> Color.White
            StepState.CURRENT -> Color.White
            StepState.UPCOMING -> Color(0xFFAFC0D8)
        }

        if (step.state == StepState.CURRENT) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .graphicsLayer {
                        scaleX = currentPulse
                        scaleY = currentPulse
                    }
                    .clip(CircleShape)
                    .background(PrimaryBlue.copy(alpha = 0.10f))
            )
        }

        Box(
            modifier = Modifier
                .size(if (step.state == StepState.CURRENT) 50.dp else 43.dp)
                .shadow(
                    if (step.state == StepState.CURRENT) 10.dp else 3.dp,
                    CircleShape,
                    ambientColor = when (step.state) {
                        StepState.DONE -> SuccessGreen.copy(alpha = 0.20f)
                        StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.32f)
                        StepState.UPCOMING -> Color.Black.copy(alpha = 0.05f)
                    },
                    spotColor = when (step.state) {
                        StepState.DONE -> SuccessGreen.copy(alpha = 0.24f)
                        StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.38f)
                        StepState.UPCOMING -> Color.Black.copy(alpha = 0.05f)
                    }
                )
                .clip(CircleShape)
                .background(nodeColor)
                .border(3.dp, borderColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when (step.state) {
                StepState.DONE -> Icon(
                    Icons.Rounded.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(25.dp)
                )
                StepState.CURRENT -> Text(
                    text = step.number.toString(),
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black
                )
                StepState.UPCOMING -> Icon(
                    Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = Muted.copy(alpha = 0.65f),
                    modifier = Modifier.size(19.dp)
                )
            }
        }
    }
}

@Composable
private fun StepCard(step: ProgressStep, modifier: Modifier = Modifier) {
    val container = when (step.state) {
        StepState.DONE -> Brush.horizontalGradient(
            listOf(Color.White, SuccessGreen.copy(alpha = 0.10f))
        )
        StepState.CURRENT -> Brush.horizontalGradient(
            listOf(Color.White, Color(0xFFE8F4FF))
        )
        StepState.UPCOMING -> Brush.horizontalGradient(
            listOf(Color.White.copy(alpha = 0.94f), SoftBlue.copy(alpha = 0.58f))
        )
    }

    val borderColor = when (step.state) {
        StepState.DONE -> SuccessGreen.copy(alpha = 0.22f)
        StepState.CURRENT -> PrimaryBlue
        StepState.UPCOMING -> Color.White.copy(alpha = 0.92f)
    }

    Surface(
        modifier = modifier
            .height(if (step.state == StepState.CURRENT) 102.dp else 94.dp)
            .graphicsLayer {
                alpha = if (step.state == StepState.UPCOMING) 0.86f else 1f
            }
            .shadow(
                if (step.state == StepState.CURRENT) 11.dp else 4.dp,
                RoundedCornerShape(24.dp),
                ambientColor = when (step.state) {
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.16f)
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.08f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.04f)
                },
                spotColor = when (step.state) {
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.20f)
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.08f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.04f)
                }
            ),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
            if (step.state == StepState.CURRENT) 2.dp else 1.dp,
            borderColor
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(container)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StepIconBubble(step)
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.Center
                ) {
                    if (step.state == StepState.CURRENT) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = PrimaryBlue
                        ) {
                            Text(
                                text = "مرحله فعلی",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(Modifier.height(5.dp))
                    } else {
                        Text(
                            text = "مرحله ${step.number}",
                            color = if (step.state == StepState.DONE) SuccessGreen else Muted.copy(alpha = 0.74f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(3.dp))
                    }

                    Text(
                        text = step.title,
                        color = if (step.state == StepState.UPCOMING) Navy.copy(alpha = 0.74f) else Navy,
                        fontSize = if (step.state == StepState.CURRENT) 20.sp else 18.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Right,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun StepIconBubble(step: ProgressStep) {
    val accent = when (step.state) {
        StepState.DONE -> SuccessGreen
        StepState.CURRENT -> PrimaryBlue
        StepState.UPCOMING -> PrimaryBlue.copy(alpha = 0.64f)
    }

    Box(
        modifier = Modifier
            .size(if (step.state == StepState.CURRENT) 54.dp else 50.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White, accent.copy(alpha = 0.18f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = step.icon,
            contentDescription = step.title,
            tint = accent,
            modifier = Modifier.size(if (step.state == StepState.CURRENT) 30.dp else 27.dp)
        )
    }
}

@Composable
private fun CheckpointBadge(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.shadow(4.dp, CircleShape),
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.96f),
        border = androidx.compose.foundation.BorderStroke(1.dp, RewardGold.copy(alpha = 0.18f))
    ) {
        Icon(
            imageVector = Icons.Rounded.Flag,
            contentDescription = "Checkpoint",
            tint = PrimaryBlue,
            modifier = Modifier
                .padding(8.dp)
                .size(22.dp)
        )
    }
}

@Composable
private fun RewardBadge(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.shadow(3.dp, CircleShape),
        shape = CircleShape,
        color = Color.White.copy(alpha = 0.95f),
        border = androidx.compose.foundation.BorderStroke(1.dp, RewardGold.copy(alpha = 0.16f))
    ) {
        Icon(
            imageVector = Icons.Rounded.Star,
            contentDescription = "Reward",
            tint = RewardGold,
            modifier = Modifier
                .padding(7.dp)
                .size(18.dp)
        )
    }
}

@Composable
private fun CurrentSparkles(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        fun sparkle(x: Float, y: Float, r: Float) {
            val p = Path().apply {
                moveTo(x, y - r)
                lineTo(x + r * 0.28f, y - r * 0.28f)
                lineTo(x + r, y)
                lineTo(x + r * 0.28f, y + r * 0.28f)
                lineTo(x, y + r)
                lineTo(x - r * 0.28f, y + r * 0.28f)
                lineTo(x - r, y)
                lineTo(x - r * 0.28f, y - r * 0.28f)
                close()
            }
            drawPath(p, RewardGold.copy(alpha = 0.88f))
        }
        sparkle(size.width * 0.10f, size.height * 0.18f, 5.dp.toPx())
        sparkle(size.width * 0.88f, size.height * 0.78f, 3.5.dp.toPx())
        sparkle(size.width * 0.18f, size.height * 0.84f, 3.dp.toPx())
    }
}

@Composable
private fun ProgressBottomNav(onHome: () -> Unit) {
    val selectedIndex = 1
    val navItems = listOf(
        NavItem("خانه", Icons.Rounded.Home),
        NavItem("مسیر پیشرفت", Icons.Rounded.TrendingUp),
        NavItem("لیست مشتریان", Icons.Rounded.Groups),
        NavItem("لیست شبکه‌سازی", Icons.Rounded.AccountTree),
        NavItem("بیشتر", Icons.Rounded.MoreHoriz)
    )

    // Exact visual language of Home's bottom navigation.
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 7.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val active = index == selectedIndex
                val containerColor by animateColorAsState(
                    targetValue = if (active) SoftBlue else Color.Transparent,
                    label = "progressNavColor"
                )
                val elevation by animateDpAsState(
                    targetValue = if (active) 7.dp else 0.dp,
                    label = "progressNavElevation"
                )
                val scale by animateFloatAsState(
                    targetValue = if (active) 1.06f else 1f,
                    label = "progressNavScale"
                )
                val tint by animateColorAsState(
                    targetValue = if (active) PrimaryBlue else Muted,
                    label = "progressNavTint"
                )

                Surface(
                    onClick = { if (index == 0) onHome() },
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = containerColor,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.25.dp,
                        PrimaryBlue.copy(alpha = 0.22f)
                    ) else null,
                    shadowElevation = elevation
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            modifier = Modifier.size(if (active) 26.dp else 22.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = tint,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
