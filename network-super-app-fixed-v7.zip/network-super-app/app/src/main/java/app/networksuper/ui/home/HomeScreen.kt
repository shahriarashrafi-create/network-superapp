package app.networksuper.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.ui.theme.*

private data class ScheduleItem(
    val time: String,
    val title: String,
    val icon: ImageVector,
    val accent: Color,
    val done: Boolean = false
)

private data class ProgressTask(
    val title: String,
    val icon: ImageVector,
    val accent: Color,
    val done: Boolean = false
)

private data class NavItem(
    val label: String,
    val icon: ImageVector
)

@Composable
fun HomeScreen() {
    var selectedNav by remember { mutableIntStateOf(0) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppBackground,
            bottomBar = {
                GameBottomNav(
                    selectedIndex = selectedNav,
                    onSelected = { selectedNav = it }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HomeHeader(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.16f)
                )
                NextActionCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.24f)
                )
                TodaySection(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.30f)
                )
                ProgressSection(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.30f)
                )
            }
        }
    }
}

@Composable
private fun HomeHeader(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
    ) {
        HeaderWaveBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ComboTile(count = 3)
                        RewardTile(showDot = true)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            ProfileAvatar()
                            Column(horizontalAlignment = Alignment.End) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.AutoAwesome,
                                        contentDescription = null,
                                        tint = RewardGold,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Text(
                                        text = "سلام شهریار",
                                        color = Navy,
                                        style = MaterialTheme.typography.headlineSmall,
                                        textAlign = TextAlign.Right,
                                        maxLines = 1
                                    )
                                }
                                Spacer(Modifier.height(2.dp))
                                RankBadge()
                            }
                        }
                    }
                }
            }

            XpProgressRow(
                current = 2480,
                target = 3000
            )
        }
    }
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val wave1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.32f)
            cubicTo(w * 0.74f, h * 0.12f, w * 0.60f, h * 0.42f, w * 0.38f, h * 0.28f)
            cubicTo(w * 0.20f, h * 0.16f, w * 0.10f, h * 0.34f, 0f, h * 0.20f)
            close()
        }
        drawPath(
            path = wave1,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = 0.34f),
                    Color(0xFF8CCBFF).copy(alpha = 0.18f),
                    Color.Transparent
                )
            )
        )

        val wave2 = Path().apply {
            moveTo(0f, h * 0.08f)
            cubicTo(w * 0.18f, h * 0.30f, w * 0.32f, h * 0.04f, w * 0.48f, h * 0.18f)
            cubicTo(w * 0.66f, h * 0.34f, w * 0.80f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.46f)
            cubicTo(w * 0.80f, h * 0.32f, w * 0.63f, h * 0.52f, w * 0.45f, h * 0.38f)
            cubicTo(w * 0.24f, h * 0.22f, w * 0.12f, h * 0.44f, 0f, h * 0.31f)
            close()
        }
        drawPath(
            path = wave2,
            color = Color.White.copy(alpha = 0.28f)
        )
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(56.dp)
            .shadow(8.dp, CircleShape, ambientColor = PrimaryBlue.copy(alpha = 0.18f), spotColor = PrimaryBlue.copy(alpha = 0.22f))
            .clip(CircleShape)
            .background(Color(0xFFE9F5FF))
            .border(2.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(49.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))
                    )
                )
                .border(2.5.dp, RewardGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Person,
                contentDescription = "پروفایل",
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
private fun RankBadge() {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF0A1E63), Color(0xFF17368B))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = "Builder",
            color = Color.White,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun ComboTile(count: Int) {
    Row(
        modifier = Modifier
            .height(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFBF4), Color(0xFFFFF0D8))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.95f), RoundedCornerShape(17.dp))
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = "کمبو",
                tint = Color(0xFFFF6A1A),
                modifier = Modifier.size(30.dp)
            )
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = null,
                tint = Color(0xFFFFC83D),
                modifier = Modifier.size(17.dp)
            )
            Icon(
                Icons.Rounded.AutoAwesome,
                contentDescription = null,
                tint = RewardGold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(8.dp)
            )
        }
        Text(
            text = count.toString(),
            color = Navy,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun RewardTile(showDot: Boolean) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFFFF), Color(0xFFFFF3E5))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.96f), RoundedCornerShape(17.dp)),
        contentAlignment = Alignment.Center
    ) {
        RewardGiftAsset(Modifier.size(34.dp))
        if (showDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(8.dp)
                    .background(Color(0xFFFF4057), CircleShape)
            )
        }
    }
}

@Composable
private fun RewardGiftAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFD348), Color(0xFFF09A16))
            ),
            topLeft = Offset(w * 0.15f, h * 0.38f),
            size = Size(w * 0.70f, h * 0.45f),
            cornerRadius = CornerRadius(w * 0.09f, w * 0.09f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFE676), Color(0xFFFFB51A))
            ),
            topLeft = Offset(w * 0.11f, h * 0.31f),
            size = Size(w * 0.78f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )
        drawRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.44f, h * 0.31f),
            size = Size(w * 0.12f, h * 0.52f)
        )
        drawRoundRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.30f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = Color(0xFFFF6671),
            topLeft = Offset(w * 0.50f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.70f),
            radius = w * 0.035f,
            center = Offset(w * 0.26f, h * 0.43f)
        )
        drawLine(
            color = Color.White.copy(alpha = 0.65f),
            start = Offset(w * 0.18f, h * 0.35f),
            end = Offset(w * 0.35f, h * 0.35f),
            strokeWidth = 2.2f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun XpProgressRow(current: Int, target: Int) {
    val progress = (current.toFloat() / target.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(3.dp, RoundedCornerShape(18.dp), ambientColor = PrimaryBlue.copy(alpha = 0.05f), spotColor = PrimaryBlue.copy(alpha = 0.07f)),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.82f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.92f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(
                    text = "$current XP",
                    color = PrimaryBlue,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(9.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCE8F7))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)
                                )
                            )
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .offset(x = 3.dp)
                            .size(3.dp)
                            .background(Color.White.copy(alpha = 0.72f), CircleShape)
                    )
                }

                Text(
                    text = target.toString(),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun NextActionCard(modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .shadow(6.dp, RoundedCornerShape(24.dp), ambientColor = PrimaryBlue.copy(alpha = 0.10f), spotColor = PrimaryBlue.copy(alpha = 0.12f))
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFF045FD8), Color(0xFF168DF8), Color(0xFFEAF7FF))
                    )
                )
        ) {
            GeometricQuestArt(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.53f)
                    .align(Alignment.CenterStart)
            )

            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxWidth(0.66f)
                    .fillMaxHeight()
                    .padding(start = 8.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.SpaceEvenly
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        PremiumSmallIcon(
                            icon = Icons.Rounded.TrackChanges,
                            accent = Color(0xFFFF4B3E),
                            contentDescription = null
                        )
                        Text(
                            text = "قدم بعدی",
                            color = Navy,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth(0.88f),
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.97f),
                        shadowElevation = 4.dp
                    ) {
                        Text(
                            text = "پیگیری با علی رضایی",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            textAlign = TextAlign.Right,
                            color = Navy,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = { },
                        modifier = Modifier
                            .fillMaxWidth(0.80f)
                            .height(44.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                        contentPadding = PaddingValues(horizontal = 14.dp)
                    ) {
                        Icon(
                            Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "شروع",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GeometricQuestArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        for (i in 0..5) {
            val x = w * (0.08f + i * 0.16f)
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(x, 0f),
                end = Offset(x - h * 0.25f, h),
                strokeWidth = 2f
            )
        }

        val path = Path().apply {
            moveTo(w * 0.08f, h * 0.78f)
            cubicTo(w * 0.22f, h * 0.70f, w * 0.26f, h * 0.49f, w * 0.42f, h * 0.56f)
            cubicTo(w * 0.58f, h * 0.64f, w * 0.62f, h * 0.33f, w * 0.84f, h * 0.25f)
        }
        drawPath(
            path = path,
            color = Color(0xFFFFD35A),
            style = Stroke(width = 6f, cap = StrokeCap.Round)
        )

        listOf(
            Offset(w * 0.10f, h * 0.77f),
            Offset(w * 0.40f, h * 0.56f),
            Offset(w * 0.62f, h * 0.46f),
            Offset(w * 0.84f, h * 0.25f)
        ).forEach { p ->
            drawCircle(Color.White, radius = 11f, center = p)
            drawCircle(Color(0xFFFFD35A), radius = 11f, center = p, style = Stroke(width = 4f))
        }

        for (i in 0..3) {
            val left = w * (0.10f + i * 0.20f)
            val top = h * (0.12f + (i % 2) * 0.18f)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.10f),
                topLeft = Offset(left, top),
                size = Size(w * 0.22f, w * 0.22f),
                cornerRadius = CornerRadius(14f, 14f),
                style = Stroke(width = 3f)
            )
        }
    }
}

@Composable
private fun TodaySection(modifier: Modifier = Modifier) {
    val scheduleItems = listOf(
        ScheduleItem("10:00", "تماس", Icons.Rounded.Call, SuccessGreen, true),
        ScheduleItem("15:00", "جلسه معرفی", Icons.Rounded.Groups, PrimaryBlue),
        ScheduleItem("18:00", "جلسه تیم", Icons.Rounded.Group, WarningOrange),
        ScheduleItem("21:00", "پیگیری", Icons.Rounded.Assignment, AccentPurple)
    )

    HomeSectionCard(modifier = modifier) {
        SectionHeader(
            title = "امروز من",
            rightIcon = Icons.Rounded.CheckCircle,
            rightIconTint = SuccessGreen,
            leftContent = {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(SoftBlue)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        Icons.Rounded.CalendarMonth,
                        contentDescription = null,
                        tint = PrimaryBlue,
                        modifier = Modifier.size(19.dp)
                    )
                    Text(
                        text = "دوشنبه ۲۳ مهر",
                        color = Navy,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )

        Spacer(Modifier.height(5.dp))

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            val todayRowState = rememberLazyListState()
            LazyRow(
                state = todayRowState,
                modifier = Modifier.weight(1f),
                reverseLayout = true,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 0.dp)
            ) {
                itemsIndexed(scheduleItems) { index, item ->
                    val visibleItem = todayRowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                    val isEdgePreview = visibleItem != null && (
                        visibleItem.offset < todayRowState.layoutInfo.viewportStartOffset ||
                            visibleItem.offset + visibleItem.size > todayRowState.layoutInfo.viewportEndOffset
                        )
                    ScheduleCard(
                        item = item,
                        modifier = Modifier
                            .width(140.dp)
                            .fillMaxHeight()
                            .graphicsLayer { alpha = if (isEdgePreview) 0.62f else 1f }
                    )
                }
            }
        }
    }
}

@Composable
private fun ScheduleCard(item: ScheduleItem, modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(19.dp),
            colors = CardDefaults.cardColors(containerColor = item.accent.copy(alpha = 0.065f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, item.accent.copy(alpha = 0.17f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusMark(done = item.done)
                        Text(
                            text = item.time,
                            color = item.accent,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                PremiumIconBubble(
                    icon = item.icon,
                    accent = item.accent,
                    contentDescription = item.title,
                    modifier = Modifier.size(43.dp)
                )

                Text(
                    text = item.title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ProgressSection(modifier: Modifier = Modifier) {
    val taskItems = listOf(
        ProgressTask("مرتب کردن اتاق", Icons.Rounded.Hotel, SuccessGreen, true),
        ProgressTask("روتین صبح", Icons.Rounded.WbSunny, WarningOrange),
        ProgressTask("نرمش روزانه", Icons.Rounded.FitnessCenter, PrimaryBlue),
        ProgressTask("هدف بلندمدت", Icons.Rounded.Flag, AccentPurple)
    )

    HomeSectionCard(modifier = modifier) {
        SectionHeader(
            title = "مسیر پیشرفت",
            rightIcon = Icons.Rounded.EmojiEvents,
            rightIconTint = RewardGold,
            leftContent = {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SoftBlue
                ) {
                    Text(
                        text = "مرحله ۶ از ۱۲",
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                        color = PrimaryBlueDark,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        )

        Spacer(Modifier.height(5.dp))

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            val progressRowState = rememberLazyListState()
            LazyRow(
                state = progressRowState,
                modifier = Modifier.weight(1f),
                reverseLayout = true,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 0.dp)
            ) {
                itemsIndexed(taskItems) { index, task ->
                    val visibleItem = progressRowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                    val isEdgePreview = visibleItem != null && (
                        visibleItem.offset < progressRowState.layoutInfo.viewportStartOffset ||
                            visibleItem.offset + visibleItem.size > progressRowState.layoutInfo.viewportEndOffset
                        )
                    ProgressTaskCard(
                        task = task,
                        modifier = Modifier
                            .width(144.dp)
                            .fillMaxHeight()
                            .graphicsLayer { alpha = if (isEdgePreview) 0.62f else 1f }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProgressTaskCard(task: ProgressTask, modifier: Modifier = Modifier) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(19.dp),
            colors = CardDefaults.cardColors(containerColor = task.accent.copy(alpha = 0.06f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, task.accent.copy(alpha = 0.16f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        StatusMark(done = task.done)
                    }
                }

                PremiumIconBubble(
                    icon = task.icon,
                    accent = task.accent,
                    contentDescription = task.title,
                    modifier = Modifier.size(43.dp)
                )

                Text(
                    text = task.title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StatusMark(done: Boolean) {
    Icon(
        imageVector = if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
        contentDescription = if (done) "انجام شده" else "انجام نشده",
        tint = if (done) SuccessGreen else Muted.copy(alpha = 0.50f),
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun PremiumIconBubble(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(2.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        Color.White.copy(alpha = 0.92f),
                        accent.copy(alpha = 0.18f)
                    )
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun PremiumSmallIcon(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?
) {
    Box(
        modifier = Modifier
            .size(31.dp)
            .shadow(1.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.88f), accent.copy(alpha = 0.13f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.82f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(23.dp)
        )
    }
}

@Composable
private fun HomeSectionCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            content = content
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    rightIcon: ImageVector,
    rightIconTint: Color,
    leftContent: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            leftContent()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PremiumSmallIcon(
                        icon = rightIcon,
                        accent = rightIconTint,
                        contentDescription = null
                    )
                    Text(
                        text = title,
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun GameBottomNav(selectedIndex: Int, onSelected: (Int) -> Unit) {
    val navItems = listOf(
        NavItem("خانه", Icons.Rounded.Home),
        NavItem("مسیر پیشرفت", Icons.Rounded.TrendingUp),
        NavItem("لیست مشتریان", Icons.Rounded.Groups),
        NavItem("لیست شبکه‌سازی", Icons.Rounded.AccountTree),
        NavItem("بیشتر", Icons.Rounded.MoreHoriz)
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 7.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val active = index == selectedIndex
                val containerColor by animateColorAsState(
                    targetValue = if (active) SoftBlue else Color.Transparent,
                    label = "navColor"
                )
                val elevation by animateDpAsState(
                    targetValue = if (active) 7.dp else 0.dp,
                    label = "navElevation"
                )
                val scale by animateFloatAsState(
                    targetValue = if (active) 1.06f else 1f,
                    label = "navScale"
                )
                val tint by animateColorAsState(
                    targetValue = if (active) PrimaryBlue else Muted,
                    label = "navTint"
                )

                Surface(
                    onClick = { onSelected(index) },
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = containerColor,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.25.dp,
                        PrimaryBlue.copy(alpha = 0.22f)
                    ) else null,
                    shadowElevation = elevation
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            modifier = Modifier.size(if (active) 26.dp else 22.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = tint,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
