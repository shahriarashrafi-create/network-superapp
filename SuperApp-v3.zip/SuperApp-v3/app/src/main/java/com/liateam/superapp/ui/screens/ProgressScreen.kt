package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes

private data class PathStep(val title: String, val subtitle: String, val state: Int)

@Composable
fun ProgressScreen(contentPadding: PaddingValues, onBack: () -> Unit) {
    val steps = listOf(
        PathStep("روتین‌های پایه", "ساخت عادت‌های روزانه موفقیت", 1),
        PathStep("معرفی محصول", "آشنایی کامل با محصول", 1),
        PathStep("ارتباط‌سازی", "ایجاد و گسترش ارتباطات مؤثر", -1),
        PathStep("دعوت و پیش‌مشاوره", "مرحله فعلی مسیر", 2),
        PathStep("Follow-up", "پیگیری حرفه‌ای و مستمر", 0),
        PathStep("فروش و سفارش", "تبدیل علاقه‌مند به مشتری", 0)
    )

    LazyColumn(
        contentPadding = PaddingValues(
            start = SuperDimens.ScreenPadding,
            end = SuperDimens.ScreenPadding,
            top = contentPadding.calculateTopPadding() + 12.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.background(SuperColors.Background)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Text)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("مسیر پیشرفت", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                    Text("قدم‌های اصلی رشد کسب‌وکار", color = SuperColors.TextSecondary, fontSize = 13.sp)
                }
            }
        }

        items(steps.size) { index ->
            val step = steps[index]
            PathStepCard(index + 1, step)
        }
    }
}

@Composable
private fun PathStepCard(number: Int, step: PathStep) {
    val accent = when (step.state) {
        1 -> SuperColors.Green
        -1 -> SuperColors.Red
        2 -> SuperColors.Blue
        else -> SuperColors.TextSecondary
    }
    val background = when (step.state) {
        1 -> SuperColors.GreenSoft
        -1 -> SuperColors.RedSoft
        2 -> SuperColors.BlueSoft
        else -> Color.White
    }
    val icon = when (step.state) {
        1 -> Icons.Outlined.Check
        -1 -> Icons.Outlined.Close
        0 -> Icons.Outlined.Lock
        else -> Icons.Outlined.Flag
    }

    Card(
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = background),
        elevation = CardDefaults.cardElevation(defaultElevation = if (step.state == 2) 2.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(48.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                Text("$number. ${step.title}", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(step.subtitle, color = SuperColors.TextSecondary, fontSize = 12.sp)
            }
            Text(
                when (step.state) {
                    1 -> "تکمیل شد"
                    -1 -> "ناموفق"
                    2 -> "فعلی"
                    else -> "قفل"
                },
                color = accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
