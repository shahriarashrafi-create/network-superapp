package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskStatus

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenProgress: () -> Unit,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    val pendingTasks = tasks.filter { it.status == TaskStatus.TODO }
    val nextAction = pendingTasks.firstOrNull() ?: tasks.first()
    val doneCount = tasks.count { it.status == TaskStatus.DONE }
    val progress = if (tasks.isEmpty()) 0f else doneCount.toFloat() / tasks.size

    LazyColumn(
        modifier = Modifier.background(SuperColors.Background),
        contentPadding = PaddingValues(
            start = SuperDimens.ScreenPadding,
            end = SuperDimens.ScreenPadding,
            top = contentPadding.calculateTopPadding() + 14.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { HomeHeader() }
        item {
            NextActionCard(
                task = nextAction,
                onStart = onOpenActions
            )
        }
        item {
            ProgressSummaryCard(
                progress = progress,
                doneCount = doneCount,
                totalCount = tasks.size,
                onClick = onOpenProgress
            )
        }
        item {
            TodayPlanSection(
                tasks = tasks.take(3),
                onOpenActions = onOpenActions,
                onTaskStatus = onTaskStatus
            )
        }
    }
}

@Composable
private fun HomeHeader() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(SuperColors.BlueSoft)
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ش", color = SuperColors.Blue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text("سلام، شهریار", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 24.sp)
                    Text("امروز روی قدم بعدی تمرکز کن", color = SuperColors.TextSecondary, fontSize = 13.sp)
                }
            }
            IconButton(onClick = {}) {
                Icon(Icons.Outlined.NotificationsNone, contentDescription = "اعلان‌ها", tint = SuperColors.Navy)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = SuperShapes.Small,
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatBlock("سطح ۳", "در مسیر لیدر", SuperColors.Gold)
                Box(modifier = Modifier.padding(horizontal = 14.dp).size(width = 1.dp, height = 36.dp).background(SuperColors.Border))
                Column(modifier = Modifier.weight(1f)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("XP", color = SuperColors.TextSecondary, fontSize = 12.sp)
                        Text("۲۴۰ / ۵۰۰", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(7.dp))
                    LinearProgressIndicator(
                        progress = { 0.48f },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                        color = SuperColors.Blue,
                        trackColor = SuperColors.NeutralSoft
                    )
                }
                Box(modifier = Modifier.padding(horizontal = 14.dp).size(width = 1.dp, height = 36.dp).background(SuperColors.Border))
                StatBlock("۷ روز", "متوالی", SuperColors.Orange)
            }
        }
    }
}

@Composable
private fun StatBlock(value: String, label: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(label, color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NextActionCard(task: AppTask, onStart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFFF2F8FF), Color(0xFFE2F1FF))
                    )
                )
                .border(1.dp, Color(0xFFCAE3FF), SuperShapes.Card)
                .padding(20.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(46.dp).clip(CircleShape).background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
                    }
                    Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                        Text("قدم بعدی", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(task.title, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(task.subtitle, color = SuperColors.TextSecondary, fontSize = 14.sp, lineHeight = 22.sp)
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = SuperShapes.Small,
                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                        Text("شروع", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    if (task.points > 0) {
                        Box(
                            modifier = Modifier
                                .padding(start = 10.dp)
                                .background(SuperColors.GoldSoft, SuperShapes.Small)
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Text("+${task.points} XP", color = Color(0xFF9B6A00), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressSummaryCard(
    progress: Float,
    doneCount: Int,
    totalCount: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(SuperShapes.Small).background(SuperColors.BlueSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Timeline, contentDescription = null, tint = SuperColors.Blue)
                    }
                    Column(modifier = Modifier.padding(start = 10.dp)) {
                        Text("مسیر پیشرفت", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("مرحله فعلی: دعوت و پیش‌مشاوره", color = SuperColors.TextSecondary, fontSize = 12.sp)
                    }
                }
                Text("مشاهده", color = SuperColors.Blue, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(5) { index ->
                    val active = index < 2
                    val current = index == 2
                    Box(
                        modifier = Modifier
                            .size(if (current) 24.dp else 18.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    active -> SuperColors.Green
                                    current -> SuperColors.Blue
                                    else -> SuperColors.NeutralSoft
                                }
                            )
                            .border(if (current) 4.dp else 0.dp, if (current) SuperColors.GoldSoft else Color.Transparent, CircleShape)
                    )
                    if (index < 4) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(3.dp)
                                .background(if (active) SuperColors.Green else SuperColors.Border)
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("کارهای امروز", color = SuperColors.TextSecondary, fontSize = 12.sp)
                Text("$doneCount از $totalCount انجام شده", color = SuperColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
            Spacer(Modifier.height(7.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                color = SuperColors.Blue,
                trackColor = SuperColors.NeutralSoft
            )
        }
    }
}

@Composable
private fun TodayPlanSection(
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("برنامه امروز", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(
                "مشاهده همه",
                color = SuperColors.Blue,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                modifier = Modifier.clickable(onClick = onOpenActions)
            )
        }
        tasks.forEach { task ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = SuperShapes.Small,
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        onTaskStatus(
                            task.id,
                            if (task.status == TaskStatus.DONE) TaskStatus.TODO else TaskStatus.DONE
                        )
                    }) {
                        Icon(
                            if (task.status == TaskStatus.DONE) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (task.status == TaskStatus.DONE) SuperColors.Green else SuperColors.TextSecondary
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(task.title, color = SuperColors.Text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(task.subtitle, color = SuperColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(
                        modifier = Modifier
                            .background(SuperColors.BlueSoft, SuperShapes.Pill)
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(task.source.label, color = SuperColors.Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
