package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.TaskSource
import com.liateam.superapp.ui.model.TaskStatus

@Composable
fun ActionsScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onTaskStatus: (Int, TaskStatus) -> Unit,
    onOpenProgress: () -> Unit
) {
    var selectedSource by remember { mutableStateOf(TaskSource.TEAM) }
    val filtered = tasks.filter { it.source == selectedSource }
    val next = tasks.firstOrNull { it.status == TaskStatus.TODO }

    LazyColumn(
        contentPadding = PaddingValues(
            start = SuperDimens.ScreenPadding,
            end = SuperDimens.ScreenPadding,
            top = contentPadding.calculateTopPadding() + 18.dp,
            bottom = contentPadding.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.background(SuperColors.Background)
    ) {
        item {
            Column {
                Text("اقدام‌ها", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                Text("فقط کاری که الان باید انجام شود", color = SuperColors.TextSecondary, fontSize = 13.sp)
            }
        }

        if (next != null) {
            item {
                Card(
                    shape = SuperShapes.Card,
                    colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(44.dp).background(Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue)
                            }
                            Column(modifier = Modifier.padding(start = 10.dp).weight(1f)) {
                                Text("Next Action", color = SuperColors.Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(next.title, color = SuperColors.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = {},
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = SuperShapes.Small,
                            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                        ) {
                            Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                            Text("شروع کار", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenProgress),
                shape = SuperShapes.Small,
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(42.dp).background(SuperColors.BlueSoft, SuperShapes.Small),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.Timeline, contentDescription = null, tint = SuperColors.Blue)
                    }
                    Column(modifier = Modifier.padding(start = 10.dp).weight(1f)) {
                        Text("Progress Path", color = SuperColors.Text, fontWeight = FontWeight.Bold)
                        Text("دعوت و پیش‌مشاوره • مرحله فعلی", color = SuperColors.TextSecondary, fontSize = 12.sp)
                    }
                    Text("مشاهده", color = SuperColors.Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TaskSource.entries.forEach { source ->
                    FilterChip(
                        selected = selectedSource == source,
                        onClick = { selectedSource = source },
                        label = { Text(source.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SuperColors.BlueSoft,
                            selectedLabelColor = SuperColors.Blue,
                            containerColor = Color.White,
                            labelColor = SuperColors.TextSecondary
                        )
                    )
                }
            }
        }

        items(filtered.size) { index ->
            val task = filtered[index]
            ActionTaskCard(task = task, onTaskStatus = onTaskStatus)
        }
    }
}

@Composable
private fun ActionTaskCard(
    task: AppTask,
    onTaskStatus: (Int, TaskStatus) -> Unit
) {
    val accent = when (task.status) {
        TaskStatus.DONE -> SuperColors.Green
        TaskStatus.FAILED -> SuperColors.Red
        TaskStatus.TODO -> SuperColors.Blue
    }
    val soft = when (task.status) {
        TaskStatus.DONE -> SuperColors.GreenSoft
        TaskStatus.FAILED -> SuperColors.RedSoft
        TaskStatus.TODO -> Color.White
    }

    Card(
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = soft),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(42.dp).background(
                        if (task.status == TaskStatus.TODO) SuperColors.BlueSoft else Color.White,
                        CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = accent)
                }
                Column(modifier = Modifier.padding(start = 10.dp).weight(1f)) {
                    Text(task.title, color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(task.subtitle, color = SuperColors.TextSecondary, fontSize = 12.sp)
                }
                if (task.points > 0) {
                    Text("+${task.points} XP", color = Color(0xFF9B6A00), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { onTaskStatus(task.id, TaskStatus.DONE) },
                    modifier = Modifier.background(SuperColors.GreenSoft, SuperShapes.Small)
                ) {
                    Icon(Icons.Outlined.Check, contentDescription = "انجام شد", tint = SuperColors.Green)
                }
                IconButton(
                    onClick = { onTaskStatus(task.id, TaskStatus.FAILED) },
                    modifier = Modifier.background(SuperColors.RedSoft, SuperShapes.Small)
                ) {
                    Icon(Icons.Outlined.Close, contentDescription = "انجام نشد", tint = SuperColors.Red)
                }
                IconButton(
                    onClick = { onTaskStatus(task.id, TaskStatus.TODO) },
                    modifier = Modifier.background(SuperColors.NeutralSoft, SuperShapes.Small)
                ) {
                    Icon(Icons.Outlined.Refresh, contentDescription = "بازنشانی", tint = SuperColors.TextSecondary)
                }
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier.background(SuperColors.NeutralSoft, SuperShapes.Pill).padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text(
                        when (task.status) {
                            TaskStatus.DONE -> "انجام شد"
                            TaskStatus.FAILED -> "انجام نشد"
                            TaskStatus.TODO -> "در انتظار"
                        },
                        color = accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
