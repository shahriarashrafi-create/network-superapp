package com.liateam.superapp.ui.model

enum class AppSection {
    HOME, ACTIONS, NETWORK, MESSAGES, MORE, PROGRESS
}

enum class TaskSource(val label: String) {
    TEAM("ثابت تیم"),
    SPONSOR("حامی"),
    PERSONAL("شخصی")
}

enum class TaskStatus {
    TODO, DONE, FAILED
}

data class AppTask(
    val id: Int,
    val title: String,
    val subtitle: String,
    val source: TaskSource,
    val status: TaskStatus = TaskStatus.TODO,
    val points: Int = 0
)

fun initialTasks(): List<AppTask> = listOf(
    AppTask(1, "دعوت یک نفر", "امروز با یک مخاطب جدید گفتگو را شروع کن", TaskSource.TEAM, points = 20),
    AppTask(2, "پیگیری یک مشتری بالقوه", "حداقل یک Follow-up واقعی ثبت کن", TaskSource.TEAM, points = 15),
    AppTask(3, "معرفی محصول", "محصول مناسب را به یک مخاطب معرفی کن", TaskSource.TEAM, points = 20),
    AppTask(4, "مرور متن دعوت", "متن دعوت را یک‌بار تمرین و آماده کن", TaskSource.SPONSOR, points = 10),
    AppTask(5, "ثبت گزارش روز", "خلاصه فعالیت‌های امروز را مرور کن", TaskSource.SPONSOR, points = 10),
    AppTask(6, "۱۰ دقیقه مطالعه", "روی رشد فردی خودت سرمایه‌گذاری کن", TaskSource.PERSONAL),
    AppTask(7, "برنامه فردا", "سه اولویت فردا را مشخص کن", TaskSource.PERSONAL)
)
