# Super App v3 — Android UI Foundation

Offline-first Android milestone for the Network Marketing Super App.

## Included
- Stable application id: `com.liateam.superapp`
- Stable signing keystore from v1/v2
- versionCode 3 / versionName 1.1.0
- Jetpack Compose light design system
- RTL-first Persian UI
- Final-direction Home screen focused on Next Action
- Main bottom navigation: Home / Actions / My Network / Messages / More
- Action Center with Team / Sponsor / Personal tasks
- Done / Failed / Reset local task states
- Progress Path preview and dedicated screen
- Local mock data only; backend calls are disabled in this version

## Build
`./gradlew assembleDebug --stacktrace`
