package app.networksuper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import app.networksuper.ui.home.HomeScreen
import app.networksuper.ui.progress.ProgressScreen
import app.networksuper.ui.theme.NetworkSuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NetworkSuperAppTheme {
                var screen by remember { mutableIntStateOf(0) }

                when (screen) {
                    1 -> ProgressScreen(onHome = { screen = 0 })
                    else -> HomeScreen(onOpenProgress = { screen = 1 })
                }
            }
        }
    }
}
