package app.networksuper.ui.progress

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.Assignment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.TrackChanges
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.ui.theme.AppBackground
import app.networksuper.ui.theme.Muted
import app.networksuper.ui.theme.Navy
import app.networksuper.ui.theme.PrimaryBlue
import app.networksuper.ui.theme.RewardGold
import app.networksuper.ui.theme.SoftBlue
import app.networksuper.ui.theme.SuccessGreen

private enum class StepState { DONE, CURRENT, UPCOMING }

private data class ProgressStep(
    val number: Int,
    val title: String,
    val icon: ImageVector,
    val state: StepState
)

private data class NavItem(
    val label: String,
    val icon: ImageVector
)

@Composable
fun ProgressScreen(onHome: () -> Unit = {}) {
    val currentStep = 6
    val stepsDescending = remember {
        listOf(
            12 to Pair("قله هدف", Icons.Rounded.Flag),
            11 to Pair("رهبری تیم", Icons.Rounded.WorkspacePremium),
            10 to Pair("هدف بلندمدت", Icons.Rounded.TrackChanges),
            9 to Pair("توسعه مهارت‌ها", Icons.Rounded.AutoAwesome),
            8 to Pair("ارتباط با مشتری", Icons.Rounded.Groups),
            7 to Pair("مدیریت مالی", Icons.Rounded.Assignment),
            6 to Pair("ورزش روزانه", Icons.Rounded.FitnessCenter),
            5 to Pair("مطالعه و یادگیری", Icons.Rounded.Group),
            4 to Pair("روتین صبح", Icons.Rounded.WbSunny),
            3 to Pair("ساخت عادت", Icons.Rounded.AutoAwesome),
            2 to Pair("شروع مسیر", Icons.Rounded.TrendingUp),
            1 to Pair("قدم اول", Icons.Rounded.Home)
        ).map { (number, info) ->
            ProgressStep(
                number = number,
                title = info.first,
                icon = info.second,
                state = when {
                    number < currentStep -> StepState.DONE
                    number == currentStep -> StepState.CURRENT
                    else -> StepState.UPCOMING
                }
            )
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppBackground,
            bottomBar = { ProgressBottomNav(onHome = onHome) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                ProgressHeader(
                    currentStep = currentStep,
                    totalSteps = stepsDescending.size,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                JourneyViewport(
                    steps = stepsDescending,
                    currentStep = currentStep,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ProgressHeader(
    currentStep: Int,
    totalSteps: Int,
    modifier: Modifier = Modifier
) {
    val progress = currentStep.toFloat() / totalSteps.toFloat()

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.88f))
            .border(1.dp, Color.White, RoundedCornerShape(24.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        HeaderBackdrop(Modifier.matchParentSize())

        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = SoftBlue,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            PrimaryBlue.copy(alpha = 0.18f)
                        )
                    ) {
                        Text(
                            text = "مرحله $currentStep از $totalSteps",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            color = PrimaryBlue,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Black
                        )
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PremiumHeaderIcon()
                            Text(
                                text = "مسیر پیشرفت",
                                color = Navy,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(9.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCE8F7))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progress)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)
                                    )
                                )
                        )
                    }
                    Text(
                        text = "${(progress * 100).toInt()}٪",
                        color = PrimaryBlue,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun HeaderBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path().apply {
            moveTo(0f, h * 0.05f)
            cubicTo(w * 0.20f, h * 0.28f, w * 0.34f, h * 0.02f, w * 0.55f, h * 0.18f)
            cubicTo(w * 0.74f, h * 0.34f, w * 0.87f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.50f)
            cubicTo(w * 0.78f, h * 0.36f, w * 0.62f, h * 0.55f, w * 0.43f, h * 0.40f)
            cubicTo(w * 0.23f, h * 0.25f, w * 0.10f, h * 0.45f, 0f, h * 0.31f)
            close()
        }
        drawPath(p, Color(0xFF9FD6FF).copy(alpha = 0.13f))
    }
}

@Composable
private fun PremiumHeaderIcon() {
    Box(
        modifier = Modifier
            .size(40.dp)
            .shadow(3.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White, RewardGold.copy(alpha = 0.16f))
                )
            )
            .border(1.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Rounded.EmojiEvents,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
private fun JourneyViewport(
    steps: List<ProgressStep>,
    currentStep: Int,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape(26.dp))
            .background(Color.White.copy(alpha = 0.44f))
            .border(1.dp, Color.White.copy(alpha = 0.84f), RoundedCornerShape(26.dp))
    ) {
        JourneyBackdrop(Modifier.matchParentSize())

        // 4 full steps are visible, while the step above and below are half-visible and faded.
        val rowHeight = maxHeight / 5f
        val density = LocalDensity.current
        val firstVisibleIndex = steps.indexOfFirst { it.number == currentStep + 4 }.coerceAtLeast(0)
        val halfRowPx = with(density) { (rowHeight / 2f).roundToPx() }
        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = firstVisibleIndex,
            initialFirstVisibleItemScrollOffset = halfRowPx
        )

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = true
        ) {
            itemsIndexed(
                items = steps,
                key = { _, item -> item.number }
            ) { _, step ->
                ProgressStepRow(
                    step = step,
                    cardOnRight = step.number % 2 == 0,
                    rowHeight = rowHeight,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .height(rowHeight * 0.62f)
                .background(
                    Brush.verticalGradient(
                        0f to AppBackground.copy(alpha = 0.94f),
                        0.44f to AppBackground.copy(alpha = 0.44f),
                        1f to Color.Transparent
                    )
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(rowHeight * 0.62f)
                .background(
                    Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.56f to AppBackground.copy(alpha = 0.44f),
                        1f to AppBackground.copy(alpha = 0.94f)
                    )
                )
        )
    }
}

@Composable
private fun JourneyBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height

        fun hill(baseY: Float, peakX: Float, peakY: Float, width: Float, alpha: Float) {
            val p = Path().apply {
                moveTo(peakX - width / 2f, baseY)
                lineTo(peakX, peakY)
                lineTo(peakX + width / 2f, baseY)
                close()
            }
            drawPath(p, Color(0xFF86C6FF).copy(alpha = alpha))
        }

        hill(h * 0.27f, w * 0.18f, h * 0.15f, w * 0.46f, 0.08f)
        hill(h * 0.24f, w * 0.72f, h * 0.10f, w * 0.62f, 0.07f)
        hill(h * 0.58f, w * 0.27f, h * 0.43f, w * 0.52f, 0.07f)
        hill(h * 0.62f, w * 0.82f, h * 0.49f, w * 0.48f, 0.06f)
        hill(h * 0.92f, w * 0.21f, h * 0.78f, w * 0.58f, 0.06f)
        hill(h * 0.94f, w * 0.74f, h * 0.81f, w * 0.54f, 0.05f)

        drawCircle(
            color = PrimaryBlue.copy(alpha = 0.08f),
            radius = w * 0.16f,
            center = Offset(w * 0.90f, h * 0.12f)
        )
        drawCircle(
            color = SuccessGreen.copy(alpha = 0.05f),
            radius = w * 0.13f,
            center = Offset(w * 0.05f, h * 0.72f)
        )
    }
}

@Composable
private fun ProgressStepRow(
    step: ProgressStep,
    cardOnRight: Boolean,
    rowHeight: Dp,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.height(rowHeight)) {
        JourneyRoadSegment(
            step = step,
            cardOnRight = cardOnRight,
            modifier = Modifier.fillMaxSize()
        )

        StepCard(
            step = step,
            modifier = Modifier
                .align(if (cardOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                .fillMaxWidth(0.43f)
                .padding(horizontal = 8.dp)
        )

        StepNode(
            step = step,
            modifier = Modifier
                .align(Alignment.Center)
                .offset(x = if (cardOnRight) (-18).dp else 18.dp)
        )
    }
}

@Composable
private fun JourneyRoadSegment(
    step: ProgressStep,
    cardOnRight: Boolean,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val centerX = w * 0.50f
        val nodeX = centerX + if (cardOnRight) -18.dp.toPx() else 18.dp.toPx()

        val road = Path().apply {
            moveTo(centerX, h + 2f)
            cubicTo(centerX, h * 0.80f, nodeX, h * 0.66f, nodeX, h * 0.50f)
            cubicTo(nodeX, h * 0.34f, centerX, h * 0.20f, centerX, -2f)
        }

        drawPath(
            path = road,
            color = Color.White.copy(alpha = 0.96f),
            style = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = road,
            brush = Brush.verticalGradient(
                listOf(
                    PrimaryBlue.copy(alpha = 0.20f),
                    Color(0xFF57B9FF).copy(alpha = 0.55f),
                    PrimaryBlue.copy(alpha = 0.20f)
                )
            ),
            style = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round)
        )
        drawPath(
            path = road,
            color = Color.White.copy(alpha = 0.86f),
            style = Stroke(
                width = 2.dp.toPx(),
                cap = StrokeCap.Round,
                pathEffect = PathEffect.dashPathEffect(
                    floatArrayOf(7.dp.toPx(), 8.dp.toPx()),
                    0f
                )
            )
        )

        if (step.state == StepState.CURRENT) {
            drawCircle(
                color = PrimaryBlue.copy(alpha = 0.08f),
                radius = 31.dp.toPx(),
                center = Offset(nodeX, h * 0.50f)
            )
        }
    }
}

@Composable
private fun StepNode(step: ProgressStep, modifier: Modifier = Modifier) {
    val nodeColor = when (step.state) {
        StepState.DONE -> SuccessGreen
        StepState.CURRENT -> PrimaryBlue
        StepState.UPCOMING -> Color.White
    }
    val borderColor = when (step.state) {
        StepState.DONE -> Color.White
        StepState.CURRENT -> Color.White
        StepState.UPCOMING -> Muted.copy(alpha = 0.46f)
    }

    Box(
        modifier = modifier
            .size(if (step.state == StepState.CURRENT) 46.dp else 38.dp)
            .shadow(
                if (step.state == StepState.CURRENT) 9.dp else 3.dp,
                CircleShape,
                ambientColor = when (step.state) {
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.20f)
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.28f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.06f)
                },
                spotColor = when (step.state) {
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.22f)
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.34f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.06f)
                }
            )
            .clip(CircleShape)
            .background(nodeColor)
            .border(3.dp, borderColor, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        when (step.state) {
            StepState.DONE -> Icon(
                Icons.Rounded.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
            StepState.CURRENT -> Text(
                text = step.number.toString(),
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
            StepState.UPCOMING -> Text(
                text = step.number.toString(),
                color = Muted,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun StepCard(step: ProgressStep, modifier: Modifier = Modifier) {
    val container = when (step.state) {
        StepState.DONE -> Brush.horizontalGradient(
            listOf(Color.White, SuccessGreen.copy(alpha = 0.10f))
        )
        StepState.CURRENT -> Brush.horizontalGradient(
            listOf(Color.White, Color(0xFFEAF4FF))
        )
        StepState.UPCOMING -> Brush.horizontalGradient(
            listOf(Color.White.copy(alpha = 0.96f), SoftBlue.copy(alpha = 0.70f))
        )
    }

    val borderColor = when (step.state) {
        StepState.DONE -> SuccessGreen.copy(alpha = 0.20f)
        StepState.CURRENT -> PrimaryBlue
        StepState.UPCOMING -> Color.White
    }

    Surface(
        modifier = modifier
            .height(76.dp)
            .shadow(
                if (step.state == StepState.CURRENT) 8.dp else 3.dp,
                RoundedCornerShape(22.dp),
                ambientColor = when (step.state) {
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.14f)
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.08f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.05f)
                },
                spotColor = when (step.state) {
                    StepState.CURRENT -> PrimaryBlue.copy(alpha = 0.16f)
                    StepState.DONE -> SuccessGreen.copy(alpha = 0.08f)
                    StepState.UPCOMING -> Color.Black.copy(alpha = 0.05f)
                }
            ),
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
        border = androidx.compose.foundation.BorderStroke(
            if (step.state == StepState.CURRENT) 1.6.dp else 1.dp,
            borderColor
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(container)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            StepIconBubble(step)
            Text(
                text = step.title,
                modifier = Modifier.weight(1f),
                color = if (step.state == StepState.UPCOMING) Navy.copy(alpha = 0.78f) else Navy,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Right,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun StepIconBubble(step: ProgressStep) {
    val accent = when (step.state) {
        StepState.DONE -> SuccessGreen
        StepState.CURRENT -> PrimaryBlue
        StepState.UPCOMING -> PrimaryBlue.copy(alpha = 0.70f)
    }

    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White, accent.copy(alpha = 0.17f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.92f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = step.icon,
            contentDescription = step.title,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun ProgressBottomNav(onHome: () -> Unit) {
    val selectedIndex = 1
    val navItems = listOf(
        NavItem("خانه", Icons.Rounded.Home),
        NavItem("مسیر پیشرفت", Icons.Rounded.TrendingUp),
        NavItem("لیست مشتریان", Icons.Rounded.Groups),
        NavItem("لیست شبکه‌سازی", Icons.Rounded.AccountTree),
        NavItem("بیشتر", Icons.Rounded.MoreHoriz)
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 7.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val active = index == selectedIndex
                val containerColor by animateColorAsState(
                    targetValue = if (active) SoftBlue else Color.Transparent,
                    label = "progressNavColor"
                )
                val elevation by animateDpAsState(
                    targetValue = if (active) 7.dp else 0.dp,
                    label = "progressNavElevation"
                )
                val scale by animateFloatAsState(
                    targetValue = if (active) 1.06f else 1f,
                    label = "progressNavScale"
                )
                val tint by animateColorAsState(
                    targetValue = if (active) PrimaryBlue else Muted,
                    label = "progressNavTint"
                )

                Surface(
                    onClick = { if (index == 0) onHome() },
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = containerColor,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.25.dp,
                        PrimaryBlue.copy(alpha = 0.22f)
                    ) else null,
                    shadowElevation = elevation
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            modifier = Modifier.size(if (active) 26.dp else 22.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = tint,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
