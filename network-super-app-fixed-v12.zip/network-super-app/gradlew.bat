\
    @echo off
    where gradle >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
      gradle %*
      exit /b %ERRORLEVEL%
    )
    echo Gradle is not installed. Install Gradle 8.9 or use GitHub Actions setup-gradle.
    exit /b 1
