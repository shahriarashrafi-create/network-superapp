package app.networksuper.ui.theme

import androidx.compose.ui.graphics.Color

val AppBackground = Color(0xFFF6F9FE)
val Navy = Color(0xFF0D1B4C)
val PrimaryBlue = Color(0xFF0E6FFF)
val PrimaryBlueDark = Color(0xFF064DCC)
val SoftBlue = Color(0xFFEAF3FF)
val SuccessGreen = Color(0xFF10B963)
val WarningOrange = Color(0xFFFF7A1A)
val AccentPurple = Color(0xFF8A4DFF)
val RewardGold = Color(0xFFF5B51B)
val Muted = Color(0xFF7888AA)
