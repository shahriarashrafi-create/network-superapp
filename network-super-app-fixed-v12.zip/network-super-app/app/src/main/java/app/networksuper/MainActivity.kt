package app.networksuper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.networksuper.ui.home.HomeScreen
import app.networksuper.ui.theme.NetworkSuperAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NetworkSuperAppTheme {
                HomeScreen()
            }
        }
    }
}
