package app.networksuper.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.networksuper.ui.theme.*

private data class HomeCardItem(
    val title: String,
    val icon: ImageVector,
    val accent: Color,
    val done: Boolean = false,
    val meta: String? = null
)

private data class NavItem(
    val label: String,
    val icon: ImageVector
)

@Composable
fun HomeScreen() {
    var selectedNav by remember { mutableIntStateOf(0) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = AppBackground,
            bottomBar = {
                GameBottomNav(
                    selectedIndex = selectedNav,
                    onSelected = { selectedNav = it }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HomeHeader(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.16f)
                )
                NextActionCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.24f)
                )
                TodaySection(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.30f)
                )
                ProgressSection(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.30f)
                )
            }
        }
    }
}

@Composable
private fun HomeHeader(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
    ) {
        HeaderWaveBackdrop(Modifier.fillMaxSize())

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.offset(x = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ComboTile(count = 3)
                        RewardTile(showDot = true)
                    }

                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            ProfileAvatar()
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "شهریار اشرفی",
                                    color = Navy,
                                    style = MaterialTheme.typography.headlineSmall,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                                Spacer(Modifier.height(2.dp))
                                RankBadge()
                            }
                        }
                    }
                }
            }

            XpProgressRow(
                current = 2480,
                target = 3000
            )
        }
    }
}

@Composable
private fun HeaderWaveBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        val wave1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.32f)
            cubicTo(w * 0.74f, h * 0.12f, w * 0.60f, h * 0.42f, w * 0.38f, h * 0.28f)
            cubicTo(w * 0.20f, h * 0.16f, w * 0.10f, h * 0.34f, 0f, h * 0.20f)
            close()
        }
        drawPath(
            path = wave1,
            brush = Brush.horizontalGradient(
                listOf(
                    Color(0xFFBDE3FF).copy(alpha = 0.34f),
                    Color(0xFF8CCBFF).copy(alpha = 0.18f),
                    Color.Transparent
                )
            )
        )

        val wave2 = Path().apply {
            moveTo(0f, h * 0.08f)
            cubicTo(w * 0.18f, h * 0.30f, w * 0.32f, h * 0.04f, w * 0.48f, h * 0.18f)
            cubicTo(w * 0.66f, h * 0.34f, w * 0.80f, h * 0.10f, w, h * 0.24f)
            lineTo(w, h * 0.46f)
            cubicTo(w * 0.80f, h * 0.32f, w * 0.63f, h * 0.52f, w * 0.45f, h * 0.38f)
            cubicTo(w * 0.24f, h * 0.22f, w * 0.12f, h * 0.44f, 0f, h * 0.31f)
            close()
        }
        drawPath(
            path = wave2,
            color = Color.White.copy(alpha = 0.28f)
        )
    }
}

@Composable
private fun ProfileAvatar() {
    Box(
        modifier = Modifier
            .size(56.dp)
            .shadow(8.dp, CircleShape, ambientColor = PrimaryBlue.copy(alpha = 0.18f), spotColor = PrimaryBlue.copy(alpha = 0.22f))
            .clip(CircleShape)
            .background(Color(0xFFE9F5FF))
            .border(2.dp, Color.White.copy(alpha = 0.95f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(49.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF1AA5FF), Color(0xFF0D56CE))
                    )
                )
                .border(2.5.dp, RewardGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Person,
                contentDescription = "پروفایل",
                tint = Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
private fun RankBadge() {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(Color(0xFF0A1E63), Color(0xFF17368B))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Icon(
            Icons.Rounded.WorkspacePremium,
            contentDescription = null,
            tint = RewardGold,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = "Builder",
            color = Color.White,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun ComboTile(count: Int) {
    Row(
        modifier = Modifier
            .height(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFBF4), Color(0xFFFFF0D8))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.95f), RoundedCornerShape(17.dp))
            .padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = "کمبو",
                tint = Color(0xFFFF6A1A),
                modifier = Modifier.size(30.dp)
            )
            Icon(
                Icons.Rounded.Whatshot,
                contentDescription = null,
                tint = Color(0xFFFFC83D),
                modifier = Modifier.size(17.dp)
            )
            Icon(
                Icons.Rounded.AutoAwesome,
                contentDescription = null,
                tint = RewardGold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(8.dp)
            )
        }
        Text(
            text = count.toString(),
            color = Navy,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun RewardTile(showDot: Boolean) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .shadow(6.dp, RoundedCornerShape(17.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.10f))
            .clip(RoundedCornerShape(17.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFFFFFFFF), Color(0xFFFFF3E5))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.96f), RoundedCornerShape(17.dp)),
        contentAlignment = Alignment.Center
    ) {
        RewardGiftAsset(Modifier.size(34.dp))
        if (showDot) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(8.dp)
                    .background(Color(0xFFFF4057), CircleShape)
            )
        }
    }
}

@Composable
private fun RewardGiftAsset(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFD348), Color(0xFFF09A16))
            ),
            topLeft = Offset(w * 0.15f, h * 0.38f),
            size = Size(w * 0.70f, h * 0.45f),
            cornerRadius = CornerRadius(w * 0.09f, w * 0.09f)
        )
        drawRoundRect(
            brush = Brush.verticalGradient(
                listOf(Color(0xFFFFE676), Color(0xFFFFB51A))
            ),
            topLeft = Offset(w * 0.11f, h * 0.31f),
            size = Size(w * 0.78f, h * 0.18f),
            cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
        )
        drawRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.44f, h * 0.31f),
            size = Size(w * 0.12f, h * 0.52f)
        )
        drawRoundRect(
            color = Color(0xFFE94D57),
            topLeft = Offset(w * 0.30f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = Color(0xFFFF6671),
            topLeft = Offset(w * 0.50f, h * 0.10f),
            size = Size(w * 0.20f, h * 0.23f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.70f),
            radius = w * 0.035f,
            center = Offset(w * 0.26f, h * 0.43f)
        )
        drawLine(
            color = Color.White.copy(alpha = 0.65f),
            start = Offset(w * 0.18f, h * 0.35f),
            end = Offset(w * 0.35f, h * 0.35f),
            strokeWidth = 2.2f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun XpProgressRow(current: Int, target: Int) {
    val progress = (current.toFloat() / target.toFloat()).coerceIn(0f, 1f)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(3.dp, RoundedCornerShape(18.dp), ambientColor = PrimaryBlue.copy(alpha = 0.05f), spotColor = PrimaryBlue.copy(alpha = 0.07f)),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.82f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.92f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Text(
                    text = "$current XP",
                    color = PrimaryBlue,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black
                )

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(9.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCE8F7))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress)
                            .clip(CircleShape)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF25B0FF), Color(0xFF157CF0), PrimaryBlue)
                                )
                            )
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .offset(x = 3.dp)
                            .size(3.dp)
                            .background(Color.White.copy(alpha = 0.72f), CircleShape)
                    )
                }

                Text(
                    text = target.toString(),
                    color = Muted,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun NextActionCard(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .shadow(
                6.dp,
                RoundedCornerShape(24.dp),
                ambientColor = PrimaryBlue.copy(alpha = 0.10f),
                spotColor = PrimaryBlue.copy(alpha = 0.12f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF075BD3),
                        Color(0xFF0879EA),
                        Color(0xFF1594F8)
                    )
                )
            )
    ) {
        NextActionBackdrop(Modifier.fillMaxSize())

        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 10.dp, start = 10.dp)
                .width(98.dp)
                .height(28.dp),
            shape = RoundedCornerShape(13.dp),
            color = Color(0xFF0B5FBE).copy(alpha = 0.76f),
            border = androidx.compose.foundation.BorderStroke(
                1.4.dp,
                Color.White.copy(alpha = 0.90f)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.TrackChanges,
                    contentDescription = null,
                    tint = Color(0xFFFF5A4D),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    text = "قدم بعدی",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Right,
                    maxLines = 1
                )
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-4).dp)
                .fillMaxWidth(0.64f)
                .height(48.dp),
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.98f),
            shadowElevation = 4.dp
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "پیگیری با علی رضایی",
                    modifier = Modifier.padding(horizontal = 14.dp),
                    textAlign = TextAlign.Center,
                    color = Navy,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Surface(
            onClick = { },
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = 48.dp)
                .fillMaxWidth(0.55f)
                .height(46.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1478F3),
            border = androidx.compose.foundation.BorderStroke(
                2.dp,
                Color.White.copy(alpha = 0.96f)
            ),
            shadowElevation = 1.dp
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "شروع",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Spacer(Modifier.width(7.dp))
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun NextActionBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // One unified geometric backdrop; no progress curve or split illustration.
        for (i in -1..7) {
            val x = w * (0.02f + i * 0.16f)
            drawLine(
                color = Color.White.copy(alpha = 0.09f),
                start = Offset(x, 0f),
                end = Offset(x - h * 0.25f, h),
                strokeWidth = 2f
            )
        }

        for (row in 0..2) {
            for (col in 0..4) {
                val left = w * (0.06f + col * 0.20f) + if (row % 2 == 1) w * 0.06f else 0f
                val top = h * (0.13f + row * 0.27f)
                drawRoundRect(
                    color = Color.White.copy(alpha = if ((row + col) % 3 == 0) 0.12f else 0.07f),
                    topLeft = Offset(left, top),
                    size = Size(w * 0.14f, w * 0.14f),
                    cornerRadius = CornerRadius(14f, 14f),
                    style = Stroke(width = 3f)
                )
            }
        }

        // Very soft light pools keep the background premium without competing with the CTA.
        drawCircle(
            color = Color.White.copy(alpha = 0.07f),
            radius = w * 0.22f,
            center = Offset(w * 0.14f, h * 0.78f)
        )
        drawCircle(
            color = Color(0xFF9FDBFF).copy(alpha = 0.09f),
            radius = w * 0.18f,
            center = Offset(w * 0.82f, h * 0.18f)
        )
    }
}

@Composable
private fun SyncedHomeSection(
    modifier: Modifier = Modifier,
    title: String,
    titleIcon: ImageVector,
    titleIconTint: Color,
    badgeText: String,
    badgeIcon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    HomeSectionCard(modifier = modifier) {
        SectionHeader(
            title = title,
            rightIcon = titleIcon,
            rightIconTint = titleIconTint,
            leftContent = {
                SectionMetaPill(
                    text = badgeText,
                    icon = badgeIcon
                )
            }
        )
        Spacer(Modifier.height(5.dp))
        content()
    }
}

@Composable
private fun SectionMetaPill(
    text: String,
    icon: ImageVector? = null
) {
    Surface(
        modifier = Modifier.height(32.dp),
        shape = RoundedCornerShape(12.dp),
        color = SoftBlue
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = text,
                color = if (icon == null) PrimaryBlueDark else Navy,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SyncedItemCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    done: Boolean,
    meta: String? = null,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Card(
            modifier = modifier,
            shape = RoundedCornerShape(19.dp),
            colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.062f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.165f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusMark(done = done)
                        if (meta != null) {
                            Text(
                                text = meta,
                                color = accent,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                maxLines = 1
                            )
                        } else {
                            Spacer(Modifier.width(1.dp))
                        }
                    }
                }

                PremiumIconBubble(
                    icon = icon,
                    accent = accent,
                    contentDescription = title,
                    modifier = Modifier.size(43.dp)
                )

                Text(
                    text = title,
                    color = Navy,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun SyncedItemRow(
    items: List<HomeCardItem>,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        val rowState = rememberLazyListState()
        LazyRow(
            state = rowState,
            modifier = modifier,
            reverseLayout = true,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 0.dp)
        ) {
            itemsIndexed(items) { index, item ->
                val visibleItem = rowState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == index }
                val isEdgePreview = visibleItem != null && (
                    visibleItem.offset < rowState.layoutInfo.viewportStartOffset ||
                        visibleItem.offset + visibleItem.size > rowState.layoutInfo.viewportEndOffset
                )
                SyncedItemCard(
                    title = item.title,
                    icon = item.icon,
                    accent = item.accent,
                    done = item.done,
                    meta = item.meta,
                    modifier = Modifier
                        .width(140.dp)
                        .fillMaxHeight()
                        .graphicsLayer { alpha = if (isEdgePreview) 0.78f else 1f }
                )
            }
        }
    }
}

@Composable
private fun TodaySection(modifier: Modifier = Modifier) {
    val scheduleItems = listOf(
        HomeCardItem("تماس", Icons.Rounded.Call, SuccessGreen, true, "10:00"),
        HomeCardItem("جلسه معرفی", Icons.Rounded.Groups, PrimaryBlue, meta = "15:00"),
        HomeCardItem("جلسه تیم", Icons.Rounded.Group, WarningOrange, meta = "18:00"),
        HomeCardItem("پیگیری", Icons.Rounded.Assignment, AccentPurple, meta = "21:00")
    )

    SyncedHomeSection(
        modifier = modifier,
        title = "امروز من",
        titleIcon = Icons.Rounded.CheckCircle,
        titleIconTint = SuccessGreen,
        badgeText = "دوشنبه ۲۳ مهر",
        badgeIcon = Icons.Rounded.CalendarMonth
    ) {
        SyncedItemRow(
            items = scheduleItems,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ProgressSection(modifier: Modifier = Modifier) {
    val taskItems = listOf(
        HomeCardItem("مرتب کردن اتاق", Icons.Rounded.Hotel, SuccessGreen, true),
        HomeCardItem("روتین صبح", Icons.Rounded.WbSunny, WarningOrange),
        HomeCardItem("نرمش روزانه", Icons.Rounded.FitnessCenter, PrimaryBlue),
        HomeCardItem("هدف بلندمدت", Icons.Rounded.Flag, AccentPurple)
    )

    SyncedHomeSection(
        modifier = modifier,
        title = "مسیر پیشرفت",
        titleIcon = Icons.Rounded.EmojiEvents,
        titleIconTint = RewardGold,
        badgeText = "مرحله ۶ از ۱۲"
    ) {
        SyncedItemRow(
            items = taskItems,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StatusMark(done: Boolean) {
    Icon(
        imageVector = if (done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
        contentDescription = if (done) "انجام شده" else "انجام نشده",
        tint = if (done) SuccessGreen else Muted.copy(alpha = 0.50f),
        modifier = Modifier.size(22.dp)
    )
}

@Composable
private fun PremiumIconBubble(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(2.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        Color.White.copy(alpha = 0.92f),
                        accent.copy(alpha = 0.18f)
                    )
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun PremiumSmallIcon(
    icon: ImageVector,
    accent: Color,
    contentDescription: String?,
    containerSize: androidx.compose.ui.unit.Dp = 31.dp,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp
) {
    Box(
        modifier = Modifier
            .size(containerSize)
            .shadow(1.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(Color.White.copy(alpha = 0.88f), accent.copy(alpha = 0.13f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.82f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
private fun HomeSectionCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            content = content
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    rightIcon: ImageVector,
    rightIconTint: Color,
    leftContent: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            leftContent()
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PremiumSmallIcon(
                        icon = rightIcon,
                        accent = rightIconTint,
                        contentDescription = null
                    )
                    Text(
                        text = title,
                        color = Navy,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun GameBottomNav(selectedIndex: Int, onSelected: (Int) -> Unit) {
    val navItems = listOf(
        NavItem("خانه", Icons.Rounded.Home),
        NavItem("مسیر پیشرفت", Icons.Rounded.TrendingUp),
        NavItem("لیست مشتریان", Icons.Rounded.Groups),
        NavItem("لیست شبکه‌سازی", Icons.Rounded.AccountTree),
        NavItem("بیشتر", Icons.Rounded.MoreHoriz)
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 7.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            navItems.forEachIndexed { index, item ->
                val active = index == selectedIndex
                val containerColor by animateColorAsState(
                    targetValue = if (active) SoftBlue else Color.Transparent,
                    label = "navColor"
                )
                val elevation by animateDpAsState(
                    targetValue = if (active) 7.dp else 0.dp,
                    label = "navElevation"
                )
                val scale by animateFloatAsState(
                    targetValue = if (active) 1.06f else 1f,
                    label = "navScale"
                )
                val tint by animateColorAsState(
                    targetValue = if (active) PrimaryBlue else Muted,
                    label = "navTint"
                )

                Surface(
                    onClick = { onSelected(index) },
                    modifier = Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                    },
                    shape = RoundedCornerShape(18.dp),
                    color = containerColor,
                    border = if (active) androidx.compose.foundation.BorderStroke(
                        1.25.dp,
                        PrimaryBlue.copy(alpha = 0.22f)
                    ) else null,
                    shadowElevation = elevation
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            modifier = Modifier.size(if (active) 26.dp else 22.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = item.label,
                            color = tint,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (active) FontWeight.Black else FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
