package com.liateam.superapp.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MilitaryTech
import androidx.compose.material.icons.outlined.PersonAddAlt
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.CoinStarAsset
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.ProgressMilestone
import com.liateam.superapp.ui.model.ProgressStage
import com.liateam.superapp.ui.model.ProgressStageState
import com.liateam.superapp.ui.model.progressMilestones
import com.liateam.superapp.ui.model.progressStages

@Composable
fun ProgressStageDetailScreen(
    contentPadding: PaddingValues,
    stageId: Int,
    tasks: List<AppTask>,
    onBack: () -> Unit,
    onStartTask: (Int) -> Unit,
    onOpenRelated: (HomeDestination) -> Unit,
    onBackToCurrent: () -> Unit
) {
    val stage = progressStages(tasks).firstOrNull { it.id == stageId } ?: progressStages(tasks)[2]
    val checked = remember(stageId) {
        mutableStateListOf<Boolean>().apply {
            stage.subtasks.forEachIndexed { index, _ ->
                add(stage.state == ProgressStageState.DONE || (stage.state == ProgressStageState.CURRENT && index < stage.progressCurrent))
            }
        }
    }
    val scroll = rememberScrollState()
    val doneCount = checked.count { it }

    BackHandler(onBack = onBack)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFF5FAFF), Color.White, Color(0xFFF8FBFF))))
    ) {
        StageDetailBackdrop(stage.id)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = contentPadding.calculateTopPadding() + 6.dp,
                    bottom = contentPadding.calculateBottomPadding() + 96.dp
                ),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StageDetailHeader(stage = stage, onBack = onBack)
            StageHero(stage = stage, doneCount = doneCount)

            if (stage.state == ProgressStageState.LOCKED) {
                LockedStageCard(stage = stage, onBackToCurrent = onBackToCurrent)
            } else {
                StageSubtasks(
                    stage = stage,
                    checked = checked,
                    onToggle = { index ->
                        if (stage.state == ProgressStageState.CURRENT) checked[index] = !checked[index]
                    }
                )
            }

            StagePurposeCard(stage)
            StageRewardCard(stage)

            when (stage.state) {
                ProgressStageState.DONE -> CompletedStageRecord(stage)
                ProgressStageState.FAILED -> FailedStageCard(onRetry = { stage.taskId?.let(onStartTask) })
                else -> Unit
            }

            stage.relatedDestination?.let { destination ->
                RelatedSectionCard(destination = destination, onOpen = { onOpenRelated(destination) })
            }
        }

        StagePrimaryAction(
            modifier = Modifier.align(Alignment.BottomCenter),
            stage = stage,
            doneCount = doneCount,
            onStartTask = onStartTask,
            onBackToCurrent = onBackToCurrent
        )
    }
}

@Composable
private fun StageDetailBackdrop(stageId: Int) {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(Color(0xFF78C4FF).copy(alpha = 0.08f), size.width * 0.40f, Offset(size.width * 0.95f, size.height * 0.12f))
        drawCircle(Color(0xFF48C997).copy(alpha = 0.045f), size.width * 0.28f, Offset(size.width * 0.04f, size.height * 0.62f))
        val grid = 42.dp.toPx()
        var x = 0f
        while (x <= size.width) {
            drawLine(Color(0xFF6E9CC2).copy(alpha = 0.025f), Offset(x, 0f), Offset(x, size.height), 1f)
            x += grid
        }
        if (stageId % 2 == 0) {
            drawCircle(SuperColors.Gold.copy(alpha = 0.055f), 30.dp.toPx(), Offset(size.width * 0.12f, size.height * 0.20f))
        }
    }
}

@Composable
private fun StageDetailHeader(stage: ProgressStage, onBack: () -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
        }
        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
            Text("مرحله ${stage.id} از ۸", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.5.sp)
            Text(stage.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 22.sp, maxLines = 1)
        }
    }
}

@Composable
private fun StageHero(stage: ProgressStage, doneCount: Int) {
    val accent = stageAccent(stage.state)
    val soft = stageSoft(stage.state)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(if (stage.state == ProgressStageState.CURRENT) 4.dp else 1.dp, RoundedCornerShape(24.dp), clip = false)
            .then(
                if (stage.state == ProgressStageState.CURRENT) Modifier.border(1.2.dp, SuperColors.Blue.copy(alpha = 0.52f), RoundedCornerShape(24.dp))
                else Modifier
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StageSymbol(stageId = stage.id, state = stage.state, size = 62.dp)
                Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp), horizontalAlignment = Alignment.End) {
                    Surface(color = soft, shape = SuperShapes.Pill) {
                        Text(
                            stageStateLabel(stage.state),
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            color = accent,
                            fontWeight = FontWeight.Black,
                            fontSize = 8.5.sp
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(stage.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp, textAlign = TextAlign.End)
                }
            }
            if (stage.progressTotal > 0) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$doneCount از ${stage.progressTotal} زیرکار", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${stage.durationMinutes} دقیقه", color = SuperColors.TextSecondary, fontSize = 8.5.sp)
                }
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { (doneCount / stage.progressTotal.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = SuperColors.BlueSoft
                )
            }
        }
    }
}

@Composable
private fun StageSubtasks(stage: ProgressStage, checked: List<Boolean>, onToggle: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.7.dp)
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("کارهای این مرحله", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                Text("${checked.count { it }} / ${stage.subtasks.size}", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
            }
            stage.subtasks.forEachIndexed { index, label ->
                val isChecked = checked.getOrNull(index) == true
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isChecked) SuperColors.GreenSoft else Color(0xFFF8FBFF), RoundedCornerShape(14.dp))
                        .clickable(enabled = stage.state == ProgressStageState.CURRENT) { onToggle(index) }
                        .padding(horizontal = 10.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(if (isChecked) SuperColors.Green else Color.White, CircleShape)
                            .border(1.dp, if (isChecked) SuperColors.Green else SuperColors.BorderBlue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isChecked) Icon(Icons.Outlined.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        else Text("${index + 1}", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 9.sp)
                    }
                    Text(
                        label,
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                        color = SuperColors.Navy,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.5.sp,
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun StagePurposeCard(stage: ProgressStage) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lightbulb, contentDescription = null, tint = SuperColors.Blue)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text("هدف این مرحله", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text(stage.description, color = SuperColors.TextSecondary, fontSize = 9.3.sp, textAlign = TextAlign.End)
            }
        }
    }
}

@Composable
private fun StageRewardCard(stage: ProgressStage) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("پاداش مرحله", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Spacer(Modifier.height(9.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RewardMetric("+${stage.rewardXp}", "XP", SuperColors.Blue, SuperColors.BlueSoft, Modifier.weight(1f))
                RewardMetric("+${stage.rewardCoin}", "سکه", SuperColors.GoldDeep, SuperColors.GoldSoft, Modifier.weight(1f))
                RewardMetric("${stage.durationMinutes}", "دقیقه", SuperColors.Purple, SuperColors.PurpleSoft, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RewardMetric(value: String, label: String, accent: Color, soft: Color, modifier: Modifier) {
    Surface(modifier = modifier, color = soft, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
            Text(label, color = SuperColors.TextSecondary, fontSize = 8.sp)
        }
    }
}

@Composable
private fun LockedStageCard(stage: ProgressStage, onBackToCurrent: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F9FC)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFFE8EEF4), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color(0xFF8392A3))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text("این مرحله هنوز قفل است", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(stage.unlockCondition, color = SuperColors.TextSecondary, fontSize = 9.2.sp)
                Spacer(Modifier.height(7.dp))
                Text(
                    "برگشت به مرحله فعال",
                    color = SuperColors.Blue,
                    fontWeight = FontWeight.Black,
                    fontSize = 9.sp,
                    modifier = Modifier.clickable(onClick = onBackToCurrent)
                )
            }
        }
    }
}

@Composable
private fun CompletedStageRecord(stage: ProgressStage) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SuperColors.GreenSoft),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.TaskAlt, contentDescription = null, tint = SuperColors.Green)
                Text("ثبت فعالیت", modifier = Modifier.weight(1f).padding(horizontal = 8.dp), color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text("تکمیل شده", color = SuperColors.Green, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
            }
            Spacer(Modifier.height(7.dp))
            Text("پاداش این مرحله دریافت شده و سابقه آن در مسیر پیشرفت نگه داشته می‌شود.", color = SuperColors.TextSecondary, fontSize = 9.sp)
        }
    }
}

@Composable
private fun FailedStageCard(onRetry: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SuperColors.RedSoft),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Refresh, contentDescription = null, tint = SuperColors.Red)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text("این مرحله ناموفق ثبت شده", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
                Text("می‌توانی Reset کنی و دوباره تلاش کنی.", color = SuperColors.TextSecondary, fontSize = 9.sp)
            }
            Text("تلاش دوباره", color = SuperColors.Red, fontWeight = FontWeight.Black, fontSize = 8.5.sp, modifier = Modifier.clickable(onClick = onRetry))
        }
    }
}

@Composable
private fun RelatedSectionCard(destination: HomeDestination, onOpen: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.6.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(SuperColors.PurpleSoft, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Timeline, contentDescription = null, tint = SuperColors.Purple)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.End) {
                Text("بخش مرتبط", color = SuperColors.TextSecondary, fontSize = 8.sp)
                Text(destination.title, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 11.5.sp)
            }
            Text("باز کردن", color = SuperColors.Blue, fontWeight = FontWeight.Black, fontSize = 8.5.sp)
        }
    }
}

@Composable
private fun StagePrimaryAction(
    modifier: Modifier,
    stage: ProgressStage,
    doneCount: Int,
    onStartTask: (Int) -> Unit,
    onBackToCurrent: () -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth().shadow(12.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp), clip = false),
        color = Color.White.copy(alpha = 0.97f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 16.dp, end = 16.dp, top = 11.dp, bottom = 10.dp)
        ) {
            when (stage.state) {
                ProgressStageState.CURRENT -> {
                    Button(
                        onClick = { stage.taskId?.let(onStartTask) },
                        enabled = stage.taskId != null,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                    ) {
                        Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("شروع / ادامه مرحله", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.5.sp)
                    }
                    stage.nextTitle?.let {
                        Spacer(Modifier.height(5.dp))
                        Text("بعد از این: $it", color = SuperColors.TextSecondary, fontSize = 8.3.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    }
                }
                ProgressStageState.LOCKED -> OutlinedButton(
                    onClick = onBackToCurrent,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Text("رفتن به مرحله فعال", color = SuperColors.Blue, fontWeight = FontWeight.Black)
                }
                ProgressStageState.FAILED -> Button(
                    onClick = { stage.taskId?.let(onStartTask) },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Red)
                ) { Text("Reset و تلاش دوباره", color = Color.White, fontWeight = FontWeight.Black) }
                ProgressStageState.DONE -> Surface(color = SuperColors.GreenSoft, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(11.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Check, contentDescription = null, tint = SuperColors.Green, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("این مرحله تکمیل شده", color = SuperColors.Green, fontWeight = FontWeight.Black, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StageSymbol(stageId: Int, state: ProgressStageState, size: androidx.compose.ui.unit.Dp) {
    val accent = stageAccent(state)
    val icon = stageIcon(stageId)
    Box(
        modifier = Modifier
            .size(size)
            .background(stageSoft(state), CircleShape)
            .border(1.dp, accent.copy(alpha = 0.20f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(accent.copy(alpha = 0.07f), size.minDimension * 0.36f, Offset(size.width * 0.37f, size.height * 0.32f))
            drawCircle(Color.White.copy(alpha = 0.78f), size.minDimension * 0.28f, Offset(size.width * 0.50f, size.height * 0.50f))
        }
        Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(size * 0.42f))
        if (state == ProgressStageState.LOCKED) {
            Box(Modifier.align(Alignment.BottomEnd).size(size * 0.32f).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = Color(0xFF8C99A8), modifier = Modifier.size(size * 0.18f))
            }
        }
    }
}

private fun stageIcon(stageId: Int): ImageVector = when (stageId) {
    1 -> Icons.Outlined.Lightbulb
    2 -> Icons.Outlined.Groups
    3 -> Icons.Outlined.PersonAddAlt
    4 -> Icons.Outlined.Inventory2
    5 -> Icons.Outlined.Schedule
    6 -> Icons.Outlined.ShoppingCart
    7 -> Icons.Outlined.TrackChanges
    else -> Icons.Outlined.AutoGraph
}

private fun stageAccent(state: ProgressStageState): Color = when (state) {
    ProgressStageState.DONE -> SuperColors.Green
    ProgressStageState.FAILED -> SuperColors.Red
    ProgressStageState.CURRENT -> SuperColors.Blue
    ProgressStageState.LOCKED -> Color(0xFF8C99A8)
}

private fun stageSoft(state: ProgressStageState): Color = when (state) {
    ProgressStageState.DONE -> SuperColors.GreenSoft
    ProgressStageState.FAILED -> SuperColors.RedSoft
    ProgressStageState.CURRENT -> SuperColors.BlueSoft
    ProgressStageState.LOCKED -> Color(0xFFF0F3F7)
}

private fun stageStateLabel(state: ProgressStageState): String = when (state) {
    ProgressStageState.DONE -> "تکمیل شده"
    ProgressStageState.FAILED -> "ناموفق"
    ProgressStageState.CURRENT -> "مرحله فعال"
    ProgressStageState.LOCKED -> "قفل"
}

@Composable
fun ProgressMilestoneDetailScreen(
    contentPadding: PaddingValues,
    milestoneId: Int,
    tasks: List<AppTask>,
    onBack: () -> Unit
) {
    val milestone = remember(milestoneId) { progressMilestones().firstOrNull { it.id == milestoneId } ?: progressMilestones().first() }
    val completedStages = progressStages(tasks).count { it.state == ProgressStageState.DONE }
    val unlocked = completedStages >= milestone.afterStage

    BackHandler(onBack = onBack)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFBF0), Color.White, Color(0xFFF7FBFF))))
    ) {
        MilestoneBackdrop()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = contentPadding.calculateTopPadding() + 6.dp,
                    bottom = contentPadding.calculateBottomPadding() + 22.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = SuperColors.Navy)
                }
                Text(
                    milestone.title,
                    modifier = Modifier.weight(1f),
                    color = SuperColors.Navy,
                    fontWeight = FontWeight.Black,
                    fontSize = 22.sp,
                    textAlign = TextAlign.End
                )
            }

            Spacer(Modifier.height(14.dp))
            MilestoneAsset(final = milestone.final)
            Spacer(Modifier.height(12.dp))
            Text(milestone.badgeTitle, color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(milestone.subtitle, color = SuperColors.TextSecondary, fontSize = 10.sp)
            Spacer(Modifier.height(18.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("پیشرفت تا جایزه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text("$completedStages / ${milestone.afterStage}", color = SuperColors.GoldDeep, fontWeight = FontWeight.Black, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (completedStages / milestone.afterStage.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                        color = SuperColors.Gold,
                        trackColor = Color(0xFFFFF0C4)
                    )
                    Spacer(Modifier.height(7.dp))
                    Text(
                        if (unlocked) "جایزه آماده دریافت است" else "${milestone.afterStage - completedStages} مرحله تا باز شدن این جایزه",
                        color = if (unlocked) SuperColors.Green else SuperColors.TextSecondary,
                        fontSize = 9.sp,
                        fontWeight = if (unlocked) FontWeight.Black else FontWeight.Medium
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8DF)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("داخل این جایزه", color = SuperColors.Navy, fontWeight = FontWeight.Black, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RewardMetric("+${milestone.rewardCoin}", "سکه", SuperColors.GoldDeep, Color.White, Modifier.weight(1f))
                        RewardMetric("+${milestone.rewardXp}", "XP", SuperColors.Blue, Color.White, Modifier.weight(1f))
                        RewardMetric("1", "نشان", SuperColors.Purple, Color.White, Modifier.weight(1f))
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SuperColors.BlueSoft2),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    MilestoneBenefit(Icons.Outlined.MilitaryTech, "نشان دائمی در پروفایل")
                    MilestoneBenefit(Icons.Outlined.AutoGraph, if (milestone.final) "باز شدن مسیر رشد بعدی" else "پیشروی سریع‌تر به مرحله بعد")
                    MilestoneBenefit(Icons.Outlined.TrackChanges, "ثبت در تاریخچه مسیر پیشرفت")
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (unlocked) SuperColors.GoldDeep else SuperColors.Blue)
            ) {
                Text(if (unlocked) "دریافت جایزه" else "بازگشت به مسیر", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun MilestoneBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        drawCircle(SuperColors.Gold.copy(alpha = 0.08f), size.width * 0.45f, Offset(size.width * 0.14f, size.height * 0.18f))
        drawCircle(SuperColors.Blue.copy(alpha = 0.05f), size.width * 0.34f, Offset(size.width * 0.90f, size.height * 0.68f))
    }
}

@Composable
private fun MilestoneAsset(final: Boolean) {
    Box(
        modifier = Modifier
            .size(118.dp)
            .background(Color(0xFFFFF3C6), CircleShape)
            .border(1.dp, SuperColors.Gold.copy(alpha = 0.35f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(Color.White.copy(alpha = 0.65f), w * 0.36f, Offset(w * 0.50f, h * 0.50f))
            if (final) {
                drawLine(SuperColors.GoldDeep, Offset(w * 0.50f, h * 0.26f), Offset(w * 0.50f, h * 0.72f), 5f, StrokeCap.Round)
                val flag = Path().apply {
                    moveTo(w * 0.50f, h * 0.25f)
                    lineTo(w * 0.78f, h * 0.33f)
                    lineTo(w * 0.50f, h * 0.43f)
                    close()
                }
                drawPath(flag, SuperColors.Gold)
            } else {
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(Color(0xFFFFD75B), Color(0xFFF0A51B))),
                    topLeft = Offset(w * 0.24f, h * 0.40f),
                    size = Size(w * 0.52f, h * 0.35f),
                    cornerRadius = CornerRadius(14f, 14f)
                )
                drawRoundRect(Color(0xFF70431D), Offset(w * 0.24f, h * 0.51f), Size(w * 0.52f, h * 0.08f), CornerRadius(6f, 6f))
                drawRoundRect(SuperColors.GoldBright, Offset(w * 0.44f, h * 0.48f), Size(w * 0.12f, h * 0.18f), CornerRadius(5f, 5f))
            }
        }
    }
}

@Composable
private fun MilestoneBenefit(icon: ImageVector, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(18.dp))
        }
        Text(label, modifier = Modifier.weight(1f).padding(horizontal = 9.dp), color = SuperColors.Navy, fontWeight = FontWeight.Bold, fontSize = 9.8.sp, textAlign = TextAlign.End)
    }
}
