# SuperApp v1.3.0 (Build 5)

Android Super App skeleton using Kotlin + Jetpack Compose.

## Build 5
- Home redesigned as a compact gamified action hub.
- No photo/background image assets are included.
- Home visual elements are built with Compose code, gradients, shapes and vector Material icons.
- 30 Home shortcuts are available in a horizontal 5-page pager (6 shortcuts per page).
- Only the shortcut block scrolls horizontally; Header, status, Next Action, reward strip and bottom navigation stay fixed.
- The right edge includes a continuation cue/fade and pager dots show the current page.
- All 30 shortcuts are clickable and open a real route or a module placeholder ready for implementation.
- Existing Progress Path, Actions, Network and bottom navigation remain wired.
- Backend/network polling remains inactive in this Android build.

Application ID and signing key are preserved from previous builds for in-place updates.
