package com.liateam.superapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Timeline
import androidx.compose.material.icons.outlined.TrackChanges
import androidx.compose.material.icons.outlined.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liateam.superapp.ui.designsystem.SuperColors
import com.liateam.superapp.ui.designsystem.SuperDimens
import com.liateam.superapp.ui.designsystem.SuperShapes
import com.liateam.superapp.ui.model.AppTask
import com.liateam.superapp.ui.model.HomeDestination
import com.liateam.superapp.ui.model.homeDestinations

private data class ShortcutVisual(
    val icon: ImageVector,
    val accent: Color,
    val soft: Color
)

@Composable
fun HomeScreen(
    contentPadding: PaddingValues,
    tasks: List<AppTask>,
    onOpenActions: () -> Unit,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val nextAction = tasks.firstOrNull { it.status.name == "TODO" } ?: tasks.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFFF9FCFF), Color(0xFFF3F8FE), SuperColors.Background)
                )
            )
            .padding(
                start = SuperDimens.ScreenPadding,
                end = SuperDimens.ScreenPadding,
                top = contentPadding.calculateTopPadding() + 7.dp,
                bottom = contentPadding.calculateBottomPadding() + 7.dp
            )
    ) {
        HomeHeader()
        Spacer(Modifier.height(7.dp))
        StatusStrip()
        Spacer(Modifier.height(8.dp))

        NextActionHero(
            modifier = Modifier.weight(1.22f),
            task = nextAction,
            onStart = onOpenActions
        )

        Spacer(Modifier.height(8.dp))
        RewardStrip()
        Spacer(Modifier.height(8.dp))

        ShortcutPager(
            modifier = Modifier.weight(1.52f),
            onOpenDestination = onOpenDestination
        )
    }
}

@Composable
private fun HomeHeader() {
    Row(
        modifier = Modifier.fillMaxWidth().height(50.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box {
            IconButton(
                onClick = {},
                modifier = Modifier
                    .size(42.dp)
                    .background(Color.White, SuperShapes.Small)
            ) {
                Icon(Icons.Outlined.NotificationsNone, contentDescription = "اعلان‌ها", tint = SuperColors.Navy)
            }
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(9.dp)
                    .background(SuperColors.Red, CircleShape)
                    .border(1.5.dp, Color.White, CircleShape)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("سلام، شهریار", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
            Text("امروز روی قدم بعدی تمرکز کن", color = SuperColors.TextSecondary, fontSize = 10.5.sp)
        }

        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFE7F3FF), Color.White)))
                .border(2.dp, SuperColors.Gold.copy(alpha = 0.65f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("ش", color = SuperColors.Blue, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(15.dp)
                    .background(SuperColors.Gold, CircleShape)
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("★", color = Color.White, fontSize = 7.sp)
            }
        }
    }
}

@Composable
private fun StatusStrip() {
    Card(
        modifier = Modifier.fillMaxWidth().height(61.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.94f)),
        shape = SuperShapes.Small,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CompactStat("سطح ۳", "مسیر لیدر", SuperColors.Gold)
            Hairline()
            Column(modifier = Modifier.weight(1.25f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("XP", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
                    Text("۲۴۰ / ۵۰۰", color = SuperColors.Text, fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                }
                Spacer(Modifier.height(5.dp))
                LinearProgressIndicator(
                    progress = { 0.48f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    color = SuperColors.Blue,
                    trackColor = Color(0xFFE4EDF8)
                )
            }
            Hairline()
            CompactStat("۶۹۵", "سکه", SuperColors.Gold)
            Hairline()
            CompactStat("۷", "روز متوالی", SuperColors.Orange)
        }
    }
}

@Composable
private fun CompactStat(value: String, label: String, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 13.5.sp)
        Text(label, color = accent, fontSize = 8.8.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Hairline() {
    Box(
        modifier = Modifier
            .padding(horizontal = 9.dp)
            .width(1.dp)
            .height(31.dp)
            .background(SuperColors.Border)
    )
}

@Composable
private fun NextActionHero(
    modifier: Modifier,
    task: AppTask,
    onStart: () -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(Color(0xFFF5FAFF), Color(0xFFE8F4FF))))
                .border(1.dp, Color(0xFFC7E2FF), SuperShapes.Card)
                .padding(15.dp)
        ) {
            val compact = maxHeight < 170.dp
            Row(modifier = Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1.15f), verticalArrangement = Arrangement.Center) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).background(Color.White.copy(alpha = 0.75f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Flag, contentDescription = null, tint = SuperColors.Blue, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.width(7.dp))
                        Text("قدم بعدی", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        task.title,
                        color = SuperColors.Text,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = if (compact) 21.sp else 24.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        "امروز یک مخاطب جدید را دعوت کن.",
                        color = SuperColors.TextSecondary,
                        fontSize = 10.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(if (compact) 6.dp else 9.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = onStart,
                            modifier = Modifier.weight(1f).height(if (compact) 39.dp else 43.dp),
                            shape = SuperShapes.Small,
                            colors = ButtonDefaults.buttonColors(containerColor = SuperColors.Blue)
                        ) {
                            Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("شروع", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                        }
                        Box(
                            modifier = Modifier
                                .padding(start = 7.dp)
                                .background(SuperColors.GoldSoft, SuperShapes.Pill)
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text("+${task.points} XP", color = Color(0xFF9A6700), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.width(9.dp))
                CodeGoalIllustration(modifier = Modifier.weight(0.78f).fillMaxHeight())
            }
        }
    }
}

@Composable
private fun CodeGoalIllustration(modifier: Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(108.dp)
                .clip(SuperShapes.Card)
                .background(Brush.linearGradient(listOf(Color(0xFFE2F0FF), Color(0xFFF8FBFF))))
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 5.dp, bottom = 14.dp)
                .size(width = 48.dp, height = 32.dp)
                .background(SuperColors.Blue, SuperShapes.Small)
        )
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(width = 54.dp, height = 43.dp)
                .background(Color.White, SuperShapes.Small)
                .border(1.dp, Color(0xFFDCEAF9), SuperShapes.Small)
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 12.dp, end = 5.dp)
                .size(59.dp)
                .background(Brush.linearGradient(listOf(Color(0xFFFFE7A4), Color(0xFFF4B92A))), SuperShapes.Small),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Flag, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
        }
        Icon(
            Icons.Outlined.Timeline,
            contentDescription = null,
            tint = SuperColors.Blue,
            modifier = Modifier.align(Alignment.CenterStart).size(33.dp)
        )
    }
}

@Composable
private fun RewardStrip() {
    Card(
        modifier = Modifier.fillMaxWidth().height(63.dp),
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBF0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0xFFFFE3A1), SuperShapes.Small)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RewardChestIcon()
            Spacer(Modifier.width(9.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("صندوق پاداش", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text("هر ۳ ساعت یک پاداش جدید", color = SuperColors.TextSecondary, fontSize = 9.5.sp)
            }
            Box(
                modifier = Modifier.background(Color.White, SuperShapes.Pill).padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text("02:15:36", color = SuperColors.Text, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(7.dp))
            Box(
                modifier = Modifier.size(34.dp).background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("‹", color = SuperColors.Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RewardChestIcon() {
    Box(modifier = Modifier.size(47.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .size(width = 42.dp, height = 26.dp)
                .background(Brush.linearGradient(listOf(Color(0xFFF9C13E), Color(0xFFE59A17))), SuperShapes.Small)
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 6.dp)
                .size(width = 42.dp, height = 17.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF4C9AF7), Color(0xFF146ED2))), SuperShapes.Small)
        )
        Box(
            modifier = Modifier
                .size(16.dp)
                .background(SuperColors.GoldSoft, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("★", color = SuperColors.Gold, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ShortcutPager(
    modifier: Modifier,
    onOpenDestination: (HomeDestination) -> Unit
) {
    val pages = remember { homeDestinations().chunked(6) }
    val pagerState = rememberPagerState(pageCount = { pages.size })

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = SuperShapes.Card,
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.80f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val pageWidth = maxWidth - 22.dp

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    pageSize = PageSize.Fixed(pageWidth),
                    pageSpacing = 8.dp,
                    contentPadding = PaddingValues(start = 0.dp, end = 22.dp),
                    beyondViewportPageCount = 1
                ) { page ->
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        ShortcutPage(
                            destinations = pages[page],
                            currentPage = page,
                            pageCount = pages.size,
                            onOpenDestination = onOpenDestination
                        )
                    }
                }
            }

            if (pagerState.currentPage < pages.lastIndex) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .fillMaxHeight()
                        .width(17.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, SuperColors.BlueSoft.copy(alpha = 0.82f))
                            )
                        )
                )
            }
        }
    }
}

@Composable
private fun ShortcutPage(
    destinations: List<HomeDestination>,
    currentPage: Int,
    pageCount: Int,
    onOpenDestination: (HomeDestination) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(26.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("دسترسی سریع", color = SuperColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            Spacer(Modifier.weight(1f))
            Text("${currentPage + 1} / $pageCount", color = SuperColors.Blue, fontWeight = FontWeight.Bold, fontSize = 9.5.sp)
        }
        Spacer(Modifier.height(5.dp))

        val top = destinations.take(3)
        val bottom = destinations.drop(3)
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            top.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            bottom.forEach { destination ->
                ShortcutTile(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    destination = destination,
                    onClick = { onOpenDestination(destination) }
                )
            }
            repeat(3 - bottom.size) { Spacer(Modifier.weight(1f)) }
        }
        Spacer(Modifier.height(5.dp))
        Row(
            modifier = Modifier.fillMaxWidth().height(12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(pageCount) { index ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (index == currentPage) 8.dp else 6.dp)
                        .background(if (index == currentPage) SuperColors.Blue else Color(0xFFD7E2EF), CircleShape)
                )
            }
        }
    }
}

@Composable
private fun ShortcutTile(
    modifier: Modifier,
    destination: HomeDestination,
    onClick: () -> Unit
) {
    val visual = shortcutVisual(destination)
    Card(
        modifier = modifier,
        onClick = onClick,
        shape = SuperShapes.Small,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, SuperColors.Border, SuperShapes.Small)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(visual.soft, SuperShapes.Small),
                contentAlignment = Alignment.Center
            ) {
                Icon(visual.icon, contentDescription = null, tint = visual.accent, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(4.dp))
            Text(
                destination.title,
                color = SuperColors.Text,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.3.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun shortcutVisual(destination: HomeDestination): ShortcutVisual = when (destination) {
    HomeDestination.PROGRESS -> ShortcutVisual(Icons.Outlined.Timeline, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.NETWORK -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.GreenSoft)
    HomeDestination.ACADEMY -> ShortcutVisual(Icons.Outlined.School, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.MY_WEEK -> ShortcutVisual(Icons.Outlined.CalendarMonth, SuperColors.Purple, SuperColors.PurpleSoft)
    HomeDestination.ACTIONS -> ShortcutVisual(Icons.Outlined.TaskAlt, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.CUSTOMERS -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Orange, SuperColors.OrangeSoft)
    HomeDestination.LEADER_CENTER -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Gold, SuperColors.GoldSoft)
    HomeDestination.GOALS -> ShortcutVisual(Icons.Outlined.TrackChanges, SuperColors.Red, SuperColors.RedSoft)
    HomeDestination.RANK_REWARDS -> ShortcutVisual(Icons.Outlined.EmojiEvents, SuperColors.Gold, SuperColors.GoldSoft)
    HomeDestination.EVENTS -> ShortcutVisual(Icons.Outlined.Event, SuperColors.Red, SuperColors.RedSoft)
    HomeDestination.LIBRARY -> ShortcutVisual(Icons.Outlined.MenuBook, SuperColors.Purple, SuperColors.PurpleSoft)
    HomeDestination.SALES -> ShortcutVisual(Icons.Outlined.ShoppingCart, SuperColors.Green, SuperColors.GreenSoft)
    HomeDestination.REPORTS -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.PERSONAL_STORE -> ShortcutVisual(Icons.Outlined.Storefront, SuperColors.Orange, SuperColors.OrangeSoft)
    HomeDestination.PROFILE -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.SETTINGS -> ShortcutVisual(Icons.Outlined.Settings, SuperColors.TextSecondary, SuperColors.NeutralSoft)
    HomeDestination.SEARCH -> ShortcutVisual(Icons.Outlined.Search, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.NOTIFICATIONS -> ShortcutVisual(Icons.Outlined.NotificationsNone, SuperColors.Red, SuperColors.RedSoft)
    HomeDestination.FOCUS -> ShortcutVisual(Icons.Outlined.Timer, SuperColors.Purple, SuperColors.PurpleSoft)
    HomeDestination.TREE -> ShortcutVisual(Icons.Outlined.AccountTree, SuperColors.Green, SuperColors.GreenSoft)
    HomeDestination.PROFILE_360 -> ShortcutVisual(Icons.Outlined.Person, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.GROUPS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Orange, SuperColors.OrangeSoft)
    HomeDestination.CHANNELS -> ShortcutVisual(Icons.Outlined.ChatBubbleOutline, SuperColors.Purple, SuperColors.PurpleSoft)
    HomeDestination.TEAM_MEMBERS -> ShortcutVisual(Icons.Outlined.Groups, SuperColors.Green, SuperColors.GreenSoft)
    HomeDestination.DREAM_BOARD -> ShortcutVisual(Icons.Outlined.Flag, SuperColors.Gold, SuperColors.GoldSoft)
    HomeDestination.ACHIEVEMENTS -> ShortcutVisual(Icons.Outlined.WorkspacePremium, SuperColors.Gold, SuperColors.GoldSoft)
    HomeDestination.LEADERBOARD -> ShortcutVisual(Icons.Outlined.Assessment, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.REWARD_STORE -> ShortcutVisual(Icons.Outlined.CardGiftcard, SuperColors.Orange, SuperColors.OrangeSoft)
    HomeDestination.WEBSITE -> ShortcutVisual(Icons.Outlined.Language, SuperColors.Blue, SuperColors.BlueSoft)
    HomeDestination.ORDERS -> ShortcutVisual(Icons.Outlined.ReceiptLong, SuperColors.Green, SuperColors.GreenSoft)
}
